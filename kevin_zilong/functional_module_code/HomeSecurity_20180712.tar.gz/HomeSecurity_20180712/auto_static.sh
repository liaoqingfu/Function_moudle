#!/bin/sh
export STAGING_DIR=/opt/staging_dir
rm lib/libxm_av.so
make clean
make
cp ./sdk_demo /home/ryan/share
sync
