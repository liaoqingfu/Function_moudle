/*
 ============================================================================
 Name        : xm_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-18 
 Description :
 ============================================================================
 */

#ifndef zx_XM_INTERFACE_H
#define zx_XM_INTERFACE_H

#include "base.h"
#include <errno.h>
#include <pthread.h>
#include "sys_interface.h"

#define CONF_PATH                   "/mnt/DataDisk/"  	//固定值(参数保存区)

#define TFCARD_RD_FLAG  255
#define FRAME_TYPE_I    1

#define XM_AUDIO_MAX_QUEUE  150   // 队列大小 150 * 320*2  96K
#define XM_VIDEO_MAX_QUEUE  90    // 队列大小 90 * 60*1000 5.4M，(可存6秒)

typedef enum
{
	CAMERA_CLOSED = 0x00,
	CAMERA_CLOSEING = 0x01, //关闭中，防止一个正在关闭时又来PIR 打开
}ZX_CAMERA_ST;      // 每个占1bit

typedef struct xm_camera_info
{
	short	channel;
	short	clientmark;		// 有多个容户端可打开/关闭 camera,投票
}XM_CAMERA_INFO;


#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

int zx_init_camera_sdk(int print_type, void *list);
int zx_deinit_camera_sdk(void);
int zx_open_camera(int channel, short clientmark);
int zx_close_camera(int channel);
int zx_match_dev(int ip_addr,char* pMacAddr,int MacLen);
int zx_set_log_print_type(int print_type);
int zx_send_command(int command_type, char *command_data, int channel);
int get_camera_clientmark(short channel);
int zx_update_xmdsp(int channel, char* pfilePath, int firmwaretype);
int zx_get_dev_version(int channel, char* sw_ver, char *hw_ver);
int zx_wait_channel_ready(int channel, int timeout, int type);
int zx_get__snapshot_img(int channel, int width, int height);

#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_PPCS_INTERFACE_H */
