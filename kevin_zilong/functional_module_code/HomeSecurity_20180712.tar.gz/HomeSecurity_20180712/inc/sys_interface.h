/*
 ============================================================================
 Name        : sys_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-18 
 Description :
 ============================================================================
 */

#ifndef zx_SYS_INTERFACE_H
#define zx_SYS_INTERFACE_H

#include "base.h"
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <semaphore.h>

//#include "iwlib.h"
//#include "ocean.h"
//#include "smsgs_proto.h"
//#include "appclient.h"


#define GPIO_DEV               "/dev/gpio"
#define	WIFI_DEVICE		       "ra0"
#define SSID                   "SSID1"
#define WPAPSK                 "WPAPSK1"
#define LOG_CONF               "/etc/zx_log.conf"

#define SDCARD_DEV             "/mnt/sdcard/"

#define MAC_LEN_BYTE           (6)   //MAC BYTE长度
#define MAC_STR_LEN            (18)  //MAC字符串长度  11:22:33:44:55:AB
#define AES128Key_SIZE         (20)  //AES 128秘钥长度
#define POST_SER_STR_SIZE      (600) //最大推送消息长度
#define PUSH_QUERY_SER_LIST    (256) //PUSH查询服务器码
#define FILENAMEMAX            (64)  /* 文件名长度 /media/mmcblk0p1/Camera01/20180425112401.dat = 45*/

//#undef DEVICE_SN_LEN
#define DEVICE_SN_LEN          (16)  //设备SN长度
#define HIGH_PRIORITY          (90)  //高优先级
#define MID_PRIORITY           (85)  //中优先级
#define LOW_PRIORITY           (80)  //低优先级
//#define MAX_SUB1G_CONNECT      (50)   //允许连接的最大设备数
#define MAX_SUB1G_CONNECT      (1)    //允许连接的最大设备数
#define MAX_THREAD_COUNT       (32)   //允许建立的最大线程数

#define WIFI_ADDR_START_INDEX  (5)    //摄像头分配的IP开始值 192.168.32.5
#define WIFI_ADDR_END_INDEX    (250)  //ip地址结束值  192.168.32.250
#define WIFI_ADDR_BASE         "192.168.32."  //IP地址段
#define ZX_HUB_IP              "192.168.32.2" //基站IP地址

#define THREAD_EXIT            (9999)


#define TIMER_OTA_EVERY_DAY    (86400)    //864000 OTA定时器 秒
#define TIMER_ETH_DETCTION     (10)        //300   网络检测定时器 秒
#define TIMER_WATCH_DOG        (120)      //120    踢狗定时器 秒
#define TIMER_LAN_BROADCAST    (500)      //300    局域网广播定时器 毫秒

#define THREAD_STACK_SIZE      (20480)

#define PARAM_VER              (16777220) //0000 0001 0000 0000 0000 0000 0000 0001
#define PROGRAM_VER            (16777217) //0000 0001 0000 0000 0000 0000 0000 0001

#define RUN_P2P_SERVER         1   //是否打开P2P服务
#define RUN_PUSH_STREAM        1   //是否打开推流服务
#define RUN_LOCAL_STORGE       1   //是否打开本地存储服务
#define RUN_AI_MODULE          0   //是否打开AI服务
#define RUN_XMSDK_NORMAL       0   
#define FOR_HARD_TEST          0   //硬件测试相关
#define GET_WIFI_SIGNAL        0   //获取wifi信号强度

#define USE_DOMAIN_NAME        0   //用域名连接P2P服务器
#define ZX_UPGRADE_EN          1
#define ZX_RSA_EN              1

//#define MAX_CAMERA_NUM         16  //最大可连接摄像头数
#define MAX_CAMERA_NUM         1  //最大可连接摄像头数


#define SCHEDULE_SIZE          (852)  //单个设备计划任务最大字节数 768到852

#define TF_INSERT              35   //TF卡插入事件
#define TF_REMOVE              36   //TF卡拔掉事件
#define TF_INSERT_MOUNT        37   //TF卡加载成功事件
#define TF_REMOVE_UMOUNT       38   //TF卡卸载成功事件
#define TF_INSERT_FORMAT       39   //TF卡插入,但需要格式化(非原厂等)
#define TF_FORMAT_FAIL         40   //TF卡挂载失败或格式化失败
#define TF_FORMAT_BUSY         41   //TF卡在写入


#define CAM_1310_BIN_PATH      "/mnt/sdcard/sensor_cc1310lp_with_crc.bin"
#define CAM_3518_BIN_PATH      "/mnt/sdcard/haiyi_wifi_imx323_1080P.bin"
#define CAM_3518_BIN_PATH_720  "/mnt/sdcard/haiyi_wifi_ov9732_720P.bin"
#define CAM_3518_ROOTFS        "/mnt/sdcard/rootfs_hy.bin"
#define CAM_3518_UBOOT        "/mnt/sdcard/3518_uboot.bin"

//#define HOME_SEC_PID_PATH      "/var/run/home_sec.pid" //PID文件路径
#define HOME_SEC_PID_PATH      "/mnt/sdcard/home_sec.pid" //PID文件路径


#define LOG_FILE               "/mnt/sdcard/test.log"
#define LOG_FILE_BZ2           "/mnt/sdcard/test.log.bz2"

#define KEY_GPIO_NUM		   11   //GPIO 11 KEY 按键事件


#pragma pack(1)

typedef enum __GPIO_DIR
{
    GPIO_DIR_OUT    = 0,
    GPIO_DIR_IN     = 1,
}GPIO_DIR;

typedef enum thread_type
{
    THREAD_TEST = 0,
    WATCH_DOG  = 1,      //看门狗
    TEST_CASE,           //测试线程
    OTA_SERVER,          //OTA升级
    NET_DET,             //网络检测
    LAN_BROADCAST,       //局域网探测 用于广播账户绑定信息
    P2P_COMMAND_READ,    //P2P命令通道读取  0
    P2P_MEDIA_READ,      //P2P媒体通道读取  1
    P2P_LISTEN,          //P2P监听
    AUDIO_PLAY,          //声音播放
    RECORD_SEND,         //历史记录回传
    DISK_MANAGER,        //本地存储管理
    RECORD_TO_MP4,       //历史记录转MP4下载
    TFCARD_WRITE,        //TF卡写(存储)
    SCHEDULE_CHECK,      //布防检测
    P2P_MEDIA_WRITE,     //P2P媒体通道发送  2
    STREAM_SEND,         //流媒体
    AI_RECV,             //AI接收
	STRESS_TEST,         //压力测试

    PUSH_INFO = 100,     //消息推送 (以下线程使用消息队列)
    SUB1G_RECV,          //SUB1G接收
    PARAM_WRITE,         //配置信息写入flash
    P2P_NOTIFY_WRITE,    //P2P通知消息
    LOG_UPLOAD,          //log上传
}THREAD_TYPE;

typedef enum zx_devtype
{
    ZX_HUB      =0x00,
    XM_CAMERA   =0x01,  // 大类
    DOOR_SENSOR,
    FLOODLIGHT,

    SUB1G_MODULE =0x20,// 小类
    AI_MODULE,
    PUSHMUXER,
}ZX_DEVTYPE;

typedef enum zx_push_info_type
{
    PUSH_SECURITY_EVT = 0x01, // msgsnd() 的msg_type不能是0
    PUSH_TFCARD_EVT,
    PUSH_DOOR_SENSOR_EVT,
}ZX_PUSH_TYPE;

typedef enum zx_tfcard_status
{
    TFCARD_NORMAL,       // 工作正常
    TFCARD_NON_ORIGINAL, // 非原厂配置，需要格式化
    TFCARD_MOUNT_FAIL,   // 挂载失败
    TFCARD_FORMAT_FAIL,  // 格式化失败
    TFCARD_REMOVE,       // TFCARD移除
    TFCARD_BUSY,         // TFCARD忙,稍后再试
}ZX_TFCARD_STATUS;

typedef enum flash_param_type
{
	HAVE_BIND_ACCOUNT,   //已经绑定账户
	UNBIND_ACCOUNT,      //基站解除绑定账户
	SET_HUB_NAME,        //设置基站名称
	SET_HUB_TIMETONE,    //设置基站时区
	HUB_BIND_DEV,        //基站绑定设备
	SET_DEV_NAME,        //设置设备名称
	SET_DEV_PARAM,       //设置设备参数
	SET_HUB_PARAM,       //设置设备参数
    
}FLASH_PARAM_TYPE;

typedef struct thread_info
{
	pthread_t    thread_id;          //线程ID
    int          msg_index;          //信息队列索引号
    int          msg_id;             //消息队列ID
	int          session_handle;     //P2P连接号
    short        thread_type;        //线程类型
}THREAD_INFO;

typedef struct dev_base_param
{
//	AppclientDeviceDescriptor sub1g_info;       //16      SUB1G连接信息 painid、addr、long addr 
    char dev_mac[SMALL_STR_LEN];                //16      设备mac地址
	char dev_ipaddr[SMALL_STR_LEN];             //16      设备IP地址
	char dev_sn[SHORT_STR_LEN];                 //32      设备SN
	char dev_software_main_ver[SMALL_STR_LEN];  //16      设备主系统软件版本号
	char dev_hardware_main_ver[SMALL_STR_LEN];  //16      设备主系统硬件版本号
	char dev_software_sec_ver[SMALL_STR_LEN];   //16      设备辅助系统软件版本号
	char dev_hardware_sec_ver[SMALL_STR_LEN];   //16      设备辅助系统硬件版本号
    char dev_schedule[SCHEDULE_SIZE];           //852     设备计划任务
	char dev_name[SHORT_STR_LEN];               //32      设备名称
    char channle_id;                            //1       XM SDK通道号
	unsigned char dev_type;                     //1       设备类型
	unsigned char dev_online_states;            //1       设备在线状态
	unsigned char dev_electric_quantity;        //1       设备电量
    char          dev_sub1g_rssi;               //1       设备SUB1G信号强度
    char          dev_wifi_rssi;                //1       设备wifi信号强度
    unsigned char dev_gsession_status;          //1       设备g-sensor状态
	unsigned char dev_gsession_sensitivity;     //1       设备重力加速度传感器灵敏度
    unsigned char dev_pir_status;               //1       设备PIR状态  
    unsigned char dev_pir_sensitivity;          //1       设备PIR灵敏度
    unsigned char dev_move_det_status;          //1       设备移动侦测状态
    unsigned char dev_move_det_sensitivity;     //1       设备移动侦测灵敏度
    unsigned char dev_ir_cut_status;            //1       设备IR-CUT状态
    unsigned char dev_night_vision_mode;        //1       设备红外灯模式
    unsigned char dev_light_status;             //1       设备红外灯状态	
    unsigned char dev_voice_det_status;         //1       设备声音侦测状态
    unsigned char dev_voice_det_sensitivity;    //1       设备声音侦测灵敏度
    unsigned char dev_video_mirr_mode;          //1       摄像头视频翻转状态
    unsigned char dev_osd_mode;                 //1       摄像头OSD模式
	unsigned char dev_led_status;				//1    	  摄像头led状态   
    unsigned char dev_mic_status;               //1		  mic状态
    unsigned char dev_mic_volume;               //1		  mic音量
    unsigned char dev_speaker_status;           //1	      speaker状态
	unsigned char dev_speaker_volume;           //1       speaker音量
    unsigned char dev_camera_status;            //1       摄像头状态
    unsigned char dev_siren_status;             //1
    unsigned char dev_siren_volume;             //1
    unsigned char dev_video_frame_rate;         //1       摄像头帧率
    unsigned char dev_video_iframe_interval;    //1       摄像头I帧间隔
	unsigned short dev_video_bitrate;           //2       视频码流 kbps/s    
    unsigned short dev_video_width;             //2       视频宽度
    unsigned short dev_video_height;            //2       视频长度
 // ------------------------------------------------------以下为 dev_reserve 长度 NORMAL_STR_LEN
    unsigned char  update_status;               //1       设备升级状态 20180308新增
    unsigned char  dev_storage_type;            //1       是否开通云存储 20180317新增, 由后台推送
    time_t         storage_cycle;               //4       云存储的生命周期，20180426废弃(由后台推送)
    unsigned char  pri_action;                  //1       PRI 触发后的4种动作(录像和生音)，20180426新增
    unsigned char dev_door_sensor_led_switch;
    unsigned char dev_door_sensor_is_battery_low;
    unsigned char dev_door_sensor_state;
    unsigned char dev_door_sensor_alarm_enable;
    unsigned char dev_door_sensor_current_battery_vol;//*100mV
    char dev_reserve[NORMAL_STR_LEN-96];  				// 91]; // = 121B   保留字段用于扩展 schedule新增72字节 852-768
	
}DEV_BASE_PARAM;


typedef struct p2p_base_info
{
	char p2p_uid[SHORT_STR_LEN];               //32       P2P UID
	char p2p_initstr[NORMAL_STR_LEN];          //128      P2P初始化连接串
	char p2p_license[SMALL_STR_LEN];           //16       P2P授权码
	char push_license[LICENSE_STR_LEN];          //8       PUSH授权码
	char NDT_license[LICENSE_STR_LEN];          //8       NDT授权码
	char push_aes128_key[AES128Key_SIZE];      //20       PUSH秘钥
	char push_encdec_key[AES128Key_SIZE];      //20       PUSH明文
	char push_utct_string[SMALL_STR_LEN];      //16        
	char push_query_ser_list[PUSH_QUERY_SER_LIST];  //256   PUSH查询服务器码
	char push_post_server_string[POST_SER_STR_SIZE]; //600  
}P2P_BASE_INFO;

typedef struct hub_base_info
{
	int  version;                               //4       配置版本号
	int  wifi_channel;                          //4       hub wifi信道
	char have_bind_app;                         //1       是否已经绑定APP
	char hub_software_main_ver[SMALL_STR_LEN];  //16      HUB 7628软件版本号
	char hub_hardware_main_ver[SMALL_STR_LEN];  //16      HUB硬件版本号
	char hub_software_sec_ver[SMALL_STR_LEN];   //16      SUB1G 1310 软件版本号
	char hub_hardware_sec_ver[SMALL_STR_LEN];   //16      SUB1G硬件版本号
	char hub_wlan_ip_addr[SHORT_STR_LEN];       //16      公网IP地址
	char account_id[NORMAL_STR_LEN];            //32      绑定账户
	char hub_name[SHORT_STR_LEN];               //32      HUB名称
	char time_tone[SHORT_STR_LEN];              //16      HUB时区  
	char hub_sn[SHORT_STR_LEN];                 //32	  基站SN
	unsigned char gsession_status;              //1       g-sensor总状态
	unsigned char pir_status;                   //1       PIR总状态
	unsigned char move_det_status;              //1       移动侦测总状态
	unsigned char ir_cut_status;                //1       IR-CUT总状态  
	unsigned char voice_det_status;             //1       音频侦测总状态  
	unsigned char storage_type;                 //1       是否开通云存储
	unsigned short record_time_out;             //2       单次录像时长
	unsigned char ai_status;                    //1       AI检测开关  
	unsigned char update_status;                //1       基站升级状态  20180307 新增
	unsigned char spk_volume;                   //1       机站音量(0~26) 20180605 新增
	unsigned char rsa_pub_id;                   //1       RSA_pub_id 20180605 新增
	char rsa_pubkey_n[256+1];                   //257     20180605 新增
	unsigned char upload_log;                   //1       20180608 新增是否上传log
	char  hub_reserve[LONG_STR_LEN-261];		//512-260=251 保留字段用于扩展
}HUB_BASE_INFO;


typedef struct hub_base_param
{
	P2P_BASE_INFO p2p_info;                     //        P2P连接配置信息	
	HUB_BASE_INFO hub_info;                     //        基站配置信息 	
	DEV_BASE_PARAM dev_param[MAX_SUB1G_CONNECT];  //672*64	设备配置及连接信息
	
}HUB_BASE_PARAM;

typedef struct wifi_con_info
{
	short channel;
    char hub_wifi_mac[MAC_LEN_BYTE];         //18
	char hub_wifi_ssid[SMALL_STR_LEN];      //16
	char hub_wifi_pwd[SMALL_STR_LEN];       //16
}WIFI_INFO;

typedef struct zx_param_data
{
	long int msg_type;
	int param_type;
}ZX_PARAM_DATA;

typedef enum
{
    HUB_CRASH  = 1, // 死机
    LOG_NORMAL,     // 普通
    AI_CRASH,       // AI死机
}ZX_LOG_TYPE;

typedef struct zx_log_param
{
    long  int msg_type;        // log类型, 死机还是普通log, must be > 0
    int devtype;               // 设备类型
    const char* sn;            // 设备SN
    const char* level;         // log等级
    const char* module;        // 子模块
    const char* key_prefix;    // App出错配对log
    const char* err_str;       // 错误码
    long  reserve;
}ZX_LOG_PARAM;

#define		MSG_ID_UPGRADE_7628					0x2A	
#define		MSG_UPGRADE_MAGIC_NUM_LEN_MAX		18
#define		MSG_UPGRADE_FILE_PATH_LEN_MAX		128

#define		MSG_MAGIC_NUM						"wifi_upgrade_magic"
// for test only.
#define		MSG_IMAGE_FULL_PATH	                "/mnt/sdcard/7628_emmc.img"

#define		SYSTEM_PARTION_SIZE_MAX				0xe00000 // 14MB

typedef	struct __MSG_WIFI_ROUTER_UPGRADE_INFO{
	char  	magic_num [ MSG_UPGRADE_MAGIC_NUM_LEN_MAX + 2 ];   // default is "wifi_upgrade_magic"  len is 18
	char  	image_path[ MSG_UPGRADE_FILE_PATH_LEN_MAX + 4 ];	
	size_t	file_size; // check file whether is big than the partion.	
}MSG_WIFI_ROUTER_UPGRADE_INFO, *lpMSG_WIFI_ROUTER_UPGRADE_INFO;


#ifdef __cplusplus
extern "C"
{
#endif

zx_Uint64 zx_Tm_LocalTime(void);
int get_current_channel(void);
int zx_eth_state_get(void);

int get_wifi_info(WIFI_INFO *info);
int zx_init_sys_interface(THREAD_INFO *thread_info, HUB_BASE_PARAM *base_param);

int zx_set_thread_info(int channel, int thread_type, pthread_t thread_id, int session_handle);
THREAD_INFO *zx_get_thread_list(void);
int zx_get_msgid_by_session_type(int session, int thread_type);

int zx_get_tid_by_type(int type, int tid);
int zx_get_msgid_by_type(int type);

int zx_clear_thread_info_by_msgid(int msgid);
int zx_clear_thread_info_by_sessionid(int session_id); 
int zx_create_thread(int priority, void *(*function)(void*), void *arg, int channel, int thread_type, int session_handle);

int zx_set_timetone(char *timetone);
char *zx_get_hub_ipaddr(char *ifname);

int write_base_param(HUB_BASE_PARAM *param);
int write_config_param(int param_type);
int read_base_param(HUB_BASE_PARAM *param);
int clean_base_param(void);

int zx_create_dir(const char *path);

int zx_get_program_version(void);



//获取系统版本号
int zx_get_system_soft_version(char *version);

int zx_update_dev_version(char *main_sw_version, char *sec_sw_version, char *hw_version, int channel);
int zx_hub_ota_process(void *version, const char *new_main_ver, const char *cur_main_ver);
int zx_check_process_runing(const char *process_name);

char zx_reg_gpio_int(int gpio_num);
int zx_write_pid_file(void);
void zx_set_stack_limits(unsigned int limits);
void zx_do_system(char *fmt, ...);
int zx_clear_thread_info_by_type(int type);
char zx_gpio_dir( int gpio_num, GPIO_DIR dir );
char zx_gpio_set_value( int gpio_num, int set_value );
char zx_gpio_get_value( int gpio_num );
int zx_ver_cmp(const char *new_ver, const char *cur_ver); //版本格式 *.*.*

int upload_log_param(int log_type, int devtype,
                         const char* sn,
                         const char* level,
                         const char* module,
                         const char* key_prefix,
                         const char* err_str);
void zx_upload_crash_log(const char* path_file, ZX_LOG_PARAM * log);
void zx_upload_test_log(ZX_LOG_PARAM * log);

void *log_upload_thread(void *argv);

#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_PPCS_INTERFACE_H */
