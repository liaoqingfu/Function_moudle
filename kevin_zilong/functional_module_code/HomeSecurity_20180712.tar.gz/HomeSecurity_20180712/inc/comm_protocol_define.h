/*
 ============================================================================
 Name        : comm_protocol_define.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-20 
 Description :
 ============================================================================
 */

#ifndef _P2P_COMM_DEFINE_H
#define _P2P_COMM_DEFINE_H

#include "base.h"
#include "sys_interface.h"

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

#define TRY_COUNT          (3)
#define RANDOMSIZE         (4)

#define ERR_INFO_LEN       (128)

#define FLOODLIGHT_WIFI_LIST_LEN       (4096)

#define NORMAL_PARAM_LEN   (256)
#define BORADCAST_PORT     (57603)
#define COMM_HEARD_LEN     (16)

#define PAG_HEARD_TAG      (0x48595A58)
#define SUB1G_ADDR_LEN_L   (8)
#define SUB1G_ADDR_LEN_S   (4)
#define MAC_BYTE_LEN       (6)

#define P2P_COMMAND_CHANNEL  (0)
#define P2P_MEDIA_CHANNEL    (1)
#define P2P_NOTIFY_CHANNEL   (2)
#define P2P_DOWNLOAD_CHANNEL (3)
#define MAX_CAMERA_CHANNEL_ID  (15)    //最大摄像头通道数
//#define MAX_CAMERA_NUM       (MAX_CAMERA_CHANNEL_ID+1)
#define MAX_DEV_CONNECT      (50)       //系统支持的设备数(CAMERA和其它可接入的智能设备)
//#define MAX_CONNECT_NUM      (8)        // P2P最大连接数
#define MAX_CONNECT_NUM      (3)        // P2P最大连接数

#define HUB_SELF             (1000)

#define VIDEO_FRAME_SIZE   (64*1000)

//#define AUDIO_FRAME_SIZE   (320*2+1)
#define AUDIO_FRAME_SIZE   (160*2+1)


#define SEC_CAMERA_NAME    "Camera"
#define SEC_DOORSENSOR_NAME "DoorSensor"
#define MAX_FILE_NAME      (256)
#define MSG_PROCESS_EXIT   (1500)

#define FRAME_RATE         (15)
#define FRAME_RATE_720     (25)
#define H264_GOP_INTERVAL  (30)

#define SUB1G_EXTADDR_LEN  (20)
#define MAX_BATCH_DEL_NUM  (50)


typedef enum
{
	APP_CMD_START_REC_BROADCASE = 900,   //开始接收基站广播
	APP_CMD_STOP_REC_BROADCASE,          //停止接收基站广播
	APP_CMD_FLBIND_BROADCAST,			 //floodlight 广播命令
	APP_CMD_BIND_BROADCAST = 1000,       //1000基站配对广播	
	APP_CMD_BIND_SYNC_ACCOUNT_INFO,      //1001 APP同步账户信息
	APP_CMD_UNBIND_ACCOUNT,              //1002 APP解除账户绑定信息
	APP_CMD_START_REALTIME_MEDIA,   	 //1003 APP 查看实时视频
	APP_CMD_STOP_REALTIME_MEDIA, 		 //1004 APP 停止查看实时视频
	APP_CMD_START_TALKBACK,				 //1005 APP开始对讲
	APP_CMD_STOP_TALKBACK,				 //1006停止对讲
	APP_CMD_START_VOICECALL,			 //1007开始语音通话
	APP_CMD_STOP_VOICECALL,				 //1008停止语音通话
	APP_CMD_START_RECORD,                //1009开始录像
	APP_CMD_STOP_RECORD,                 //1010停止录像
	APP_CMD_PIR_SWITCH,                  //1011红外告警开关
	APP_CMD_CLOSE_PIR,                   //1012关闭红外告警
	APP_CMD_IRCUT_SWITCH,                //1013夜视开关
	APP_CMD_CLOSE_IRCUT,                 //1014关闭夜视
	APP_CMD_EAS_SWITCH,                  //1015防盗开关
	APP_CMD_CLOSE_EAS,                   //1016关闭防盗
	APP_CMD_AUDDEC_SWITCH,               //1017音频侦测开关
	APP_CMD_CLOSE_AUDDEC,                //1018关闭音频侦测
	APP_CMD_DEVS_LOCK_SWITCH,            //1019设备锁定
	APP_CMD_DEVS_UNLOCK,                 //1020设备解锁
	APP_CMD_RECORD_IMG,				     //1021获取录像缩略图 
	APP_CMD_RECORD_IMG_STOP,			 //1022停止获取缩略图
	APP_CMD_STOP_SHARE,                  //1023视频共享
	APP_CMD_DOWNLOAD_VIDEO,              //1024视频下载
	APP_CMD_RECORD_VIEW,                 //1025录像回放
	APP_CMD_RECORD_PLAY_CTRL,			 //1026回放控制
	APP_CMD_DELLETE_RECORD,              //1027录像删除
	APP_CMD_SNAPSHOT,				     //1028抓图
	APP_CMD_FORMAT_SD,                   //1029格式化基站SD卡
	APP_CMD_CHANGE_PWD,                  //1030修改管理员密码
	APP_CMD_CHANGE_WIFI_PWD,             //1031修改wifi密码
	APP_CMD_WIFI_CONFIG,				 //1032切换上级路由器
	APP_CMD_TIME_SYCN,					 //1033时间同步
	APP_CMD_HUB_REBOOT,			         //1034重启基站
	APP_CMD_DEVS_REBOOT,			     //1035重启设备
	APP_CMD_HUB_TO_FACTORY,		         //1036基站恢复出厂
	APP_CMD_DEVS_TO_FACTORY,             //1037设备恢复出厂设置
	APP_CMD_DEVS_BIND_BROADCASE,		 //1038设备绑定广播
	APP_CMD_DEVS_BIND_NOTIFY,            //1039设备绑定通知
	APP_CMD_DEVS_UNBIND,                 //1040设备解除绑定
	APP_CMD_RECORDDATE_SEARCH, 		     //1041搜索存在录像的日期
	APP_CMD_RECORDLIST_SEARCH,			 //1042搜索指定日期的录像 
	APP_CMD_UPDATE,                      //1043版本更新
	APP_CMD_P2P_DISCONNECT,              //1044断开P2P连接
	APP_CMD_DEV_LED_SWITCH,              //1045打开设备指示灯	
	APP_CMD_CLOSE_DEV_LED,               //1046关闭设备指示灯
	APP_CMD_COLLECT_RECORD,              //1047记录收藏操作
	APP_CMD_DECOLLECT_RECORD,            //1048取消记录收藏
	APP_CMD_BATCH_RECORD,                //1049批量删除记录
	APP_CMD_STRESS_TEST_OPER,            //1050压力测试
	APP_CMD_DOWNLOAD_CANCEL,             //1051视频下载取消

	APP_CMD_GATEWAYINFO=1100,			 //1100获取基站信息
	APP_CMD_GET_BATTERY,				 //1101获取电池电量
	APP_CMD_SDINFO,                      //1102获取SD卡信息
	APP_CMD_CAMERA_INFO,				 //1103获取摄像机信息
	APP_CMD_GET_RECORD_TIME,			 //1104获取录像时长
	APP_CMD_GET_MDETECT_PARAM,		     //1105获取移动侦测参数
	APP_CMD_MDETECTINFO,				 //1106获取移动侦测状态
	APP_CMD_GET_ARMING_INFO,			 //1107获取布防撤防配置信息
	APP_CMD_GET_ARMING_STATUS,			 //1108获取设备布防撤防状态
	APP_CMD_GET_AUDDEC_INFO,             //1109获取音频侦测参数
	APP_CMD_GET_AUDDEC_SENSITIVITY,      //1110获取音频侦测灵敏度
	APP_CMD_GET_AUDDE_CSTATUS,           //1111获取音频侦测状态
	APP_CMD_GET_MIRRORMODE,			     //1112获取视频翻转状态
	APP_CMD_GET_IRMODE,				     //1113获取夜视模式
	APP_CMD_GET_IRCUTSENSITIVITY,        //1114获取IRCUT光感门限
	APP_CMD_GET_PIRINFO,                 //1115获取PIR配置参数
	APP_CMD_GET_PIRCTRL,				 //1116获取PIR状态
	APP_CMD_GET_PIRSENSITIVITY,			 //1117获取PIR灵敏度
	APP_CMD_GET_EAS_STATUS,              //1118获取防盗状态
	APP_CMD_GET_CAMERA_LOCK,			 //1119获取摄像机锁定状态
	APP_CMD_GET_GATEWAY_LOCK,			 //1120获取网关锁定状态
	APP_CMD_GET_UPDATE_STATUS,			 //1121获取升级状态
	APP_CMD_GET_ADMIN_PWD,               //1122获取管理员密码
	APP_CMD_GET_WIFI_PWD,                //1123获取wifi密码
	APP_CMD_GET_EXCEPTION_LOG,           //1124获取异常日志
	APP_CMD_GET_NEWVESION,			     //1125获取新版本
	APP_CMD_GET_HUB_TONE_INFO,           //1126获取基站提示音配置
	APP_CMD_GET_DEV_TONE_INFO,           //1127获取设备提示音配置
	APP_CMD_GET_HUB_NAME,                //1128获取基站名称
	APP_CMD_GET_DEVS_NAME,               //1129获取设备名称
	APP_CMD_GET_P2P_CONN_STATUS,         //1130获取P2P连接状态
	APP_CMD_GET_DEV_STATUS,              //1131获取设备状态  0：离线  1：在线
    APP_CMD_GET_HUB_LOG,                 //1132获取HUB log

	APP_CMD_GET_FLOODLIGHT_WIFI_LIST = 1199,    //获取当前wifi列表

	APP_CMD_SET_LANGUAGE=1200,			 //1200设置语言
	APP_CMD_SET_TONE_FILE,               //1201设置基站提示音
	APP_CMD_SET_DEVS_TONE_FILE,          //1202设置设备提示音
	APP_CMD_SET_RECORDTIME,			     //1203设置录像时长(全局)
	APP_CMD_SET_MDETECTPARAM,			 //1204设置移动侦测配置
	APP_CMD_SET_RESOLUTION,			     //1205设置视频分辨率
	APP_CMD_SET_BITRATE,				 //1206设置码率
	APP_CMD_SET_MIRRORMODE,			     //1207设置视频翻转
	APP_CMD_SET_IRMODE,				     //1208设置夜视模式
	APP_CMD_SET_PIR_INFO,                //1209设置PIR配置
	APP_CMD_SET_PIRSENSITIVITY,			 //1210设置PIR灵敏度  0-255
	APP_CMD_SET_ARMING_SCHEDULE,	     //1211设置布防撤防配置
	APP_CMD_SET_AUDDEC_INFO,			 //1212设置音频侦测配置
	APP_CMD_SET_AUDDEC_SENSITIVITY,      //1213设置音频侦测门限
	APP_CMD_SET_DEVS_OSD,                //1214设置设备OSD
	APP_CMD_SET_TIMEZONE,                //1215设置基站时区
	APP_CMD_SET_HUB_NAME,                //1216设置基站名称
	APP_CMD_SET_DEVS_NAME,               //1217设置设备名称
	APP_CMD_SET_HUB_PIR_STATUS,          //1218设置基站PIR总状态
	APP_CMD_SET_HUB_IRCUT_STATUS,        //1219设置基站IRCUT总开关
	APP_CMD_SET_HUB_GS_STATUS,           //1220设置基站防盗总开关
	APP_CMD_SET_HUB_MVDEC_STATUS,        //1221设置基站运动侦测总开关
	APP_CMD_SET_HUB_AUDEC_STATUS,        //1222设置基站音频侦测总开关
	APP_CMD_SET_STORGE_TYPE,             //1223设置存储类型	
	APP_CMD_SET_ARMING,                  //1224摄像头布防	
	APP_CMD_SET_DISARMING,               //1225摄像头撤防	
	APP_CMD_SET_GSSENSITIVITY,			 //1226设置GS灵敏度	 0-127
	APP_CMD_SET_AUDIOSENSITIVITY,	     //1227设置音频侦测灵敏度		
	APP_CMD_SET_DEV_STORAGE_TYPE,        //1228设置设备的存储类型
	APP_CMD_SET_DEV_MIC_VOLUME,          //1229设置设备的麦克增益
	APP_CMD_SET_DEV_SPEAKER_VOLUME,      //1230设置设备的喇叭音量
	APP_CMD_SET_AI_PHOTO,                //1231设置AI识别的头像
	APP_CMD_DEL_USER_PHOTO,              //1232按USER_ID删除AI用户的头像
	APP_CMD_SET_PRI_ACTION,              //1233PRI触发后的行为
	APP_CMD_DEL_FACE_PHOTO,              //1234按FACE_ID删除AI用户的头像
	APP_CMD_SET_HUB_SPK_VOLUME,          //1235设置HUB的喇叭音量
	APP_CMD_SET_AI_SWITCH,               //1236设置是否打开AI检测

	APP_CMD_SET_FLOODLIGHT_wifi_INFO = 1298,	//设置floodlight的wifi信息
	APP_CMD_SET_FLOODLIGHT_LED_SWTICH = 1299,	//设置floodlight灯的开关

	APP_CMD_VIDEO_FRAME = 1300,          //1300视频帧传输
	APP_CMD_AUDIO_FRAME,                 //1301音频帧传输
	APP_CMD_STREAM_MSG,                  //1302流媒体
	APP_CMD_CONVERT_MP4_OK,              //1303转换成MP4完成
    APP_CMD_DOENLOAD_FINISH,             //1304MP4下载完成
    XM_SNAPSHOT_FRAME,                   //1305缩略图

    APP_CMD_DOOR_SENSOR_MIN = 1500,
	APP_CMD_DOOR_SENSOR_INFO_REPORT = 1500,
    APP_CMD_DOOR_SENSOR_GET_INFO,
    APP_CMD_DOOR_SENSOR_GET_DOOR_STATE,
    APP_CMD_DOOR_SENSOR_DOOR_EVT,
    APP_CMD_DOOR_SENSOR_LOW_POWER_REPORT,
    APP_CMD_DOOR_SENSOR_ENABLE_LED,
    APP_CMD_DOOR_SENSOR_ALARM_ENABLE,

	APP_CMD_ENTRY_SENSOR_STATUS = 1550,//door state,0 = close,1 = open
	APP_CMD_ENTRY_SENSOR_CHANGE_TIME = 1551,// seconds after 1970.1.1
	APP_CMD_ENTRY_SENSOR_BAT_STATE = 1552,//0 = OK,1 = low power
	

	APP_CMD_DOOR_SENSOR_MAX = 1600,
}APP_CMD_CODE;


typedef enum
{
	SUB1G_CMD_BIND  =  2000,	        //设备发起配对请求
	SUB1G_CMD_BIND_SUCESS,	            //设备确认配对成功
	SUB1G_CMD_WAKEUP,                   //基站唤醒设备      (0:出视频流     1:用于设置不出视频 2:新版本通知)
	SUB1G_CMD_SLEEP,                    //基站请求设备休眠
	SUB1G_CMD_CHECK_STATUS,			    //基站检查设备状态
	SUB1G_CMD_GET_VOLTAGE,				//获取电池电量
	SUB1G_CMD_GET_RSSI,			        //获取SUB1G信号强度
	SUB1G_CMD_OPEN_PIR,				    //打开PIR
	SUB1G_CMD_CLOSE_PIR,			    //关闭PIR
	SUB1G_CMD_SET_PIR_SENSITIVITY,      //设置PIR灵密度
	SUB1G_CMD_OPEN_GSENSOR,			    //打开GSENSOR
	SUB1G_CMD_CLOSE_GSENSOR,			//关闭GSENSOR
	SUB1G_CMD_SET_GSENSOR_SENSITIVITY,  //设置GSENSOR灵密度
	SUB1G_CMD_UPDATE_WIFI_INFO,         //基站更新设备wifi信息
	SUB1G_CMD_GET_VERSION,              //获取设备版本号
	SUB1G_CMD_OPEN_AUDIO_DEC,           //打开音频侦测
	SUB1G_CMD_CLOSE_AUDIO_DEC,          //关闭音频侦测
	SUB1G_CMD_OPEN_LED,                 //打开指示灯
	SUB1G_CMD_CLOSE_LED,                //关闭指示灯
	SUB1G_CMD_OPEN_LIGHT_DEC,           //打开光感
	SUB1G_CMD_CLOSE_LIGHT_DEC,          //关闭光感
    SUB1G_CMD_AUDIO_LOOPTEST,           //麦克、喇叭回环测试
    SUB1G_CMD_OPEN_WIFI,                //打开WIFI
	SUB1G_CMD_CLOSE_WIFI,               //关闭WIFI
	SUB1G_CMD_WIFI_TXTEST,              //WIFI发射功率测试
	SUB1G_CMD_WIFI_RXTEST,              //WIFI接收灵敏度测试
	SUB1G_CMD_OPER_IRCUT,               //IRCUT操作
	SUB1G_CMD_WRITE_SN,                 //写设备SN
	SUB1G_CMD_READ_SN,                  //读设备SN
	SUB1G_CMD_WRITE_MAC,                //写设备MAC
	SUB1G_CMD_READ_MAC,                 //读设备MAC
	SUB1G_CMD_SWITCH_SERIAL,            //USB口切换3518串口
	SUB1G_CMD_SET_LIGHT_SENSITIVITY,    //设置光感灵敏度
	SUB1G_CMD_SET_IRLED_POWER,          //设置红外灯亮度
	SUB1G_CMD_DISASSOC_DEV,             //设备解除配对
	SUB1G_CMD_GET_DEV_COUNT,            //获取连接设备数
	SUB1G_CMD_GET_MT_VERSION,           //获取网关版本号
	SUB1G_CMD_ACTIVE_DEV = 2037,         //摄像头激活
    SUB1G_CMD_RESTORE_FACTORY_MODE,     //恢复出厂设置
	SUB1G_CMD_ENTER_AGING_TEST = 2039,    //摄像头进入老化模式
    SUB1G_CMD_GET_3518_VERSION = 2040,  //获取3518E版本号

	SUB1G_CMD_GET_BAT_TEMP = 2041,      //获取电池温度
    SUB1G_CMD_GET_ACTIVE_STATE = 2042,   //获取摄像头激活状态
    SUB1G_CMD_SET_MIC_STATE = 2043,      //打开/关闭麦克
    SUB1G_CMD_SET_SPEAKER_STATE = 2044,  //打开/关闭喇叭
	SUB1G_CMD_SET_LED_STATE = 2045,      //设置指示灯是否闪烁
    SUB1G_CMD_CHECK_WATCHDOG = 2046,  //检查看门狗是否正常


	SUB1G_CMD_GET_WIFI_SIGNAL = 2080,   //获取wifi信号强度
	SUB1G_CMD_GET_SUB1G_SIGNAL = 2081,   //获取SUB1G信号强度

	SUB1G_REP_LOWPOWER  =  2100,        //SUB1G上报低电警告
	SUB1G_REP_GSENSOR,                  //SUB1G上GSENSOR警告
	SUB1G_REP_PIR,                      //SUB1G上PIR警告
	SUB1G_REP_CAMERA_DIED,              //SUB1G上报Camera死机
	SUB1G_REP_AUDIO_DEC,                //SUB1G上报声音侦测事件
	SUB1G_REP_LIGHT_DEC,                //SUB1G上报光感事件
	SUB1G_REP_KEY,                      //SUB1G上报按键事件
	SUB1G_REP_RUNTIME_STATE=2107,       //摄像头上报运行状态参数
	SUB1G_REP_CHARGE_STATE,             //充电状态上报

    /*for door sensor*/
    SUB1G_DOOR_SENSOR_CMD_ID_MIN = 2200,
    SUB1G_DOOR_SENSOR_DEVICE_INFO_REPORT = 2200,
    SUB1G_DOOR_SENSOR_GET_INFO ,
    SUB1G_DOOR_SENSOR_EVT_REPORT, //for sensor reporting door open or close event
    SUB1G_DOOR_SENSOR_GET_STATE, //for hub to get door state
    SUB1G_DOOR_SENSOR_BAT_VOL_REPORT,
    SUB1G_DOOR_SENSOR_ENABLE_LED,//for hub to close led blink if user closed
    SUB1G_DOOR_SENSOR_CONNECTION_CHECK,

    SUB1G_DOOR_SENSOR_BUTTON_TEST = 2250,//for factory test button
    SUB1G_DOOR_SENSOR_LED_TEST,  //for factory test white/red LED

	SUB1G_DOOR_SENSOR_CMD_ID_MAX = 2300,
    /*for door sensor end*/
}SUB1G_CMD_CODE;

typedef enum
{
	MEDIA_AUDIO = 1, //音频
	MEDIA_VIDEO,
}QUEUE_MEDIA_TYPE;

typedef enum
{
	AUDIO_PIPE = 1, //音频
	VIDEO_PIPE,
    SUB1G_PIPE
}PIPE_TYPE;

typedef enum
{
	VIDEO_HIGH_QUALITY = 1, //1080P 2Mbps
    VIDEO_MID_QUALITY,      //1080P 1.2Mbps
    VIDEO_LOW_QUALITY,      //720P 600kbps
}VIDEO_QUALITY;

typedef enum
{
	LOCAL_STORGE = 0x01,    //本地存储
	CLOUD_STORGE = 0x02,    //云存储
	LOACL_AND_CLOUD,        //本地存储+云存储
}STORGE_TYPE;

typedef enum
{
	VIDEO_2M = 1200,     //1080P 1.2Mbps
    VIDEO_1_5M = 800,   //720P 0.8Mbps
    VIDEO_600k = 500,    //720P 500kbps
}VIDEO_BITRATE;


typedef enum
{
	WAKEUP_WITH_VIDEO = 0,    //唤醒并获取音视频数据
    WAKEUP_NO_WIFI_VIDEO,     //唤醒但不获取音视频数据、不连接wifi用于设置参数
    WAKEUP_WITH_WIFI,         //唤醒连接wifi不获取音视频，用于版本升级
}DEV_WAKEUP_TYPE;


typedef enum
{
    CLIENT_NULL = 0x00, //无
    CLIENT_P2P  = 0x01, //点对点的应用
    CLIENT_PIR  = 0x02, //PIR
    CLIENT_PUSH = 0x04, //流媒体推送
    CLIENT_CMD  = 0x08, //cmd line
    CLIENT_OTA  = 0x10, //OTA update
}ZX_CLIENT_TYPE;      // 每个占1bit


typedef enum
{
	RELEASE_ALL = 1,              //清除所有通道
	RELEASE_SINGLE_CHANNEL,       //清除指定通道
}ZX_RELEASE_CHANNEL;              //清除讯美SDK通道信息


typedef enum{
	SWITCH_CLOSE = 0,    						//(0)关闭
	SWITCH_OPEN  = 1						//(1)开启	
}SWITCH_STATUS;


// device bind the base station 
typedef struct param_one_string 
{
	unsigned char      value[NORMAL_STR_LEN]; 	
} PARAM_ONE_STRING;

typedef struct param_session_file
{
	int   session_id;
	char  filename[NORMAL_STR_LEN];
} PARAM_SESSION_FILE;


typedef enum
{
	SCHEDULE_EVERYDAY = 1,  //每天
    SCHEDULE_WORKDAY,       //工作日
	SCHEDULE_ONLYONE,       //仅一次
}SCHEDULE_TYPE; 

typedef struct loop_schedule
{
	unsigned char tm_weekday; //0-6 0:星期日  
	unsigned char start_h;
	unsigned char start_m;
	unsigned char end_h;
	unsigned char end_m;
	unsigned char action;
}LOOP_SCHEDULE;


typedef struct once_schedule
{
	unsigned char start_yy;
	unsigned char start_mm;
	unsigned char start_dd;
	unsigned char start_h;
	unsigned char start_m;
	unsigned char end_yy;
	unsigned char end_mm;
	unsigned char end_dd;
	unsigned char end_h;
	unsigned char end_m;
	unsigned char action;
}ONCE_SCHEDULE;

typedef struct bs_once_schedule
{
    time_t        start_time;
    time_t        end_time;
    unsigned char action;
}BS_ONCE_SCHEDULE;      // 在某时间段做什么

#define LOOP_SCH_COUNT     (15*7)  //105*5=525
#define ONCE_SCH_COUNT     (20)    //20*10=200
#define APP_SCHEDULE_SIZE  (2048)

typedef struct dev_schedule
{
	unsigned char loop_sch_count;
    unsigned char once_sch_count;
    unsigned char defult_action;    // SCHEDULE时间段之外的默认动作
    LOOP_SCHEDULE loop_sch[LOOP_SCH_COUNT];
    ONCE_SCHEDULE once_sch[ONCE_SCH_COUNT];
}DEV_SCHEDULE;

typedef struct param_set_scheduled 
{	
	unsigned short     channel;
	DEV_SCHEDULE       schedule; 
	char               account[NORMAL_STR_LEN];	
	char               app_schedule[APP_SCHEDULE_SIZE];
} PARAM_SCHEDULED;

typedef struct rsa_pub_info
{
    unsigned int   channel; // 兼容以前下发的int channel
    unsigned char  nkey[NORMAL_PARAM_LEN+1]; //1024bit=256
}RSA_PUB_INFO;

typedef struct record_info
{
    unsigned int record_id;
    char         file_path[NORMAL_STR_LEN]; 
}RECORD_INFO;

typedef struct record_batch_del 
{	
	unsigned short     record_count;
	char               account[NORMAL_STR_LEN];	
	RECORD_INFO        record_list[MAX_BATCH_DEL_NUM]; 
} REC_BATCH_DEL;

typedef struct param_set_param 
{
	unsigned short     ivalue;
	unsigned short     ivalue1;
	unsigned char      channel;
	char               value[NORMAL_STR_LEN]; 
	char               account[NORMAL_STR_LEN];	
} PARAM_SET_PARAM;

typedef struct param_set_param_ex
{
	unsigned int     ivalue;
	unsigned int     ivalue1;
	unsigned char    channel;
	char             value[NORMAL_STR_LEN]; 
	char             account[NORMAL_STR_LEN];	
} PARAM_SET_PARAM_EX;


typedef struct param_one_int 
{
	unsigned int    value; 
} PARAM_ONE_INT;

typedef struct param_one_int_set 
{
	unsigned int    value; 
	char            account[NORMAL_STR_LEN];		
} PARAM_ONE_INT_SET;

typedef struct param_two_int 
{
	unsigned int    value; 
	unsigned int    value1; 	
} PARAM_TWO_INT;

typedef struct param_two_int_set 
{
	unsigned int    value; 
	unsigned int    value1; 	
	char              account[NORMAL_STR_LEN];	
} PARAM_TWO_INT_SET;

typedef struct param_app_bind 
{	
	char sn[DEVICE_SN_LEN+1];
	char ip_addr[DEVICE_SN_LEN];
	unsigned int port;
} PARAM_APP_BIND;

typedef struct param_app_bind_account 
{
	char sn[DEVICE_SN_LEN+1];	
	char account[NORMAL_STR_LEN];
	char hub_name[SHORT_STR_LEN];
	char time_tone[SHORT_STR_LEN];
} PARAM_APP_BIND_ACCOUNT;

typedef struct exec_result 
{
	int            error_code;
    char           error_info[ERR_INFO_LEN];
} EXEC_RESULT;


typedef struct floodlight_wifi_list
{
	unsigned int    data_len;
    char           	wifi_data[FLOODLIGHT_WIFI_LIST_LEN];
} FLOODLIGHT_WIFI_LIST;



typedef enum 
{
    NO_SEC_KEY = 0,      //不需要加密
    SEC_RSAKEY = 1,      //RSA和AES加密,实时视频
    SEC_KEYVER = 2,      //RSA和AES加密,录像的加密版本
}P2P_SIGN_CODE;


typedef enum
{
	AUTH_OPEN  = 0,
    AUTH_WEP,
    AUTH_WPAWPA2,
}WIFI_AUTH_TYPE;

/*******SUB1G STRUCT*********/
//摄像头发起的绑定请求
typedef struct sub1g_dev_bind
{
	unsigned int dev_addr_code;                       //摄像头SUB1G地址码 8
	char         dev_sn[SUB1G_EXTADDR_LEN];             //摄像头SN号  20
	char         dev_mac[MAC_BYTE_LEN];            //摄像头mac  6
}SUB1G_DEV_BIND;

//基站向摄像头发起的控制参数
typedef struct sub1g_dev_control
{
	unsigned char value;
}SUB1G_DEV_CONTROL;

//基站向摄像头发起的控制扩展参数
typedef struct sub1g_dev_control_ex
{
	unsigned char value;
	unsigned char value1;
}SUB1G_DEV_CONTROL_EX;

//摄像头激活
typedef struct sub1g_set_aging_test_param
{
	char           wifi_ssid[SMALL_STR_LEN];       //hub wifi ssid 16 
	char           wifi_pwd[SMALL_STR_LEN];        //hub wifi pwd  16 
    char           batch_num[OTHER_STR_LEN];       //生产批次号     20
	char           dev_model[SHORT_STR_LEN];       //设备型号       32
}SUB1G_AGINGTEST_PARAM;


//设置亮度
typedef struct sub1g_set_light_sensitivity
{
    unsigned short value;
}SUB1G_LIGHT_SENSITIVITY;


typedef struct sub1g_light_report
{
	unsigned int dev_addr_code;
	unsigned int r_value;
	unsigned int g_value;
	unsigned int b_value;
	unsigned int ir_value;
}SUB1G_LIGHT_REPORT;


typedef struct sub1g_gsensor_report
{
	unsigned int dev_addr_code;
	unsigned short x_value;
	unsigned short y_value;
	unsigned short z_value;
}SUB1G_GSENSOR_REPORT;

typedef struct sub1g_dev_control_rep
{
	unsigned int dev_addr_code;
	char value;
}SUB1G_DEV_CONTROL_REP;


//wifi 工厂测试
typedef struct sub1g_wifi_control
{
	unsigned char       channel;
	unsigned char       type;
	char                temp[SMALL_STR_LEN];
}SUB1G_DEV_WIFI_CONTROL;

//设置的字符串参数
typedef struct param_sub1g_param 
{
	char value[SUB1G_EXTADDR_LEN];	
} SUB1G_SET_STR_PARAM;

//摄像头绑定成功后基站向摄像头的响应
typedef struct sub1g_dev_bind_sucess
{
	unsigned int dev_addr_code;                       //摄像头SUB1G地址码 8
	char         dev_ip_addr[SMALL_STR_LEN];          //摄像头IP 
}SUB1G_DEV_BIND_OK;

//摄像头充电状态上报
typedef struct sub1g_dev_charge_state
{
	unsigned int    dev_addr_code;                       //摄像头SUB1G地址码 8
	char            charge_type;                         //充电状态 1：快充  2：普通充电 0：未充电
    unsigned char   electric_quantity;                   //电池点亮  百分比
}SUB1G_DEV_CHARGE_STATE;


//摄像头运行状态上报
typedef struct sub1g_dev_runtime_state
{
	unsigned int    dev_addr_code;                       //摄像头SUB1G地址码 8
	unsigned char   ircut_state;                         //ircut状态 1：打开  0：关闭
	unsigned char   irled_state;                         //红外灯状态 0：关闭 1：自动 2：打开
	unsigned char   pir_state;                           //pir状态 1：打开  0：关闭                    
	unsigned char   gsensor_state;                       //gsensor状态 1：打开  0：关闭
	unsigned char   rled_state;                          //红色指示灯状态 1：打开  0：关闭
	unsigned char   wled_state;                          //白色指示灯状态 1：打开  0：关闭
	unsigned char   charge_state;                        //充电状态 1：快充  2：普通充电 0：未充电      
	unsigned char   key_state;                           //按键状态 1：按下  0：未按下
	unsigned char   speaker_state;                       //喇叭状态 1：打开  0：关闭
    unsigned char   mic_state;                           //麦克状态 1：打开  0：关闭
    unsigned char   electric_quantity;                   //电池点亮  百分比
	unsigned char   temp[8];                             //备用字段
}SUB1G_DEV_RUNTIME_STATE;


//wifi基本信息
typedef struct sub1g_hub_wifi_info
{
	short        channel;                            //wifi channel
	char         hub_wifi_mac[MAC_BYTE_LEN];         //hub wifi mac 
	char         hub_wifi_ssid[SMALL_STR_LEN];       //hub wifi ssid
	char         hub_wifi_pwd[SMALL_STR_LEN];        //hub wifi pwd	
    char         dev_ip_addr[SMALL_STR_LEN];         //dev ip 
//	char         hub_ip_addr[SMALL_STR_LEN];         //hub ip 
	char         auth_type; 
}SUB1G_HUB_WIFI_INFO;

//获取版本号的回应
typedef struct sub1g_dev_version
{
	unsigned int   dev_addr_code;      //摄像头SUB1G地址码
	char           version[SUB1G_EXTADDR_LEN];        //sub1g版本号
}SUB1G_DEV_VERSION;


//获取版本号的回应
typedef struct sub1g_dev_version_ex
{
	unsigned int   dev_addr_code;      //摄像头SUB1G地址码
	char           s_version[SMALL_STR_LEN];   //3518软件版本号  16字节
	char           h_version[SMALL_STR_LEN];   //3518硬件版本号  16字节
}SUB1G_DEV_VERSION_EX;


/*added by dennis for door sensor msg between hub and app*/
typedef struct door_sensor_device_info
{
    char dev_software_main_ver[SMALL_STR_LEN]; 
    char dev_hardware_main_ver[SMALL_STR_LEN];
    char dev_mac[SMALL_STR_LEN];
    char dev_sn[SHORT_STR_LEN];
    unsigned char led_switch;//to check whether LED blink is enabled when door open/close
    unsigned char doorState;
    unsigned char isBatteryLow;// 1 battery low,0 battery ok
}DOOR_SENSOR_DEVICE_INFO;

/*******SUB1G COMMAND END********/

/*added by dennis for door sensor msg*/

typedef enum eMediaType
{
	AV_STREAM_NONE,
	AV_STREAM_START,
	AV_STREAM_VIDEO,
	AV_STREAM_AUDIO,
	AV_STREAM_STOP,
	AV_STREAM_ADD,
	AV_STREAM_DEL,
}eMediaType;



typedef struct video_info
{
    int         frame_size;
//  int         stream_type;
    int         frame_type;
    short       frame_rate;
    short       width;
    short       height;
//  int         channel;
//  long        reserve;
    long long   ntimestamp;
    char        buf[VIDEO_FRAME_SIZE];
}VIDEO_FRAME;

#define VIDEO_ENCRYPT_SIZE  (VIDEO_FRAME_SIZE+16)
#define VIDEO_HEAD_SIZE     (22)
typedef struct video_encrypt
{
    int         frame_size;
    int         frame_type;
    short       frame_rate;
    short       width;
    short       height;
    long long   ntimestamp;
    char        aes_key[NORMAL_STR_LEN+1];    //RSA加密后长度128B
    char        buf[VIDEO_ENCRYPT_SIZE];      //加密后数据可能变长,最长增加16字节
}VIDEO_ENCRYPT;

typedef struct audio_info
{
	int           frame_size;
    int           channel;
    //long        reserve;
	long long     ntimestamp;
    char          buf[AUDIO_FRAME_SIZE];
}AUDIO_FRAME;

typedef struct zx_stream_msg
{	
    unsigned char   stream_type;				//流媒体类型
    unsigned char 	channel;					//通道号
	char	        fileName[MAX_FILE_NAME];	//流媒体文件名
}ZX_STREAN_MSG;


typedef struct notify_dev_info
{
	unsigned char   channle_id;
    char            dev_sn[SHORT_STR_LEN];
    char            dev_name[SMALL_STR_LEN];
    unsigned char   dev_type;
}NOTIFY_DEV_INFO;


typedef struct playback_control_param
{
    unsigned char       control_type;     //回放控制类型 1、暂停；2、停止、3、拖放
    unsigned int        fram_num;          //要开始播放的frame
}PLAYBACK_CONTROL_PARAM;

#define JPG_BUF_SIZE  (100*1000)
typedef struct ai_info_ 
{
    unsigned int    user_id;  // 0:新用户; 非0:已存在的用户
    unsigned int    group_id; // 用户组
    unsigned int    face_id;  //人脸ID, 0:新用户; 非0:编辑用户信息
    unsigned int    image_size;
    float           face_point[21*2];
    char            nick_name[16];
    char            notify;     // 这个图片的人是否发送通知信息    
    char            image_buf[JPG_BUF_SIZE];
} AI_INFO;


typedef struct ai_image_info 
{
    char            account[NORMAL_STR_LEN];    
    AI_INFO         ai_info;
} AI_IMAGE_INFO;


#define COMM_VERSION  1 // 当前通信协议

/*for door sensor added by dennis.yang*/
typedef struct sub1g_door_sensor_info
{
    char hw_version[16];
    char sw_version[16];
    unsigned char macAddr[8];
    unsigned char sn[16];
    unsigned char led_switch;//to check whether LED blink is enabled when door open/close
    unsigned char doorState;
    unsigned char batteryVol;//  * 100mV
}SUB1G_DOOR_SENSOR_INFO;


typedef struct msg_sub1g_door_sensor_device_info_report
{
    SUB1G_DOOR_SENSOR_INFO doorSensorInfo;
}MSG_SUB1G_DOOR_SENSOR_DEVICE_INFO_REPORT;

typedef struct msg_sub1g_door_sensor_get_info_req
{
    
}MSG_SUB1G_DOOR_SENSOR_GET_INFO_REQ;

typedef struct msg_sub1g_door_sensor_get_info_resp
{
    SUB1G_DOOR_SENSOR_INFO doorSensorInfo;
}MSG_SUB1G_DOOR_SENSOR_GET_INFO_RESP;

typedef struct msg_sub1g_door_sensor_evt_report
{
    unsigned char evt;//0=close,1=open
}MSG_SUB1G_DOOR_SENSOR_EVT_REPORT;

typedef struct msg_sub1g_door_sensor_evt_resp
{

}MSG_SUB1G_DOOR_SENSOR_EVT_RESP;

typedef struct msg_sub1g_door_sensor_get_door_state_req
{

}MSG_SUB1G_DOOR_SENSOR_GET_DOOR_STATE_REQ;

typedef struct msg_sub1g_door_sensor_get_door_state_resp
{
    unsigned char state;//0=close,1=open
}MSG_SUB1G_DOOR_SENSOR_GET_DOOR_STATE_RESP;

typedef struct msg_sub1g_door_sensor_bat_vol_report
{
    unsigned char batVol;//  * 100mV
}MSG_SUB1G_DOOR_SENSOR_BAT_VOL_REPORT;

typedef struct msg_sub1g_door_sensor_low_power_resp
{

}MSG_SUB1G_DOOR_SENSOR_LOW_POWER_RESP;


typedef struct msg_sub1g_door_sensor_enable_led_req
{
    unsigned char enable;
}MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_REQ;

typedef struct msg_sub1g_door_sensor_enable_led_resp
{

}MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_RESP;




typedef struct msg_sub1g_door_sensor_button_test_report
{

}MSG_SUB1G_DOOR_SENSOR_BUTTON_TEST_REPORT;


typedef struct msg_sub1g_door_sensor_led_test_req
{
    unsigned char led;//0 = red,1 = white
    unsigned char state;//0 = off,1 = on
}MSG_SUB1G_DOOR_SENSOR_LED_TEST_REQ;

/*for door sensor added by dennis.yang end*/


typedef struct zx_communication_head 
{
    unsigned int    head_tag;                   //消息头
    unsigned short  command_id;                 //命令字
    unsigned int    param_len;                  //命令参数长度
    unsigned char   version;                    //通信协议版本
    unsigned char   ir_mode;                    //Camera工作模式,AI使用
    unsigned char   channel_id;                 //对于挂靠在基站的设备指的设备编号
    unsigned char   sign_code;                  //标识码
    unsigned char   is_response;                //是否是应答
    unsigned char   dev_type;                   //设备类型
}ZX_COMM_HEAD;

typedef struct zx_communication_packet 
{
	ZX_COMM_HEAD             msg_head;
	union 
	{
		EXEC_RESULT          result_info;          //执行结果信息
		PARAM_APP_BIND       app_bind;
		PARAM_ONE_STRING     dev_bind;             //device bind struct
     	//PARAM_DEV_LOGIN      dev_login;             //device login struct
		PARAM_APP_BIND_ACCOUNT  bind_account;
		PARAM_ONE_INT        one_int_param;
		PARAM_TWO_INT        two_int_param;
		PARAM_SCHEDULED      scheduled;
		PARAM_ONE_STRING     one_string_param;
		PARAM_SET_PARAM      set_param;
		SUB1G_DEV_BIND       sub1g_bind;
		SUB1G_HUB_WIFI_INFO  wifi_info;
		SUB1G_DEV_BIND_OK    sub1g_bink_ok;
		//VIDEO_FRAME          video;
        //AUDIO_FRAME          audio;	
		SUB1G_DEV_CONTROL    sub1g_dev_ctl;	
		SUB1G_DEV_CONTROL_REP sub1g_ctl_rep;
		SUB1G_DEV_VERSION    dev_version;
		NOTIFY_DEV_INFO      dev_base_info;
		ZX_STREAN_MSG        stream_msg;
		SUB1G_DEV_WIFI_CONTROL wifi_ctl;
		SUB1G_SET_STR_PARAM  sub1g_str_param;
		DEV_SCHEDULE         dev_schedule;
		PLAYBACK_CONTROL_PARAM palyback_ctrl;
		SUB1G_LIGHT_SENSITIVITY light_sensitivity;
		SUB1G_LIGHT_REPORT      light_report;
		SUB1G_GSENSOR_REPORT    gsensor_report;

		/*for door sensor added by dennis.yang*/
        DOOR_SENSOR_DEVICE_INFO device_info_report;
		MSG_SUB1G_DOOR_SENSOR_GET_INFO_RESP get_device_info_resp;
		MSG_SUB1G_DOOR_SENSOR_EVT_REPORT door_sensor_evt;
		MSG_SUB1G_DOOR_SENSOR_GET_DOOR_STATE_RESP get_door_state_resp;
		MSG_SUB1G_DOOR_SENSOR_BAT_VOL_REPORT low_power_report;
		MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_REQ enable_led_req;
		MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_RESP enable_led_resp;
		FLOODLIGHT_WIFI_LIST	floodlight_wifi_list;
    }param_body;
} ZX_COMMUNICATION_PACKET;



typedef struct zxxm_communication_head 
{
	unsigned int    head_tag;	                //消息头
	unsigned short  command_id;                 //命令字
	unsigned short  param_len;                  //命令参数长度
	unsigned short  random;	                    //随机数（>=1000）
	unsigned char   channel_id;                 //对于挂靠在基站的设备指的
												//是设备编号，对于自联网的设备无意义
	unsigned char   sign_code;	                //标识码
	unsigned char   is_response;                //是否是应答
    unsigned char   dev_type;                   //设备类型
}ZXXM_COMM_HEAD;

typedef struct zxxm_communication_packet 
{
	ZXXM_COMM_HEAD             msg_head;
	union 
	{
		EXEC_RESULT          result_info;          //执行结果信息
		PARAM_APP_BIND       app_bind;
		PARAM_ONE_STRING     dev_bind;             //device bind struct
		PARAM_APP_BIND_ACCOUNT  bind_account;
		PARAM_ONE_INT        one_int_param;
		PARAM_TWO_INT        two_int_param;
		PARAM_ONE_STRING     one_string_param;
		PARAM_SET_PARAM      set_param;
		SUB1G_DEV_BIND       sub1g_bind;
		SUB1G_HUB_WIFI_INFO  wifi_info;
		SUB1G_DEV_BIND_OK    sub1g_bink_ok;
		SUB1G_DEV_CONTROL    sub1g_dev_ctl;	
		SUB1G_DEV_CONTROL_REP sub1g_ctl_rep;
		SUB1G_DEV_VERSION    dev_version;
		NOTIFY_DEV_INFO      dev_base_info;
		SUB1G_DEV_WIFI_CONTROL wifi_ctl;
		SUB1G_SET_STR_PARAM  sub1g_str_param;
		SUB1G_LIGHT_SENSITIVITY light_sensitivity;
		SUB1G_LIGHT_REPORT      light_report;
		SUB1G_GSENSOR_REPORT    gsensor_report;
		SUB1G_AGINGTEST_PARAM   aging_test;
		SUB1G_DEV_VERSION_EX    ver_3518;
		SUB1G_DEV_CHARGE_STATE  charge_state;
		SUB1G_DEV_RUNTIME_STATE runtime_state;
		
		/*for door sensor added by dennis.yang*/
        MSG_SUB1G_DOOR_SENSOR_DEVICE_INFO_REPORT device_info_report;
		MSG_SUB1G_DOOR_SENSOR_GET_INFO_RESP get_device_info_resp;
		MSG_SUB1G_DOOR_SENSOR_EVT_REPORT door_sensor_evt;
		MSG_SUB1G_DOOR_SENSOR_GET_DOOR_STATE_RESP get_door_state_resp;
		MSG_SUB1G_DOOR_SENSOR_BAT_VOL_REPORT bat_vol_report;
		MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_REQ enable_led_req;
		MSG_SUB1G_DOOR_SENSOR_ENABLE_LED_RESP enable_led_resp;
		MSG_SUB1G_DOOR_SENSOR_BUTTON_TEST_REPORT button_test_report;
		MSG_SUB1G_DOOR_SENSOR_LED_TEST_REQ ledTest;
		/*for door sensor added by dennis.yang end*/
    }param_body;
} ZXXM_COMMUNICATION_PACKET;


typedef struct zx_msg_data
{
	long int msg_type;
	ZX_COMMUNICATION_PACKET comm_data;
}ZX_MAG_DATA;

typedef struct zxxm_msg_data
{
	long int msg_type;
	
#if 0
	AppclientDeviceDescriptor appClientDev;
#endif

	ZXXM_COMMUNICATION_PACKET comm_data;
}ZXXM_MAG_DATA;


#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* _P2P_COMM_DEFINE_H */




