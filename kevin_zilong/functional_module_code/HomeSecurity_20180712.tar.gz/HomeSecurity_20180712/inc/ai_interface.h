/*============================================================================
 Name        : ai_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-12-05
 Description :
 ============================================================================*/

#include "base.h"
#include "comm_protocol_define.h"


#ifndef zx_AI_INTERFACE_H
#define zx_AI_INTERFACE_H

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

#define TCP_SERVER_PORT     10051

#define AI_CMD_PING                     0x10
#define AI_CMD_GET_VISION               0x11
#define AI_CMD_SET_WORKMODE             0x12
#define AI_CMD_START                    0x13
#define AI_CMD_TRANSFORH264             0x14

#define AI_CMD_UPDATA_FIRMWARE_OTA      0x15
#define AI_CMD_UPDATA_FIRMWARE_DATA     0x16
#define AI_CMD_UPDATA_FIRMWARE_START    0x17

#define AI_CMD_PLAYER_PCM_PARA          0x18
#define AI_CMD_PLAYER_PCM_TRAN          0x19
#define AI_CMD_PLAYER_PCM_STOP          0x1a

#define AI_CMD_REBOOOT                  0x1b
#define AI_CMD_SET_SN                   0x1c
#define AI_CMD_GET_SN                   0x1d

#define AI_CMD_SND_TEST       0x00

#define AI_REPLY_PING         0x80
#define AI_REPLY_VERSION      0x81
#define AI_REPLY_MODE         0x82
#define AI_REPLY_START        0x83
#define AI_REPLY_H264FRAME    0x84

#define AI_REPLY_FW_PREPARE   0x85
#define AI_REPLY_FW_DATA      0x86
#define AI_REPLY_FW_UPDATE    0x87

#define AI_REPLY_AUDIO_OPEN   0x88
#define AI_REPLY_AUDIO_DATA   0x89
#define AI_REPLY_AUDIO_CLOSE  0x8a

#define AI_REPLY_REBOOT       0x8b
#define AI_REPLY_SET_SN       0x8c
#define AI_REPLY_GET_SN       0x8d

#define AI_REPLY_SND_TEST     0x70

#define AI_REPLY_FACE         0xa0  //人脸识别结果
#define AI_REPLY_BODY         0xa1  //人形识别结果
#define AI_REPLY_FACETRACK    0xa2  //人脸跟踪

#define PING_REPLY "readsense server reply ping."


#define HEAD_MAGIC "READSENSE"
#define MAGIC_SIZE (sizeof(HEAD_MAGIC) - 1)

#define AI_INDEX_SIZE         sizeof(unsigned int)
#define AI_DATA_SIZE          (100 * 1024)
#define AI_BUFSIZE            (AI_INDEX_SIZE + AI_DATA_SIZE)

typedef enum {
    MODE_FACE_BODY_RECOGNITION = 0, //人脸身体识别
    MODE_FACE_TRACK,                //人脸跟踪

    MODE_FACE_RECOGNITION = 10,     //人脸识别
    MODE_BODY_DETECTION,            //人形识别

    MODE_MAX,
} eworkmode;

typedef struct ai_ping_status{
    unsigned char ping_status[35];      //AI返回ping包确认值
} AI_PING_STATUS;

typedef struct ai_version{
    char kernelversion[10];
    char rootfsversion[10];
    char algorversion[10];
} AI_VERION;

typedef struct ai_algorithm_control
{
    char  algor_id;
}AI_ALGORITHM_CONTROL;

typedef struct ai_rep_algor_status
{
    char rep_ok; //这里表成功失败
}AI_REP_ALGOR_STATUS;

typedef struct ai_rep_start_ok
{
    char rep_ok; //这里表成功失败
}AI_REP_START_OK;

typedef struct h264_rspacket{
    unsigned int frame_count;
    unsigned char buffer[AI_DATA_SIZE];    //数据
} H264_RSPACKET;

typedef struct ai_h264_rep_ok{
    unsigned int frame_num;      //帧计数
    unsigned char  rep_ok;       //确认是否正确接收到数据包
}AI_H264_REP_OK;

typedef struct ai_update_type
{
    unsigned char type;      //升级类型
}AI_UPDATE_TYPE;

typedef struct ai_updata_ok
{
    unsigned char  get_value;           //返回值
}AI_UPDATA_OK;

typedef struct ai_updata_fw_data
{
    unsigned int  pack_count;
    unsigned char buffer[AI_DATA_SIZE];    //数据
}AI_UPDATA_FW_DATA;

typedef struct ai_updata_data_ok
{
    unsigned int pack_num;      //传送包序号
    unsigned char get_value;     //返回状态
}AI_UPDATA_DATA_OK;

typedef struct ai_updata_md5_data
{
    unsigned char buffer_md5[16];   //数据
}AI_UPDATA_MD5_DATA;

typedef struct ai_updata_md5_ok
{
    unsigned char get_value;           //返回状态
}AI_UPDATA_MD5_OK;

typedef struct ai_pcm_para
{
    unsigned int  rate;           //
    unsigned char  bits;
    unsigned char  channels;
    unsigned char  volume;
}AI_PCM_PARA;

typedef struct ai_pcm_para_ok
{
    unsigned char  get_value;           //返回值
}AI_PCM_PARA_OK;

typedef struct ai_pcm_data
{
    unsigned char buffer[AI_BUFSIZE];      //数据
}AI_PCM_DATA;

typedef struct ai_pcm_data_ok
{
    unsigned char  get_value;           //返回值
}AI_PCM_DATA_OK;
typedef struct ai_pcm_over_ok
{
    unsigned char  get_value;           //返回值
}AI_PCM_OVER_OK;

typedef struct ai_set_module_sn
{
    unsigned char sn_num[16];      //sn号
}AI_SET_MODULE_SN;

typedef struct ai_set_sn_ok
{
    unsigned char  get_value;           //返回值
}AI_SET_SN_OK;

typedef struct ai_module_sn
{
    unsigned char sn_num[16];      //sn号
}AI_MODULE_SN;

#define FACE_RECOGNITION_FEATURE_DIMENSION 128

typedef struct tag_RS_FACE_RECOGNITION_RESULT
{
    int left;
    int top;
    int right;
    int bottom;

    float fr_feature[FACE_RECOGNITION_FEATURE_DIMENSION]; //128*4
} RS_FACE_RECOGNITION_RESULT;

typedef struct tag_RS_BODY_DETECTION_RESULT
{
    int left;
    int top;
    int right;
    int bottom;
} RS_BODY_DETECTION_RESULT;

typedef struct tag_RS_FACE_TRACKING_RESULT
{
    int index;

    int left;
    int top;
    int right;
    int bottom;

    float blur_prob;
    float front_prob;

    int fr_available_flag;
    float fr_feature[FACE_RECOGNITION_FEATURE_DIMENSION];
} RS_FACE_TRACKING_RESULT;

typedef struct {
    unsigned int index; //帧号
    int cnt;            //人脸数
    unsigned char data[AI_DATA_SIZE];
} RS_REP_ALGO_RESULT;


typedef struct {
    unsigned char  magic[MAGIC_SIZE];
    unsigned char  version;
    unsigned char  id;
    unsigned char  cmdtype;
    unsigned int   bodysize;
} packet_head;

#define HEADSIZE sizeof(packet_head)

typedef struct {
    packet_head head;
    union
    {
        AI_PING_STATUS ai_ping;
        AI_VERION ai_module_version;
        AI_ALGORITHM_CONTROL ai_algor_ctrl;
        AI_REP_ALGOR_STATUS ai_rep_algor;
        AI_REP_START_OK ai_start;
        H264_RSPACKET h264_pkt;
        AI_H264_REP_OK h264_result;
        RS_REP_ALGO_RESULT algor_result;
        AI_PCM_PARA ai_para;
        AI_PCM_PARA_OK ai_para_ok;
        AI_PCM_DATA ai_data;
        AI_PCM_DATA_OK ai_data_ok;
        AI_PCM_OVER_OK ai_over_ok;
        AI_SET_MODULE_SN ai_set_sn;
        AI_SET_SN_OK ai_sn_result;
        AI_MODULE_SN ai_get_sn;
        AI_UPDATE_TYPE ai_updata_type;
        AI_UPDATA_OK ai_updata_result;
        AI_UPDATA_FW_DATA ai_updata_data;
        AI_UPDATA_DATA_OK ai_updata_data_result;
        AI_UPDATA_MD5_DATA ai_md5_data;
        AI_UPDATA_MD5_OK ai_md5_result;
        unsigned char face_data[AI_BUFSIZE];
    }param_body;
} rspacket;


int zx_set_ai_workmode(char mode, char channel);
int send_packet_to_ai(unsigned char cmdtype, char channel, void *pdata);
int zx_init_ai_model(void);
int zx_deinit_ai_model(void);

#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_AI_INTERFACE_H */


