/*
 ============================================================================
 Name        : circular_buffer.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-15 
 Description :
 ============================================================================
 */

#ifndef _CIRCULAR_BUFFER_H
#define _CIRCULAR_BUFFER_H

#include "base.h"
#include "comm_protocol_define.h"

#pragma pack(1)

#define MAXVIDEOQUEUE     (15)
#define MAXAUDIOQUEUE     (25)

#define NOTUSE            (0)
#define ADDTOQUEUE        (1)
#define WAITFORCODEC      (2)
#define CODECING          (3)

#define VIDEO_BUF_SIZE    (32*1024)

typedef struct _tagQueue
{
	unsigned short   nUseFlag; 			//标记队列是否在用
	unsigned short   frame_size;		//大小
	char             *pFrameBuf;		//队列数据节点
	struct _tagQueue *pNextQueue;		//下一个
} QUEUE;

#ifdef __cplusplus
extern "C"
{
#endif

/*
创建队列，将队列构成链表回环
返回值：成功返回 队列链表指针，失败返回NULL
queue_num：创建队列的个数
buf_size：创建队列节点数据的大小
*/
QUEUE * create_queue(unsigned int queue_num, unsigned int buf_size);

/*
清除队列
返回值：无
pQueue：队列指针
queue_num：队列个数
*/
void clear_queue(QUEUE *pQueue,unsigned int queue_num);

//判断队列是否可用
zx_Bool query_queue(QUEUE *pQueue, QUEUE **ppQueue,int type, int queue_num);

//判断队列是否已经在用
zx_Bool query_use_queue(QUEUE *pQueue, QUEUE **ppQueue, int queue_num);

//销毁队列
void destroy_queue(QUEUE *pQueue);
	
#ifdef __cplusplus
};
#endif

#pragma pack()

#endif
