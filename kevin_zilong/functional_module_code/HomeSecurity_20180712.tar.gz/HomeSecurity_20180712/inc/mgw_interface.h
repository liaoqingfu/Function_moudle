/*============================================================================
 Name        : mgw_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-3-15 
 Description : 
 ============================================================================*/


#include "http.h"
#include "cjson.h"
#include "zlog.h"
#include "cloud_storage_interface.h"
#include "push_stream.h"

 

#ifndef zx_MGW_INTREFACE_H
#define zx_MGW_INTREFACE_H


#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif


#define MGW_SERV_PORT 		7076
#define MGW_SERV_IP 		"54.149.203.16"

#define AGREE_BYTE			'f'		//协议类型，默认 'f'
#define TRANSFER_COUNT		0		//转换器个数
#define BODY_BODECODEC		'j'		//包体加解器方式，默认'j':json
 
#define MAXLINE 			4096
#define TRANSFER_ID 		8
#define URI_LEN 			256
#define BODY_LEN 			1024
#define META_LEN 			0	//暂时设置为0
#define OPEN_MAX 			10
#define MGW_LOG				0		//log日志

typedef unsigned short  	UINT16;
typedef unsigned int 		UINT32;
typedef unsigned long  		ULONG;
typedef unsigned long long 	UINT64;

#define TypePull			1    	//拉取
#define TYPEREPLY 			2		//回复
#define TYPEPUSH 			3		//推送
#define PACKAGES_SEQ		1000000	//包序号



#define HEARTBEST_URL			"/styxx/v1/hub/heartbeat"
#define LIVE_START_URL 			"/styxx/v1/router/live_start"
#define FACE_CHANGED_URL		"/styxx/v1/router/face_change"
#define VERSION_PING_URL		"/styxx/v1/version/ping"


typedef struct mgw_commun_pro{
	UINT32 packetlen;    				//整包长度
	char byte;           				//协议类型,默认 'f'
	char transfer;  					//转换器个数
	//char transferids[TRANSFER_ID];		//转换器ID数组,'g'是压缩
	UINT64 seq; 						//包序号
	char ptype;							//包类型 1:拉取 		2:拉取回复  	3: 推送
	UINT32 urilen;						//uri长度
	char* uri;							//uri值
	UINT32 metalen;						//参数长度，默认0
	//char* meta;							//参数值
	char bodecodec;						//包体加解器方式，默认'j':json，'p':protobuf，'s':string
	char *body;							//包数据
	
}MGW_COMMUN_PRO;

#if 0
typedef struct mgw_response_data{
	int code;					//返回码 0：成功
	char *message;				//返回信息
	char *timestamp;			//时间戳
	char *data;					//响应数据
}mgw_response_data;
#endif


/*
成功返回结构体指针，失败返回 NULL
将结构体进行初始化，赋初值分配空间
*/
MGW_COMMUN_PRO *zx_mgw_commun_init(); //初始化结构体

/*
成功返回 0，失败返回 -1
给结构体成员赋值相应的数据
参数 mgw_com : 传入传出参数
*/
int zx_mgw_commun_assignment_value(
		MGW_COMMUN_PRO *mgw_com,	//需要赋值的结构体
		char *url,					//url
		char byte,					//协议类型
		char transfer,				//转换器个数
		char ptype, 				//包类型 1:拉取		2:拉取回复		3: 推送
		char bodecodec, 			//包体加解器方式，默认‘j':json，'p':protobuf，'s':string
		UINT64 mgw_seq, 			//包序号
		char *body					//body
	);



/*
打印结构体数据
*/
void zx_mgw_commun_printf(MGW_COMMUN_PRO *mgw_com);


/*
成功返回组好的数据包，失败返回 NULL
将结构体组包，用于网络发送
参数 mgw_com : 传入参数
*/
char *zx_mgw_commun_set_data_packages(MGW_COMMUN_PRO *mgw_com);


/*
成功返回 socket 句柄，失败返回 -1
创建socket网络连接句柄，设置为非阻塞
参数 serv_ip : 服务器IP
参数 serv_port : 服务器端口
*/
int zx_mgw_commun_create_socket(char *serv_ip,unsigned int serv_port);


/*
成功返回 0 ；失败返回 -1
发送组包好的数据
参数 mgw_com_buf : 传入参数，需要发送的数据
参数 sockfd : socket句柄，用于网络发送数据
*/
int zx_mgw_commun_send_data(int sockfd,char *send_com_buf_data,UINT32 data_packages_len );


/*
成功返回数据包 ；失败返回 NULL
接受网络数据包
参数 sockfd : socket句柄，用于网络接受数据
参数 data_packages_len : 接收到的数据包的长度，传入，传出参数
*/
char *zx_mgw_commun_recv_data(int sockfd,UINT32 *data_packages_len);

/*
成功返回 0 失败返回 -1
解析网络数据包
参数 src_data : 网络读取到是数据
参数 dst_mgw_com : 解析包后数据存放入结构体
*/
int zx_mgw_commun_parsing_data(char *src_data,MGW_COMMUN_PRO *dst_mgw_com);


/*
清理结构体，释放空间
参数 mgw_com : 传入参数
*/
void zx_mgw_commun_free(MGW_COMMUN_PRO *mgw_com);


void zx_mgw_setTimer(int seconds, int useconds);	//定时
ssize_t mgw_Readn(int fd,void *vptr,size_t n);	//n是需要读取的字节数
ssize_t mgw_Read(int fd, void *ptr, size_t nbytes);
ssize_t mgw_Writen(int fd, const void *vptr, size_t n);
ssize_t mgw_Write(int fd, const void *ptr, size_t nbytes);
UINT64 ntohl64(UINT64 host);
UINT64 hl64ton(UINT64 host);
UINT64 zx_mgw_CurTime_s(void);
int zx_ota_system(const char * cmdstring);



int zx_mgw_commun_long_connection_func();


#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_MGW_INTREFACE_H */



