/*============================================================================
 Name        : floodlight_interface.h
 Author      : oceanwing.com
 Copyright   : 2018(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-06-06 
 Description : 
 ============================================================================*/
#include "hal.h"
#include "hal_audio.h"
#include "hal_interface.h"
#include "hal_pir.h"
#include "hal_video.h"
#include "hal_wifi.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_ircut.h"
#include "hal_ota.h"



#ifndef zx_FLOODLIGHT_INTERFACE_H
#define zx_FLOODLIGHT_INTERFACE_H

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

#define		HISI_OUT
#define		HISI_IN

#define HISI_TCP_PORT				9009	//TCP port
#define HISI_TCP_REUSEADDR_LEN		300

#define HISI_VER_NAME				"0.0.0.1_"				//版本号，里面会去掉下划线
#define	SOFTWARE_PREFIX				"sw_version="
#define	SOFTWARE_VERSION_FILE		"/etc/version"


#define HISI_VERSION_NAME_LEN 		32					//版本名的长度
#define HISI_WIFI_DEV_NAME_LEN		16					//wifi设备名的长度
#define HISI_WIFI_CONNECT_TIME		20					//一次wifi连接的时长，重试三次

#define HISI_PIR_COUNT				3					//pir的数量
#define HISI_FLOODLIGHT_ALARM_TIME	30					//pir触发告警时间

#define HISI_LEFT_PIR				0					//左pir
#define HISI_MIDDLE_PIR				1					//中pir
#define HISI_RIGHT_PIR				2					//右pir

#define HISI_RED_LED_FLASH_FREQ		1000				//ms
#define HISI_WHITE_LED_FLASH_FREQ	1000				//ms

#define HISI_WIFI_AP_OPEN			1					//wifi在ap模式后，热点鉴权方式 open
#define HISI_WIFI_AP_AES			2					//wifi在ap模式后，热点鉴权方式 AES
#define HISI_WIFI_AP_PSK2			3					//wifi在ap模式后，热点鉴权方式 psk2

#define HISI_CH0					0  					//视频流的通道号,默认是0				1920x1080
	
#define HISI_ENABLE 				1					//使能
#define HISI_DISABLE 				0					//不使能

#define HISI_COLORFUL_MODE			0					//彩色模式
#define HISI_BLACK_WHITE_MODE		1					//黑白模式
#define HISI_GET_TEM_PHOTO_TIME		5					//

#define HISI_LOG_SWITCH				0	  				//控制log打印开关

#define HISI_FLASH_DATA_LEN 		1024				//读写flash的数据长度
#define HISI_DATA_LEN				512			

#define HISI_MIC_VOLUME				95					//MIC 的音量
#define HISI_SPEAKER_VOLUME			95					//SPEAKER的音量
#define HISI_CAM_SN_LEN				16					//设备sn长度

#define HISI_WIFI_MAC_LEN			32					//MAC 的长度
#define HISI_WIFI_IP_LEN			32					//IP  的长度
#define HISI_WIFI_DATA_LEN			64					//wifi的ssid和密码长度
#define HISI_ACCOUNT_ID_LEN			128					//id账号的长度


#define HISI_KEY_HOLDTIME_MS		5000   				//ms

#define HISI_FLOOD_LIGHT_VALUE 		30					//floodlight灯的亮度
#define HISI_FLOOD_LIGHT_OFF		0					//关闭floodlight灯
#define HISI_IR_LIGHT_VALUE			95					//IR led 的亮度

#define HISI_WIFI_SSID_AP_MODE 		"eufy_setup"			//AP模式的wifi名称
#define HISI_WIFI_PASSWORD_AP_MODE 	"12345678"			//AP模式的wifi密码，不能设置少于8位

#define HISI_CAMERA_1080P_BITRATE			768					//摄像头码率

#define HISI_CAMERA_720P_BITRATE			480					//摄像头码率

#define HISI_CAMERA_360P_BITRATE			320					//摄像头码率





#define FLOODLIGHT_DEV_SN			"T8001G0217530010"	//设备sn 
//#define FLOODLIGHT_DEV_SN			"T8001G0217530001"	//设备sn 
//#define FLOODLIGHT_DEV_SN			"T8001G0317480032"	//设备sn 



#define	HISI_SECTION_NAME_INFO		"hisi_device_info"
#define HISI_OFFSET_SECTION_INFO	0x0000				//设备信息

#define	HISI_FACTORY_NAME_OTP		"hisi_Factory_info"
#define HISI_OFFSET_FACTORY_OTP		0x8000				//32k
#define HISI_AUDIO_PLAY				0

#define HISI_RTMP					"rtmp"
#define HISI_RTSP					"rtsp"

#define	HISI_DEV_SN_OFFSET				( HISI_OFFSET_FACTORY_OTP + 0x0 )
#define HISI_DEV_WIFI_SSID_OFFSET		( HISI_OFFSET_FACTORY_OTP + HISI_CAM_SN_LEN + 0x0)
#define HISI_DEV_WIFI_PASSWORD_OFFSET	( HISI_OFFSET_FACTORY_OTP + HISI_CAM_SN_LEN + HISI_WIFI_DATA_LEN + 0x0)
#define HISI_DEV_ACCOUNT_ID_OFFSET		( HISI_OFFSET_FACTORY_OTP + HISI_CAM_SN_LEN + HISI_WIFI_DATA_LEN + HISI_WIFI_DATA_LEN + 0x0)


#define	HISI_DEV_SN_LEN				16


#define HISI_WIFI_AP_MODE			0					//wifi 是AP模式
#define HISI_WIFI_STA_MODE			1					//wifi 是STA模式

extern int wifi_connect_count;



#define HISI_NTP_SERVER  	"210.72.145.39" 		//"133.100.11.8"		//服务器
#define HISI_NTP_PORT    	123														//端口
#define HISI_JAN_1970    	0x83aa7e80	//3600s*24h*(365days*70years+17days)
#define HISI_NTPFRAC(x) 	(4294 * (x) + ((1981 * (x)) >> 11))
#define HISI_USEC(x) 		(((x) >> 12) - 759 * ((((x) >> 10) + 32768) >> 16))



typedef struct hisi_ntptime
{
  unsigned int coarse;
  unsigned int fine;
  
}HISI_NTP_TIME;



typedef enum 
{
	PIR_ZERO_LEVEL = 0,
	PIR_ONE_LEVEL,
	PIR_TWO_LEVEL,
	PIR_THREE_LEVEL,
	PIR_FOUR_LEVEL,
	PIR_FIVE_LEVEL,
	PIR_SIX_LEVEL,
	PIR_SEVEN_LEVEL
	
}HISI_PIR_SENSIVITY_LEVEL;

typedef enum
{
	SENSER_BRIGHTNESS = 0,  	//亮度
	SENSER_CONTRAST,		 	//对比度
	SENSER_CHROMA,			 	//色度
	SENSER_SATURATION			//饱和度
	
}CAMERA_SENSER_TYPE;

typedef enum
{
	CUR_DAY = 0,							//白天
	CUR_NIGHT,								//黑夜
	
	NIGHT_PHOTOSENSI_VALUE = 0X05,			//黑夜
	DAY_PHOTOSENSI_VALUE = 0X11				//白天
	
}HISI_PHOTOSENSITIVE;

typedef enum
{
	OFF_STATE = 0,				//关闭
	ON_STATE,					//打开
	FLASH_STATE					//闪烁
	
}HISI_SWITCH_STATE;

typedef enum
{
	INIT_CONDITION = 0,
	PIR_TIGGER_CONDITION,			//pir触发
	SCHEDULE_CONDITION,				//schedule触发
	MANUAL_CONDITION				//手动触发

}LAST_TIGGER_CONDITION;

typedef enum
{
	WIFI_NO_CONNECT = 0,
	WIFI_CONNECTTING,
	WIFI_CONNECTED
}HISI_WIFI_CONNECT_STATUS;


//红外灯模式
typedef enum{

	HISI_IRLEDMODE_AUTO = 0,				//(0)自动
	HISI_IRLEDMODE_ON ,						//(1)开启
	HISI_IRLEDMODE_OFF						//(2)关闭
	
}HISI_IRLEDMODE;


struct zx_hisi_timers

{
	int interval; 				//定时时间
	void(*timer_handler)(); 	//处理函数
	
}ZX_HISI_TIMERS;




typedef struct _hisi_camera_info_data
{
	int tem_sensor_adc_value;						//温敏传感器的值
	int photo_sensor_value;							//光敏传感器值

	int flash_data_len;								//分区数据的大小
	int key_holdtime_ms;							//按键时长	ms
	int bitrate;									//码率				[256-2M]

	int channel;									//视频流通道 			[0,1]
	int brightness;									//亮度 				[0-100]
	int contrast;									//对比度 				[0-100]
	int chroma;										//色度				[0-100]
	int saturation;									//饱和度				[0-100]

	int gop;										//I帧间隔				[0-15]
	int fps;										//帧率				[0-15]
	int colormode;									//图像色彩				[0:彩色,1:黑白]

	int irled_value;								//夜视灯值，红外
	int floodlight_value;							//floodlight灯的值
	int red_led_flash_freq;							//红LED 闪烁频率
	int white_led_flash_freq;						//白LED 闪烁频率

	int mic_volume;									//mic 音量
	int speaker_volume;								//speaker 音量

	VIDEO_FLIP_E angle;								//视频角度				[0:0°, 1:90°, 2:180°, 3:270° ]
	MD_LEVEL_E sensitivity;							//移动侦测灵敏度			[0-3]
	RESOLUTION_DEF_E resolution;					//分辨率				[0:RES_VGA , 1:RES_720P , 2:RES_1080P]
	POWER_FREQ_E pwfreq;							//电力线频率				[0:F50HZ, 1:F60HZ]
	BITRATE_MODE_E bit_mode;						//码率模式				[0:VBR,1:CBR]

	char ircut_state;								//ircut开关状态 [0: 关     	1: 开]
	char ircut_set_mode;							//ircut开关模式 [0：自动      	 1：开启 2:关闭 ]
	char mic_state;									//mic的开关状态 [0: 关     	1: 开]
	char osd_state;									//osd的开关状态	[0: 关     	1: 开]
	char red_led_state;								//红led灯的状态 [0: 关     	1: 开	2: 闪烁]
	char white_led_state;							//白led灯的状态 [0: 关     	1: 开	2: 闪烁]
	char white_led_tigger;							//白灯触发条件		
	char floodlight_state;							//floodlight 灯的状态
	char floodlight_last_tigger;					//最后触发的条件
	char pir_floodlight_tigger_time;				//pir触发等待时间
	char pir_sen_value[HISI_PIR_COUNT];				//pir灵敏度的值
	char pir_sen_state[HISI_PIR_COUNT];				//pir的开关状态 [0: 关     	1: 开]

	char version[HISI_VERSION_NAME_LEN];			//库的版本信息
	char pir_version[HISI_VERSION_NAME_LEN];		//MCU PIR的版本信息
	char dev_sn[DEVICE_SN_LEN + 2];					//设备sn号
	char account_id[HISI_ACCOUNT_ID_LEN];			//ID号
	char tem_sensor_value;							//板子的温度值
	
}HISI_CAMERA_INFO_DATA;


typedef struct _hisi_wifi_list_data
{
	HAL_WIFI_AP_INFO wifi_list_info;			//wifi信息结构体
	int wifi_info_count;						//扫描到的wifi数量
	struct _hisi_wifi_list_data *next;			
	
}HISI_WIFI_LIST_DATA;


typedef struct _hisi_camera_wifi_data
{
	int wifi_signal;								//wifi信号强度
    int wifi_enc;      								//鉴权方式
    int wifi_auth;									//鉴权方式
    int wifi_channel;								//wifi信道频率
    char wifi_mode;									//wifi模式，0是ap模式，1是sta模式
	char wifi_dev_name[HISI_WIFI_DEV_NAME_LEN];		//WiFi设备名称	
	char wifi_ssid[HISI_WIFI_DATA_LEN];				//wifi名称
	char wifi_password[HISI_WIFI_DATA_LEN];			//wifi密码
	char wifi_ip[HISI_WIFI_IP_LEN];					//ip
	char wifi_mac[HISI_WIFI_MAC_LEN];				//mac
	
}HISI_CAMERA_WIFI_DATA;


/***************************************
设置系统为当前时间
返回值：无
参数: 无
***************************************/
void zx_set_system_cur_time(void);


/***************************************
获取键盘的键值，会有阻塞
返回值：成功返回   		键值 ，失败返回-1
参数: 无
***************************************/
int zx_getch(void);


/***************************************
初始化 初始化floodlight接口函数
返回值：成功返回 0 ，失败返回-1
参数: 无
***************************************/
int zx_hisi_floodlight_init(void);


/***************************************
去初始化 去初始化floodlight接口函数
返回值：无
参数: 无
***************************************/
int zx_hisi_floodlight_deinit(void);


/***************************************
打开ircut
返回值：无
参数: 无
***************************************/
int zx_hisi_set_ircut_on();


/***************************************
关闭ircut
返回值：无
参数: 无
***************************************/
int zx_hisi_set_ircut_off();



/***************************************
判断当前是白天还是黑夜
返回值：
返回 0 : 白天
返回 1 ：黑夜
返回 -1: 错误
参数: 无
***************************************/
int zx_hisi_judge_day_or_night(void);



/***************************************
获取wifi的IP地址
返回值：成功返回0 失败返回 -1
参数: outip 输入输出参数，设备IP信息
****************************************/
int zx_hisi_get_wifi_localip(char* outip);


/***************************************
获取wifi的IP地址
返回值：成功返回0 失败返回 -1
参数: outmac 输入输出参数，设备mac信息
***************************************/
int zx_hisi_get_wifi_mac(char* outmac);


/***************************************
初始化 卓翼的所有接口
返回值：成功返回 0 ，失败返回其他
参数: 无
***************************************/
int zx_hisi_hal_all_init(void);


/***************************************
去初始化 卓翼的所有接口
返回值：无
参数: 无
***************************************/
void zx_hisi_hal_all_deinit(void);


/***************************************
设置打印卓翼log信息
返回值：无
参数: print_type 输入参数，0为不打开log打印，1为打开log打印
***************************************/
void zx_hisi_set_hal_log_print(int print_type);


/***************************************
wifi链表初始化
返回值：成功返回wifi链表的头指针，失败返回NULL
参数：无
***************************************/
HISI_WIFI_LIST_DATA* zx_hisi_wifi_list_init(void);


/***************************************
wifi链表节点赋值和插入
返回值：成功返回 获取到的wifi数量，失败返回 -1
参数：pPre 输入参数，wifi链表信息，从此节点后插入
***************************************/
int zx_hisi_wifi_list_upgrade_insert(HISI_WIFI_LIST_DATA *pPre);


/***************************************
打印wifi链表
返回值：成功返回 0，失败返回 -1
参数：pPre 输入参数，wifi链表信息
参数：wifi_ssid 打印需要的wifi_ssid 的信息
***************************************/
int zx_hisi_wifi_list_all_printf(HISI_WIFI_LIST_DATA *pPre);


/***************************************
打印wifi链表
返回值：成功返回 0，失败返回 -1
参数：pPre 输入参数，wifi链表信息
参数：wifi_ssid 打印需要的wifi_ssid 的信息
***************************************/
int zx_hisi_wifi_list_printf_ssid(HISI_WIFI_LIST_DATA *pPre);



/***************************************
打印wifi链表里的指定wifi信息
返回值：成功返回 0，失败返回 -1
参数：pPre 输入参数，wifi链表信息
参数：wifi_ssid 打印需要的wifi_ssid 的信息
***************************************/
int zx_hisi_wifi_list_printf(HISI_WIFI_LIST_DATA *pPre,char *wifi_ssid);



/***************************************
发送给APP的wifi列表数据
返回值：成功返回 0，失败返回 -1
参数：send_data 传出参数，发送给app端的数据
参数：data_len 发送数据的长度
***************************************/
int zx_hisi_wifi_list_send_app_data(char *send_data,int data_len);


/***************************************
解析app端的数据，连接网络
返回值：成功返回 0，失败返回 -1
参数：buf_data 传入参数，从app端接收的数据
*/
int zx_hisi_parsing_data_connect_network(char *buf_data);


/***************************************
释放wifi链表
返回值：成功返回 0，失败返回 -1
参数：head 输入参数，wifi链表头节点
***************************************/
int zx_hisi_wifi_list_free(HISI_WIFI_LIST_DATA *head);


/***************************************
floodlight灯定时熄灭
返回值：成功返回 0，失败返回 -1
参数：flood_light_time 输入参数，定时的时间
***************************************/
int zx_hisi_flood_light_alarm(unsigned int flood_light_time);


/***************************************
设置floodlight灯亮度
返回值：成功返回 0，失败返回 -1
参数：light_value 输入参数，控制灯的亮度【0-100】
***************************************/
int zx_hisi_set_flood_light_value(unsigned int light_value);



/***************************************
floodlight灯打开
返回值：成功返回 0，失败返回 -1
参数：无
***************************************/
int zx_hisi_flood_light_on(void);


/***************************************
floodlight灯关闭
返回值：成功返回 0，失败返回 -1
参数：无
***************************************/
int zx_hisi_flood_light_off(void);


/***************************************
IRLED灯打开
返回值：成功返回 0，失败返回 -1
参数：无
***************************************/
int zx_hisi_irled_on(void);


/***************************************
IRLED灯关闭
返回值：成功返回 0，失败返回 -1
参数：无
***************************************/
int zx_hisi_irled_off(void);



/***************************************
红led灯闪烁
返回值：成功返回 0，失败返回其他
参数：flash_freq 输入参数，灯的闪烁频率，单位ms，不可以设置为0
***************************************/
int zx_hisi_set_red_led_flash_freq(unsigned int flash_freq);


/***************************************
白led灯闪烁
返回值：成功返回 0，失败返回其他
参数：flash_freq 输入参数，灯的闪烁频率，单位ms，不可以设置为0
***************************************/
int zx_hisi_set_white_led_flash_freq(unsigned int flash_freq);



/***************************************
红led灯闪烁
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_red_led_flash(void);


/***************************************
白led灯闪烁
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_white_led_flash(void);


/***************************************
红灯常亮
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_red_led_on(void);


/***************************************
红灯关闭
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_red_led_off(void);


/***************************************
白灯常亮
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_white_led_on(void);


/***************************************
白灯关闭
返回值：成功返回 0，失败返回其他
参数：无
***************************************/
int zx_hisi_set_white_led_off(void);


/***************************************
摄像头wifi信息结构体初始化
返回值：成功返回 摄像头结构体指针，失败返回NULL
参数：无
***************************************/
HISI_CAMERA_WIFI_DATA* zx_hisi_camera_wifi_data_init(void);


/***************************************
获取当前设备wifi的信息
返回值：成功返回 0，失败返回 -1
参数：pPre 输入参数，wifi链表信息
参数：cam_wifi_info 输入输出参数，获取到的wifi信息
***************************************/
int zx_hisi_get_camera_wifi_data(HISI_CAMERA_WIFI_DATA* cam_wifi_info);


/***************************************
打印当前设备wifi的信息
返回值：无
参数：cam_wifi_info 设备wifi信息结构体
***************************************/
void zx_hisi_camera_wifi_info_printf(HISI_CAMERA_WIFI_DATA *cam_wifi_info);


/***************************************
摄像机连接wifi
返回值：成功返回 0，失败返回其他
参数：wifi_ssid   			wifi的名称
参数：wifi_password		wifi的密码
参数：wifi_info			设备wifi的信息
***************************************/
int zx_hisi_camera_connect_network(const char*wifi_ssid,		const char*wifi_password);


/***************************************
摄像头信息结构体初始化
返回值：成功返回 摄像头结构体指针，失败返回NULL
参数：无
***************************************/
HISI_CAMERA_INFO_DATA* zx_hisi_camera_info_data_init(void);



/***************************************
获取设备信息
返回值：成功返回 0，失败返回-1
参数：cam_info 输入输出参数
***************************************/
int zx_hisi_get_camera_info_data(HISI_CAMERA_INFO_DATA *cam_info);


/***************************************
打印设备信息
返回值：无
参数：cam_info 输入参数
***************************************/
void zx_hisi_camera_dev_info_printf(HISI_CAMERA_INFO_DATA *cam_info);



/***************************************
设置摄像头参数
返回值：成功返回 0，失败返回-1
参数：brightness  		亮度
参数：contrast			对比度
参数：chroma			色度
参数：saturation		饱和度
参数：angle			视频角度
参数：colormode		色彩模式
参数：sensitivity		移动侦测灵敏度
参数：resolution		视频分辨率
参数：fps				帧率
参数：gop				I帧间隔
参数：pwfreq			电力线频率
参数：bitrate			码率
参数：bit_mode			码率模式
***************************************/
int zx_hisi_set_camera_senser_parameter(
	int brightness,					//亮度				[0-100]
	int contrast,					//对比度				[0-100]
	int chroma,						//色度				[0-100]
	int saturation,					//饱和度				[0-100]
	VIDEO_FLIP_E angle,				//视频角度  			[0:0°, 90:90°, 180:180°, 270:270° ]
	int colormode,					//色彩模式				[0:彩色,1:黑白]
	MD_LEVEL_E sensitivity,			//移动侦测灵敏度			[0-3]
	RESOLUTION_DEF_E resolution,	//视频分辨率				[0:RES_VGA , 1:RES_720P , 2:RES_1080P] 
	int fps,						//帧率
	int gop,						//I帧间隔
	POWER_FREQ_E pwfreq,			//电力线频率				[0:F50HZ, 1:F60HZ]
	int bitrate,					//码率
	BITRATE_MODE_E bit_mode			//码率模式				[0:VBR,1:CBR]	//CBR不能设置
	);


/***************************************
设置pir灵敏度
返回值：返回值：成功返回 0 ，失败返回 -1
参数：left_pir 设置左pir灵敏度值 					[0-7],等级越高越灵敏
参数：lmiddle_pir 设置中pir灵敏度值				[0-7],等级越高越灵敏
参数：right_pir 设置右pir灵敏度值					[0-7],等级越高越灵敏
***************************************/
int zx_hisi_set_pir_sensivity_value(int left_pir, int middle_pir, int right_pir);


/***************************************
设置pir灵敏度
返回值：返回值：成功返回 0 ，失败返回 -1
***************************************/
int zx_hisi_set_pir_on(void);


/***************************************
设置pir灵敏度
返回值：返回值：成功返回 0 ，失败返回 -1
***************************************/
int zx_hisi_set_pir_off(void);


/***************************************
设置mic和speaker的音量
返回值：成功返回 0 ，失败返回 -1
参数：mic_volume 设置mic的音量 	音量值[0-100]				
参数：speaker_volume 设置speaker的音量			音量值[0-100]	
***************************************/
int zx_hisi_set_camera_volume(int mic_volume,int speaker_volume);


/***************************************
读flash工厂信息
返回值：成功返回读取到的数据长度，失败返回 -1
参数：buf 输出参数，读取后信息存储
参数：len 输入参数，读取数据的长度
***************************************/
int zx_hisi_camera_flash_read_fac_otp ( HISI_OUT  char *buf, HISI_IN  size_t len);


/***************************************
写flash工厂信息
返回值：成功返回写入的数据长度，失败返回 -1
参数：buf 输入参数，写入到flash信息
参数：len 输入参数，写入信息的长度
***************************************/
int zx_hisi_camera_flash_write_fac_otp( HISI_OUT  char *buf, HISI_IN  size_t len);


/***************************************
读flash设备信息
返回值：成功返回读取到的数据长度，失败返回 -1
参数：buf 输出参数，读取后信息存储
参数：len 输入参数，读取数据的长度
***************************************/
int zx_hisi_camera_flash_read_dev_info ( HISI_OUT  char *buf, HISI_IN  size_t len);


/***************************************
写flash设备信息
返回值：成功返回写入的数据长度，失败返回 -1
参数：buf 输入参数，写入到flash信息
参数：len 输入参数，写入信息的长度
***************************************/
int zx_hisi_camera_flash_write_dev_info( HISI_OUT  char *buf, HISI_IN  size_t len);


/***************************************
设置设备sn号
返回值：成功返回设置的数据长度，失败返回 -1
参数：buf 输入参数，写入到flash中的sn号
参数：len 输入参数，写入信息的长度
***************************************/
int zx_hisi_set_device_sn( char * buf, size_t len );


/***************************************
获取设备的sn号
返回值：成功返回获取到的数据长度，失败返回 -1
参数：buf 输入参数，获取到的sn号
参数：len 输入参数，获取的长度
***************************************/
int zx_hisi_get_device_sn( char * buf, size_t len );



/***************************************
获取wifi的密码
返回值：成功返回获取到的数据长度，失败返回 -1
参数：buf 输入参数，获取到的wifi名称
参数：len 输入参数，获取的长度
***************************************/
int zx_hisi_get_flash_wifi_ssid( char * buf, size_t len );


/***************************************
获取wifi的密码
返回值：成功返回获取到的数据长度，失败返回 -1
参数：buf 输入参数，获取到的wifi密码
参数：len 输入参数，获取的长度
***************************************/
int zx_hisi_get_flash_wifi_password( char * buf, size_t len );


/***************************************
获取account ID号
返回值：成功返回获取到的数据长度，失败返回 -1
参数：buf 输入参数，获取到的wifi名称
参数：len 输入参数，获取的长度
***************************************/
int zx_hisi_get_flash_account_id( char * buf, size_t len );

/***************************************
设置account ID号
返回值：成功返回获取到的数据长度，失败返回 -1
参数：buf 输入参数，获取到的wifi名称
参数：len 输入参数，获取的长度
***************************************/
int zx_hisi_set_flash_account_id( char * buf, size_t len );



/***************************************
按键事件
返回值：无
参数：无
***************************************/
void zx_hisi_camera_key_event(void);


/***************************************
视频推流
返回值：无
参数：无
***************************************/
void zx_hisi_video_push_stream(void);


/***************************************
音频推流
返回值：无
参数：无
***************************************/
void zx_hisi_audio_push_stream(void);


/***************************************
摄像机绑定app
返回值：成功返回 0 失败返回 -1
参数：无
***************************************/
int zx_hisi_camera_app_bind_module();


/***************************************
PIR事件
返回值：无
参数：无
***************************************/
void zx_hisi_cam_pir_detect_event(void);


/***************************************
移动侦测事件
返回值：无
参数：无
***************************************/
void zx_hisi_cam_motion_event(void);


/***************************************
获取温度和光敏的值
返回值：成功返回 0 ，失败返回 -1
参数：无
***************************************/
int zx_hisi_cam_get_tmp_photo_value_pthread(void);

/***************************************
设置摄像机的默认参数
返回值：成功返回 0 失败返回 -1
参数：无
***************************************/
int zx_hisi_set_camera_parameter(void);


/***************************************
获取flash中wifi名称和密码
返回值：成功返回 0 失败返回 -1
参数：ssid_data  		wifi名称
参数：password_data		wifi密码
***************************************/
int hisi_get_flash_ssid_and_password(char *ssid_data,char *password_data);


/***************************************
设置flash中wifi名称和密码
返回值：成功返回 0 失败返回 -1
参数：ssid_data  		wifi名称
参数：password_data		wifi密码
***************************************/
int zx_hisi_set_flash_ssid_and_password(char *ssid_data,char *password_data);


/***************************************
停止TCP的server
返回值：无
参数：无
***************************************/
void zx_hisi_stop_tcp_server(void);


/***************************************
OTA升级
返回值：成功返回 0 ，失败返回 -1
参数：file_path 升级文件路径
***************************************/
int zx_hisi_ota_updata_version(char *file_path);



/***************************************
更新设备信息到flash
返回值：成功返回 0 ，失败返回 -1
参数：无
***************************************/
void zx_hisi_floodlight_update_flash_dev_info(void);


int zx_hisi_set_new_time();


#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_FLOODLIGHT_INTERFACE_H */




































