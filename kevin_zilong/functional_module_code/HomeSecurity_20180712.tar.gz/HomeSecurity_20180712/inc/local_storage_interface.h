/*============================================================================
 Name        : local_storage_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-12-05
 Description :
 ============================================================================*/
#include <stdio.h>
#include <openssl/rsa.h>

#include "base.h"
#include "comm_protocol_define.h"
#include "sys_interface.h"
#include "ai_interface.h"


#ifndef zx_LOCAL_STORAGE_INTERFACE_H
#define zx_LOCAL_STORAGE_INTERFACE_H

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

#define PIR_TRIGER_NUM     3    // PIR触发防抖 (PIR_TRIGER_SLOT秒收PIR_TRIGER_NUM个提示)
#define PIR_TRIGER_SLOT   (3000)    // ms

#define LOCAL_SAVE_DIR    "/mnt/sdcard"
#define LOCAL_LINK_FILE   "/mnt/sdcard/localfilelink.dat"
#define MP4_SAVE_PATH     "/mnt/sdcard/video/"

#define MEDIA_CB_TIME        (20*1000)  // 20ms
#define SCHEDULE_DETCTION    60         // 每60s检测一次布防

#define RECORD_TIME_OUT      (120*1000) // 120s
#define WAIT_CAMERA_STREAM   (15*1000)  // 15s

#define FACEMAX              (10)

//#define HISI_AUDIO_MAX_QUEUE  150   // 队列大小 150 * 320*2  96K
//#define HISI_VIDEO_MAX_QUEUE  90    // 队列大小 90 * 60*1000 5.4M，(可存6秒)

#define HISI_AUDIO_MAX_QUEUE  25   // 队列大小 25 * 160*2  9K
#define HISI_VIDEO_MAX_QUEUE  15    // 队列大小 15 * 60*1000 900k，(可存1秒)



typedef enum
{
    SCHEDULE_INIT = 0,   //
    SCHEDULE_ARMING,     //已布防
    SCHEDULE_DISARMING,  //已撤防
}SCHEDULE_STATUS;

typedef enum
{
    PRI_IDLE   = 0x00,  // 关闭
    PRI_RECORD = 0x01,  // 录像
    PRI_ALARM  = 0x02,  // 播告警音
    PRI_AI     = 0x04,  // 开关AI人脸检测
    PRI_RECORD_ALARM = 0x03,   // 录像并告警
    PRI_ALL    = 0x07,  // 所有动作
}PRI_ACTION;

typedef enum
{
    PLAYBACK_NORMAL = 0,// 正常
    PLAYBACK_PAUSE,     // 暂停
    PLAYBACK_STOP,      // 停止
    PLAYBACK_DRAG,      // 拖放
}PLAYBACK_CTRL;

typedef struct playctrl_st
{
    int                    session_id;
    PLAYBACK_CONTROL_PARAM playctrl;    // 从APP接收的拖放指令
}PLAYCTRL_ST;

typedef enum
{
    STORAGE_IDLE = 0,           // 空闲
    STORAGE_OPEN_CAMERA,        // 打开camera, 等待出流
    STORAGE_AI_WAIT,            //AI忙，等待识别结束, camera video存入队列
    STORAGE_AI_RECOGNITION,     //占用AI人脸身体识别, 其它camera不能抢占
    STORAGE_AI_DETECTION,       //识别到没人,继续识别,释放控制权，其它camera可抢占
    STORAGE_AI_END_DETECTION,   //没有识别到人脸,且控制权被抢占，结束检测
    STORAGE_TF_WRITE,           //开始进行本地录像和云存储
    STORAGE_AI_TRACK,           //录像同时做AI人脸跟踪,其它camera可抢占AI
    STORAGE_AI_WRITE,           //只录像, AI不再跟踪人脸
}STORAGE_STATUS;

struct filenode {
    char flag;                  /* 文件属性标记 : 1：收藏 or 普通*/
    char filename[FILENAMEMAX]; /* 文件名 */
    zx_Uint32 frame_num;        // 记录的视频帧数,还没应用
};

struct filelist {
    struct filenode info;
    struct filelist *next;      /* 指向下一个链表的指针 */
};

typedef struct local_fp_info
{
    short     channel;          // 废弃
    FILE *    fp;
    int       sockfd;

    int       record_flag;      // 录像进度状态机
    int       triger_pir_count; // pri 触发次数
    int       arming_action;    // 布防动作
    
    unsigned int frame_num;
    long long start_time;       // 录制开始ms
    long long end_time;         // 录制结束ms
    long long ai_warning_time;  // 发送AI识别通知计时

    int       storage_pipe[2];  // 多端写入，一端读出

    int       faceid[FACEMAX];
    char      filename[FILENAMEMAX];    /* 本地保存的文件 /media/mmcblk0p1/Camera01/20180425112401.dat */
    char      cloudfile[FILENAMEMAX];   /* 云存储的本地临时文件 */
    char      short_url[SHORT_STR_LEN];
}LOCAL_FP_INFO;

typedef struct local_resend_info
{
    unsigned int frame_num;
    unsigned int storagetype;
    long long start_time;       // 录制开始ms
    long long end_time;         // 录制结束ms
    char *    thumbnail;        // 缩略图指针
    int       faceid[FACEMAX];
    char      filename[FILENAMEMAX];    /* 本地保存的文件 /media/mmcblk0p1/Camera01/20180425112401.dat */
    char      cloudfile[FILENAMEMAX];   /* 云存储的本地临时文件 */
    char      dev_sn[SHORT_STR_LEN];
}LOCAL_RESEND_INFO;

struct resend_filelist {
    LOCAL_RESEND_INFO resend;
    struct resend_filelist *next;      /* 指向下一个链表的指针 */
};

typedef struct ai_frame_st
{
    int           frame_No;
    int           len;
    unsigned char buf[AI_DATA_SIZE];    //
}AI_FRAME_ST;

#define RSA_KEYLEN     (128)
typedef struct zx_rsakey_st
{
    char key_id;                  // 公钥号
    char pubkey[RSA_KEYLEN+1];    // 公钥的n模字符串
}ZX_RSAKEY_ST;

long long zx_LocalTime_ms(void);
char *rand_str(char *str, const int len);
int zx_local_storage_ini( void );

void zx_deinit_local_storage( void );

FILE * get_local_fp_by_channel(unsigned int channel);

int file_list_del(char *pfilename);

int batch_del_files(REC_BATCH_DEL *pdel);

int save_all_link_to_flash( void );

int pir_triger_handle_by_channel(unsigned int channel);

int get_all_link_from_flash(void);
int free_all_link_node(void);
int remove_old_file_note(void);
int update_file_favorite(char *pfilename, int favorite);
void zx_set_playclt_by_session(int session_id, PLAYBACK_CONTROL_PARAM playctrl);
void * zx_tfcard_h264_playback_thread(void *argv); // 本地视频回放
void * zx_h264tomp4_thread(void *argv);	// 视频下载
void * zx_storage_write_thread( void *argv ); // 视频存储（本地 or 云）
int update_storage_status_by_channel(unsigned char channel, char status);
int update_ai_warning_by_channel(unsigned char channel, char status);
int update_ai_record_faceid(unsigned char channel, int id);
unsigned int get_system_tf_free(unsigned int *ptotalsize);
LOCAL_FP_INFO* get_local_filerecord_by_channel(unsigned int channel);
int zx_update_dev_pri_action_by_channel(int channel, int action);
void zx_check_cloud_storage(void);
int zx_update_local_rsa_pubkey(unsigned char key_id, char *nkey);
int zx_check_local_rsa_pubkey( void );
void zx_resend_hub_history_record( void );
int update_record_time_by_channel(unsigned char channel);


//本地存储
int zx_motion_and_pir_triger_local_storage(unsigned int channel);



#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_LOCAL_STORAGE_INTERFACE_H */


