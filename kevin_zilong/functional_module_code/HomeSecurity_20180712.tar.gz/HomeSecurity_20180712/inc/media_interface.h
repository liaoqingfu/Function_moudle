/*============================================================================
 Name        : media_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-12-05 
 Description : 
 ============================================================================*/

#include "base.h"

#ifndef zx_MEDIA_INTERFACE_H
#define zx_MEDIA_INTERFACE_H

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

int zx_play_wav(char * file_path);

#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_MEDIA_INTERFACE_H */


