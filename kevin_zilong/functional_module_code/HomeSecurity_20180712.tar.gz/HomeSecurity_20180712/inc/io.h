/*
 ============================================================================
 Name        : io.h
 Author      : Oceanwing.com
 Copyright   : 2012(c) Shanghai Oceanwing Information Technologies Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description : 
 ============================================================================
 */

#ifndef zx_IO_H
#define zx_IO_H

#include "http.h"
#include "reader.h"

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

/*============================================================================*/
/* type zx_Io_PutExtra */

typedef struct _zx_Io_PutExtraParam 
{
	const char* key;
	const char* value;
	struct _zx_Io_PutExtraParam* next;
} zx_Io_PutExtraParam;

typedef struct _zx_Io_PutExtra 
{
	zx_Io_PutExtraParam* params;
	const char* mimeType;
	zx_Uint32 crc32;
	zx_Uint32 checkCrc32;

	// For those file systems that save file name as Unicode strings,
	// use this field to name the local file name in UTF-8 format for CURL.
	const char* localFileName;

	// For those who want to invoke a upload callback on the business server
	// which returns a JSON object.
	void* callbackRet;
	zx_Error (*callbackRetParser)(void*, zx_Json*);

	// For those who want to abort uploading data to server.
	void * upAbortUserData;
	zx_Rd_FnAbort upAbortCallback;

    const char *upHost;
} zx_Io_PutExtra;

/*============================================================================*/
/* type zx_Io_PutRet */

typedef struct _zx_Io_PutRet 
{
	const char* hash;
	const char* key;
    const char* persistentId;
} zx_Io_PutRet;

typedef size_t (*rdFunc)(void* buffer, size_t size, size_t n, void* rptr);

/*============================================================================*/
/* func zx_Io_PutXXX */

#ifndef zx_UNDEFINED_KEY
#define zx_UNDEFINED_KEY		NULL
#endif

zx_Error zx_Io_PutFile(
	zx_Client* self, zx_Io_PutRet* ret,
	const char* uptoken, const char* key, const char* localFile, zx_Io_PutExtra* extra);

zx_Error zx_Io_PutBuffer(
	zx_Client* self, zx_Io_PutRet* ret,
	const char* uptoken, const char* key, const char* buf, size_t fsize, zx_Io_PutExtra* extra);

zx_Error zx_Io_PutStream(
    zx_Client* self, 
	zx_Io_PutRet* ret,
    const char* uptoken, const char* key, 
	void* ctx, // 'ctx' is the same as rdr's last param
	size_t fsize, 
	rdFunc rdr, 
	zx_Io_PutExtra* extra);

/*============================================================================*/

#pragma pack()

#ifdef __cplusplus
}
#endif

#endif // zx_IO_H

