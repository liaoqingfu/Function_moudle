
#ifndef __PUSH_STREAM_H__
#define __PUSH_STREAM_H__

//#include "xm_interface.h"
#include "comm_protocol_define.h"
#include "circular_buffer.h"

#pragma pack(1)

//#define IP_ADDR_REMOTE    "192.168.1.155"
#define IP_ADDR_REMOTE    "127.0.0.1"
#define RTMP_ADDR_REMOTE  "rtmp://192.168.1.181/live/test"
//#define RTMP_ADDR_REMOTE  "test.mp4"
//#define RTMP_ADDR_REMOTE  "rtsp://192.168.1.155/live.sdp"
//#define RTMP_ADDR_REMOTE  "rtsp://54.67.33.61/live.sdp"
//#define RTMP_ADDR_REMOTE  "rtsp://127.0.0.1/live"

#define MAX_STREAM_TYPE	  4

typedef enum STREAM_PROTOCAL_TYPE {

	ZX_STREAM_TYPE_NONE = -1,
	ZX_STREAM_TYPE_MP4,
	ZX_STREAM_TYPE_RTMP,	   //for PC web + Google Home  + Phone Web
	ZX_STREAM_TYPE_RTSP_WAN,   //for echo show 
	ZX_STREAM_TYPE_RTSP_LAN    //for nas rtsp push 
	
}STREAM_PROTOCAL_TYPE;


typedef struct st_video_info
{
	   int         frame_type;
       int         frame_size;
       short       frame_rate;
       short       width;
       short       height;
       long long   ntimestamp;
}VIDEO_INFO;

typedef struct stream_connect_info
{
	int 		    invalid; 	//是否有效
	int             channel; 
	void            *video_queue;	
	void            *audio_queue;

	int          	 video_pipe[2];
	int          	 audio_pipe[2];
	
	int 		     sendFd;
	unsigned char 	 iSendThreadRunState;	  // 0 执行完 1正在执行
	unsigned char 	 iVideoCallBackRunState;  // 0 执行完 1正在执行
	unsigned char 	 iAudioCallBackRunState;  // 0 执行完 1正在执行
 	unsigned char 	 iControlThreadRun;

	VIDEO_INFO		 videoInfo;

	unsigned char 	 iPushStreamState[MAX_STREAM_TYPE];
	char 			 szFileName[MAX_STREAM_TYPE][MAX_FILE_NAME];
	
	pthread_mutex_t  pushMutex;
	
}STREAM_CONNECT_INFO;

#if RUN_PUSH_STREAM

#ifdef __cplusplus
extern "C"
{
#endif

int connect_video_server(void);

STREAM_CONNECT_INFO *zx_get_stream(int channel);

int zx_start_stream(int channel,char *url);

int zx_stream_send_video_frame(int channel,char *buff);

int zx_stream_add_new_push(STREAM_CONNECT_INFO * ctx,char *url);

int zx_stream_get_push_type(char *url);

int zx_stream_set_push_type(STREAM_CONNECT_INFO *ctx,char *url);


#ifdef __cplusplus
};
#endif

#endif

#pragma pack(0)

#endif

