/*
 ============================================================================
 Name        : sub1g_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-28 
 Description :
 ============================================================================
 */

#ifndef _SUB1G_INTERFACE_H
#define _SUB1G_INTERFACE_H

#include "base.h"
#include "sys_interface.h"


#define ALLOW_BIND_TIME_OUT   (120*1000)
#define DOOR_SENSOR_MAX_NUM 16
#define DOOR_SENSOR_CHANNEL_ID_START 16

#pragma pack(1)

typedef enum 
{
	PIR_SENSITIVITY_LOW   = 1,
	PIR_SENSITIVITY_HIGH,	
}PIR_SENSITIVITY;

typedef enum
{
	RED_LED   = 1,
    WHITE_LED = 2
}ZX_LED_TYPE;


#ifdef __cplusplus
extern "C"
{
#endif

//int zx_init_sub1g(DEV_BASE_PARAM *dev_param);	
int zx_init_sub1g(HUB_BASE_PARAM *hub_param, void *list);
int zx_deinit_sub1g();
int zx_set_bind_status(int session_id, int timeout);
int zx_get_dev_count(void);	
int zx_get_colector_version(char *version);	
int zx_sub1g_send_data(uint32_t dest, void *msg, int len);
int zx_sub1g_send_command(int command_type, int channel, int value, int value1);
int zx_sub1g_disassoc_all_dev(void);
int zx_sub1g_send_command_ex(int command_type, int channel, int value, char *value1);
int zx_sub1g_enter_factory_test(int command_type, int channel, int value, char *value1, char *value2, char *value3, char *value4);
int * zx_get_p2p_pipe_by_channel(int channel, int type);
int zx_upload_dev_info(void);
int zx_dev_ota_process(void *version, void *version_720, const char *new_ver, int type);
int zx_hub_sub1g_ota_process(void *version, const char *new_ver, const char *cur_ver);
int zx_clean_dev_linkinfo_by_channel(char channel_id);
int zx_hub_sub1g_led_control(int led_type, int state);
int zx_sub1g_disassoc_by_shortaddr(unsigned int shortaddr);
int zx_hub_sub1g_quick_charge_control(int state); //state 0:�򿪿�� 1:�رտ��

	
#ifdef __cplusplus
};
#endif

#pragma pack()

#endif
