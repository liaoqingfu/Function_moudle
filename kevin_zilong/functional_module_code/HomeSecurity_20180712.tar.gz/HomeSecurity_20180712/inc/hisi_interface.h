/*============================================================================
 Name        : hisi_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-04-27 
 Description : 
 ============================================================================*/


#ifndef zx_HISI_INTERFACE_H
#define zx_HISI_INTERFACE_H

#include "base.h"
#include <errno.h>
#include <pthread.h>
#include <net/if.h>	
#include <sys/socket.h>	
#include <net/if_arp.h>		/* For ARPHRD_ETHER */
#include <sys/socket.h>		/* For AF_INET & struct sockaddr */
#include <netinet/in.h>         /* For struct sockaddr_in */
#include <netinet/if_ether.h>

#include "sys_interface.h"

#include "hal.h"
#include "hal_audio.h"
#include "hal_interface.h"
#include "hal_pir.h"
#include "hal_video.h"
#include "cjson.h"
#include "hal_wifi.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_ircut.h"



#define CONF_PATH               "/mnt/DataDisk/"  	//固定值(参数保存区)
#define FRAME_TYPE_I    		1
#define TFCARD_RD_FLAG  		255
#define HISI_AUDIO_FILE					"/mnt/sdcard/hisi_audio.g711"




#ifdef __cplusplus
extern "C"
{
#endif
#pragma pack(1)


typedef enum
{
	CAMERA_CLOSED = 0x00,
	CAMERA_CLOSEING = 0x01, //关闭中，防止一个正在关闭时又来PIR 打开
}ZX_HISI_CAMERA_ST;      // 每个占1bit

typedef struct hisi_camera_info
{
	short	channel;
	short	clientmark;		// 有多个容户端可打开/关闭 camera,投票
}HISI_CAMERA_INFO;




//摄像机版本信息                                        
typedef struct _cameraversion{
	char masterhardversion[32];				//主控模块硬件版本号
	char mastersoftversion[32];				//主控模块软件版本号
	char id[32];							//摄像机ID或序列号
	char dsphardversion[32];				//DSP硬件版本号
	char dspsoftversion[32];				//DSP软件版本号
}HISI_CAMERA_VERSION;









int zx_hisi_init_camera_sdk(int print_type, void *list);

int zx_hisi_deinit_camera_sdk(void);


/***************************************
打开摄像头
返回值：成功返回 0 失败返回 -1
参数：
***************************************/
int zx_hisi_open_camera(int channel, short clientmark);

int hisi_get_camera_clientmark(short channel);
int hisi_set_camera_clientmark(short channel, short clientmark);

void hisi_clear_camera_status(short channel);



/***************************************
关闭摄像头
返回值：成功返回 0 失败返回 -1
参数：
***************************************/
int zx_hisi_close_camera(int channel);

int get_hisi_camera_clientmark(short channel);

int zx_hisi_get_dev_version(int channel, char* sw_ver, char *hw_ver);

int hisi_clear_camera_clientmark(short channel, short clientmark);

int zx_hisi_tcp_server_test(void);


/*
ota 测试
*/
int hisi_ota_test();


/*
连接wifi
*/
int zx_hisi_connect_wifi_network(const char *ssid, const char *password);

int hisi_video_push_stream();

int hisi_audio_push_stream();



#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_HISI_INTERFACE_H */

