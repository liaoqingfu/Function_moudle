/*============================================================================
 Name        : hal_interface.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-04-16 
 Description : 
 ============================================================================*/

#include "mgw_interface.h"




#ifndef zx_HAL_INTERFACE_H
#define zx_HAL_INTERFACE_H

#pragma pack(1)



#ifdef __cplusplus
extern "C"
{
#endif

#define LIGHT_VALUE 			80
#define WIFI_SSID 				"ASUS_MT7628_2.4G"
#define MT7628_WIFI_SSID 		"MT7628_2.4G"
#define WIFI_PASSWORD			"asdfghjkl"

#define TP_LINK_C128 			"TP-LINK_C128"
#define TP_WIFI_PASSWORD		"jiao@123"


#define  int8      char
#define  uint8     unsigned char
#define  uint32    unsigned int
#define  ulong32   unsigned long
#define  long32    long
#define  int32     int
#define  long64    long long


//ntp时间从年开始，本地时间从年开始，这是两者之间的差值
#define  JAN_1970   0x83aa7e80      //3600s*24h*(365days*70years+17days)

//x*10^(-6)*2^32 微妙数转 NtpTime 结构的 fraction 部分
#define  NTPFRAC(x) (4294 * (x) + ((1981 * (x)) >> 11))  

//NTPFRAC的逆运算
#define  USEC(x) (((x) >> 12) - 759 * ((((x) >> 10) + 32768) >> 16))



#define  HISI_NTPSVR1  		"132.163.4.102"        	//USA
#define  HISI_NTPSVR2  		"132.163.135.132"      	//USA
#define  HISI_NTPSVR3  		"192.53.103.103"      	//Germany
#define  DEF_NTP_SERVER  	"210.72.145.44"    		//国家授时中心 ip
//#define DEF_NTP_SERVER 	"stdtime.gov.hk" 		//香港标准时间
//#define DEF_NTP_SERVER 	"pool.ntp.org"     		//ntp官方时间


#define  HISI_NTPPORT  123


typedef struct NTPPACKET
{
  uint8     li_vn_mode;
  uint8     stratum;
  uint8     poll;
  uint8     precision;
  ulong32   root_delay;
  ulong32   root_dispersion;
  int8      ref_id[4];
  ulong32   reftimestamphigh;
  ulong32   reftimestamplow;
  ulong32   oritimestamphigh;
  ulong32   oritimestamplow;
  ulong32   recvtimestamphigh;
  ulong32   recvtimestamplow;
  ulong32   trantimestamphigh;  
  ulong32   trantimestamplow;
}NTPPacket;

NTPPacket  ntppack,newpack;

//定义为long64,解决32位数的符号位问题
long64   firsttimestamp,finaltimestamp;
long64   diftime,delaytime;



//ntp时间戳结构

typedef   struct   

{
    unsigned   int  integer;
    unsigned   int  fraction;

} NtpTime;

 

//校准信息结构

typedef   struct

{
    struct  timeval dlytime;
    struct  timeval offtime;
    struct  timeval newtime;

} NtpServResp;

 

//ntp客户端配置结构，对应 ntpclient.conf 中各项

typedef   struct

{
    char  servaddr[256];
    unsigned   int  port;
    int  psec;
    int  pmin;
    int  phour;
    int  timeout;
    bool  logen;
    char  logpath[256];

} NtpConfig;





int zx_set_sta_wifi_and_connect_zhuoyi();

int zx_set_sta_wifi_and_connect();

int zx_set_sta_wifi_and_connect_one();




#ifdef __cplusplus
}
#endif

#pragma pack(0)



#endif /* zx_HAL_INTERFACE_H */



































