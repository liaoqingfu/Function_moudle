/*============================================================================
 Name        : bind_account_broadcast.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-11-21 
 Description : 
 ============================================================================*/

#include "base.h"
#include "comm_protocol_define.h"


#ifndef zx_BIND_ACCOUNT_BROADCAST_H
#define zx_BIND_ACCOUNT_BROADCAST_H

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

#define BROADCAST_PORT      (20173)
#define BORADCAST_MSG_LEN   (128)
#define WLAN_DEV_NAME       "eth2.2"
#define WLAN_DEV_WALN_NAME  "wlan0"


#define GOOGLEDNS           "8.8.8.8" //8.8.8.8
#define ALIDNS              "114.114.114.114"
#define DNS_PORT            (53)

#define XM_SERVER_PORT      (32293)

typedef void (*broadcast_process)(char* hub_info);


//input port
//return threadid
int send_boradcast(int port, char *sn, char *lan_ipaddr);
int receive_boradcast(int port, broadcast_process callback);
int zx_internet_detection(const char *ip);
void zx_stop_broadcase(void);
int zx_connect_xm_socket(const char *ip);
int zx_send_boradcast(int port, char *sn, char *lan_ipaddr);

#ifdef __cplusplus
}
#endif

#pragma pack(0)

#endif /* zx_BIND_ACCOUNT_BROADCAST_H */


