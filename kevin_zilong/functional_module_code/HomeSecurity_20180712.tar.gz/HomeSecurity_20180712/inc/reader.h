/*
 ============================================================================
 Name		: reader.h
 Author	  : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description : 
 ============================================================================
 */

#ifndef zx_READER_H
#define zx_READER_H

#include "base.h"

#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif

/*============================================================================*/
/* Declaration of Controllable Reader */

typedef int (*zx_Rd_FnAbort)(void * abortUserData, char * buf, size_t size);

enum
{
	zx_RD_OK = 0,
	zx_RD_ABORT_BY_CALLBACK,
	zx_RD_ABORT_BY_READAT
};

typedef struct _zx_Rd_Reader
{
	zx_File * file;
	zx_Off_T offset;

	int status;

	void * abortUserData;
	zx_Rd_FnAbort abortCallback;
} zx_Rd_Reader;

zx_Error zx_Rd_Reader_Open(zx_Rd_Reader * rdr, const char * localFileName);
void zx_Rd_Reader_Close(zx_Rd_Reader * rdr);
size_t zx_Rd_Reader_Callback(char * buffer, size_t size, size_t nitems, void * rdr);

#pragma pack()

#ifdef __cplusplus
}
#endif

#endif // zx_READER_H
