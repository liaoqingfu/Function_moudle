#ifndef _H_LIB_STREAM_H_
#define _H_LIB_STREAM_H_

#if defined (__cplusplus)
extern "C" {
#endif

#define 	DEBUG_7688_OP					0

//视频流通道
typedef enum{
	STREAM_VIDEO_TYPE_MAIN=0,				//(0)主码流
	STREAM_VIDEO_TYPE_SUB,					//(1)子码流 需要设备支持
	STREAM_VIDEO_TYPE_TRD					//(2)第三码流 需要设备支持
}XM_VIDEO_CHANNEL;

//返回值和错误码
typedef enum{
	XM_SUCCESS=0,							//(0)成功
	XM_PRINT_PARAM_ERR=10,					//(10)设置打印开关参数错误	
	XM_LANGUAGE_PARAM_ERR,					//(11)设置语言参数错误
	
	XM_NOINIT=101,							//(101)SDK库未初始化
	XM_INIT_BEINIT,							//(102)SDK库重复初始化
	XM_INIT_PARAM_ERR,						//(103)SDK库初始化参数错误
	XM_INIT_CAMERAPARAM_CHECK_ERR,			//(104)初始化摄像机参数检测模块失败
	XM_INIT_MCU_ERR,						//(105)初始化MCU模块失败
	XM_INIT_MCUHART_ERR,					//(106)初始化MCU心跳失败
	XM_INIT_AUDIOMANAGE_ERR,				//(107)初始化音频管理模块失败
	XM_INIT_KEYMANAGE_ERR,					//(108)初始化按键管理模块失败
	XM_INIT_CLIENT_BEINIT,					//(109)客户端模块重复初始化
	XM_INIT_CONFIG_PARAM_ERR,				//(110)配置文件参数错误
	XM_INIT_CONFIG_LOAD_ERR,				//(111)配置文件加载错误
	XM_INIT_SERVER_ERR,						//(112)初始化服务端失败
	XM_INIT_USERCHECK_ERR,					//(113)初始化用户检测模块失败
	XM_INIT_APCONNECTCHECK_ERR,				//(114)初始化网络监听模块失败
	XM_INIT_CAMERA_STATUS_CHECK_ERR,		//(115)初始化摄像机状态检测模块失败
	XM_INIT_SPEED_TEST_ERR,					//(116)初始化测速模块失败
	XM_INIT_TIMESYNE_ERR,					//(117)获取摄像机当前布防撤防状态
	XM_INIT_WAKEUP_CHECK_ERR=119,			//(119)初始化唤醒检测模块失败
	XM_INIT_VIDEODEBUG_ERR,					//(120)初始化视频调试模块失败
	
	XM_REGIST_PARAM_ERR=200,				//(200)注册回调参数错误
	
	XM_CMD_PARAM_ERR=300,					//(300)消息及信令参数错误
	XM_CMD_CONNECT_ERR,						//(301)消息及信令连接错误
	XM_CMD_SEND_ERR,						//(302)消息及信令发送失败
	XM_CMD_OPENDORR_PARAM_ERR,				//(303)开门信令参数错误
	XM_CMD_SET_FRAMERATE_PARAM_ERR, 		//(304)设置视频帧率参数错误
	XM_CMD_SET_H264GOP_PARAM_ERR,			//(305)设置I帧间隔参数错误 
	XM_CMD_SET_RESOLUTION_PARAM_ERR,		//(306)设置视频分辨率参数错误 
	XM_CMD_SET_BRIGHT_PARAM_ERR,			//(307)设置亮度参数错误
	XM_CMD_SET_CONTRAST_PARAM_ERR,			//(308)设置对比度参数错误
	XM_CMD_SET_SATURATION_PARAM_ERR,		//(309)设置饱和度参数错误
	XM_CMD_SET_HUE_PARAM_ERR,				//(310)设置色度参数错误
	XM_CMD_SET_SHARPNESS_PARAM_ERR, 		//(311)设置锐度参数错误 
	XM_CMD_SET_BITRATE_PARAM_ERR,			//(312)设置码率参数错误
	XM_CMD_SET_MODE_PARAM_ERR,				//(313)设置鱼眼模式参数错误
	XM_CMD_SET_MIRRORMODE_PARAM_ERR, 		//(314)设置视频翻转参数错误
	XM_CMD_SET_ROTATEMODE_PARAM_ERR,		//(315)设置视频旋转参数错误
	XM_CMD_SET_OSDMODE_PARAM_ERR,			//(316)设置OSD参数错误
	XM_CMD_SET_IRLEDMODE_PARAM_ERR,			//(317)设置红外灯模式参数错误
	XM_CMD_SET_PIRCTRL_PARAM_ERR,			//(318)设置PIR开关参数错误
	XM_CMD_SET_PIRSENSITIVITY_PARAM_ERR,	//(319)设置PIR灵敏度参数错误
	XM_CMD_SNAPSHORT_PARAM_ERR,				//(320)抓图参数错误
	XM_CMD_IRCURT_CHANGE_ERR,				//(321)IRCURT切换参数错误
	XM_CMD_POWERFREQ_CHANGE_ERR,			//(322)电源频率参数错误
	
	XM_AUDIO_PLAY_NOINIT=400,				//(400)声音(APP->CAMARA)播放模块未初始化
	XM_AUDIO_PLAY_PARAM_ERR,				//(401)声音(APP->CAMARA)播放参数错误
	XM_AUDIO_PLAY_NO_CONNECT,				//(402)声音(APP->CAMARA)播放通道未连接
	XM_AUDIO_PLAY_ERR,						//(403)声音(APP->CAMARA)播放回放失败
	
	XM_USER_STATUS_SET_ERR=500,				//(500)用户状态设置失败(唤醒休眠功能)
	XM_USER_STATUS_GETIP_ERR,				//(501)获取客户端IP失败
	
	XM_GET_DEVICE_MAC_PARAM_ERR=600,		//(600)获取网关MAC地址输入参数错误
	XM_GET_DEVICE_SSID_PARAM_ERR,			//(601)获取网关SSID输入参数错误
	XM_GET_DEVICE_SSID_ERR,					//(602)获取网关SSID失败
	XM_GET_WIRELESS_PARAM_ERR,				//(603)获取网络信息输入参数错误
	XM_GET_WIFILIST_PARAM_ERR,				//(604)获取WIFI列表输入参数错误
	XM_GET_WIFILIST_ERR,					//(605)获取WIFI列表失败
	XM_GET_NETLINK_PARAM_ERR,				//(606)获取网关与路由器连接状态输入参数错误
	XM_GET_NETLINK_SIGNAL_PARAM_ERR,		//(607)获取网关与路由器连接信号强度输入参数错误
	XM_GET_NETLINK_SIGNAL_ERR,				//(608)获取网关与路由器连接信号失败
	XM_GET_CAMERA_ONLINE_PARAM_ERR,			//(609)获取摄像机与网关连接状态输入参数错误
	XM_GET_CAMERA_VERSION_PARAM_ERR,		//(610)获取摄像机版本号输入参数错误
	XM_GET_VIDEO_MIRROR_ERR,				//(611)获取摄像机视频翻转状态失败
	XM_GET_CAMERA_IP_PARAM_ERR,				//(612)获取摄像机IP输入参数错误
	XM_GET_VIDEO_MIRROR_PARAM_ERR,			//(613)获取摄像机视频翻转状态输入参数错误
	XM_GET_VIDEO_ENCOERD_PARAM_ERR,			//(614)获取摄像机编码器信息输入参数错误
	XM_GET_VIDEO_ENCOERD_ERR,				//(615)获取摄像机编码器信息失败
	XM_GET_IRLED_MODE_PARAM_ERR,			//(616)获取红外灯模式输入参数错误
	XM_GET_IRLED_MODE_ERR,					//(617)获取红外灯模式失败
	XM_GET_PIRCTRL_PARAM_ERR,				//(618)获取PIR开关输入参数错误
	XM_GET_PIRCTRL_ERR,						//(619)获取PIR开关失败
	XM_GET_PIRSENSITIVITY_PARAM_ERR,		//(620)获取PIR灵敏度输入参数错误
	XM_GET_PIRSENSITIVITY_ERR,				//(621)获取PIR灵敏度失败
	XM_GET_MATCHINFO_PARAM_ERR,				//(622)获取配对信息输入参数错误
	XM_GET_SPEED_INFO_PARAM_ERR,			//(623)获取测速信息输入参数错误
	XM_GET_CMDCH_LINK_PARAM_ERR,			//(624)获取信令通道连接状态输入参数错误
	XM_GET_CMDCH_LINK_ERR,					//(625)获取信令通道连接状态失败
	
	XM_SOUND_WAVE_MODE_PARAM_ERR=700,		//(700)声波配网模式切换输入参数错误
	XM_SOUND_WAVE_MODE_ERR,					//(701)模式错误(已处于声波配网或摄像机配对模式)
	XM_SOUND_WAVE_PLAY_PARAM_ERR,			//(702)声波播放输入参数错误
	XM_SOUND_WAVE_MODE_ENGROSS,				//(703)声波模式下无法播放提示音(需要退出声波模式)
	XM_AUDIO_FILE_PLAY_PARAM_ERR,			//(704)播放音频文件输入参数错误
	
	XM_MODE_ENABEL_PARAM_ERR=750,			//(750)模式切换(摄像机配对或AP配网)输入参数错误
	XM_CONNECTAP_PARAM_ERR,					//(751)连接上级路由器输入参数错误
	XM_SEND_433SIGNAL_PARAM_ERR,			//(752)发送433信号输入参数错误
	XM_LED_CTRL_PARAM_ERR,					//(753)LED灯控制输入参数错误
	XM_CLEAR_MATCHINFO_PARAM_ERR,			//(754)清除配对信息参数输入错误
	XM_TIME_SYCN_PARAM_ERR,               	//(755)校时参数输入错误
	XM_TIME_SYNC_TIMEOUT,					//(756)校时超时
	XM_TIME_SYCN_ERR,						//(757)校时失败
	XM_SET_DEVPASS_PARAM_ERR,				//(758)设置网关密码参数错误
	
	XM_DSP_UPGRADE_TIMEOUT	= 780,			//(780)DSP升级超时	
	XM_DSP_UPGRADE_SEND_ERR,					//(781)DSP升级发送失败	
	
	XM_OPEN_TONE_FILE_ERR	= 790,			//(790)打开提示音文件失败
	XM_SEND_TONE_FILE_ERR,					//(791)发送提示音文件失败
	XM_INPUT_PARAM_ERR,						//(792)输入参数的错误
	XM_CAN_NOT_FIND_FD_ERR,					//(793)不能正确找到句柄
	XM_READ_TONE_FILE_ERR					//(793)读文件失败
	
}XM_ERRCODE;

//打印开关
typedef enum{
	XM_PRINT_CLOSE=0,						//(0)打印开关 关闭
	XM_PRINT_OPEN,							//(1)打印开关 开启
}XM_PRINT_SWITCH; 


//摄像机推送消息 
//消息通过message_callback接收
typedef enum{
	COMMON_TYPE_KEY_DOWN=20002,				//(20002)摄像机呼叫
	COMMON_TYPE_GET_WIFI_INFO=20005,		//(20005)摄像机请求配对
	COMMON_TYPE_TAMPER,						//(20006)防拆报警
	COMMON_TYPE_BATTERY_LEVEL,				//(20007)电池电量
	COMMON_TYPE_LOW_POWER,					//(20008)电池电量低
	COMMON_TYPE_EXTERNAL_POWER,				//(20009)外部电源接入
	COMMON_TYPE_PIR_TRIGGER,				//(20010)红外报警
	COMMON_TYPE_WIFI_INFO_ACK,				//(20011)摄像机配对成功确认
	COMMON_TYPE_GET_SIGNO_ACK,				//(20012)信号强度回复
	COMMON_TYPE_GET_UART_ACK=20014,			//(20014)DSP配置回复
	COMMON_TYPE_OPEN_DOOR_ACK=20117,		//(20117)开门指令回复
	COMMON_TYPE_DEVICE_POWEROFF,			//(20118)摄像机关机
	COMMON_TYPE_DEVICE_POWERON,				//(20119)摄像机开机
	COMMON_TYPE_BATTERY_FULL,				//(20120)摄像机电池已充满
	COMMON_TYPE_POWERREMOVE,				//(20121)外部电源移除
	COMMON_TYPE_ARM_STATUS,					//(20122)布防撤防状态
	COMMON_TYPE_PIRSENSITIVITY,				//(20123)PIR灵敏度
	COMMON_TYPE_PIRDELAY=20125,				//(20125)PIR触发确认次数(此接口预留)
	COMMON_TYPE_BATTERY_LEVEL_EX,			//(20126)电量检测(新接口)
	COMMON_TYPE_WAKEUP_RESP,				//(20127)唤醒回复
	COMMON_TYPE_POWERDOWN_RESP,	 			//(20128)休眠回复
	COMMON_TYPE_TIMESYNC_ACK,				//(20129)时间同步回复
	COMMON_TYPE_GET_GETMCUVER_ACK,			//(20130)获取MCU的版本信息回复
	COMMON_TYPE_GET_VERSION_ACK,			//(20131)获取DSO的版本信息回复
	COMMON_TYPE_GET_BASICINFO_ACK,			//(20132)获摄像机基本信息(分辨率，码流，帧率)
	COMMON_TYPE_SET_TONE_ACK,				//(20133)设置摄像机提示音文件回复
	COMMON_TYPE_SET_LANG_ACK				//(20134)设置摄像机提示音语言回复
}XM_MESSAGE_TYPE;


//以下是利用XMHAL_SendCmd发送摄像机的配置/获取参数的命令字段
typedef enum{ 
	//从COMMON_TYPE_DSP_START~COMMON_TYPE_SNAPSHORT 是通过message_callback 接收 COMMON_TYPE_GET_UART_ACK 消息
	//然后从msgdata中取出XM_DSP_REPORT结构 
	//结构中的type值则对应下面的消息值
	COMMON_TYPE_DSP_START=10000,			//(10000)DSP启动
	COMMON_TYPE_INSERT_IFRAME,				//(10001)强插I帧
	COMMON_TYPE_OPEN_DOOR,					//(10002)开锁(需要对接门锁)
	COMMON_TYPE_SET_FRAMERATE=10009,		//(10009)视频帧率
	COMMON_TYPE_SET_H264GOP,				//(10010)视频I帧间隔
	COMMON_TYPE_SET_RESOLUTION,				//(10011)视频分辨率
	COMMON_TYPE_SET_BRIGHT,					//(10012)视频亮度
	COMMON_TYPE_SET_CONTRAST,				//(10013)视频对比度
	COMMON_TYPE_SET_SATURATION,				//(10014)视频饱合度
	COMMON_TYPE_SET_HUE,					//(10015)视频色度
	COMMON_TYPE_SET_SHARPNESS,				//(10016)视频锐度
	COMMON_TYPE_SET_BITRATE,				//(10017)视频码率
	COMMON_TYPE_RESET_FACTORY=10030,		//(10030)恢复出厂	
	COMMON_TYPE_MODE_CHANGE=10032,			//(10032)鱼眼模式切换
	COMMON_TYPE_FECSAVEPARAM,				//(10033)圆心校正参数保存
	COMMON_TYPE_SET_MIRROR,					//(10034)视频翻转状态
	COMMON_TYPE_SET_ROTATE,					//(10035)设置视频旋转
	COMMON_TYPE_SET_OSDMODE,				//(10036)OSD模式设置 
	COMMON_TYPE_SET_MDETECT,				//(10037)移动侦测参数
	COMMON_TYPE_SET_IRLEDMODE,				//(10038)红外模式
	COMMON_TYPE_SET_POWERFREQ=10040,		//(10040)电源刷新频率	
	COMMON_TYPE_SNAPSHORT=10050,			//(10050)抓图
	COMMON_TYPE_OPEN_CAMERALOG,				//(10051)摄像头日志开启
	COMMON_TYPE_SET_MICGAIN,				//(10052)设置摄像头mic增益
	COMMON_TYPE_SET_SPKGAIN,				//(10053)设置摄像头speaker增益
	COMMON_TYPE_SET_LANG,					//(10054)设置摄像头提示音语言
	//
	//从COMMON_TYPE_GET_SIGNO~COMMON_TYPE_GET_PIRDELAY  在message_callback 返回的命令字段对应 XM_MESSAGE_TYPE 枚举了对应返回结果。
	//其中COMMON_TYPE_SET_ARMING，COMMON_TYPE_SET_PIRSENSITIVITY，COMMON_TYPE_SET_PIRDELAY 是等设置是无反馈信息的，如想获知反馈
	//结果需要通过对应的主动查询命令字段或者摄像机主动推送过来的对应命令知晓。
	//
	COMMON_TYPE_GET_SIGNO=20501,			//(20501)获取摄像机与网关信号强度 				(返回消息-->	COMMON_TYPE_GET_SIGNO_ACK)
	COMMON_TYPE_SET_ARMING,					//(20502)设置布防撤防状态(PIR开关)				(此消息只是发送命令，并不获知配置成功与否)
	COMMON_TYPE_GET_ARMSTATUS,				//(20503)获取布防撤防状态(PIR开关) 				(返回消息-->	COMMON_TYPE_ARM_STATUS)
	COMMON_TYPE_GET_BATTERY,				//(20504)获取电池电量							(返回消息-->	COMMON_TYPE_BATTERY_LEVEL_EX)
	COMMON_TYPE_SET_PIRSENSITIVITY,			//(20505)设置PIR灵敏度						(此消息只是发送命令，并不获知配置成功与否)
	COMMON_TYPE_GET_PIRSENSITIVITY,			//(20506)获取PIR灵敏度						(返回消息-->	COMMON_TYPE_PIRSENSITIVITY)
	COMMON_TYPE_TIME_SYNC,					//(20507)校时								(返回消息-->	COMMON_TYPE_TIMESYNC_ACK)
	COMMON_TYPE_UNBOND_CAM,					//(20508)解绑摄像机(预留暂不支持)				(此消息只是发送命令，并不获知配置成功与否)
	COMMON_TYPE_RECORD_RELAY,				//(20509)保持视频连接(用于事件触发保活视频)		(返回消息-->	COMMON_TYPE_TIMESYNC_ACK)
	COMMON_TYPE_SET_PIRDELAY,				//(20510)设置PIR触发确认次数					(此消息只是发送命令，并不获知配置成功与否,此接口预留)
	COMMON_TYPE_GET_PIRDELAY,				//(20511)获取PIR触发确认次数					(返回消息-->	COMMON_TYPE_PIRDELAY,此接口预留)
	COMMON_TYPE_GET_GETMCUVER				//(20512)获取MCU版本信息						(返回消息-->	COMMON_TYPE_GET_GETMCUVER_ACK)
}XM_DSP_CONFIG;

//卡片机支持
#define COMMON_TYPE_START_VIDEO				30001		//开始视频(仅卡片机)
#define COMMON_TYPE_STOP_VIDEO				30002		//结束视频(仅卡片机)

//产测命令
//通过XMHAL_SendCmd接口下发
typedef enum{
	COMMON_TYPE_SPEED_START=10003,			//(10003)开始测速
	COMMON_TYPE_SPEED_STOP,					//(10004)停止测速
	COMMON_TYPE_SET_MICVOL=10007,			//(10007)设置3200麦增益(已停用)
	COMMON_TYPE_SET_SPEEKVOL,				//(10008)设置3200喇叭增益(已停用)
	COMMON_TYPE_IRCUT_CHANGE=10041,			//(10041)IRCUT切换
	COMMON_TYPE_AGEING=10051				//(10051)设置3200进入老化模式
}XM_PRODUCTION_TEST;

//布防撤防状态(PIR开关)
typedef enum{
	XM_DISARMED=0,							//(0)撤防
	XM_ARMING								//(1)布防
}XM_ARM_STATUS;

//PIR报警确认次数
typedef enum{
	XM_PIR_DELAY_TIME_1=0,					//(0)1次
	XM_PIR_DELAY_TIME_2,					//(1)2次
	XM_PIR_DELAY_TIME_3,					//(2)3次
	XM_PIR_DELAY_TIME_4						//(3)4次
}XM_PIR_DELAY;

//分辨率
typedef enum{
	XM_RESOLUTION_1080P=0x60,				//(0x60)1920x1080
	XM_RESOLUTION_960P,						//(0x61)1280x960
	XM_RESOLUTION_720P,						//(0x62)1280x720
	XM_RESOLUTION_576P,						//(0x63)720x576
	XM_RESOLUTION_480P,						//(0x64)720x480
	XM_RESOLUTION_360P,						//(0x65)640x360
	XM_RESOLUTION_288P,						//(0x66)352x288
	XM_RESOLUTION_240P						//(0x67)360x240
}XM_RESOLUTION;

//视频翻转状态
typedef enum{
	XM_VIDEO_MIRRMODE_NORMAL=0,				//(0)不翻转
	XM_VIDEO_MIRRMODE_HORIZONTALLY,			//(1)水平
	XM_VIDEO_MIRRMODE_VERTICALLY,			//(2)垂直
	XM_VIDEO_MIRRMODE_HORIZVERTI			//(3)水平垂直
}XM_MIRROR;

//视频旋转
typedef enum{
	XM_VIDEO_ROTATEMODE_0=0,				//(0)不旋转
	XM_VIDEO_ROTATEMODE_90,					//(1)90度旋转
	XM_VIDEO_ROTATEMODE_180,				//(2)180度旋转
	XM_VIDEO_ROTATEMODE_270					//(3)270度旋转
}XM_ROTATE;

//OSD模式
typedef enum{
	XM_VIDEO_OSDMODE_NO=0,					//(0)不显示OSD
	XM_VIDEO_OSDMODE_ONLYTIME,				//(1)仅显示时间
	XM_VIDEO_OSDMODE_ALL					//(2)显示时间+logo
}XM_OSDMODE;

//红外灯模式
typedef enum{
	XM_IRLEDMODE_OFF=0,						//(0)关闭
	XM_IRLEDMODE_AUTO,						//(1)自动
	XM_IRLEDMODE_ON							//(2)开启
}XM_IRLEDMODE;

//抓图
typedef struct _snapshot{ 
	unsigned int eventtype;					// 0:APP触发(默认填写) 1:pir触发 2:移动侦测触发
	unsigned int number;  					// 抓图张数 默认1张 
	unsigned int quality;					// 抓图质量 0:默认 1:高 2:中 3:低
	unsigned int intervalTime;  			// 抓图间隔 ms 默认1000
	unsigned int width;						// 分辨率 宽
	unsigned int height;					// 分辨率 高
	unsigned int reciver;  					// 保留
}XM_SNAPSHORT;

//IRCUT切换模式
typedef enum{
	XM_IRCUT_DAY=2,							//(2)白天模式
	XM_IRCUT_NIGHT							//(3)夜晚模式
}XM_IRCUT_MODE;

//音频管理命令类
typedef enum{
	AUDIO_CONFIG_START=0x10,				//(0x10)开启识别声波配网数据 (独占 开启后不能播放提示音)
	AUDIO_CONFIG_STOP,						//(0x11)停止识别声波配网数据
	AUDIO_CONFIG_VPLAYER,					//(0x12)启动虚拟播放器(将字符串转为声波)
	AUDIO_CONFIG_PLAYFILE=0x14				//(0x14)播放指令音频文件
}XM_AUDIO_CONFIG;

//音频文件类型
typedef enum{
	AUDIO_FILETYPE_PCM=0,					//(0)PCM
	AUDIO_FILETYPE_WAV,						//(1)WAV
	AUDIO_FILETYPE_OPUS						//(2)OPUS
}XM_AUDIO_FILE_TYPE;

//设备信息
typedef enum{
	DEVICE_INFO_MAC=0x20,					//(0x20)MAC地址
	DEVICE_INFO_LED_RED,					//(0x21)LED-RED
	DEVICE_INFO_LED_BLUE,					//(0x22)LED-BLUE
	DEVICE_INFO_WIFI_CHANNEL=0x24,			//(0x24)WIFI信道
	DEVICE_INFO_WIFI_STRENGTH				//(0x25)WIFI信号强度
}XM_DEVIVE_INFO;


//摄像机配对和AP配网
typedef enum{
	MODE_TYPE_CAMERA_PAIR,					//(0x40)摄像机配对
	MODE_TYPE_AP_CONFIG						//(0x41)AP配网模式
}XM_PAIR_MODE;


//摄像机配对和AP配网开关
typedef enum{
	MODE_CHANGE_OPEN=1,						//(1)开启
	MODE_CHANGE_CLOSE						//(2)关闭
}XM_PAIR_CTRL;


//摄像机在线状态
typedef enum{
	CAMERA_CONNECT_FAILD=0,					//(0)摄像机未连接到网关
	CAMERA_CONNECT_SUCCESS					//(1)摄像机已连接到网关
}XM_CAMERA_STATUS;

//视频调试信息
typedef enum{
	XM_VDEBUG_TYPE_FRAMERATE=0,				//(0)实时帧率
	XM_VDEBUG_TYPE_LOSTFRAME,				//(1)丢帧
	XM_VDEBUG_TYPE_FRAMERATEABERRANT		//(2)帧率异常
}XM_VIDEO_DEBUG;

//摄像机DSP升级
typedef enum{
	UPGRADE_ING=0,						//(0)正在升级
	UPGRADE_FAILED,						//(1)升级失败
	UPGRADE_OK,							//(2)升级成功
}XM_CAMERA_UPRADE;

typedef enum{
	UPDATE_TYPE_SYS=2,					//升级系统
	UPDATE_TYPE_UBOOT,					//升级Uboot
	UPDATE_TYPE_APP,					//升级应用
	UPDATE_TYPE_SUB1G					//升级SUB1G
}XM_CAMERA_UPGRADETYPE;

typedef enum
{
	LIB_LOG,						//库的日志
	CAMERA_LOG						//摄像头日志
}XM_LOG_MODULE_TYPE;

typedef enum
{
	NO_LEVEL_LOG,					//不打印
	INFO_LEVEL_LOG,					//普通打印信息
	WARRING_LEVEL_LOG,				//警告打印信息
	ERROR_LEVEL_LOG					//错误打印信息
}XM_LOG_LV_TYPE;

typedef enum
{
	ADDCAM_TONE=1,				//添加摄像头
	ALARM_1_TOME,				//报警铃声1
	ALARM_2_TOME,				//报警铃声2
	PAIR_TONE,					//启动配对
	LOWPWR_TONE,				//低电量
	TURNOFF_TONE				//关闭摄像头
}XM_TONE_TYPE;

typedef enum
{
	CN_TONE=1,				//中文
	EN_TOME,				//英文
}XM_TONE_LAN_TYPE;


#pragma pack(1)
//摄像机请求配对消息回复
typedef struct _wifiinfo{
	char	type;							//加密方式  1-OPEN 2-AES 3-psk2 
	char	ssid[32];						//网关ssid
  	char	key[64];						//网关密码
	char	reserve;						//保留
	int 	ip;								//网关分配给设备的IP
	int		dhcp;							//0:禁止DHCP 1:开启DHCP
}XM_WIFI_INFO;
#pragma pack()

//收到报警信号后摄像机询问是否需要录像(保持摄像机上电状态)
typedef struct _recordinfo{
	char type;								//是否录像(保持上电) 0 不录像  1 需要录像
	char video;								//保留
	char audio;								//保留 
	char reserve;							//保留
}XM_RECORD_INFO;


//摄像机版本信息                                        
typedef struct _cameraversion{
	char masterhardversion[32];				//主控模块硬件版本号
	char mastersoftversion[32];				//主控模块软件版本号
	char id[32];							//摄像机ID或序列号
	char dsphardversion[32];				//DSP硬件版本号
	char dspsoftversion[32];				//DSP软件版本号
}XM_CAMERA_VERSION;

//DSP配置回复 (通过 XMHAL_SendCmd 接口下发的配置或获取指令均返回该结构)
typedef struct _uart_ack{
	int type;								//命令字
	int result;								//反馈结果  0 成功 1 失败
}XM_DSP_REPORT;

//摄像机配对信息(当前版本支持4路)
typedef struct _matchdata{
	char mac[18];							//mac地址
	char ip[16];							//ip地址
	int channel;							//通道号
	int status;								//通道是否配对(0 未配对 1 已配对)
}XM_CAMERA_MATCH_DATA;

typedef struct _matchinfo{
	int matchnum;							//已配对摄像机个数
	XM_CAMERA_MATCH_DATA m_data[16];		//配对摄像机列表
}XM_CAMERA_MATCH_LIST;

typedef struct batteryinfo
{
	int bat; 								//电池电量百分比,如果设备无法提供，该值为-1.例如50，表示50%
	int vol; 								//电池电压，如果设备无法提供，该值为-1。例如43表示 4.3v
	char devmode[16]; 						//设备型号
}XM_CAMERA_BATTER_STRU;

typedef struct Camparaminfo
{
	unsigned char Mirror;			//0(正常) 1(水平) 2(垂直) 3(水平垂直)
	unsigned char OsdMode;			//0(无) 1(只显示时间,默认值) 2(显示时间,帧率和码率)
	unsigned char IrLedAuto;		//0(关闭) 1(自动) 2(开启)
	unsigned short bitrate;			//视频码流
	unsigned short fps;				//֡视频帧率
	unsigned short width;			//视频高度
	unsigned short height;			//视频高度
	unsigned short speak_gain;		//喇叭增益
	unsigned short mic_gain;		//mic增益
	
}XM_CAMERA_BASIC_STRU;


/******************************************************** 
	视频回调                                              
	buff             视频数据                             
	size             数据大小                             
	stream_type      视频流格式                           
	                 IAV_ENCODE_H264(1)                   
	                 IAV_ENCODE_MJPEG(2)                  
	frame_type       帧类型                               
	                 1为I帧 非1为P帧                      
	width            宽度                                 
	height           高度                                 
	ntimestamp       时间戳                               
	channel          通道                                 
	reserve          保留                                 
********************************************************/
typedef int (*videocallback)(char *buff, int size, int stream_type, int frame_type, int frame_rate,
	                         int width, int height, long long ntimestamp, int channel, long reserve);

/******************************************************** 
	音频回调                                              
	buff			 音频数据                             
	size             数据大小                             
	ntimestamp       时间戳                               
	channel          通道号                               
	reserve          保留                                 
********************************************************/
typedef int (*audiocallback)(char *buff, int size, long long ntimestamp, int channel, long reserve);

/******************************************************** 
	抓图图片回调                                          
	buff			 图片数据(jpg)                        
	size             数据大小                             
	ntimestamp       时间戳(秒)                           
	channel          通道号                               
	reserve          保留                                 
********************************************************/
typedef int (*imgcallback)(char *buff, int size, int channel,long long ntimestamp,long reserve);

/******************************************************** 
    消息推送回调                                          
	msgtype          消息类型                             
	msgdata          消息数据                             
	channel          通道号                               
	reserve          保留                                 
********************************************************/
typedef int (*msgcallback)(int msgtype, char *msgdata, int channel, long reserve);

/******************************************************** 
    摄像机唤醒结果回调                                    
	result            唤醒结果                            
********************************************************/
typedef int (*wakeupstatuscallback)(int channel, int result, long reserve);

/******************************************************** 
    摄像机接受外部命令准备的回调                                    
	result            通道号                           
********************************************************/
typedef int (*CmdReadycallback)(int channel, long reserve);

/******************************************************** 
    摄像机与网关视频传输调试信息回调(丢帧及帧率异常)      
	type              类型(0 帧率 1 丢帧 1 帧率异常)      
 	data1			  帧率      当前帧率                  
 					  丢帧:     当前帧号                  
	                  帧率异常: 当前帧率                  
	data2             丢帧:     上帧帧号                  
	                  帧率异常: 编码器帧率                
********************************************************/
typedef int (*framedebugcallback)(int channel, int type, int data1, int data2, long reserve);


/******************************************************** 
    升级摄像头DSP模块     
	State             升级状态(参考XM_CAMERA_UPRADE) 
 	ErrCode			  错误码（参考XM_ERRCODE）
	reserve           预留字段                
********************************************************/
typedef int (*UpdateDspcallback)(unsigned int State,unsigned int ErrCode,long reserve);

/******************************************************** 
    日志获取的回调函数定义    
	plogstr           日志字符串 
 	size			  字符串长度
	logtype           日志模块类型
	lvtype			  打印信息等级
	reserve           预留字段    
********************************************************/
typedef int (*logcallback)(char *plogstr, int size, XM_LOG_MODULE_TYPE logtype,XM_LOG_LV_TYPE lvtype, long reserve);

/******************************************************** 
	funcname:     XMHAL_getlibversion                     
	Description:  get lib version                         
	              Anywhere can be called                  
	intput:                                               
	output:                                               
********************************************************/
char *XMHAL_getlibversion();

/******************************************************** 
	funcname:     XMHAL_Print                             
	Description:  open or close lib print                 
	              Anywhere can be called                  
	intput:                                               
	output:                                               
********************************************************/
int XMHAL_Print(XM_PRINT_SWITCH flag);

/******************************************************** 
	funcname:     XMHAL_Print_avinfo                      
	Description:  open or close avinfo print              
				  Anywhere can be called                  
	intput:                                               
	output:                                               
********************************************************/
int XMHAL_Print_avinfo(XM_PRINT_SWITCH flag);

/******************************************************** 
	funcname:     XMHAL_Init                              
	Description:  init xm_av lib                          
	intput:       eth_name                                
				  audio_flag                              
	              talk_flag                               
	              conf_path                               
	output:                                               
********************************************************/
int XMHAL_Init(char *eth_name, int audio_flag, int talk_flag, char *conf_path);

/******************************************************** 
	funcname:     XMHAL_Deinit                            
	Description:  deinit xm_av lib                        
	intput:                                               
	output:                                               
********************************************************/
int XMHAL_Deinit();

/******************************************************** 
	funcname:     XMHAL_RegistsVideo                      
	Description:  regist video callbackfunc               
	intput:       callbackfunc                            
	              channel                                 
	              streamtype                              
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistVideo(videocallback callback, int channel, XM_VIDEO_CHANNEL stream_type, long reserv);

/******************************************************** 
	funcname:     XMHAL_RegistAudio                       
	Description:  regist audio callbackfunc               
	intput:       callbackfunc                            
	              channel                                 
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistAudio(audiocallback callback, int channel, long reserv);

/******************************************************** 
	funcname:     XMHAL_RegistImgage                       
	Description:  regist image callbackfunc               
	intput:       callbackfunc                            
	              channel                                 
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistImgage(imgcallback callback, int channel, long reserv);


/******************************************************** 
	funcname:     XMHAL_RegistMsg                         
	Description:  regist msg callbackfunc                 
	intput:       callbackfunc                            
	              channel                                 
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistMsg(msgcallback callback, int channel, long reserv);

/******************************************************** 
	funcname:     XMHAL_RegistWakeupResult                
	Description:  regist wakeup result callbackfunc       
	intput:       callbackfunc                            
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistWakeupResult(wakeupstatuscallback callback, long reserv);
/******************************************************** 
	funcname:     XMHAL_RegistTransparentCmdReady                
	Description:  regist ready transparent cmd result callbackfunc       
	intput:       callbackfunc                            
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistTransparentCmdReady(CmdReadycallback callback, long reserv);

/******************************************************** 
	funcname:     XMHAL_Registvideodebug                  
	Description:  regist video debug callbackfunc         
	intput:       callbackfunc                            
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_Registvideodebug(framedebugcallback callback, long reserv);

/******************************************************** 
	funcname:     XMHAL_RegistLogProc                  
	Description:  regist get log callbackfunc         
	intput:       callbackfunc                            
	              reserv                                  
	output:                                               
********************************************************/
int XMHAL_RegistLogProc(logcallback callback, long reserv);

/******************************************************** 
	funcname:     XMHAL_SendCmd                           
	Description:  send cmd to devive                      
	intput:       type                                    
	              data                                    
	              channel                                 
	output:                                               
********************************************************/
int XMHAL_SendCmd(int type, char *data, int channel);

/******************************************************** 
	funcname:     XMHAL_AudioPlay                         
	Description:  play audio                              
	intput:       buff                                    
	              size                                    
	              channel                                 
	output:                                               
********************************************************/
int XMHAL_AudioPlay(char *buff, int size, int channel);

/******************************************************** 
	funcname:     XMHAL_UserOnline                        
	Description:  set user status(wake up or power down)  
	intput:       val                                     
	              channel                                 
	output:                                               
********************************************************/
int XMHAL_UserOnline(int val, int channel);

/******************************************************** 
	funcname:     XMHAL_GetCameraOnlineStatus             
	Description:  get camera connect to gateway status    
	intput:       status                                  
	              channel                                 
	output:       status                                  
********************************************************/
int XMHAL_GetCameraOnlineStatus(XM_CAMERA_STATUS *status, int channel);

/******************************************************** 
	funcname:     XMHAL_GetCameraIp                       
	Description:  get camera ip                           
 	intput:       ip (char getip[16])                     
	output:       ip                                      
********************************************************/
int XMHAL_GetCameraIp(char *ip, int channel);

/******************************************************** 
	funcname:     XMHAL_GetVideoMirrorMode                
	Description:  get video mirror mode                   
	intput:       mode                                    
	              channel                                 
	output:       mode                                    
********************************************************/
int XMHAL_GetVideoMirrorMode(XM_MIRROR *mode, int channel);

/******************************************************** 
	funcname:     XMHAL_GetVideoEncordInfo                
	Description:  get video encord info                   
	intput:       fps                                     
	              bitrate                                 
	              width                                   
	              height                                  
	output:       status                                  
********************************************************/
int XMHAL_GetVideoEncordInfo(int *fps, int *bitrate, int *width, int *height, int channel);

/******************************************************** 
	funcname:     XMHAL_GetIrLedMode                      
	Description:  get ir led mode                         
	intput:       mode                                    
	              channel                                 
	output:       mode                                    
********************************************************/
int XMHAL_GetIrLedMode(XM_IRLEDMODE *mode, int channel);

/******************************************************** 
	funcname:     XMHAL_GetMatchInfo                      
	Description:  get camera match info                 
	intput:       m_info                                  
	intput:       m_info                                  
********************************************************/
int XMHAL_GetMatchInfo(XM_CAMERA_MATCH_LIST *m_info);

/******************************************************** 
	funcname:     XMHAL_GetSpeedTestInfo                  
	Description:  get speed test info (only in speedtest) 
	intput:       current_speed                           
				  max_speed                               
	              min_speed                               
 	              ave_speed                               
	              totol_package                           
	              lost_package                            
	              channel                                 
	intput:       current_speed                           
				  max_speed                               
	              min_speed                               
 	              ave_speed                               
	              totol_package                           
	              lost_packag                             
********************************************************/
int XMHAL_GetSpeedTestInfo(int *current_speed, int *max_speed, int *min_speed,
                           int *ave_speed, int *totol_package, int *lost_package,
                           int channel);

/******************************************************** 
	funcname:     XMHAL_GetCmdLinkStatus                  
	Description:  get cmd channel link status             
	intput:       status                                  
	              channel                                 
	output:       status                                  
********************************************************/
int XMHAL_GetCmdLinkStatus(int *status, int channel);

/******************************************************** 
	funcname:     XMHAL_ModeEnable                        
	Description:  open or close camera-pair or APconfig   
 	intput:       type                                    
	              val                                     
	output:                                               
********************************************************/
int XMHAL_ModeEnable(XM_PAIR_MODE type, XM_PAIR_CTRL val);

/******************************************************** 
	funcname:     XMHAL_GetCameraBasicInfo              
	Description:  get 3518e basic infomation （resolution,bitrate....）     
	intput:       channel
	output:                                                
********************************************************/
int XMHAL_GetCameraBasicInfo(int channel);

/******************************************************** 
	funcname:     XMHAL_GetDSPVersion              
	Description:  get 3518e firmware version     
	intput:       channel
	output:                                                
********************************************************/
int XMHAL_GetDSPVersion(int channel);

/******************************************************** 
	funcname:     XMHAL_MatchDev              
	Description:  band camera with gateway     
	intput:       IPAddr                                    
	              pMacAddr
				  MacLen
	output:       channel                                         
********************************************************/
int XMHAL_MatchDev(int IPAddr,char* pMacAddr,int MacLen);

/******************************************************** 
	funcname:     XMHAL_ClearCameraMatchInfo              
	Description:  clear all or one channel matchinfo      
	intput:       type                                    
	              channel                                 
	output:                                               
********************************************************/
int XMHAL_ClearCameraMatchInfo(int type, int channel);

/******************************************************** 
	funcname:     XMHAL_TimeSync                          
	Description:  sync current time to camara           
	intput:       channel                                 
	output:                                               
********************************************************/
int XMHAL_TimeSync(int channel);

/******************************************************** 
	funcname:     XMHAL_SendToneFile                          
	Description:  Send Tone file to 3518e        
	intput:       channel          
				  pfilePath
				  ToneId
	output:                                               
********************************************************/
int  XMHAL_SendToneFile(int channel,char* pfilePath,XM_TONE_TYPE ToneId);

/******************************************************** 
	funcname:     XMHAL_ReleaseChannle                          
	Description:  close channel  socket          
	intput:       channel                                 
	output:                                               
********************************************************/
int XMHAL_ReleaseChannle(int channel);

/******************************************************** 
	funcname:     XMHAL_UpdateDSPMoudule                          
	Description:  upgrade camera DSP moudule         
	intput:       channel                           
				  pfilePath
				  firmwaretype
				  UpdateCbFnc	
				  reserve
	output:                                               
********************************************************/
int XMHAL_UpdateDSPMoudule(int channel,char* pfilePath,int firmwaretype,UpdateDspcallback UpdateCbFnc,long reserve);
#if defined (__cplusplus)
}
#endif

#endif

