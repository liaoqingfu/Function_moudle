#ifndef NTPCLIENT_H
#define NTPCLIENT_H

/* when present, debug is a true global */

#define ENABLE_DEBUG 1

#ifdef ENABLE_DEBUG
extern int debug;
#else
#define debug 0
#endif

#define USATIMESERVERURL	"time.nist.gov"			//美国标准技术院
#define CHINATIMESERVERURL	"www.time.ac.cn"		//中科院国家授时中心时间
#define ALITIMESERVERURL	"ntp1.aliyun.com"			//美国标准技术院


/* global tuning parameter */
extern double min_delay;

/* prototype for function defined in phaselock.c */
int contemplate_data(unsigned int absolute, double skew, double errorbar, int freq);

int zx_hisi_time_calibration();


#endif
