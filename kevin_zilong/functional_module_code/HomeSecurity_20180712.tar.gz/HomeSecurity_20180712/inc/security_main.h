/*============================================================================
 Name        : security_main.h
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-11-21 
 Description :
 ============================================================================*/

#ifndef zx_SECURITY_MAIN_H
#define zx_SECURITY_MAIN_H

#include <pthread.h>
#include "base.h"



#pragma pack(1)

#ifdef __cplusplus
extern "C"
{
#endif


typedef enum
{
	BROADCAST = 1,
	P2P_LISTEN,
    P2P_COMMAND_SEND,
    P2P_COMMAND_REC,
    P2P_VIDEO_SEND,
	P2P_VIDEO_REC,
    P2P_AUDIO_SEND,
    P2P_AUDIO_REC,
    PUSH_MSG,
    DEV_COMMAND_REC,
    DEV_VIDEO_REC,
    DEV_VIDEO_SEND,
    DEV_AUDIO_REC,
    DEV_AUDIO_SEND    
}THREAD_TYPE;

typedef struct thread_list
{
	int pthread_id;
    
}THREAD_LIST;




#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_SECURITY_MAIN_H */
