/*
 ============================================================================
 Name        : ppcs_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-10-30 
 Description :
 ============================================================================
 */

#ifndef zx_PPCS_INTERFACE_H
#define zx_PPCS_INTERFACE_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <openssl/rsa.h>

#include "base.h"
#include "PPCS/PPCS_API.h"
#include "PPCS/PPCS_Error.h"
#include "sys_interface.h"

#pragma pack(1)

#define READ_TIME_OUT       (10000)

#ifdef __cplusplus
extern "C"
{
#endif

#define MAX_P2P_BUF_SIZE  (512*1024)
#define MAX_P2P_BUF_256K  (256*1024)
#define MAX_P2P_BUF_1M    (1024*1024)
#define MAX_P2P_BUF_2M    (2048*1024)

typedef struct p2p_connect_info
{
	int          session_handle; 
	int          video_pipe[2];
	int          audio_pipe[2];
	//int media_send_msgid;     
	short        channel; 
	void         *video_queue;	
	void         *audio_queue; 	             
	st_PPCS_Session session_info;
	RSA          *rsa_pubkey;
}P2P_CONNECT_INFO;

int zx_init_p2p_server(P2P_CONNECT_INFO *list, HUB_BASE_PARAM *base_param, int shared, char *lan_ipaddr);
int zx_deinit_p2p_server(void);
int zx_p2p_send_media(int channel, void *data, int data_len);
int zx_write_notify(int channel, uint8_t *data, int data_len, int session_id);

P2P_CONNECT_INFO* zx_get_p2p_connect_info();
int zx_update_p2p_channel_by_session(int session_id, int channel);
int zx_get_dev_sn_by_channel(int channel, char *value);
int zx_get_dev_name_by_channel(int channel, char *value);
int * zx_get_p2p_pipe_by_session(int session_id, int type);
int zx_get_p2p_session_by_channel(int channel);
char *get_p2p_err_info(int err);
int zx_download_data_send(char *data, UINT32 data_len, int session_id);


#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_PPCS_INTERFACE_H */
