/*
 ============================================================================
 Name        : sub1g_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-28 
 Description :
 ============================================================================
 */

#ifndef _SUB1G_INTERFACE_H
#define _SUB1G_INTERFACE_H

#include "base.h"
#include "sys_interface.h"


#define HISI_ALLOW_BIND_TIME_OUT   (120*1000)

#pragma pack(1)

typedef enum 
{
	PIR_SENSITIVITY_LOW   = 1,
	PIR_SENSITIVITY_HIGH,	
}HISI_PIR_SENSITIVITY;


#ifdef __cplusplus
extern "C"
{
#endif


int zx_hisi_send_command(int command_type, int channel, int value, int value1);


	
#ifdef __cplusplus
};
#endif

#pragma pack()

#endif
