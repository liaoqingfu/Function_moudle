/*
 ============================================================================
 Name        : encrypt_decrypt.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description :
 ============================================================================
 */

#ifndef zx_ENCRYPT_DECRYPT_H
#define zx_ENCRYPT_DECRYPT_H

#include <openssl/rsa.h>
#include <openssl/aes.h>
#include "base.h"

#ifdef __cplusplus
extern "C"
{
#endif

const char *zx_MD5_HexStr(const char *src);

int int_aes_encryptkey(char *password, AES_KEY *aes_key);
int int_aes_decryptkey(char *password, AES_KEY *aes_key);
int aes_encrypt(AES_KEY *encryptkey, unsigned char *in_data, int data_len, unsigned char *out_data);
int aes_decrypt(AES_KEY *decryptkey, unsigned char *in_data, int data_len, unsigned char *out_data);

RSA* rsa_get_pubKey(char* rsa_n);
int rsa_encrypt(RSA *pubKey, unsigned char* from, unsigned char* to);

#ifdef __cplusplus
}
#endif

#endif // zx_TIME_H



