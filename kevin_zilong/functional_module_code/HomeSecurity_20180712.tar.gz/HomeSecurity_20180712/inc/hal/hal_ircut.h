#ifndef     __HAL_IRCUT_H__
#define     __HAL_IRCUT_H__

#ifdef	__cplusplus
extern "C" { 
#endif

typedef enum  hal_IRCUT_CTRL_E
{
	IRCUT_CTRL_OFF = 0,
	IRCUT_CTRL_ON  ,
	IRCUT_CTRL_BUTT
}HAL_IRCUT_CTRL_E;

/*
ircut模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_ircut_init(void);

/*
控制ircut模块
参数：ircut_ctrl 0是关，1是开
成功返回 0 ，失败返回其他
*/
int hal_ircut_ctrl(HAL_IRCUT_CTRL_E ircut_ctrl);

/*
ircut模块去初始化
参数：无
返回值：无
*/
void hal_ircut_deinit(void);



#ifdef __cplusplus
}
#endif	

#endif

