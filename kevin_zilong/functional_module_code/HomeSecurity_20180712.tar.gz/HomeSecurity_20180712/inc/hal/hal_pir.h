#ifndef     __HAL_PIR_H__
#define     __HAL_PIR_H__

#ifdef	__cplusplus
extern "C" { 
#endif

/*
参数说明: ch  被触发的PIR 位置数 [0-2]
*/
typedef     void (*pir_detect_cb)(int ch);

/*
pir模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_pir_init(void);

/*
pir设置灵敏度
参数：PirNum pir位置数 0，1，2   3颗pir
参数：sensivity 灵敏度 [0-7],等级越高越灵敏
成功返回 0 ，失败返回其他
不支持独立设置3个PIR各自的灵敏度，只能是同样的灵敏度。参数传0即可。
*/
int hal_pir_set_sensivity(char PirNum, int sensivity);

/*
获取pir灵敏度
参数：PirNum pir位置数 0，1，2   3颗pir
成功返回 sensivity 灵敏度 [0-7]，失败返回其他？
获取一个即可
*/
int hal_pir_get_sensivity(char PirNum);

/*
pir使能控制
参数：ch  pir位置数 0，1，2   3颗pir
参数：enable 0是去使能，1是使能
成功返回 0 ，失败返回其他
支持设置各自的使能，int a[3] = {0,1,0}		中间PIR使能
*/
int hal_pir_enable(int *pir_enable);

//int hal_pir_enable(char ch, int enable);

/*
注册pir感应通知回调函数
参数：cb函数入口
返回值：无
*/
void hal_pir_register_detect_cb(pir_detect_cb cb);

/*
获取pir软件版本
参数：version  获取到是软件版本如:V3.1.0
参数：len 传下去的version 的大小，需不小于8 Byte
成功返回 0 ，失败返回其他
*/
int hal_get_pir_softversions(char *version, int len);

/*
pir模块去初始化
参数：无
返回值：无
*/
void hal_pir_deinit(void);

#ifdef __cplusplus
}
#endif	

#endif

