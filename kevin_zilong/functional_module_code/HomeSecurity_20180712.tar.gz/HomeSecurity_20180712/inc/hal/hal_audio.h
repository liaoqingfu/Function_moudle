#ifndef     __HAL_AUDIO_H__
#define     __HAL_AUDIO_H__

#ifdef	__cplusplus
extern "C" { 
#endif
/*
参数说明： 	data 音频数据
			len 数据的大小
			pts 时间戳 ms
			user_data 保留 传NULL 即可
*/
typedef     void (*audio_stream_cb)(char *data, int len, unsigned int pts, void *user_data);

/*
audio模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_audio_init(void);

/*
关闭mic输入
参数：enable  0是关闭，1是打开
成功返回 0 ，失败返回其他
*/
int hal_audio_vin_enable(int enable);



/*
设置speaker音量
参数：volume 音量值[0-100]
成功返回 0 ，失败返回其他
*/
int hal_audio_set_vout(int volume);

/*
获取speaker音量
参数：volume 指针返回音量值[0-100]
成功返回 0 ，失败返回其他
*/

int hal_audio_get_vout(int *volume);


/*
设置mic音量
参数：volume 音量值[0-100]
成功返回 0 ，失败返回其他
*/
int hal_audio_set_vin(int volume);

/*
获取mic音量
参数：volume 指针返回音量值[0-100]
成功返回 0 ，失败返回其他
*/

int hal_audio_get_vin(int *volume);


/*
注册音频获取回调函数
*/
void hal_audio_register_cb(audio_stream_cb cb, void *user_data);

/*
音频输出
参数：data 播放的数据
参数：len 数据的长度
成功返回 0 ，失败返回其他
*/
int hal_audio_out(char *data, int len);

/*
音频输出
参数：pPath 播放的文件路径
成功返回 0 ，失败返回其他
*/
int hal_audio_play_file(const char *pPath);

/*
audio模块去初始化
参数：无
返回值：无
*/
void hal_audio_deinit(void);

#ifdef __cplusplus
}
#endif	

#endif

