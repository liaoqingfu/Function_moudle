#ifndef     __HAL_KEY_H__
#define     __HAL_KEY_H__

#ifdef	__cplusplus
extern "C" { 
#endif

/*
参数：keycode  1是短按，2是长按
*/
typedef     void (*key_detect_cb)(int keycode);

/*
led模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_key_init(void);

/*
设置定义长按的时间
参数：key_holdtime_ms 按键时长定义，单位ms
成功返回 0 ，失败返回其他
*/
int hal_set_keyhold_time(int key_holdtime_ms);

/*
注册按键的回调函数
keycode 1: 短按
keycode 2: 长按
*/
void hal_key_register_detect_cb(key_detect_cb cb);

/*
led模块去初始化
参数：无
返回值：无
*/
void hal_key_deinit(void);

#ifdef __cplusplus
}
#endif	

#endif

