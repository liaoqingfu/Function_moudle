#ifndef     __HAL_WIFI_H__
#define     __HAL_WIFI_H__

#ifdef	__cplusplus
extern "C" { 
#endif


typedef struct HAL_WIFI_AP_INFO_T
{
    int signal;				//信号强度
    int enc;      			//鉴权方式
    int auth;				//鉴权方式
    int channel;			//频率信道
    char ssid[128];        	//wifi名称
}HAL_WIFI_AP_INFO;

/*
获取WiFi设备名称
参数：wifi_dev_name 获取到的wifi设备名称
成功返回 0 ，失败返回其他
*/
int hal_get_wifi_dev_name(char *wifi_dev_name);

/*
设置WiFi为AP模式
ssid :AP热点的名称
password: AP热点的密码
auth_type: 热点鉴权方式 1-OPEN  2-AES  3-psk2
成功返回 0 ，失败返回其他
*/
int hal_set_wifi_ap_mode(const char *ssid, const char *password, const int auth_type);

/*
设置WiFi为STA模式
参数：无
成功返回 0 ，失败返回其他
*/
int hal_set_wifi_sta_mode(void);

/*
切换为STA模式并连接指定的AP   不可重复调用，在AP模式切换为STA模式时才调用
ssid : 指定AP的ssid
password : AP的密码
连接上AP后会自动获取IP
成功返回 0 ，失败返回其他
*/
int hal_set_wifi_sta_mode_and_connect(const char *ssid, const char *password);

/*
WiFi连接指定的AP
ssid : 指定AP的ssid
password : AP的密码
连接上AP后不会自动获取IP
成功返回 0 ，失败返回其他
*/
int hal_wifi_connect(char *ssid, char *key);

/**
获取附近的AP列表
参数：pApList 获取到wifi信息的结构体
返回值:热点的数量 失败返回负值
**/
int hal_wifi_get_aplist(HAL_WIFI_AP_INFO **pApList);

/*
检测连接指定SSID的AP 的状态
参数：ssid  wifi名称
返回值:
0 :未连接
1:正在连接
2:已连接上
*/
int hal_wifi_check_link(char *ssid);

/*
自动获取IP
参数：无
成功返回 0 ，失败返回其他
*/
int hal_wifi_udhcpc(void);


#ifdef __cplusplus
}
#endif	

#endif

