#ifndef     __HAL_H__
#define     __HAL_H__

#ifdef	__cplusplus
extern "C" { 
#endif

enum HAL_DEBUG_LEVEL
{
	HAL_LEVEL_ERROR,
	HAL_LEVEL_WARN,
	HAL_LEVEL_INFO,
	HAL_LEVEL_DEBUG,
	HAL_LEVEL_MAX,
};

typedef     void (*hal_log_out_cb)(char *plogstr, int size, int logtype, int lvtype, long reserve);

/*
初始化hal misc子模块
参数：无
成功返回 0 ，失败返回其他
*/
int hal_misc_init(void);

/*
获取温度传感器值
参数：无
成功返回采集到的温度传感器的ADC值，失败返回负值
*/
int hal_tsensor_value(void);

/*
获取光敏传感器值
参数：无
成功返回采集到的光敏传感器的ADC值，失败返回负值
经过我们这边测试采集到的ADC值大于0x11 为白天，小于0x05为夜晚。可供参考
*/
int hal_lsensor_value(void);

/*
设置 IR LED 的亮度
参数：value [0 - 100]
成功返回 0 ，失败返回其他
*/
int hal_set_irled_bright(int value);

/*
获取 IR LED 的亮度
参数：无
成功返回：亮度值 [0 - 100]，失败返回负值
*/
int hal_get_irled_bright(void);

/*
设置 floodlight 的亮度
参数：value [0-100]
成功返回 0 ，失败返回其他
*/
int hal_set_floodlight_bright(int value);

/*
获取floodlight 的亮度值
参数：无
成功返回：亮度值[0-100],失败返回小于0
*/
int hal_get_floodlight_bright(void);

/*
从参数分区读取数据
参数: param_data 数据指针
		offset 参数分区的偏移量
		param_len 要读取的数据大小
返回值:返回实际读到的数据 ，失败为负值
*/
int hal_read_param_partition(void *param_data, int offset, int param_len);

/*
写数据到参数分区
参数: param_data 数据指针
		offset 参数分区的偏移量
		param_len 数据的大小
成功返回 0 ，失败返回其他
*/
int hal_write_param_partition(const void *param_data, int offset, const int param_len);

/*
获取参数分区内数据的大小
参数: param_len  数据大小的指针
成功返回 0 ，失败返回其他
*/
int hal_get_param_partition_datasize(int *param_len);

/*
hal misc子模块去初始化
参数：无
返回值：无
*/
void hal_misc_deinit(void);

/*
获取库文件版本
参数：version 获取到的软件版本
成功返回 0 ，失败返回其他
*/
int hal_get_version(char *version);

/*
log 打印回调注册函数
*/
void hal_log_register_out_cb(hal_log_out_cb cb);

/*
清除参数分区数据接口
成功返回 0 ，失败返回其他
慎用
*/
int hal_clear_param_partition(void);


/*
获取板子的温度
参数:无
返回板子的温度 如:返回值为40，表示板子温度为40
*/
char hal_get_temperature(void);

/*
获取SD卡状态
返回值: 0 存在TF卡，-1 不存在TF卡
*/
int hal_sd_exist(void);
/*
获取SN号接口
参数：sn 获取到的sn 号
成功返回 0 ，失败返回其他
*/
int hal_get_sn(char *sn);




#ifdef __cplusplus
}
#endif	/* __cplusplus */

#endif

