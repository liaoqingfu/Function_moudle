#ifndef     __HAL_OTA_H__
#define     __HAL_OTA_H__

#ifdef	__cplusplus
extern "C" { 
#endif

typedef int(*ota_callback)(unsigned int state,      /* ota状态 */
                           unsigned int err_code,   /* 错误代码 */
                           long reserve);           /* 保留 */

		   
						   
/*
ota升级函数
参数：bin_path 升级文件路径
参数：bin_len 文件大小
参数：bin_type 文件类型 保留 传0 即可
成功返回 0 ，失败返回其他
*/						   
int hal_ota_update(const char *bin_path, const int bin_len, const int bin_type);

/*
注册OTA升级回调函数
参数：cb 函数入口
返回值：无
*/
void hal_ota_register_cb(ota_callback cb);

#ifdef __cplusplus
}
#endif	

#endif

