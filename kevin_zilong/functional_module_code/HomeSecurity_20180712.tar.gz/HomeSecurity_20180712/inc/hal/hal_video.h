#ifndef     __HAL_VIDEO_H__
#define     __HAL_VIDEO_H__

#ifdef	__cplusplus
extern "C" { 
#endif

/*
回调函数参数说明 :
ch 编码通道，一般都是0
data 视频数据指针
len 视频数据大小
stream_type :    1：H264 2：H265 3：MJPEG
frame_type : 1：I帧  2：P帧   //    没有B帧
u32Width : 宽度
u32Height:高度
pts : 时间戳
*/
typedef     void(*video_stream_cb)(int ch, char *data, int len, unsigned int stream_type, unsigned int frame_type, unsigned int  u32Width , unsigned int  u32Height, long long pts);
typedef     void(*motion_detect_cb)(void *user_data);

typedef enum POWERR_FREQ_T
{
    FREQ_50HZ = 0x0,
    FREQ_60HZ,
    FREQ_BUTT
}POWER_FREQ_E;

typedef enum VIDEO_FLIP_T
{
	VIDEO_FLIP_NORMAL = 0,
	VIDEO_FLIP_H,
	VIDEO_FLIP_V,
	VIDEO_FLIP_HV,
    VIDEO_FLIP_BUTT
}VIDEO_FLIP_E;

 


typedef enum BITRATE_MODE_T
{
    MODE_VBR = 0x0,
    MODE_CBR,
    MODE_BUTT
}BITRATE_MODE_E;

typedef enum RESOLUTION_DEF_T
{
    RES_VGA = 0x0,  /* 640 x 360 */
    RES_720P,       /* 1280 x 720 */
    RES_1080P,      /* 1920 x 1080 */
    RES_BUTT
}RESOLUTION_DEF_E;

typedef enum MD_LEVEL_T   
{
	HAL_MD_LOW = 0, 	  
	HAL_MD_NORMAL,
	HAL_MD_HIGHT,	
	HAL_MD_HIGHTEST,
    HAL_MD_BUTT
}MD_LEVEL_E;




/*
video模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_video_init();

/*
video设置: 色度/亮度/对比度/饱和度
参数：type 类型 0：亮度，1：对比度，2：色度，3：饱和度
参数：value 调节的值[0-100]
成功返回 0 ，失败返回其他
*/
int hal_video_set_csc(int type, int value);

/*
获取video: 色度/亮度/对比度/饱和度
参数：type 类型 0：亮度，1：对比度，2：色度，3：饱和度
参数：value 获取到的值
成功返回 0 ，失败返回其他
*/
int hal_video_get_csc(int type, int *value);

/*
video设置: 图像翻转
参数：value 0：0°，1：90°，2：180°，3：270°
成功返回 0 ，失败返回其他
*/
int hal_video_set_torate(VIDEO_FLIP_E value);

/*
获取video: 图像翻转
参数：value 获取到的图像角度
成功返回 0 ，失败返回其他
*/
int hal_video_get_torate(VIDEO_FLIP_E *value);

/*
video设置: 电力线频率
参数：freq F50HZ/F60HZ
成功返回 0 ，失败返回其他
*/
int hal_video_set_pwrfreq(POWER_FREQ_E freq);

/*
获取video: 电力线频率
参数：freq 获取到的电力线频率
成功返回 0 ，失败返回其他
*/
int hal_video_get_pwrfreq(POWER_FREQ_E *freq);

/*
video设置: 帧率     帧率和GOP 一致
参数：ch 编码通道，[0，1]，高清和标清
参数：fps [0-15] 帧率的范围大小吗？（需要跟卓翼确定）
成功返回 0 ，失败返回其他
*/
int hal_video_set_fps(int ch, int fps);

/*
获取video: 帧率     帧率和GOP 一致
参数：ch 编码通道，[0，1]，高清和标清
参数：fps 获取到的帧率
成功返回 0 ，失败返回其他
*/
int hal_video_get_fps(int ch, int *fps);

/*
video 设置帧率和GOP
参数：VencCh 编码通道，[0，1]，高清和标清
参数：fps [0-15] 
参数：gop I帧间隔
成功返回 0 ，失败返回其他
*/
int hal_video_set_fpsAndgop(int VencCh, int fps, int gop);

/*
获取video 帧率和GOP
参数：VencCh 编码通道，[0，1]，高清和标清
参数：fps 获取到的帧率
参数：gop 获取到的I帧间隔
成功返回 0 ，失败返回其他
*/
int hal_video_get_fpsAndgop(int VencCh, int *fps, int *gop);


/*
video设置: 码率
参数：ch 编码通道，[0，1]，高清和标清
参数：bitrate 	256-2M大小
参数：mode 模式 VBR/CBR
成功返回 0 ，失败返回其他
*/
int hal_video_set_bitrate(int ch, int bitrate, BITRATE_MODE_E mode);

/*
获取video: 码率
参数：ch 编码通道，[0，1]，高清和标清
参数：bitrate 	获取到的大小
参数：mode 获取到的模式 
成功返回 0 ，失败返回其他
*/
int hal_video_get_bitrate(int ch, int *bitrate, BITRATE_MODE_E *mode);

/*
video设置: 分辨率
参数：ch 编码通道，[0，1]，高清和标清
参数：resolution 分辨率 RES_VGA/RES_720P/RES_1080P
成功返回 0 ，失败返回其他
*/
int hal_video_set_resolution(int ch, RESOLUTION_DEF_E resolution);

/*
获取video: 分辨率
参数：ch 编码通道，[0，1]，高清和标清
参数：resolution 获取到的分辨率 
成功返回 0 ，失败返回其他
*/
int hal_video_get_resolution(int ch, RESOLUTION_DEF_E *resolution);

/*
video设置: motion detect灵敏度
参数：sensitivity 灵敏度 1-10
成功返回 0 ，失败返回其他
*/
int hal_video_set_md_sensitivity(MD_LEVEL_E sensitivity);
/*
video获取: motion detect灵敏度
参数：sensitivity 指针返回灵敏度 1-10
成功返回 0 ，失败返回其他
*/

int hal_video_get_md_sensitivity(MD_LEVEL_E *sensitivity);


/*
video设置: 时间osd
参数：enable 0是去使能，1是使能
成功返回 0 ，失败返回其他
*/
int hal_video_osd_time(int enable);

/*
video强制输出idr
参数：ch 编码通道，[0，1]，高清和标清
成功返回 0 ，失败返回其他
*/
int hal_video_force_idr(int ch);

/*
video注册视频获取回调函数
*/
void hal_video_register_stream_cb(video_stream_cb cb);
/*
video注册移动侦测回调函数
*/
void hal_video_register_md_cb(motion_detect_cb cb, void *user_data);  //user_data参数不能传，

/*
获取图像的色彩模式
参数：无
返回值: 0 :彩色  1:黑白
*/
int hal_get_video_color_mode(void);

/*
设置图像的色彩模式
参数mode:  0 :彩色  1:黑白
返回值：0：成功，其他：失败
*/
int hal_set_video_color_mode(int mode);

/**
打开摄像头
参数: 无
返回值：0：成功，其他：失败

**/
int hal_open_camera(void);
/**
关闭摄像头
参数: 无
返回值：0：成功，其他：失败

**/

int hal_close_camera(void);


/*
video模块去初始化
参数：无
返回值：无
*/
void hal_video_deinit();

#ifdef __cplusplus
}
#endif	

#endif

