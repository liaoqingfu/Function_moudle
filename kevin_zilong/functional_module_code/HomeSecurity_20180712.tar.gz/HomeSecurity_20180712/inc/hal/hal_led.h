#ifndef     __HAL_LED_H__
#define     __HAL_LED_H__

#ifdef	__cplusplus
extern "C" { 
#endif

typedef enum  hal_LED_TYPE_E
{
	HAL_LED_TYPE_RED = 0,
	HAL_LED_TYPE_WHITE  ,
	HAL_LED_TYPE_BUTT
}HAL_LED_TYPE_E;

typedef enum  hal_LED_STATUS_E
{
	HAL_LED_STATUS_OFF = 0,
	HAL_LED_STATUS_ON ,
	HAL_LED_STATUS_FLASH ,
	HAL_LED_STATUS_BUTT
}HAL_LED_STATUS_E;

/*
led模块初始化
参数：无
成功返回 0 ，失败返回其他
*/
int hal_led_init(void);
/*
led 控制
参数 led_type ：灯的类型
参数 led_status ：灯的状态
成功返回 0 ，失败返回其他
*/
int hal_led_ctrl(HAL_LED_TYPE_E led_type, HAL_LED_STATUS_E led_status);
/*
设置LED指示灯闪烁的周期
参数 led_type ： 灯的类型
参数 frequency ： 灯闪烁的频率周期，单位 ms
成功返回 0 ，失败返回其他
*/
int hal_led_SetFlashFreq(HAL_LED_TYPE_E led_type, int frequency);

/*
led模块去初始化
参数：无
返回值：无
*/
void hal_led_deinit(void);

#ifdef __cplusplus
}
#endif	

#endif

