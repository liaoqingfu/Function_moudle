/*============================================================================
 Name        : push_interface.h
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-12-04 
 Description :
 ============================================================================*/

#ifndef zx_PUSH_INTERFACE_H
#define zx_PUSH_INTERFACE_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "base.h"
#include "PPCS/WiPN_API.h"
#include "sys_interface.h"

#pragma pack(1)


#ifdef __cplusplus
extern "C"
{
#endif

int zx_init_push_server(HUB_BASE_PARAM *base_param);
int zx_deinit_push_server(void);
int zx_push_message(const char *title, const char *content, short channel);
int zx_push_message_door_sensor(const char *title, const char *content, short channel,char evt);
int zx_push_tfcard_message(const char *title, const char *content, char status);

#ifdef __cplusplus
}
#endif

#pragma pack()

#endif /* zx_PUSH_INTERFACE_H */
