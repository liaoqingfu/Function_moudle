#ifndef _G711_CODEC_H
#define _G711_CODEC_H


#define    G711_A_LAW      (0)
#define    G711_MU_LAW     (1)
#define    DATA_LEN        (16)

#ifdef __cplusplus
extern "C"
{
#endif

	//int encode(char *a_psrc, char *a_pdst, int in_data_len, unsigned char type);
	//int decode(char *a_psrc, char *a_pdst, int in_data_len, unsigned char type);
	int g711a_encode(const char* psrc, unsigned char* pdst, int nin_size);
	int g711a_decode(const unsigned char* psrc, char* pdst, int nin_size);
	
#ifdef __cplusplus
};
#endif
#endif
