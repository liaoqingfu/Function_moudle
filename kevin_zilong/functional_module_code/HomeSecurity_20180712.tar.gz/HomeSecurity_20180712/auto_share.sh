#!/bin/sh
make clean
make
cp ./home_security /mnt/hgfs/D/Work/Project/BatteryCamera/版本
sync
