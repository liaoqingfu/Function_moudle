/*============================================================================
 Name        : mgw_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-3-15 
 Description : 
 ============================================================================*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/socket.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>

#include "mgw_interface.h"
#include "floodlight_interface.h"


extern HUB_BASE_PARAM *base_param;
char *version;

UINT64 send_seq = PACKAGES_SEQ;
UINT64 recv_seq = 0;
int mgw_running = 1;



UINT64 zx_mgw_CurTime_s(void)			//获取当前时间，秒
{
    struct timeval tv;
    UINT64 time_s; 
    gettimeofday(&tv, NULL);     
    time_s = (UINT64)tv.tv_sec  + (UINT64)tv.tv_usec;

    return time_s;
}


UINT64 hl64ton(UINT64 host)   
{   
	UINT64   ret = 0;   
	ULONG   high,low;
	
	low   =   host & 0xFFFFFFFF;
	high   =  (host >> 32) & 0xFFFFFFFF;
	
	low   =   htonl(low);   
	high   =   htonl(high);   
	
	ret   =   low;
	ret   <<= 32;   
	ret   |=   high;   
	return   ret;   
}

UINT64 ntohl64(UINT64 host)   
{   
	UINT64   ret = 0;   
	ULONG   high,low;
	
	low   =   host & 0xFFFFFFFF;
	high   =  (host >> 32) & 0xFFFFFFFF;
	
	low   =   ntohl(low);   
	high   =   ntohl(high);   
	
	ret   =   low;
	ret   <<= 32;   
	ret   |=   high;   
	return   ret;   
}

ssize_t mgw_Write(int fd, const void *ptr, size_t nbytes)
{
	ssize_t n;

again:
	if ((n = write(fd, ptr, nbytes)) == -1) 
	{
		if (errno == EINTR)
		{
			dzlog_warn(" write interrupt errno is EINTR. ");
			goto again;
		}
		else
		{
			dzlog_error(" write error. ");
			return -1;
		}	
	}
	return n;
}


ssize_t mgw_Writen(int fd, const void *vptr, size_t n)
{
	size_t nleft;
	ssize_t nwritten;
	const char *ptr;

	ptr = vptr;
	nleft = n;
	
	while (nleft > 0) 
	{
		if ( (nwritten = write(fd, ptr, nleft)) <= 0) 
		{
			if (nwritten < 0 && errno == EINTR)
			{
				dzlog_warn(" write interrupt errno is EINTR. ");
				nwritten = 0;
			}
			else
			{
				dzlog_error(" write error. ");
				return -1;
			}	
		}
		nleft -= nwritten;
		ptr += nwritten;
	}
	return n;
}

ssize_t mgw_Read(int fd, void *ptr, size_t nbytes)
{
	ssize_t n;
again:
	if ((n = read(fd, ptr, nbytes)) == -1) 
	{
		if (errno == EINTR)
		{
			dzlog_warn(" read interrupt errno is EINTR. ");
			goto again;
		}	
		else
		{
			dzlog_error(" read error. ");
			return -1;
		}
	}
	return n;
}


ssize_t mgw_Readn(int fd,void *vptr,size_t n)	//n是需要读取的字节数
{
    size_t nleft;  		//usigned int 剩余未读取的字节数
    ssize_t nread; 		//int 实际读到的字节数
    char *ptr;

    ptr=vptr;
    nleft=n;
	
    while(nleft>0)
    {
        if((nread=read(fd,ptr,nleft))<0)
        {
            if(errno == EINTR)
            {
				dzlog_warn(" read interrupt errno is EINTR. ");
                nread=0;
            }
            else
            {
				dzlog_error(" read error. ");
                return -1;
            }
        }
        else if(nread==0)
        {
			dzlog_info(" read end or read is empty. ");
            break;
        }
        nleft -= nread; 	//剩余长度 = 总长度 - 已读长度
        ptr += nread; 		//移动指针位置，读取下次文件的时候从已读的后面开始读取
    }
    return n-nleft;
}






void zx_mgw_setTimer(int seconds, int useconds)	//定时
{
    struct timeval temp;

    temp.tv_sec = seconds;
    temp.tv_usec = useconds;

	dzlog_info("****** wait %ds %dus time ******",seconds,useconds);

    select(0, NULL, NULL, NULL, &temp);
	
    return ;
}



/*
成功返回结构体指针，失败返回 NULL
将结构体进行初始化，赋初值分配空间
*/
MGW_COMMUN_PRO *zx_mgw_commun_init() 
{
	
	MGW_COMMUN_PRO *mgw_comm = NULL;
	dzlog_info("mgw commun init start");
	
	mgw_comm = (MGW_COMMUN_PRO *)malloc(sizeof(MGW_COMMUN_PRO));
	
	if(!mgw_comm)
	{
		dzlog_error(" out of memory for mgw_comm. ");
		return NULL;
	}
	
	memset(mgw_comm,0,sizeof(MGW_COMMUN_PRO));
	
	mgw_comm->packetlen = 0;	//协议包长度
	mgw_comm->byte = 'f';  		//协议包类型，默认 f
	mgw_comm->transfer = 0;		//转换器个数，
	
	//memset(mgw_comm->transferids,0,TRANSFER_ID); //转换器Id,'g'是压缩
	
	mgw_comm->seq = 0;			//包序号
	mgw_comm->ptype = 0;		//包类型 1:拉取 		2:拉取回复     	3: 推送
	mgw_comm->urilen = 0;		//uri长度

	mgw_comm->uri = NULL;		//uri

	mgw_comm->metalen = 0;		//参数长度，默认0

	//mgw_comm->meta = NULL; 	//参数值
	
	mgw_comm->bodecodec = 'j';  //包体加解器方式，默认‘j':json，'p':protobuf，'s':string

	mgw_comm->body = NULL;

	dzlog_info("mgw commun init end");
	return mgw_comm;
}


/*
成功返回 0，失败返回 -1
给结构体成员赋值相应的数据
参数 mgw_com : 传入参数
*/
int zx_mgw_commun_assignment_value(
	MGW_COMMUN_PRO *mgw_com,	//需要赋值的结构体
	char *url,					//url
	char byte,					//协议类型
	char transfer,				//转换器个数
	char ptype,					//包类型 1:拉取 		2:拉取回复  	3: 推送
	char bodecodec,				//包体加解器方式，默认‘j':json，'p':protobuf，'s':string
	UINT64 mgw_seq,				//包序号
	char *body					//body数据
)
{	
	if(!mgw_com || !url || !body)
	{
		dzlog_warn("The function parameter is NULL.");
		return -1;
	}

	dzlog_info("mgw assignment value start");
	
	mgw_com->byte = byte;			//协议类型 
	mgw_com->transfer = transfer;	//转换器个数
	mgw_com->seq = mgw_seq;			//包序号
	mgw_com->ptype = ptype;			//包类型
	mgw_com->bodecodec = bodecodec;	//包体加解器方式
	mgw_com->metalen = META_LEN;	//参数长度,暂时设置为0
	
	mgw_com->urilen =strlen(url);
	
#if MGW_LOG
	dzlog_info("***mgw_com_pro->urilen = %d",mgw_com->urilen);
#endif

	mgw_com->uri = (char *)malloc(mgw_com->urilen + 2);
	
	if(!mgw_com->uri)
	{
		dzlog_error(" out of memory for mgw_com->uri. ");
		return -1;
	}
	
	memset(mgw_com->uri,0,mgw_com->urilen + 2);

	memcpy(mgw_com->uri,url,mgw_com->urilen);

	dzlog_info("***mgw_com->uri = %s",mgw_com->uri);
	
#if 0
	mgw_com->meta = (char *)malloc(META_LEN);  //参数值,暂时未定

	if(!mgw_com->meta )
	{
		if(mgw_com->uri) 
		{
			free(mgw_com->uri); 
			mgw_com->url = NULL;
		}
		dzlog_error(" out of memory for mgw_com->meta. ");
		return -1;
	}
#endif

	mgw_com->body = (char *)malloc(strlen(body) + 2);
	
	if(!mgw_com->body)
	{
		if(mgw_com->uri) 
		{
			free(mgw_com->uri); 
			mgw_com->uri = NULL;
		}
		dzlog_error(" out of memory for mgw_com->body. ");
		return -1;
	}
	memset(mgw_com->body,0,strlen(body) + 2);

	memcpy(mgw_com->body,body,strlen(body));
	
#if MGW_LOG
	dzlog_info("***mgw_com_pro->body = %s",mgw_com->body);
#endif	

	mgw_com->packetlen = sizeof(mgw_com->packetlen)+ sizeof(mgw_com->byte) \
	+ sizeof(mgw_com->transfer) + sizeof(mgw_com->seq) + sizeof(mgw_com->ptype) + \
	sizeof(mgw_com->urilen)+ strlen(mgw_com->uri)+ sizeof(mgw_com->metalen)+ \
	sizeof(mgw_com->bodecodec) + strlen(mgw_com->body);

#if MGW_LOG
	dzlog_info("***mgw_com->packetlen = %d",mgw_com->packetlen);
#endif

	dzlog_info("mgw assignment value end");
	
	return 0;
}


/*
打印结构体数据
*/
void zx_mgw_commun_printf(MGW_COMMUN_PRO *mgw_com)
{
	if(!mgw_com)
	{
		dzlog_error("The function parameter  is NULL");
		return;
	}
	dzlog_info("printf mgw commun start");
	
	dzlog_info("***packetlen = %d", mgw_com->packetlen);
	
	dzlog_info("***byte = %c", mgw_com->byte);
	
	dzlog_info("***transfer = %d", mgw_com->transfer);
	
#if 0
	int i = 0;
	for(i = 0; i < TRANSFER_ID; i++ )
	{
		dzlog_info("***transferids[%d] = %c", i,mgw_com->transferids[i]);
	}
#endif

	dzlog_info("***seq = %llu", mgw_com->seq);
	
	dzlog_info("***ptype = %d", mgw_com->ptype);
	
	dzlog_info("***urilen = %d", mgw_com->urilen);
	
#if 0
	if(mgw_com->meta)
		dzlog_info("***meta = %s", mgw_com->meta);
	else
		dzlog_info("***meta is empty.");
#endif

	if(mgw_com->uri)
		dzlog_info("***uri = %s", mgw_com->uri);
	else
		dzlog_info("***uri is empty.");
	
	dzlog_info("***metalen = %d", mgw_com->metalen);
	
	dzlog_info("***bodecodec = %c", mgw_com->bodecodec);

	if(mgw_com->body)
		dzlog_info("***body = %s", mgw_com->body);
	else
		dzlog_info("***body is empty.");

	dzlog_info("printf mgw commun end");
	
	return;
}


/*
成功返回组好的数据包，失败返回 NULL
将结构体组包，用于网络发送
参数 mgw_com : 传入参数
*/
char *zx_mgw_commun_set_data_packages(MGW_COMMUN_PRO *mgw_com)
{
	UINT32 packet_len = 0,uri_len = 0,meta_len = 0;
	UINT64 seq_len = 0;
	char *send_buf = NULL, *send_packages_buf = NULL;
	
	if(!mgw_com)
	{
		dzlog_error("The function parameter  is NULL");
		return NULL;
	}

	dzlog_info("set mgw commun data packages start");
	
	packet_len = htonl(mgw_com->packetlen);
	seq_len = hl64ton(mgw_com->seq);

	uri_len = htonl(mgw_com->urilen);
	meta_len = htonl(mgw_com->metalen);

	send_packages_buf =(char *) malloc(mgw_com->packetlen + 2);
	
	if(!send_packages_buf)
	{
		dzlog_error(" out of memory for send_packages_buf. ");
		return NULL;
	}
	
	memset(send_packages_buf,0,mgw_com->packetlen + 2);
	
	send_buf = send_packages_buf;		//保存最开始的空间地址
	
	memmove(send_packages_buf,&packet_len,sizeof(packet_len));
	send_packages_buf +=  sizeof(packet_len);
	
	memmove(send_packages_buf ,&mgw_com->byte,sizeof(mgw_com->byte));
	send_packages_buf +=  sizeof(mgw_com->byte);
	
	memmove(send_packages_buf ,&mgw_com->transfer,sizeof(mgw_com->transfer));
	send_packages_buf +=  sizeof(mgw_com->transfer);
	
	memmove(send_packages_buf ,&seq_len,sizeof(seq_len));
	send_packages_buf +=  sizeof(seq_len);
	
	memmove(send_packages_buf ,&mgw_com->ptype,sizeof(mgw_com->ptype));
	send_packages_buf +=  sizeof(mgw_com->ptype);
	
	memmove(send_packages_buf ,&uri_len,sizeof(uri_len));
	send_packages_buf +=  sizeof(uri_len);
	
	memmove(send_packages_buf ,mgw_com->uri,strlen(mgw_com->uri));
	send_packages_buf +=  strlen(mgw_com->uri);
	
	memmove(send_packages_buf ,&meta_len,sizeof(meta_len));
	send_packages_buf +=  sizeof(meta_len);
	
	memmove(send_packages_buf ,&mgw_com->bodecodec,sizeof(mgw_com->bodecodec));
	send_packages_buf +=  sizeof(mgw_com->bodecodec);
	
	memmove(send_packages_buf ,mgw_com->body,strlen(mgw_com->body));

	dzlog_info("set mgw commun data packages end");
	
	return send_buf;
}



/*
成功返回 0 失败返回 -1
解析网络数据包
参数 src_data : 网络读取到的数据
参数 dst_mgw_com : 解析包后数据存放入结构体
*/
int zx_mgw_commun_parsing_data(char *src_data,MGW_COMMUN_PRO *dst_mgw_com)
{
	int body_len = 0;
	char *data = NULL;
	
	if(!src_data || !dst_mgw_com)
	{
		dzlog_info("The function parameter  is NULL");
		return -1;
	}
	
	dzlog_info("parsing data packages start");
	
	data = src_data;
	
	memmove(&dst_mgw_com->byte,data,sizeof(dst_mgw_com->byte));
	data += sizeof(dst_mgw_com->byte);

	memmove(&dst_mgw_com->transfer,data,sizeof(dst_mgw_com->transfer));
	data += sizeof(dst_mgw_com->transfer);
	
	memmove(&dst_mgw_com->seq,data,sizeof(dst_mgw_com->seq));
	data += sizeof(dst_mgw_com->seq);
	
	dst_mgw_com->seq = ntohl64(dst_mgw_com->seq);  //网络转客户端
	
#if MGW_LOG
	dzlog_info("parsing data after ntohl seq = %llu", dst_mgw_com->seq);
#endif

	memmove(&dst_mgw_com->ptype,data,sizeof(dst_mgw_com->ptype));
	data += sizeof(dst_mgw_com->ptype);
	
	memmove(&dst_mgw_com->urilen,data,sizeof(dst_mgw_com->urilen));
	data += sizeof(dst_mgw_com->urilen);
	
	dst_mgw_com->urilen = ntohl(dst_mgw_com->urilen);  //网络转客户端
	
#if MGW_LOG
	dzlog_info("parsing data after ntohl urilen = %d", dst_mgw_com->urilen);
#endif

	dst_mgw_com->uri = (char *)malloc(dst_mgw_com->urilen + 2);

	if(!dst_mgw_com->uri)
	{
		dzlog_error(" out of memory for dst_mgw_com->uri. ");
		return -1;
	}
		
	memset(dst_mgw_com->uri,0,dst_mgw_com->urilen + 2);
	
	memmove(dst_mgw_com->uri,data,dst_mgw_com->urilen);
	
	data += dst_mgw_com->urilen;

	memmove(&dst_mgw_com->metalen,data,sizeof(dst_mgw_com->metalen));
	data += sizeof(dst_mgw_com->metalen);
	
	dst_mgw_com->metalen = ntohl(dst_mgw_com->metalen);  //网络转客户端
	
#if MGW_LOG
	dzlog_info("parsing data after ntohl metalen = %d", dst_mgw_com->metalen);
#endif

	memmove(&dst_mgw_com->bodecodec,data,sizeof(dst_mgw_com->bodecodec));
	data += sizeof(dst_mgw_com->bodecodec);
	
	body_len = dst_mgw_com->packetlen - sizeof(dst_mgw_com->packetlen)- \
	sizeof(dst_mgw_com->byte) - sizeof(dst_mgw_com->transfer)- \
	sizeof(dst_mgw_com->seq) - sizeof(dst_mgw_com->ptype) - sizeof(dst_mgw_com->urilen) - \
	strlen(dst_mgw_com->uri) - sizeof(dst_mgw_com->metalen) - sizeof(dst_mgw_com->bodecodec);
	
#if MGW_LOG
	dzlog_info("parsing data after body_len = %d", body_len);
#endif

	dst_mgw_com->body = (char *)malloc(body_len + 2);
	
	if(!dst_mgw_com->body)
	{
		if(dst_mgw_com->uri)
		{
			free(dst_mgw_com->uri);
			dst_mgw_com->uri = NULL;
		}
		dzlog_error(" out of memory for dst_mgw_com->uri. ");
		return -1;
	}
	memset(dst_mgw_com->body,0,body_len + 2);
	
	memmove(dst_mgw_com->body,data,body_len);

	dzlog_info("parsing data packages end");
	
	return 0;
}


/*
成功返回 socket 句柄，失败返回 -1
创建socket网络连接句柄，设置为非阻塞
参数 serv_ip : 服务器IP
参数 serv_port : 服务器端口
*/
int zx_mgw_commun_create_socket(char *serv_ip,unsigned int serv_port)
{
	struct sockaddr_in servaddr;
	int sockfd = -1;
	int ret = 0; 
	
	if(!serv_ip )
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}

	dzlog_info("mgw commun create socket start");
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	
	if(sockfd < 0)
	{
		dzlog_error("*** socket error : %d", sockfd);
		return -1;
	}
	
	dzlog_info("create socket is ok");
	
	bzero(&servaddr, sizeof(servaddr));
	
	servaddr.sin_family = AF_INET;
	
	inet_pton(AF_INET, serv_ip, &servaddr.sin_addr.s_addr);
	
	servaddr.sin_port = htons(serv_port);

	ret = connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
	
	if(ret < 0)
	{
		dzlog_error("*** connect error : %d", ret);
		return -1;
	}
	dzlog_info(" connect is ok ");

	return sockfd;
	
}


/*
成功返回 0 ；失败返回 -1
发送组包好的数据
参数 sockfd : socket句柄，用于网络发送数据
参数 mgw_com_buf : 传入参数，需要发送的数据
参数 data_packages_len : 传入参数，发送的数据长度
*/
int zx_mgw_commun_send_data(int sockfd,char *send_com_buf_data,UINT32 data_packages_len)
{
	int ret = -1;
	
	if(!send_com_buf_data)
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}
	dzlog_info("mgw commun send data start");
	
	ret = mgw_Writen(sockfd,send_com_buf_data,data_packages_len);
    
	if(ret == -1)
	{
		dzlog_error("mgw Writen error");
		return -1;
	}
	
	send_seq += 1;				//包序号自增
	
	dzlog_info("mgw commun send data end");
	return 0;
}




/*
成功返回数据包 ；失败返回 NULL
接受网络数据包
参数 sockfd : socket句柄，用于网络接受数据
参数 data_packages_len : 接收到的数据包的长度，传入，传出参数
*/
char *zx_mgw_commun_recv_data(int sockfd,UINT32 *data_packages_len)
{
	int n = -1;
	UINT32 len = 0;
	char *recv_com_buf_data = NULL;
	
	dzlog_info("magw commun recv data start");
	
	n =mgw_Read(sockfd, &len, sizeof(UINT32));  //先读出包长
    
	if (n == -1)
	{
		dzlog_error("mgw_Read error");
		return NULL;
	}
	
	*data_packages_len = ntohl(len);

	recv_com_buf_data = (char *)malloc(*data_packages_len + 2);
	
	if(!recv_com_buf_data)
	{
		dzlog_error(" out of memory for recv_com_buf_data. ");
		return NULL;
	}
	memset(recv_com_buf_data,0,*data_packages_len + 2);
	
	n = mgw_Readn(sockfd, recv_com_buf_data, *data_packages_len - sizeof(UINT32));
    
	if (n == -1)
	{
		dzlog_error("mgw_Readn error");
		return NULL;
	}
	dzlog_info("magw commun recv data end");
	
	return recv_com_buf_data;
	
}


/*
清理结构体，释放空间
参数 mgw_com : 传入参数
*/
void zx_mgw_commun_free(MGW_COMMUN_PRO *mgw_com)
{
	if(!mgw_com)
	{
		dzlog_error("The function parameter  is NULL");
		return;
	}
	
	dzlog_info("magw commun free start");
	
	if(mgw_com->uri)
	{
		free(mgw_com->uri);
		mgw_com->uri = NULL;
	}
#if 0
	if(mgw_com->meta)
	{
		free(mgw_com->meta);
		mgw_com->meta = NULL;
	}
#endif
	if(mgw_com->body)
	{
		free(mgw_com->body);
		mgw_com->body = NULL;
	}
	
	if(mgw_com)
	{
		free(mgw_com);
		mgw_com = NULL;
	}
	
	dzlog_info("magw commun free end");
	return;
}

/*
设置通信的body数据
成功返回 body的char *数据，失败返回 NULL
参数 timestamp 	: 时间 单位秒
参数 station_sn : 基站sn 不需要可以传 ""
参数 channel		: 摄像机通道号 不需要可以传 -1
*/
char *set_mgw_cjson_pull_body_data(UINT64 timestamp, char *station_sn, int device_channel)
{
	cJSON *param_root = NULL;
	char *s_json_param = NULL;
	char *pull_body_data = NULL;
	
	if(!station_sn)
	{
		dzlog_error("The function parameter  is NULL");
		return NULL;
	}
	dzlog_info("cjson pull body data start");

	param_root = cJSON_CreateObject();	//创建

	if(!param_root)
	{
		dzlog_error("cJSON CreateObject is error");
		return NULL;
	}
	
#if MGW_LOG
	dzlog_info("timestamp = %llu, station_sn = %s,device_channel = %d",timestamp,station_sn,device_channel);
#endif

	cJSON_AddNumberToObject(param_root,"timestamp",timestamp);

#if MGW_LOG
	dzlog_info("strlen(station_sn) = %d",strlen(station_sn));
#endif

	if(strlen(station_sn) > 0 )
	{
		cJSON_AddStringToObject(param_root,"sn",station_sn);
	}

	if(device_channel >= 0 )
	{
		cJSON_AddNumberToObject(param_root,"ch",device_channel);
	}
	
#if MGW_LOG
	dzlog_info("***cJSON pull body data add ok***");
#endif

	s_json_param = cJSON_PrintUnformatted(param_root);
	
	if(!s_json_param)
	{
		dzlog_error("cJSON PrintUnformatted is error");
		goto PULL_END;
	}
	
#if MGW_LOG
	dzlog_info("pull_body_data cJSON = %s",s_json_param);
#endif

	pull_body_data = (char *)malloc(strlen(s_json_param) + 2);
	
	if(!pull_body_data)
	{
		dzlog_error("out of memory for pull_body_data.");
		goto PULL_END;
	}

	memset(pull_body_data,0,strlen(s_json_param) + 2);

	memcpy(pull_body_data,s_json_param,strlen(s_json_param));
	
	dzlog_info("cjson pull body data end");
PULL_END:
	if(s_json_param) 
	{
		free(s_json_param); 
		s_json_param = NULL;
	}
	if(param_root) 
	{
		cJSON_Delete(param_root); 
		param_root = NULL;
	}
	
	return pull_body_data;
}


char *set_mgw_cjson_live_start_reply_body_data(int code,cJSON *body_data)
{
	UINT64 time_data = 0;
	cJSON *param_root = NULL;
	char *s_json_param = NULL;
	char *reply_body_data = NULL;

	if(!body_data)
	{
		dzlog_error("The function parameter  is NULL");
		return NULL;
	}
	dzlog_info("live start cjson reply body data start");
	
	param_root = cJSON_CreateObject();	//创建

	if(!param_root)
	{
		dzlog_error("cJSON CreateObject is error");
		return NULL;
	}

	time_data = zx_mgw_CurTime_s();

	cJSON_AddNumberToObject(param_root,"code",code);

	if(code == 0)
	{
		cJSON_AddStringToObject(param_root,"message","succeed");
		
		cJSON_AddItemToObject(param_root,"data",body_data);
	}else{
		
		cJSON_AddStringToObject(param_root,"message","failed url or ptype is error");
	}

	cJSON_AddNumberToObject(param_root,"timestamp",time_data);

#if MGW_LOG
	dzlog_info("set live start reply body data cJSON add ok");
#endif

	s_json_param = cJSON_PrintUnformatted(param_root);
	
	if(!s_json_param)
	{
		dzlog_error("cJSON PrintUnformatted is error");
		goto REPLY_END;
	}
	
#if MGW_LOG
	dzlog_info("reply body data cJSON = %s",s_json_param);
#endif

	reply_body_data = (char *)malloc(strlen(s_json_param) + 2);
	
	if(!reply_body_data)
	{
		dzlog_error("out of memory for reply_body_data.");
		goto REPLY_END;
	}

	memset(reply_body_data,0,strlen(s_json_param) + 2);

	memcpy(reply_body_data,s_json_param,strlen(s_json_param));
	
	dzlog_info("live start cjson reply body data end");

REPLY_END:
	if(s_json_param) 
	{
		free(s_json_param); 
		s_json_param = NULL;
	}
	if(param_root) 
	{
		cJSON_Delete(param_root); 
		param_root = NULL;
	}
	
	return reply_body_data;
}

char *set_mgw_cjson_face_change_reply_body_data(int code)
{
	UINT64 time_data = 0;
	cJSON *param_root = NULL;
	char *s_json_param = NULL;
	char *reply_body_data = NULL;

	dzlog_info("face change cjson reply body data start");
	
	param_root = cJSON_CreateObject();	//创建
	
#if MGW_LOG
	dzlog_info("cJSON_CreateObject is ok");
#endif

	if(!param_root)
	{
		dzlog_error("cJSON CreateObject is error");
		return NULL;
	}

	time_data = zx_mgw_CurTime_s();
	
#if MGW_LOG
	dzlog_info("***mgw CurTime_s is ok***");
#endif

	cJSON_AddNumberToObject(param_root,"code",code);

	if(code == 0)
	{
		cJSON_AddStringToObject(param_root,"message","succeed");
	}else{
		
		cJSON_AddStringToObject(param_root,"message","failed url or ptype is error");
	}

	cJSON_AddNumberToObject(param_root,"timestamp",time_data);

#if MGW_LOG
	dzlog_info("face change reply body data cJSON add ok");
#endif

	s_json_param = cJSON_PrintUnformatted(param_root);
	
	if(!s_json_param)
	{
		dzlog_error("cJSON PrintUnformatted is error");
		goto REPLY_END;
	}
	
#if MGW_LOG
	dzlog_info("face change reply body data cJSON = %s",s_json_param);
#endif	

	reply_body_data = (char *)malloc(strlen(s_json_param) + 2);
	
	if(!reply_body_data)
	{
		dzlog_error("out of memory for reply_body_data.");
		goto REPLY_END;
	}
	memset(reply_body_data,0,strlen(s_json_param) + 2);

	memcpy(reply_body_data,s_json_param,strlen(s_json_param));
	
	dzlog_info("face change cjson reply body data end");

REPLY_END:
	if(s_json_param) 
	{
		free(s_json_param); 
		s_json_param = NULL;
	}
	if(param_root) 
	{
		cJSON_Delete(param_root); 
		param_root = NULL;
	}
	
	return reply_body_data;
}

/*
接收和解析数据
*/
int zx_mgw_commun_recv_and_parsing_data(MGW_COMMUN_PRO *recv_package_data,int sockfd)
{
	
	char *recv_data = NULL;	
	int ret = -1;

	if(!recv_package_data)
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}
	
	dzlog_info("mgw commun recv and parsing data start");
	
	recv_data = zx_mgw_commun_recv_data(sockfd,&recv_package_data->packetlen); //接收数据

	if(!recv_data)
	{
		dzlog_error("recv mgw commun is error");
		ret = -1;
		goto FREE_END;
	}
	
#if MGW_LOG
	dzlog_info("mgw commun recv data is ok");
#endif

	ret = zx_mgw_commun_parsing_data(recv_data,recv_package_data); //解析数据

	if(ret == -1)
	{
		dzlog_error("send mgw commun is error");
		goto FREE_END;
	}
	
	dzlog_info("parsing recv data printf");
	zx_mgw_commun_printf(recv_package_data);

	dzlog_info("mgw commun recv and parsing data end");
	
FREE_END:
	if(recv_data)
	{
		free(recv_data);
		recv_data = NULL;
	}
	return ret;
}


int zx_mgw_commun_send_version_data(int sockfd)
{
	MGW_COMMUN_PRO *send_package_data = NULL;	//发送数据包结构体
	char *send_data = NULL;	
	char *body_data = NULL;
	UINT64 time_data = 0;
	int ret = -1;
	
	dzlog_info("******send version data start*******");

	send_package_data = zx_mgw_commun_init();	//初始化

	if(!send_package_data)
	{
		dzlog_error(" mgw commun init is error");
		goto SEND_END;
	}

	time_data = zx_mgw_CurTime_s();
	
	body_data = set_mgw_cjson_pull_body_data(time_data,"",-1);

	if(!body_data)
	{
		dzlog_error("set mgw cjson pull body_data is error");
		goto SEND_END;
	}
	
#if MGW_LOG
	dzlog_info("version pull body_data = %s",body_data);
#endif

	ret = zx_mgw_commun_assignment_value(send_package_data,VERSION_PING_URL,AGREE_BYTE,TRANSFER_COUNT,TypePull,BODY_BODECODEC,send_seq,body_data);

	if(ret == -1)
	{
		dzlog_error("mgw assignment value is error");
		goto SEND_END;
	}
	
#if MGW_LOG
	dzlog_info("******assignment value is ok*******");
#endif	
	
	dzlog_info("******send version data printf start*******");
	zx_mgw_commun_printf(send_package_data);

	send_data = zx_mgw_commun_set_data_packages(send_package_data);  //发送数据组包

	if(!send_data)
	{
		dzlog_error("set mgw commun packages is error");
		ret = -1;
		goto SEND_END;
	}

	ret = zx_mgw_commun_send_data(sockfd,send_data,send_package_data->packetlen ); //发送数据

	if(ret == -1)
	{
		dzlog_error("send mgw commun is error");
		goto SEND_END;
	}

	dzlog_info("******send version data end*******");

SEND_END:
	if(send_package_data)
	{
		zx_mgw_commun_free(send_package_data);
		send_package_data = NULL;
	}	
	
	if(send_data)
	{
		free(send_data);
		send_data = NULL;
	}
	if(body_data)
	{
		free(body_data);
		body_data = NULL;
	}
		
	return ret;
	
}

int zx_mgw_commun_send_heartbest_data(int sockfd)
{
	MGW_COMMUN_PRO *send_package_data = NULL;	//发送数据结构体
	char *send_data = NULL;
	char *body_data = NULL;
	int ret = -1;
	UINT64 time_data = 0;
	
	dzlog_info("******send heartbest data start*******");

	send_package_data = zx_mgw_commun_init();	//结构体初始化
	
	if(!send_package_data)
	{
		dzlog_error(" mgw commun init is error");
		goto FREE_END;
	}

	time_data = zx_mgw_CurTime_s();
	
	body_data = set_mgw_cjson_pull_body_data(time_data,base_param->hub_info.hub_sn,-1);
	
	if(!body_data)
	{
		dzlog_error("set mgw cjson pull body_data is error");
		goto FREE_END;
	}
	
#if MGW_LOG
	dzlog_info("heartbest send body_data = %s",body_data);
#endif

	while(mgw_running)
	{
		
		zx_mgw_setTimer(30,0);	
		ret = zx_mgw_commun_assignment_value(send_package_data,HEARTBEST_URL,AGREE_BYTE,TRANSFER_COUNT,TypePull,BODY_BODECODEC,send_seq,body_data);

		if(ret == -1)
		{
			dzlog_error("mgw assignment value is error");
			goto FREE_END;
		}

#if MGW_LOG
			dzlog_info("******assignment value is ok*******");
#endif	

		dzlog_info("****** send heartbest data printf statr *******");
		zx_mgw_commun_printf(send_package_data);

		send_data = zx_mgw_commun_set_data_packages(send_package_data);  //组包

		if(!send_data)
		{
			dzlog_error("set mgw commun packages is error");
			ret = -1;
			goto FREE_END;
		}
		
		dzlog_info("send_package_data printf");
		zx_mgw_commun_printf(send_package_data);
		
		ret = zx_mgw_commun_send_data(sockfd,send_data,send_package_data->packetlen ); //发包

		if(ret == -1)
		{
			dzlog_error("send mgw commun is error");
			goto FREE_END;
		}
		
		dzlog_info("mgw send communr is ok send_package_data->seq =  %llu",send_package_data->seq);
	}
FREE_END:
	
	if(send_package_data)
	{
		zx_mgw_commun_free(send_package_data);
		send_package_data = NULL;
	}

	if(body_data)
	{
		free(body_data);
		body_data = NULL;
	}

	if(send_data)
	{
		free(send_data);
		send_data = NULL;
	}
	return ret;
}


int zx_mgw_commun_operation_version_data(MGW_COMMUN_PRO *recv_package_data)
{
	cJSON *json_data = NULL,*body_data = NULL;

	if(!recv_package_data)
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}

	dzlog_info("******mgw commun send version start******");

	json_data = cJSON_Parse(recv_package_data->body); //字符串解析成json结构体

	if(!json_data)
	{
		dzlog_error("******cJSON Parse is error******");
		return -1;
	}
	
	if(zx_Json_GetInt(json_data,"code",0) == 0) 
	{
		body_data = cJSON_GetObjectItem(json_data,"data");
		
#if MGW_LOG
		char *s_result = NULL;
		s_result = cJSON_PrintUnformatted(body_data);
		
		if(!s_result)
		{
			dzlog_error("******cJSON GetObjectItem Body is NULL******");
			return -1;
		}
		dzlog_info("****** mgw head cjson data is %s******",s_result);
		
		if(s_result) {free(s_result); s_result = NULL;}
#endif
		version = zx_MyJson_GetString(body_data, "ver", "");

		if( !version )
		{
			dzlog_error("******MyJson GetString version is NULL******");
			return -1;
		}

		dzlog_info("****** mgw head cjson AppVersion is %s******",version);
	}

	dzlog_info("******mgw send data is ok and live start end******");
	
	return 0;
}


int zx_mgw_commun_operation_live_start_data(MGW_COMMUN_PRO *recv_package_data,int sockfd,int code)
{
	MGW_COMMUN_PRO *send_package_data = NULL; 	//发送数据包结构体
	char *send_data = NULL;		
	char *reply_body_data = NULL;
	int ret = -1;
	cJSON *json_data = NULL,*body_data = NULL;
	STREAM_CONNECT_INFO *stream_con = NULL;

	char *station = NULL;
	int channel  = -1;

	if(!recv_package_data)
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}

	dzlog_info("******mgw commun send live start******");

	send_package_data = zx_mgw_commun_init();	//结构体初始化

	if(!send_package_data)
	{
		dzlog_error(" mgw commun init is error");
		goto FREE_END;
	}
			
	json_data = cJSON_CreateObject();

	body_data = cJSON_Parse(recv_package_data->body); //字符串解析成json结构体

	if(!body_data)
	{
		dzlog_error("******cJSON Parse is error******");
		goto FREE_END;
	}

	station = zx_MyJson_GetString(body_data,"sn","");	//基站sn
	
	channel = zx_Json_GetInt(body_data,"ch",0);  		//设备通道号

	ret = zx_start_stream(channel,HISI_RTMP);			//打开摄像头

	if(ret != 0)
	{
		dzlog_error("******start streame is error******");
		goto FREE_END;
	}
	
	stream_con = zx_get_stream(channel);	//获取相关的信息
	
	if(!stream_con)
	{
		dzlog_error("******get stream is error******");
		goto FREE_END;
	}
	
	dzlog_info("******station = %s, channel = %d******",station,channel);

	dzlog_info("******station = %s******",stream_con->szFileName);

	cJSON_AddStringToObject(json_data,"url",stream_con->szFileName);		//发送推流url		   stream_con.iControlThreadRun = 0 至0就是关闭摄像头流通道
	
	reply_body_data = set_mgw_cjson_live_start_reply_body_data(code,json_data);

	if(!reply_body_data)
	{
		dzlog_error(" set mgw cjson live_start reply body data is error");
		goto FREE_END;
	}
		
#if MGW_LOG
	dzlog_info("reply_body_data = %s",reply_body_data);
#endif

	ret = zx_mgw_commun_assignment_value(send_package_data,LIVE_START_URL,AGREE_BYTE,TRANSFER_COUNT,TYPEREPLY,BODY_BODECODEC,recv_seq,reply_body_data);

	if(ret == -1)
	{
		dzlog_error("mgw assignment value is error");
		goto FREE_END;
	}
	
	dzlog_info("******send live start data printf*******");
	zx_mgw_commun_printf(send_package_data);

	send_data = zx_mgw_commun_set_data_packages(send_package_data);  //设置数据包

	if(!send_data)
	{
		dzlog_error("set mgw commun packages is error");
		ret = -1;
		goto FREE_END;
	}

	ret = zx_mgw_commun_send_data(sockfd,send_data,send_package_data->packetlen ); //发送数据

	if(ret == -1)
	{
		dzlog_error("send mgw commun is error");
		goto FREE_END;
	}

	dzlog_info("******mgw send data is ok and live start end******");

FREE_END:
	if(send_package_data)
	{
		zx_mgw_commun_free(send_package_data);
		send_package_data = NULL;
	}
	
	if(send_data)
	{
		free(send_data);
		send_data = NULL;
	}
	
	if(station)
	{
		free(station);
		station = NULL;
	}
		
	return ret;
}


int zx_mgw_commun_operation_face_change_data(MGW_COMMUN_PRO *recv_package_data,int sockfd,int code)
{
	MGW_COMMUN_PRO *send_package_data = NULL; 	//发送数据包结构体
	char *send_data = NULL;
	char *reply_body_data = NULL;
	int ret = -1;

	if(!recv_package_data)
	{
		dzlog_error("The function parameter  is NULL");
		return -1;
	}
	
	dzlog_info("******mgw commun send face change data start******");

	send_package_data = zx_mgw_commun_init();	//结构体初始化

	if(!send_package_data)
	{
		dzlog_error(" mgw commun init is error");
		goto FREE_END;
	}
	
#if MGW_LOG
	dzlog_info("******zx_mgw_commun_init is ok******");
#endif
		
	reply_body_data = set_mgw_cjson_face_change_reply_body_data(code);
	
	if(!reply_body_data)
	{
		dzlog_error(" set mgw cjson live_start reply body data is error");
		goto FREE_END;
	}
	
#if MGW_LOG
	dzlog_info("face change reply_body_data = %s",reply_body_data);
#endif

	ret = zx_mgw_commun_assignment_value(send_package_data,FACE_CHANGED_URL,AGREE_BYTE,TRANSFER_COUNT,TYPEREPLY,BODY_BODECODEC,recv_seq,reply_body_data);

	if(ret == -1)
	{
		dzlog_error("mgw assignment value is error");
		goto FREE_END;
	}
	
	dzlog_info("******send face change data printf*******");
	zx_mgw_commun_printf(send_package_data);

	send_data = zx_mgw_commun_set_data_packages(send_package_data);  //设置数据包

	if(!send_data)
	{
		dzlog_error("set mgw commun packages is error");
		goto FREE_END;
	}
	
#if MGW_LOG
	dzlog_info("******mgw commun set data packages ok*******");
#endif

	ret = zx_mgw_commun_send_data(sockfd,send_data,send_package_data->packetlen ); //发送数据
	
	if(ret == -1)
	{
		dzlog_error("send mgw commun is error");
		goto FREE_END;
	}
	
	dzlog_info("******mgw commun send face change data end******");

FREE_END:
	if(send_package_data)
	{
		zx_mgw_commun_free(send_package_data);
		send_package_data = NULL;
	}	

	if(reply_body_data)
	{
		free(reply_body_data);
		reply_body_data = NULL;
	}

	if(send_data)
	{
		free(send_data);
		send_data = NULL;
	}
		
	return ret;
}

void *mgw_commun_send_thread_funnc(void *mgw_sockfd)
{
	int ret = -1;
	int *sockfd = (int *)mgw_sockfd;

	
	dzlog_info("******mgw_commun_send_thread_funnc is start*******");

	ret = zx_mgw_commun_send_version_data(*sockfd);
	
	if(ret == -1)
	{
		dzlog_error("commun send version data is error");
		return	NULL;
	}
#if MGW_LOG
	dzlog_info("send version data is ok");
#endif	
	ret = zx_mgw_commun_send_heartbest_data(*sockfd);
	
	if(ret == -1)
	{
		dzlog_error("commun send version data is error");
		return NULL;
	}
	dzlog_info("send heartbest data is end");

	return (void *)0;

}


void *mgw_commun_recv_thread_funnc(void *mgw_sockfd)
{
	MGW_COMMUN_PRO *recv_package_data = NULL;
	int ret = -1;
	int nready = -1;
	struct timeval timeout;

	fd_set rset, allset;

	dzlog_info("******mgw_commun_recv_thread_funnc is start*******");
	
	int *sockfd = (int *)mgw_sockfd;

	recv_package_data = zx_mgw_commun_init();	//结构体初始化
	
	FD_ZERO(&allset);
    FD_SET(*sockfd, &allset);

	while(mgw_running)
	{
		rset = allset; 
		timeout.tv_sec=120;		//超时时间
		timeout.tv_usec=0;
		
		nready = select(*sockfd + 1,&rset,NULL,NULL,&timeout);

		if(nready < 0)
		{
			dzlog_error("select is error: %d",nready);
			ret = -1;
			break;
		}
		else if(nready == 0) 	//超时处理
		{
			
			dzlog_error("select is timeout,connect again");
			close(*sockfd);
			break;
		}
		
		if (FD_ISSET(*sockfd, &rset))
		{
			ret = zx_mgw_commun_recv_and_parsing_data(recv_package_data,*sockfd);
			
			if(ret == -1)
			{	
				dzlog_error("******cJSON Parse is error******");
				goto FREE_END;
			}
		
			dzlog_info("******parsing data is ok*******");
			
			recv_seq = recv_package_data->seq;
			
		#if MGW_LOG
			dzlog_info("******precv_package_data->url = %s*******",recv_package_data->uri);
		#endif
		

			if(strcmp(recv_package_data->uri,HEARTBEST_URL) == 0)	//心跳包
			{	
				dzlog_info("******heartbest is ok*******");
			}

			else if(strcmp(recv_package_data->uri,VERSION_PING_URL) == 0)	//获取版本
			{
				ret = zx_mgw_commun_operation_version_data(recv_package_data);

				if(ret == -1)
				{	
					dzlog_error("******cJSON Parse is error******");
					goto FREE_END;
				}
			}
		
			else if(strcmp(recv_package_data->uri,LIVE_START_URL) == 0)		//通知基站推流
			{
				ret = zx_mgw_commun_operation_live_start_data(recv_package_data,*sockfd,0);

				if(ret == -1)
				{	
					dzlog_error("******cJSON Parse is error******");
					goto FREE_END;
				}
			}

			else if(strcmp(recv_package_data->uri,FACE_CHANGED_URL) == 0)	//通知基站人脸更新
			{
				ret = zx_mgw_commun_operation_face_change_data(recv_package_data,*sockfd,0);

				if(ret == -1)
				{	
					dzlog_error("******cJSON Parse is error******");
					goto FREE_END;
				}
			}
			
		}
	}
	
FREE_END:
	if(recv_package_data)
	{
		zx_mgw_commun_free(recv_package_data);
		recv_package_data = NULL;
	}
	
	return (void *)0;

}


int zx_mgw_commun_long_connection_func()
{
	int ret = -1,sockfd = -1;
	pthread_t send_pid;
	pthread_t recv_pid;
	
	dzlog_info("mgw commun long connection start");
	
	while(1)
	{
	AGAIN:
		sockfd = zx_mgw_commun_create_socket(MGW_SERV_IP,MGW_SERV_PORT);

		if(sockfd == -1)
		{
			dzlog_error("socket is error,Please check whether the network is normal.");
			zx_mgw_setTimer(1,0);
			dzlog_warn("Prepare to reconnect to the network.");
			goto AGAIN;
		}
		
		ret = pthread_create(&send_pid,NULL,mgw_commun_send_thread_funnc,&sockfd);  //开线程接收数据

		if(ret != 0)
		{
			dzlog_error(" fail to create thread ,close conncet sockfd"); 
			close(sockfd);
			ret = -1;
			break;
		}

		ret = pthread_create(&recv_pid,NULL,mgw_commun_recv_thread_funnc,&sockfd);  //开线程接收数据

		if(ret != 0)
		{
			dzlog_error(" fail to create thread ,close conncet sockfd"); 
			close(sockfd);
			ret = -1;
			break;
		}

		pthread_join(send_pid,NULL);	//回收子进程
		pthread_join(recv_pid,NULL);	//回收子进程	

	}
	dzlog_info("mgw commun long connection end");

	return ret;
}


int zx_ota_system(const char * cmdstring)
{
    pid_t pid;
    int status = 0;

	dzlog_info("system start perform...");
 
	if(!cmdstring )
	{
		dzlog_warn("The function parameter  is NULL");
	    return -1; //如果cmdstring为空，返回非零值
	}

	dzlog_info("fork start...");
	
	if((pid = fork()) < 0)
	{
		dzlog_error("fork error, errno =  %d======>[ %s ]",errno,strerror(errno));
	    status = -1; //fork失败，返回-1
	}
	else if(pid == 0)
	{
		dzlog_info("fork ok , this is child process");
	    execl("/bin/sh", "sh", "-c", cmdstring, (char *)0);
		dzlog_error("execl is error");
	    _exit(127); // exec执行失败返回127
	}
	else //父进程
	{
		dzlog_info("this father process");
	    while(waitpid(pid, &status, 0) < 0)
	    {
	        if(errno != EINTR)
	        {
	            status = -1; //如果waitpid被信号中断，则返回-1
	            break;
	        }
	    }
		dzlog_info("father process waitpid ok");
	}
    return status; //如果waitpid成功，则返回子进程的返回状态
}










