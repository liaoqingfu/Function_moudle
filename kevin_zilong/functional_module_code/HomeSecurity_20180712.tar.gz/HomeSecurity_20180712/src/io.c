/*
 ============================================================================
 Name        : io.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description :
 ============================================================================
 */

#include "io.h"
#include "reader.h"
#include <curl/curl.h>

/*============================================================================*/
/* func zx_Io_form */

typedef struct _zx_Io_form 
{
    struct curl_httppost *formpost;
    struct curl_httppost *lastptr;
} zx_Io_form;

static zx_Io_PutExtra zx_defaultExtra = {NULL, NULL, 0, 0, NULL};

static void zx_Io_form_init(
        zx_Io_form *self, const char *uptoken, const char *key, zx_Io_PutExtra **extra) 
{
    zx_Io_PutExtraParam *param;
    struct curl_httppost *formpost = NULL;
    struct curl_httppost *lastptr = NULL;

    curl_formadd(&formpost, &lastptr, CURLFORM_COPYNAME, "token", CURLFORM_COPYCONTENTS, uptoken, CURLFORM_END);

    if (*extra == NULL) 
	{
        *extra = &zx_defaultExtra;
    }
    if (key != NULL) 
	{
        curl_formadd(&formpost, &lastptr, CURLFORM_COPYNAME, "key", CURLFORM_COPYCONTENTS, key, CURLFORM_END);
    }
    for (param = (*extra)->params; param != NULL; param = param->next) 
	{
        curl_formadd(&formpost, &lastptr, CURLFORM_COPYNAME, param->key, CURLFORM_COPYCONTENTS, param->value, CURLFORM_END);
    }

    self->formpost = formpost;
    self->lastptr = lastptr;
}

/*============================================================================*/
/* func zx_Io_PutXXX */

CURL *zx_Client_reset(zx_Client *self);

zx_Error zx_callex(CURL *curl, zx_Buffer *resp, zx_Json **ret, zx_Bool simpleError, zx_Buffer *resph);

static zx_Error zx_Io_call(
        zx_Client *self, zx_Io_PutRet *ret, struct curl_httppost *formpost,
        zx_Io_PutExtra *extra) 
{
    int retCode = 0;
    zx_Error err;
    struct curl_slist *headers = NULL;
    const char *upHost = NULL;

    CURL *curl = zx_Client_reset(self);

    // Bind the NIC for sending packets.
    if (self->boundNic != NULL) 
	{
        retCode = curl_easy_setopt(curl, CURLOPT_INTERFACE, self->boundNic);
        if (retCode == CURLE_INTERFACE_FAILED) 
		{
            err.code = 9994;
            err.message = "Can not bind the given NIC";
            return err;
        }
    }

    // Specify the low speed limit and time
    if (self->lowSpeedLimit > 0 && self->lowSpeedTime > 0) 
	{
        retCode = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, self->lowSpeedLimit);
        if (retCode == CURLE_INTERFACE_FAILED) 
		{
            err.code = 9994;
            err.message = "Can not specify the low speed limit";
            return err;
        }
        retCode = curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, self->lowSpeedTime);
        if (retCode == CURLE_INTERFACE_FAILED) 
		{
            err.code = 9994;
            err.message = "Can not specify the low speed time";
            return err;
        }
    }

    headers = curl_slist_append(NULL, "Expect:");

    //// For using multi-region storage.
    if (extra && (upHost = extra->upHost) == NULL) 
	{
        upHost = zx_UP_HOST;
    } // if


    curl_easy_setopt(curl, CURLOPT_URL, upHost);
    curl_easy_setopt(curl, CURLOPT_HTTPPOST, formpost);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    //// For aborting uploading file.
    if (extra->upAbortCallback) {
        curl_easy_setopt(curl, CURLOPT_READFUNCTION, zx_Rd_Reader_Callback);
    } // if

    err = zx_callex(curl, &self->b, &self->root, zx_False, &self->respHeader);
    if (err.code == 200 && ret != NULL) {
        if (extra->callbackRetParser != NULL) {
            err = (*extra->callbackRetParser)(extra->callbackRet, self->root);
        } else {
            ret->hash = zx_Json_GetString(self->root, "hash", NULL);
            ret->key = zx_Json_GetString(self->root, "key", NULL);
            ret->persistentId = zx_Json_GetString(self->root, "persistentId", NULL);
        }
    }

    curl_formfree(formpost);
    curl_slist_free_all(headers);
    return err;
}

zx_Error zx_Io_PutFile(
        zx_Client *self, zx_Io_PutRet *ret,
        const char *uptoken, const char *key, const char *localFile, zx_Io_PutExtra *extra) 
{
    zx_Error err;
    zx_FileInfo fi;
    zx_Rd_Reader rdr;
    zx_Io_form form;
    size_t fileSize;
    const char *localFileName;
    zx_Io_form_init(&form, uptoken, key, &extra);

    // BugFix : If the filename attribute of the file form-data section is not assigned or holds an empty string,
    //          and the real file size is larger than 10MB, then the Go server will return an error like
    //          "multipart: message too large".
    //          Assign an arbitary non-empty string to this attribute will force the Go server to write all the data
    //          into a temporary file and then every thing goes right.
    localFileName = (extra->localFileName) ? extra->localFileName : "OCEANWING-C-SDK-UP-FILE";

    //// For aborting uploading file.
    if (extra->upAbortCallback) 
	{
        zx_Zero(rdr);

        rdr.abortCallback = extra->upAbortCallback;
        rdr.abortUserData = extra->upAbortUserData;

        err = zx_Rd_Reader_Open(&rdr, localFile);
        if (err.code != 200) 
		{
            return err;
        } // if


        zx_Zero(fi);
        err = zx_File_Stat(rdr.file, &fi);
        if (err.code != 200) 
		{
            return err;
        } // if

        fileSize = fi.st_size;

        curl_formadd(&form.formpost, &form.lastptr, CURLFORM_COPYNAME, "file", CURLFORM_STREAM, &rdr,
                     CURLFORM_CONTENTSLENGTH, (long) fileSize, CURLFORM_FILENAME, localFileName, CURLFORM_END);
    } 
	else 
	{
        curl_formadd(&form.formpost, &form.lastptr, CURLFORM_COPYNAME, "file", CURLFORM_FILE, localFile,
                     CURLFORM_FILENAME, localFileName, CURLFORM_END);
    } // if

    err = zx_Io_call(self, ret, form.formpost, extra);

    //// For aborting uploading file.
    if (extra->upAbortCallback) 
	{
        zx_Rd_Reader_Close(&rdr);
        if (err.code == CURLE_ABORTED_BY_CALLBACK) 
		{
            if (rdr.status == zx_RD_ABORT_BY_CALLBACK) 
			{
                err.code = 9987;
                err.message = "Upload progress has been aborted by caller";
            } 
			else if (rdr.status == zx_RD_ABORT_BY_READAT) 
			{
                err.code = 9986;
                err.message = "Upload progress has been aborted by zx_File_ReadAt()";
            } // if
        } // if
    } // if

    return err;
}

zx_Error zx_Io_PutBuffer(
        zx_Client *self, zx_Io_PutRet *ret,
        const char *uptoken, const char *key, const char *buf, size_t fsize, zx_Io_PutExtra *extra) 
{
    zx_Io_form form;
    zx_Io_form_init(&form, uptoken, key, &extra);

    if (key == NULL) 
	{
        // Use an empty string instead of the NULL pointer to prevent the curl lib from crashing
        // when read it.
        // **NOTICE**: The magic variable $(filename) will be set as empty string.
        key = "";
    }

    curl_formadd(
            &form.formpost, &form.lastptr, CURLFORM_COPYNAME, "file",
            CURLFORM_BUFFER, key, CURLFORM_BUFFERPTR, buf, CURLFORM_BUFFERLENGTH, fsize, CURLFORM_END);

    return zx_Io_call(self, ret, form.formpost, extra);
}

// This function  will be called by 'zx_Io_PutStream'
// In this function, readFunc(read-stream-data) will be set
static zx_Error zx_Io_call_with_callback(
        zx_Client *self, zx_Io_PutRet *ret,
        struct curl_httppost *formpost,
        rdFunc rdr,
        zx_Io_PutExtra *extra) 
{
    int retCode = 0;
    zx_Error err;
    struct curl_slist *headers = NULL;

    CURL *curl = zx_Client_reset(self);

    // Bind the NIC for sending packets.
    if (self->boundNic != NULL) 
	{
        retCode = curl_easy_setopt(curl, CURLOPT_INTERFACE, self->boundNic);
        if (retCode == CURLE_INTERFACE_FAILED) 
		{
            err.code = 9994;
            err.message = "Can not bind the given NIC";
            return err;
        }
    }

    headers = curl_slist_append(NULL, "Expect:");

    curl_easy_setopt(curl, CURLOPT_URL, zx_UP_HOST);
    curl_easy_setopt(curl, CURLOPT_HTTPPOST, formpost);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, rdr);

    err = zx_callex(curl, &self->b, &self->root, zx_False, &self->respHeader);
    if (err.code == 200 && ret != NULL) 
	{
        if (extra->callbackRetParser != NULL) 
		{
            err = (*extra->callbackRetParser)(extra->callbackRet, self->root);
        } 
		else 
		{
            ret->hash = zx_Json_GetString(self->root, "hash", NULL);
            ret->key = zx_Json_GetString(self->root, "key", NULL);
        }
    }

    curl_formfree(formpost);
    curl_slist_free_all(headers);
    return err;
}

zx_Error zx_Io_PutStream(
        zx_Client *self, zx_Io_PutRet *ret,
        const char *uptoken, const char *key,
        void *ctx, size_t fsize, rdFunc rdr,
        zx_Io_PutExtra *extra) 
{
    zx_Io_form form;
    zx_Io_form_init(&form, uptoken, key, &extra);

    if (key == NULL) 
	{
        // Use an empty string instead of the NULL pointer to prevent the curl lib from crashing
        // when read it.
        // **NOTICE**: The magic variable $(filename) will be set as empty string.
        key = "";
    }

    // Add 'filename' property to make it like a file upload one
    // Otherwise it may report: CURL_ERROR(18) or "multipart/message too large"
    // See https://curl.haxx.se/libcurl/c/curl_formadd.html#CURLFORMSTREAM
    curl_formadd(
            &form.formpost, &form.lastptr,
            CURLFORM_COPYNAME, "file",
            CURLFORM_FILENAME, "filename",
            CURLFORM_STREAM, ctx,
            CURLFORM_CONTENTSLENGTH, fsize,
            CURLFORM_END);

    return zx_Io_call_with_callback(self, ret, form.formpost, rdr, extra);
}
