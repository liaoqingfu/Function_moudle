/*
 ============================================================================
 Name        : reader.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description :
 ============================================================================
 */

#include <curl/curl.h>

#include "reader.h"

zx_Error zx_Rd_Reader_Open(zx_Rd_Reader * rdr, const char * localFileName)
{
	zx_Error err;
	err = zx_File_Open(&rdr->file, localFileName);
	if (err.code != 200) 
	{
		return err;
	} // if

	rdr->offset = 0;
	rdr->status = zx_RD_OK;

	return zx_OK;
}

void zx_Rd_Reader_Close(zx_Rd_Reader * rdr)
{
	zx_File_Close(rdr->file);
}

size_t zx_Rd_Reader_Callback(char * buffer, size_t size, size_t nitems, void * userData)
{
	ssize_t ret;
	zx_Rd_Reader * rdr = (zx_Rd_Reader *)userData;

	ret = zx_File_ReadAt(rdr->file, buffer, size * nitems, rdr->offset);
	if (ret < 0) 
	{
		rdr->status = zx_RD_ABORT_BY_READAT;
		return CURL_READFUNC_ABORT;
	} // if

	if (rdr->abortCallback && rdr->abortCallback(rdr->abortUserData, buffer, ret)) 
	{
		rdr->status = zx_RD_ABORT_BY_CALLBACK;
		return CURL_READFUNC_ABORT;
	} // if

	rdr->offset += ret;
	return ret;
}
