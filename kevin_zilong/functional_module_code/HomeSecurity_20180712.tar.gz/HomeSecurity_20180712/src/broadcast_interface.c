/*============================================================================
 Name        : broadcast_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-11-21 
 Description : 
 ============================================================================*/

#include <sys/types.h>  
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>   
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/ip_icmp.h>
#include <fcntl.h>
#include <sys/select.h>

#include "base.h"
#include "comm_protocol_define.h"
#include "broadcast_interface.h"
#include "sys_interface.h"
#include "enc_decrypt_interface.h"
#include "if.h"

int gbroadcast_running = 1;

typedef struct broadcast_base
{
	char sn[DEVICE_SN_LEN + 1];
	char lan_ipaddr[SMALL_STR_LEN + 1];
	int  port;
}BROAD_BASE;


static void * zx_lan_broadcast(void *argv)  
{  
	#if 1
	//char *sn = (char *)argv;
	BROAD_BASE broad_base;
	
	memcpy(&broad_base, argv, sizeof(BROAD_BASE));
	
	dzlog_info("【start sn=%s ip=%s  port=%d......】", broad_base.sn, broad_base.lan_ipaddr,broad_base.port);
	
	struct timeval tv; 
	struct ifreq if_dev;
	int ret = 0;

	int sock = -1;
	//strncpy(if_dev.ifr_name, WLAN_DEV_NAME, IFNAMSIZ);
	
	strncpy(if_dev.ifr_name, WLAN_DEV_WALN_NAME, IFNAMSIZ);

	dzlog_info("if_dev,ifr_name = %s",if_dev.ifr_name);
	
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
    {     
        dzlog_error("socket error");   
        pthread_exit(0);  
    }
    if ( setsockopt(sock, SOL_SOCKET, SO_BINDTODEVICE, (char *)&if_dev, sizeof(if_dev))< 0) 
	{
		dzlog_error("【setsockopt SO_BINDTODEVICE error... ret = %d,errno = %d】",ret,errno);  
		pthread_exit(0);
	}
    
    const int opt = 1;  
    //设置该套接字为广播类型，  
    int nb = 0;  
    nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  
    if(nb == -1)  
    {  
        dzlog_error("setsockopt error...");  
        pthread_exit(0);   
    }  

	struct sockaddr_in addrto;  
    bzero(&addrto, sizeof(struct sockaddr_in));  
    addrto.sin_family = AF_INET;  
#if 1
    addrto.sin_addr.s_addr = htonl(INADDR_BROADCAST);  
#else
	addrto.sin_addr.s_addr = htonl(broad_base.lan_ipaddr);
#endif
    addrto.sin_port = htons(BROADCAST_PORT);  //BORADCAST_PORT
    
    int nlen = sizeof(addrto); 

	ZX_COMMUNICATION_PACKET msg;
	
	memset(&msg, 0, sizeof(ZX_COMMUNICATION_PACKET));
	
	msg.msg_head.head_tag = PAG_HEARD_TAG;
	
	msg.msg_head.command_id = APP_CMD_FLBIND_BROADCAST;
	
	msg.msg_head.param_len = sizeof(PARAM_APP_BIND);
	
	msg.msg_head.sign_code = NO_SEC_KEY;

	PARAM_APP_BIND *app_bind = &msg.param_body.app_bind;
	
	memset(app_bind, 0, sizeof(PARAM_APP_BIND));

	app_bind->port = broad_base.port;
	
	memcpy(app_bind->sn, broad_base.sn, strlen(broad_base.sn));	
	memcpy(app_bind->ip_addr, broad_base.lan_ipaddr, strlen(broad_base.lan_ipaddr));	

	dzlog_info("【app_bind->sn = %s , app_bind->ip_addr = %s , app_bind->port = %d】",app_bind->sn,app_bind->ip_addr,app_bind->port);

    while(gbroadcast_running)  
    {  
        tv.tv_sec = 0;    
        tv.tv_usec = TIMER_LAN_BROADCAST*1000; 
          
        switch(select(0, NULL, NULL, NULL, &tv))   
        {  
        	case -1:  
            	dzlog_info("select Error!");  
            	break;  
        	case 0:  
				{
					//从广播地址发送消息 
					//dzlog_info("【send SO_BROADCAST sn:%s, ip_addr:%s, port:%d】", app_bind->sn,app_bind->ip_addr,app_bind->port);//
        			int ret = sendto(sock, &msg, msg.msg_head.param_len + sizeof(PARAM_APP_BIND), 0, (struct sockaddr*)&addrto, nlen);  
					
        			if(ret < 0)  
        			{  
            			dzlog_error("send error[%d]....", ret);
        			} 
		 
				} 
            	break;  
        	default:  
            	break;  
        }  
    } 
	dzlog_info("exit......");
	close(sock);
	#endif
	pthread_exit(0);
	return;		
} 


int zx_send_boradcast(int port, char *sn, char *lan_ipaddr)  
{  
	BROAD_BASE broad_base;
	memset(&broad_base, 0, sizeof(BROAD_BASE));
	gbroadcast_running = 1;
	if (sn && lan_ipaddr)
	{
		memcpy(broad_base.sn, sn, strlen(sn));
		memcpy(broad_base.lan_ipaddr, lan_ipaddr, strlen(lan_ipaddr));
		broad_base.port = port;
		
		zx_create_thread(LOW_PRIORITY, zx_lan_broadcast, &broad_base, -1, LAN_BROADCAST, -1);
	}
	usleep(500*1000);
    return 0;      
} 


void zx_stop_broadcase(void)
{
	gbroadcast_running = 0;
	dzlog_info("【stop broadcase...】");
}


int zx_internet_detection(const char *ip)
{
	int fd; 
    int in_len=0, err=0,len=0, ret=-1;
    struct sockaddr_in servaddr;
	int flags;
	fd_set rdevents,wrevents,exevents;
	struct timeval tval,tv;	
	
	if(!ip || strlen(ip) <= 0)
	{
    	dzlog_error("ip len <= 0");
        return 0; 		
	}

    in_len = sizeof(struct sockaddr_in);
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd < 0)
    {   
    	dzlog_error("create socket error %d", errno);
        return 0; 
    }   
	
	flags = fcntl(fd,F_GETFL,0);
	if(fcntl(fd, F_SETFL, flags|O_NONBLOCK) < 0)
    {
		goto exit;
	}
        
	servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(DNS_PORT);
    servaddr.sin_addr.s_addr = inet_addr(ip);
    memset(servaddr.sin_zero,0,sizeof(servaddr.sin_zero));

    if((ret = connect(fd,(struct sockaddr* )&servaddr,in_len)) && (errno != EINPROGRESS)) //  && (errno !=  0)
    {                   
		//dzlog_error("can not connect to internet! ret:%d.(%d) ", ret, errno );
        goto exit;
    }   

    if(ret == 0)
    {   
    	//dzlog_info("connect internet ok ret=%d", ret);
        close(fd);
		return 1;
   	} 

	FD_ZERO(&rdevents); 
	FD_SET(fd, &rdevents);  
	wrevents = rdevents;  
	exevents = rdevents; 

	tv.tv_sec = 5;  
	tv.tv_usec = 0; 

	switch(select(fd+1, &rdevents, &wrevents, &exevents, &tv))
	{
		case -1: 
		case 0:
			goto exit;
 
		default:
		{
			if (!FD_ISSET(fd, &rdevents) && !FD_ISSET(fd, &wrevents)) 
			{
				dzlog_error("FD_ISSET err");
        		goto exit;
			}

			len = sizeof(err);
			ret = getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len);
			if (ret < 0 || err != 0) 
			{
				dzlog_error("getsockopt err ret:%d.(%d) ", ret, err);
        		goto exit;
			}

			ret = fcntl(fd, F_SETFL, flags);
			if (ret < 0) 
			{
				dzlog_error("getsockopt err ret:%d.(%d) ", ret, errno);
				goto exit;
			}

			//dzlog_info("connect internet ok!");
			close(fd);
			return 1;
		}
	}

exit:	
	close(fd);
	return 0;
}



int zx_connect_xm_socket(const char *ip)
{
	int fd; 
    int in_len = 0,ret=-1;
    struct sockaddr_in servaddr;
	int flags;
    //char buf[128];
	//fd_set rdevents,wrevents,exevents;
	//struct timeval tval,tv;
	
	
	if( !ip || strlen(ip) <= 0 )
	{
    	dzlog_error("ip len <= 0");
        return 0; 		
	}
	

	//printf("check net surf=%s\n",ip);
    in_len = sizeof(struct sockaddr_in);
    fd = socket(AF_INET,SOCK_STREAM,0);
    if(fd < 0)
    {   
    	dzlog_error("create socket error!!");
        return 0; 
    }   
	
	flags = fcntl(fd,F_GETFL,0);
	if(fcntl(fd,F_SETFL,flags|O_NONBLOCK) < 0)
    {
    	close(fd);
		return 0;
	}
        
	servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(XM_SERVER_PORT);
    servaddr.sin_addr.s_addr = inet_addr(ip);
    memset(servaddr.sin_zero,0,sizeof(servaddr.sin_zero));

    if(( ret = connect(fd,(struct sockaddr* )&servaddr,in_len)  ) && (errno != EINPROGRESS) )
    {   
    	dzlog_info("can not connect to xm server socket! ");
        close(fd);
       	return 0; 
    }   

    if(ret == 0)
    {   
    	dzlog_info("connect ok ret=%d=====",ret);
        close(fd);
       	return 1;
    } 
	return 1;
}

int receive_boradcast(int port, broadcast_process callback)  
{  
    // 绑定地址  
    struct sockaddr_in addrto;  
    bzero(&addrto, sizeof(struct sockaddr_in));  
    addrto.sin_family = AF_INET;  
    addrto.sin_addr.s_addr = htonl(INADDR_ANY);  
    addrto.sin_port = htons(57603);  
      
    // 广播地址  
    struct sockaddr_in from;  
    bzero(&from, sizeof(struct sockaddr_in));  
    from.sin_family = AF_INET;  
    from.sin_addr.s_addr = htonl(INADDR_ANY);  
    from.sin_port = htons(57603);  
      
    int sock = -1;  
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
    {     
        dzlog_error("socket error");   
        return 0;  
    }     
  	//printf("socket ok\n");
    const int opt = 1;  
    //设置该套接字为广播类型，  
    int nb = 0;  
    nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  
    if(nb == -1)  
    {  
        dzlog_error("set socket error...");  
        return 0;  
    }  
  	//printf("setsocketopt ok\n");
    if(bind(sock,(struct sockaddr *)&(addrto), sizeof(struct sockaddr)) == -1)   
    {     
        dzlog_error("bind error...");  
        return 0;  
    }  
  	//printf("bind ok\n");
    int len = sizeof(struct sockaddr);  
    char smsg[100] = {0};  
  
    while(1)  
    {  
        //从广播地址接受消息  
        int ret = recvfrom(sock, smsg, 100, 0, (struct sockaddr*)&from,(socklen_t*)&len);  
        if(ret <= 0)  
        {  
            dzlog_error("read error[%d]....",ret);  
        }  
        else  
        {         
            dzlog_error("%s", smsg);     
        }  
  
        sleep(1);  
    }  
  
    return 0;  
}  






