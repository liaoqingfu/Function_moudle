/*============================================================================
 Name        : floodlight_interface.c
 Author      : oceanwing.com
 Copyright   : 2018(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-06-06 
 Description : 
 ============================================================================*/

#include <stdio.h>  
#include <stdlib.h> 
#include <string.h>  
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <pthread.h>
#include <errno.h>
#include <netdb.h>

#include <net/if.h>	
#include <sys/socket.h>	
#include <net/if_arp.h>		/* For ARPHRD_ETHER */
#include <sys/socket.h>		/* For AF_INET & struct sockaddr */
#include <netinet/in.h>         /* For struct sockaddr_in */
#include <netinet/if_ether.h>
#include <sys/types.h> 
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <termio.h>

 
#include "mgw_interface.h"
#include "floodlight_interface.h"
#include "push_stream.h"
#include "local_storage_interface.h"



HISI_CAMERA_INFO_DATA * hisi_cam_data = NULL;

HISI_WIFI_LIST_DATA *hisi_wifi_list = NULL;

HISI_CAMERA_WIFI_DATA *hisi_cam_wifi = NULL;

short hisi_bind_dev_grunning = 1;
pthread_t tcp_server;

extern int p2p_status;
extern short gbopen_p2p;
extern short grunning;
extern int wifi_connect_status;
extern unsigned int tfcard_free_mb;
extern HUB_BASE_PARAM *base_param;
extern unsigned char gsystem_init;

struct zx_hisi_timers zx_five_timer;					//定时器
struct zx_hisi_timers zx_thirty_timer;					//定时器




int zx_getch(void)
{
     struct termios tm, tm_old;
     int fd = 0, ch;

     if (tcgetattr(fd, &tm) < 0) {//保存现在的终端设置
          return -1;
     }

     tm_old = tm;
     cfmakeraw(&tm);//更改终端设置为原始模式，该模式下所有的输入数据以字节为单位被处理
     if (tcsetattr(fd, TCSANOW, &tm) < 0) {//设置上更改之后的设置
          return -1;
     }

     ch = getchar();
     if (tcsetattr(fd, TCSANOW, &tm_old) < 0) {//更改设置为最初的样子
          return -1;
     }

     return ch;
}


/*未完成*/
void zx_set_system_cur_time(void)
{
	time_t now;    
	struct tm *timenow;  
	
	time(&now);   //time函数读取现在的时间
   
	timenow = localtime(&now);   //localtime函数把从time取得的时间now换算成你电脑中的时间    
  
	dzlog_info("Local time is [%s]",asctime(timenow));  //asctime函数把时间转换成字符

}



int zx_hisi_get_wifi_localip(char* outip)  
{  
    int i = 0;  
    int sockfd = -1;  
    struct ifconf ifconf;  
    char buf[HISI_DATA_LEN] = {0};  
    struct ifreq *ifreq = NULL;  
    char* ip = NULL;  

	if(!outip)
	{
		dzlog_error("the function parameters is NULL");
		return -1;
	}

	dzlog_info("hisi get wifi localip start");
	 
    ifconf.ifc_len = HISI_DATA_LEN;  
    ifconf.ifc_buf = buf;  
  
    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0))<0)  
    {  
		dzlog_error("sockft is error");
        return -1;  
    }  
	
    ioctl(sockfd, SIOCGIFCONF, &ifconf);    //获取所有接口信息 
    
    close(sockfd);  
	  
    ifreq = (struct ifreq*)buf;  
  
    for(i=(ifconf.ifc_len/sizeof(struct ifreq)); i > 0; i--)  
    {  
        ip = inet_ntoa(((struct sockaddr_in*)&(ifreq->ifr_addr))->sin_addr);  
      
        if(strcmp(ip,"127.0.0.1")==0)  
        {  
            ifreq++;  
            continue;  
        }  
        strcpy(outip,ip);
		
	#if HISI_LOG_SWITCH
		dzlog_info("hisi get wifi localip : %s",ip);
	#endif

		dzlog_info("hisi get wifi localip end");
	
        return 0;  
    }  
  	dzlog_error("hisi get wifi localip error");
    return -1;  
} 








int zx_hisi_set_flash_ssid_and_password(char *ssid_data,char *password_data)
{
	int ret = -1;

	if(!ssid_data || !password_data)
	{
		dzlog_error("The function parmeter is NULL.");
		return -1;
	}

	dzlog_info("hisi set flash ssid and password start");
	
	ret = zx_hisi_set_flash_wifi_ssid(ssid_data,HISI_WIFI_DATA_LEN);

	if(ret <= 0)
	{
		dzlog_error("hisi set flash wifi ssid error : %d",ret);
		return -1;
	}
	dzlog_info("hisi set flash wifi ssid ok ssid:[%s]",ssid_data);

	ret = zx_hisi_set_flash_wifi_password(password_data,HISI_WIFI_DATA_LEN);

	if(ret <= 0)
	{
		dzlog_error("hisi set flash wifi password error : %d",ret);
		return -1;
	}
	dzlog_info("【hisi set flash wifi password ok...... password:[%s]】",password_data);
	
	return 0;
}

int hisi_get_flash_ssid_and_password(char *ssid_data,char *password_data)
{
	int ret = -1;

	if(!ssid_data || !password_data)
	{
		dzlog_error("The function parmeter is NULL.");
		return -1;
	}
	
	ret = zx_hisi_get_flash_wifi_ssid(ssid_data,HISI_WIFI_DATA_LEN);
	
	if(ret <= 0)
	{
		dzlog_info("【get flash wifi ssid  empty.】");
		
	}else{
		dzlog_info("hisi_wifi_ssid=%s" , ssid_data);
	}

	ret = zx_hisi_get_flash_wifi_password(password_data,HISI_WIFI_DATA_LEN);
	
	if(ret <= 0)
	{
		dzlog_info("【get flash wifi password  empty.】");
	}else{
		dzlog_info("hisi_wifi_password=%s" , password_data);
	}

	return 0;
}

int zx_hisi_get_wifi_mac(char* outmac)

{
    struct ifreq tmp;
    int sock_mac;
    char mac_addr[HISI_WIFI_MAC_LEN] = {0};
	char wifi_name[HISI_WIFI_DEV_NAME_LEN] = {0};
	int ret = -1;
	
	dzlog_info("hisi get wifi mac start");

	if(!outmac)
	{
		dzlog_error("the function parameters is NULL");
		return -1;
	}
	
    sock_mac = socket(AF_INET, SOCK_STREAM, 0);
	
    if( sock_mac == -1)
	{
        dzlog_error("create socket fail");
        return -1;
    }
	
    memset(&tmp,0,sizeof(tmp));

	ret = hal_get_wifi_dev_name(wifi_name);

	if(ret != 0)
	{
		dzlog_error("get wifi dev name error ret = %d",ret);
		return ret;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("get wifi dev name %s",wifi_name);
#endif

    strncpy(tmp.ifr_name,wifi_name,sizeof(tmp.ifr_name)-1 );
	
    if( (ioctl( sock_mac, SIOCGIFHWADDR, &tmp)) < 0 )
	{
        dzlog_error("mac ioctl error");
        return -1;
    }

	sprintf(mac_addr, "%02x:%02x:%02x:%02x:%02x:%02x",
            (unsigned char)tmp.ifr_hwaddr.sa_data[0],
            (unsigned char)tmp.ifr_hwaddr.sa_data[1],
            (unsigned char)tmp.ifr_hwaddr.sa_data[2],
            (unsigned char)tmp.ifr_hwaddr.sa_data[3],
            (unsigned char)tmp.ifr_hwaddr.sa_data[4],
            (unsigned char)tmp.ifr_hwaddr.sa_data[5]
            );
	
#if HISI_LOG_SWITCH
    dzlog_info("local mac:%s", mac_addr);
#endif

    close(sock_mac);
	
    memcpy(outmac,mac_addr,strlen(mac_addr));
	
	dzlog_info("hisi get wifi mac end");
    return 0;
}

int zx_hisi_hal_all_init(void)
{
	int ret = -1;
	
	dzlog_info("hal hisi all init start");
	
	ret = hal_misc_init();				//初始化misc模块
	
	if(ret != 0)
	{
		dzlog_error("hal misc init error ret : %d",ret);
		goto END;
	}

#if HISI_LOG_SWITCH
	dzlog_info("hal misc init is ok");
#endif

	ret = hal_audio_init();				//初始化audio模块
	if(ret != 0)
	{
		dzlog_error("hal video init error ret : %d",ret);
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal audio init is ok");
#endif
	
	ret = hal_video_init();				//初始化video模块
		
	if(ret != 0)
	{
		dzlog_error("hal audio init error ret : %d",ret);
		hal_audio_deinit();
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal video init is ok");
#endif

	ret = hal_ircut_init();				//初始化ircut模块
	
	if(ret != 0)
	{
		dzlog_error("hal ircut init error ret : %d",ret);
		hal_audio_deinit();
		hal_video_deinit();
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal ircut init is ok");
#endif

	ret = hal_key_init();				//初始化key模块
	
	if(ret != 0)
	{
		dzlog_error("hal key init error ret : %d",ret);
		hal_audio_deinit();
		hal_video_deinit();
		hal_ircut_deinit();
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal key init is ok");
#endif

	ret = hal_led_init();				//初始化led灯模块
	
	if(ret != 0)
	{
		dzlog_error("hal led init error ret : %d",ret);
		hal_audio_deinit();
		hal_video_deinit();
		hal_ircut_deinit();
		hal_key_deinit();
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal led init is ok");
#endif

	ret = hal_pir_init();				//初始化pir模块
	
	if(ret != 0)
	{
		dzlog_error("hal pir init error ret : %d",ret);
		hal_audio_deinit();
		hal_video_deinit();
		hal_ircut_deinit();
		hal_key_deinit();
		hal_led_deinit();
		hal_misc_deinit();
		goto END;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hal pir init is ok");
#endif

	dzlog_info("hal hisi all init end");
END:
	return ret;
}


void zx_hisi_hal_all_deinit(void)
{
	dzlog_info("hal hisi all deinit start");

	hal_audio_deinit();					//去初始化audio模块
	
#if HISI_LOG_SWITCH
	dzlog_info("hal audio deinit ok");
#endif

	hal_ircut_deinit();					//去初始化ircut模块

#if HISI_LOG_SWITCH
	dzlog_info("hal ircut deinit ok");
#endif

	hal_key_deinit();					//去初始化key模块

#if HISI_LOG_SWITCH
	dzlog_info("hal key deinit ok");
#endif

	hal_led_deinit();					//去初始化led模块

#if HISI_LOG_SWITCH
	dzlog_info("hal led deinit ok");
#endif

	hal_pir_deinit();					//去初始化pir模块

#if HISI_LOG_SWITCH
	dzlog_info("hal pir deinit ok");
#endif

	hal_video_deinit(); 				//去初始化video模块
		
#if HISI_LOG_SWITCH
		dzlog_info("hal video deinit ok");
#endif

	hal_misc_deinit();					//去初始化misc模块
	
#if HISI_LOG_SWITCH
	dzlog_info("hal misc deinit ok");
#endif

	dzlog_info("【hal hisi all deinit end...】");

	return;
}




void zx_hisi_wifi_ap_info_printf(HAL_WIFI_AP_INFO *wifi_Aplist)
{
	if(!wifi_Aplist)
	{
		dzlog_error("The function parameter is NULL. ");
		return;
	}
	
	dzlog_info("*******printf start *********");
	dzlog_info("signal = %d",wifi_Aplist->signal);
	dzlog_info("enc = %d",wifi_Aplist->enc);
	dzlog_info("auth = %d",wifi_Aplist->auth);
	dzlog_info("channel = %d",wifi_Aplist->channel);
	dzlog_info("ssid = %s",wifi_Aplist->ssid);
	dzlog_info("*******printf end *********");
}



HISI_WIFI_LIST_DATA* zx_hisi_wifi_list_init(void)
{
	dzlog_info("hisi wifi list info init start");
	
	HISI_WIFI_LIST_DATA *wifi_list = NULL;
	
	wifi_list = (HISI_WIFI_LIST_DATA *)malloc(sizeof(HISI_WIFI_LIST_DATA));

	if ( !wifi_list )
	{
		dzlog_error("hisi wifi list malloc is error");
		return NULL;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi wifi list malloc ok");
#endif

	memset(wifi_list,0,sizeof(HISI_WIFI_LIST_DATA));

	wifi_list->wifi_list_info.signal = 0;
	wifi_list->wifi_list_info.enc = 0;
	wifi_list->wifi_list_info.auth = 0;
	wifi_list->wifi_list_info.channel = 0;

	memset(wifi_list->wifi_list_info.ssid,0,sizeof(wifi_list->wifi_list_info.ssid));

	wifi_list->next = NULL;

	dzlog_info("hisi wifi list info init end");

	return wifi_list;
}


int zx_hisi_wifi_list_upgrade_insert(HISI_WIFI_LIST_DATA *pPre)
{
	
	HAL_WIFI_AP_INFO *wifi_ApList = NULL;
	int ap_count = -1;
	int i = 0;
	
	if(!pPre)
	{
		dzlog_error("The function parameter is NULL.");
		return -1;
	}

	HISI_WIFI_LIST_DATA *pCur = pPre;

	HISI_WIFI_LIST_DATA *pNew = NULL;

	if( HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode )
	{
		ap_count = hal_wifi_get_aplist(&wifi_ApList); 

		if(ap_count <= 0)
		{
			dzlog_error("get wifi aplist error : %d",ap_count);
			return -1;
		}
	}else{

		dzlog_info("wifi mode is ap mode so wifi list no update...");
		return pCur->wifi_info_count;
	
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("get wifi list ok ap_count = %d\n", ap_count);
#endif

	for (i = 0; i < ap_count; i++)
	{
		
	#if HISI_LOG_SWITCH
		zx_hisi_wifi_ap_info_printf(wifi_ApList);
	#endif
	
		pCur->wifi_info_count = ap_count;				//每个节点都是wifi总共的数量
		pCur->wifi_list_info.signal = wifi_ApList->signal;
		pCur->wifi_list_info.enc = wifi_ApList->enc;
		pCur->wifi_list_info.auth = wifi_ApList->auth;
		pCur->wifi_list_info.channel = wifi_ApList->channel;
		memcpy(pCur->wifi_list_info.ssid,wifi_ApList->ssid,strlen(wifi_ApList->ssid));
		
#if HISI_LOG_SWITCH
		dzlog_info("assignment value success count %d\n",i+1);
#endif	
		++wifi_ApList;

		if(!wifi_ApList)
		{
			dzlog_info("Assignment value count %d",i + 1);
			break;
		}

		pNew = (HISI_WIFI_LIST_DATA *)malloc(sizeof(HISI_WIFI_LIST_DATA));

		if ( !pNew )
		{
			dzlog_error("wifi list malloc is error");
			return -1;
		}
		
		memset(pNew,0,sizeof(HISI_WIFI_LIST_DATA));
		
#if HISI_LOG_SWITCH
		dzlog_info("hisi wifi list pNew malloc is ok");
#endif

		pCur->next = pNew; 
		pNew->next = NULL;

		pCur = pNew;

	}

	if(wifi_ApList)
	{
		free(wifi_ApList);
		wifi_ApList = NULL;
	}

	return ap_count;
}



int zx_hisi_wifi_list_printf(HISI_WIFI_LIST_DATA *pPre,char *wifi_ssid)
{
	int i = 0;

	HISI_WIFI_LIST_DATA *pCur = NULL;
	
	if ( !pPre || !wifi_ssid)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	pCur = pPre;
	
	dzlog_info("hisi printf current wifi info start");
	
	while(1)
	{
		if(strcmp(pCur->wifi_list_info.ssid,wifi_ssid) == 0)
		{
			dzlog_info("*****************************************");
				
			dzlog_info("wifi signal = %d",pCur->wifi_list_info.signal);
			dzlog_info("wifi enc = %d",pCur->wifi_list_info.enc);
			dzlog_info("wifi auth = %d",pCur->wifi_list_info.auth);
			dzlog_info("wifi channel = %d",pCur->wifi_list_info.channel);
			dzlog_info("wifi count = %d",pCur->wifi_info_count);
			
			if(pCur->wifi_list_info.ssid || strlen(pCur->wifi_list_info.ssid))
				dzlog_info("wifi ssid = %s",pCur->wifi_list_info.ssid);
			else
				dzlog_info("wifi ssid is empty.");
			
			dzlog_info("******************************************");

			break;
			
		}

		if(!pCur)
		{
			dzlog_error("wifi list not this wifi_ssid : %s",wifi_ssid);
			break;
		}
		pCur = pCur->next;

	}
	
	dzlog_info("hisi printf current wifi info end");
	
	return 0;
}


int zx_hisi_wifi_list_all_printf(HISI_WIFI_LIST_DATA *pPre)
{
	int i = 0;
	HISI_WIFI_LIST_DATA *pCur = NULL;
	
	if ( !pPre )
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	pCur = pPre;
	
	dzlog_info("hisi printf wifi list info start");
	
	while(1)
	{
		
		dzlog_info("*****************************************");
			
		dzlog_info("wifi signal = %d",pCur->wifi_list_info.signal);
		dzlog_info("wifi enc = %d",pCur->wifi_list_info.enc);
		dzlog_info("wifi auth = %d",pCur->wifi_list_info.auth);
		dzlog_info("wifi channel = %d",pCur->wifi_list_info.channel);
		dzlog_info("wifi count = %d",pCur->wifi_info_count);
		
		if(pCur->wifi_list_info.ssid || strlen(pCur->wifi_list_info.ssid))
			dzlog_info("wifi ssid = %s",pCur->wifi_list_info.ssid);
		else
			dzlog_info("wifi ssid is empty.");
		
		dzlog_info("******************************************");

		pCur = pCur->next;

		++i;

		if(!pCur || (i >= pCur->wifi_info_count))
		{
			break;
		}
		

	}
	
	dzlog_info("hisi printf wifi list info end");
	
	return 0;
}


int zx_hisi_wifi_list_printf_ssid(HISI_WIFI_LIST_DATA *pPre)
{
	int i = 0;
	HISI_WIFI_LIST_DATA *pCur = NULL;
	
	if ( !pPre )
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	pCur = pPre;
	
	dzlog_info("******hisi printf wifi list info start******");
	
	while(1)
	{
		if(pCur->wifi_list_info.ssid || strlen(pCur->wifi_list_info.ssid))
			dzlog_info("wifi ssid = %s",pCur->wifi_list_info.ssid);
		else
			dzlog_info("wifi ssid is empty.");
		
		pCur = pCur->next;

		++i;

		if(!pCur || (i >= pCur->wifi_info_count))
		{
			break;
		}
		
		

	}
	
	dzlog_info("******hisi printf wifi list info end 【wifi count: %d】******",pPre->wifi_info_count);
	
	return 0;
}


int zx_hisi_wifi_list_free(HISI_WIFI_LIST_DATA *head)
{
	if ( !head )
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	HISI_WIFI_LIST_DATA * tmp = NULL;

	while (head != NULL)
	{
		tmp = head->next;  
		
		free(head);
		head = NULL;
		
		head = tmp;  
	}

	return 0;
}



void zx_hisi_do_alarm(int num)  
{  
	int ret = -1;
	
	if(num == SIGALRM)
	{
		dzlog_info("alarm end flood light off");  
		
		ret = hal_set_floodlight_bright(HISI_FLOOD_LIGHT_OFF);

		if(ret != 0)
		{
			dzlog_error("open flood light error");
			return;
		}
	}
        
}

int zx_hisi_flood_light_alarm(unsigned int flood_light_time)
{
	int ret = -1;
	
	if(hisi_cam_data->floodlight_last_tigger != MANUAL_CONDITION || hisi_cam_data->floodlight_last_tigger != SCHEDULE_CONDITION)
	{

		if(signal(SIGALRM , zx_hisi_do_alarm) == SIG_ERR)  
		{  
			dzlog_error("register alarm fail");  
			return -1;  
		} 
		
		alarm(flood_light_time);
		
#if HISI_LOG_SWITCH
		dzlog_info("flood light open");
#endif

		ret = hal_set_floodlight_bright(hisi_cam_data->floodlight_value);

		if(ret != 0 || hisi_cam_data->floodlight_value == 0)
		{
			dzlog_error("set flood light error ret = %d flood_led_value = %d",ret,hisi_cam_data->floodlight_value);
			return -1;
		}
	}
	return 0;
}


int zx_hisi_set_flood_light_value(unsigned int light_value)
{
	int ret = -1;

	if(light_value == 0)
	{
		dzlog_error("flood light value not zero.");
		return -1;
	}
#if 0
	ret = hal_set_floodlight_bright(light_value);

	if(ret != 0)
	{
		dzlog_error("hal set flood light bright error ret : %d",ret);
		return -1;
	}
#endif

	hisi_cam_data->floodlight_value = light_value;
	
	return 0;
}

int zx_hisi_flood_light_on(void)
{
	int ret = -1;

	//dzlog_info("hisi_cam_data->floodlight_state = %d",hisi_cam_data->floodlight_state);
	
	if(ON_STATE != hisi_cam_data->floodlight_state )
	{
		//dzlog_info("hisi_cam_data->floodlight_value = %d",hisi_cam_data->floodlight_value);
		if(hisi_cam_data->floodlight_value > 0)
		{
			ret = hal_set_floodlight_bright(hisi_cam_data->floodlight_value);

			if(ret != 0)
			{
				dzlog_error("hal set flood light bright error ret : %d",ret);
				return -1;
			}
			
		}else{
			
			ret = hal_set_floodlight_bright(HISI_FLOOD_LIGHT_VALUE);

			if(ret != 0)
			{
				dzlog_error("hal set flood light bright error ret : %d",ret);
				return -1;
			}
			
			hisi_cam_data->floodlight_value = HISI_FLOOD_LIGHT_VALUE;
		}
		
		hisi_cam_data->floodlight_state = ON_STATE;
		
		dzlog_info("【flood light open ok.】");

		
	}
	else{
		ret = 0;
		//dzlog_info("【flood light already open...】");
	}
	
	
	return 0;
}


int zx_hisi_flood_light_off(void)
{
	int ret = -1;

	if(OFF_STATE != hisi_cam_data->floodlight_state )
	{
		ret = hal_set_floodlight_bright(HISI_FLOOD_LIGHT_OFF);

		if(ret != 0)
		{
			dzlog_error("hal set flood light bright error ret : %d",ret);
			return -1;
		}
		
		hisi_cam_data->floodlight_state = OFF_STATE;

		hisi_cam_data->floodlight_last_tigger = INIT_CONDITION;
	}
	else{
		
		dzlog_info("【flood light close...】");
	}
	
	return 0;
}



int zx_hisi_set_red_led_on(void)
{
	int ret = -1;

	if(ON_STATE != hisi_cam_data->red_led_state )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set red led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->white_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("white led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_ON);
		
		if(ret != 0)
		{
			dzlog_error("set white led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->red_led_state = ON_STATE;
	}
	else{
		ret = 0;
		dzlog_info("red led on ok");
	}

	return ret;
}


int zx_hisi_set_red_led_off(void)
{
	int ret = -1;

	if(OFF_STATE != hisi_cam_data->red_led_state )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_OFF);

		if(ret != 0)
		{
			dzlog_error("set red led off error ret : %d",ret);
			return ret;
		}
		hisi_cam_data->red_led_state = OFF_STATE;
	}
	else{
		ret = 0;
		dzlog_info("red led off ok");
	}
	return ret;
}



int zx_hisi_set_white_led_on(void)
{
	int ret = -1;

	if(ON_STATE != hisi_cam_data->white_led_state )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set red led off error ret= %d",ret);
			return ret;
		}

		hisi_cam_data->red_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("red led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_ON);
		
		if(ret != 0)
		{
			dzlog_error("set white led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->white_led_state = ON_STATE;
		hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_AUTO;

		//dzlog_info("white led on ok");
	}
	else{
		ret = 0;
		//dzlog_info("white led on already ok");
	}

	return ret;
}


int zx_hisi_set_white_led_off(void)
{
	int ret = -1;

	if(OFF_STATE != hisi_cam_data->white_led_state )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_OFF);

		if(ret != 0)
		{
			dzlog_error("set white led off error ret : %d",ret);
			return ret;
		}
		
		hisi_cam_data->white_led_state = OFF_STATE;
	}
	else{
		ret = 0;
		dzlog_info("white led off ok");
	}
	
	return ret;
}



int zx_hisi_set_ircut_on()
{
	int ret = -1;
	if(hisi_cam_data->ircut_state != IRCUT_CTRL_ON)
	{
		ret = hal_ircut_ctrl(IRCUT_CTRL_ON);			//ircut打开

		if(ret != 0)
		{
			dzlog_error("hal ircut ctrl error");
			return -1;
		}

		hisi_cam_data->ircut_state = IRCUT_CTRL_ON;
		
		dzlog_info("【ircut open ok...】");

		ret = hal_set_irled_bright(HISI_IR_LIGHT_VALUE);		//设置IRled灯的亮度，即打开IRled灯

		if(ret != 0)
		{
			dzlog_error("hal set irled bright error");
			return -1;
		}

		hisi_cam_data->irled_value = HISI_IR_LIGHT_VALUE;

		dzlog_info("【IRLED open ok...】");

		ret = hal_set_video_color_mode(HISI_BLACK_WHITE_MODE);		//黑白模式

		if(ret != 0)
		{
			dzlog_error("hal set video black white mode error");
			return -1;
		}
		
		hisi_cam_data->colormode = HISI_BLACK_WHITE_MODE;
		
		dzlog_info("【set video black white mode ok...】");
	}
	return 0;
}


int zx_hisi_set_ircut_off()
{
	int ret = -1;

	if(hisi_cam_data->ircut_state != IRCUT_CTRL_OFF)
	{
		ret = hal_ircut_ctrl(IRCUT_CTRL_OFF);			//ircut关闭

		if(ret != 0)
		{
			dzlog_error("hal ircut ctrl error");
			return -1;
		}

		hisi_cam_data->ircut_state = IRCUT_CTRL_OFF;
		
		dzlog_info("【ircut close ok...】");

		ret = hal_set_irled_bright(OFF_STATE);				//设置IRLED灯为0，关闭IRLED灯

		if(ret != 0)
		{
			dzlog_error("hal set irled bright error");
			return -1;
		}

		hisi_cam_data->irled_value = 0;

		dzlog_info("【IRLED close ok...】");
		
		ret = hal_set_video_color_mode(HISI_COLORFUL_MODE);		//彩色模式

		if(ret != 0)
		{
			dzlog_error("hal set video colorful mode error");
			return -1;
		}
		
		hisi_cam_data->colormode = HISI_COLORFUL_MODE;
		
		dzlog_info("【set video colorful mode ok...】");
	}
	return 0;
}


int zx_hisi_set_red_led_flash(void)
{
	int ret = -1;

	//dzlog_info("hisi set red led flash start");

	if(FLASH_STATE != hisi_cam_data->red_led_state )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set red led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->red_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("red led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set white led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->white_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("white led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_FLASH);
		
		if(ret != 0)
		{
			dzlog_error("set red led flash error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->red_led_state = FLASH_STATE;
	}
	else{
		ret = 0;
		dzlog_info("hisi set red led flash ok");
	}
	

	return ret;
	
}


int zx_hisi_set_white_led_flash(void)
{
	int ret = -1;

//	dzlog_info("hisi set white led flash start");

	if( FLASH_STATE != hisi_cam_data->white_led_state && HISI_IRLEDMODE_OFF != hisi_cam_data->white_led_tigger )
	{
		ret = hal_led_ctrl(HAL_LED_TYPE_RED,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set red led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->red_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("red led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_OFF);
		
		if(ret != 0)
		{
			dzlog_error("set white led off error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->white_led_state = OFF_STATE;
		
#if HISI_LOG_SWITCH
		dzlog_info("white led off ok");
#endif

		ret = hal_led_ctrl(HAL_LED_TYPE_WHITE,HAL_LED_STATUS_FLASH);
		
		if(ret != 0)
		{
			dzlog_error("set white led flash error ret = %d",ret);
			return ret;
		}

		hisi_cam_data->white_led_state = FLASH_STATE;
		//dzlog_info("hisi set white led flash ok");
	}
	else{
		ret = 0;
//		dzlog_info("hisi set white led flash ok");
	}
	return ret;
}


int zx_hisi_set_red_led_flash_freq(unsigned int flash_freq)
{
	int ret = -1;

	dzlog_info("hisi set red led flash start");

	if( 0 == flash_freq )
	{
		dzlog_error("set flash freq not zero.");
		return -1;
	}
	
	ret = hal_led_SetFlashFreq(HAL_LED_TYPE_RED,flash_freq);
	
	if(ret != 0)
	{
		dzlog_error("set white led off error ret = %d",ret);
		return ret;
	}

	hisi_cam_data->red_led_flash_freq = flash_freq;
	
	dzlog_info("hisi set red led flash ok");

	return ret;
	
}


int zx_hisi_set_white_led_flash_freq(unsigned int flash_freq)
{
	int ret = -1;

	dzlog_info("hisi set white led flash start");

	if( 0 == flash_freq )
	{
		dzlog_error("set flash freq not zero.");
		return -1;
	}

	ret = hal_led_SetFlashFreq(HAL_LED_TYPE_WHITE,flash_freq);
	
	if(ret != 0)
	{
		dzlog_error("set white led off error ret = %d",ret);
		return ret;
	}

	hisi_cam_data->white_led_flash_freq = flash_freq;
	
	dzlog_info("hisi set white led flash ok");

	return ret;
}


void zx_hisi_five_output()
{
	dzlog_info("five output");
	return;
}

void zx_hisi_thirty_output()
{
	dzlog_info("thirty output.");
	return;
}


void zx_hisi_timer_manage_cb()
{

	zx_five_timer.interval--;

	if(zx_five_timer.interval == 0)

	{
		zx_five_timer.interval = 5;
		zx_five_timer.timer_handler();
	}

	zx_thirty_timer.interval--;

	if(zx_thirty_timer.interval == 0)

	{
		zx_thirty_timer.interval = 10;
		zx_thirty_timer.timer_handler();
	}
}


void zx_hisi_motion_detect_cb(void *user_data)				//移动侦测
{
	int ret = -1;
	struct timeval tv;

	//dzlog_info("【motion detect cb ......】");

	if(gsystem_init)
	{
		
#if 1	
		//dzlog_info("hisi_cam_wifi->wifi_mode = %d,wifi_connect_status = %d",hisi_cam_wifi->wifi_mode,wifi_connect_status);
		if(HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode && WIFI_CONNECTED == wifi_connect_status )
		{
			ret = zx_hisi_set_white_led_flash();
					
			if(ret != 0)
			{
				dzlog_error("set white led flash error ret = %d",ret);
				return;
			}

#endif

			//zx_motion_and_pir_triger_local_storage(HISI_CH0);

#if 1
			tv.tv_sec = 30;
			tv.tv_usec = 0;
			
			switch(select(0, NULL, NULL, NULL, &tv))
			{
			    case -1:
			        dzlog_info("select Error!");
			        break;

			    case 0:  //TIMEOUT
			        {
				      	if( hisi_cam_data->white_led_tigger != HISI_IRLEDMODE_OFF && HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode)
						{
							ret = zx_hisi_set_white_led_on();

							if(ret != 0)
							{
								dzlog_error("hisi white len on error ret = %d",ret);
								return;
							}
						}
				            
				        break;
			    	}
			    default:
			        break;
			}
#endif
		}

	}

#if 0
	ret = pir_triger_handle_by_channel(HISI_CH0);

	if(ret != 0)
	{
		dzlog_error("pir tiger handle by channel error");
		return;
	}
#endif

	//录像

}

void zx_hisi_cam_motion_event(void)
{
	dzlog_info("【zx hisi motion detect cb running】");
	hal_video_register_md_cb(zx_hisi_motion_detect_cb,NULL);
}


void *zx_get_tmp_photo_value(void *data)
{
	int nready = -1;
	int ret = -1 , value = -1;
	int num = 0;
	struct timeval tv;

	while(grunning)
	{
		tv.tv_sec = HISI_GET_TEM_PHOTO_TIME;    
        tv.tv_usec = 0;
		
		nready = select(0, NULL, NULL, NULL, &tv);		//1分钟检测一次
		
	    if (nready < 0)
	    {
	        dzlog_error("【select error errno:%d===>[%s]】",errno,strerror(errno));
			break;
	    }
		
		value = hal_tsensor_value();

		if(value < 0)
		{
			dzlog_warn("【get tem sensor value error try again】");
			continue;
			
		}else{
			
	#if HISI_LOG_SWITCH
		dzlog_info("tem sensor value : 0x%x",value);
	#endif

		hisi_cam_data->tem_sensor_value = hal_get_temperature();

	#if HISI_LOG_SWITCH
		dzlog_info("board temperature : %d",hisi_cam_data->tem_sensor_value);
	#endif
	
		}

		hisi_cam_data->photo_sensor_value = hal_lsensor_value();

		if(hisi_cam_data->photo_sensor_value < 0)
		{
			dzlog_warn("【get photo sensor value error try again】");
			continue;
		}
		
	#if HISI_LOG_SWITCH
		dzlog_info("photo sensor value : 0x%x",hisi_cam_data->photo_sensor_value);
	#endif

		if(hisi_cam_wifi->wifi_mode == HISI_WIFI_AP_MODE)
		{
			if( num >= 60 )		//5分钟后还在ap模式就退出ap模式重新配置网络
			{
				ret = hal_set_wifi_sta_mode();		//设置wifi为sta模式

				if(ret != 0)
				{
					dzlog_error("hal set wifi sta mode error : %d",ret);
					return ret;
				}

			#if 1
				dzlog_info("hal set wifi sta mode is ok");
			#endif

				hisi_cam_wifi->wifi_mode = HISI_WIFI_STA_MODE;
			
				zx_stop_broadcase();
				zx_hisi_stop_tcp_server();
				
#if HISI_AUDIO_PLAY
				if(hal_audio_play_file("/etc/en/add_cam_fail.wav") != 0)   //绑定失败播放声音
				{
					dzlog_error("hisi audio play file error");
					break;
				}
				dzlog_info("【---audio play add_cam_fail.wav ok---】");
#endif	
			}
			dzlog_info("【please configure wifi network...】");
			++num;
		}

		//zx_ota_system("echo 3 > /proc/sys/vm/drop_caches");				//清除缓存
	
	}

	dzlog_info("【get tmp photo value pthread exit...】");
	
	pthread_exit(0);
	return;
}

int zx_hisi_cam_get_tmp_photo_value_pthread(void)
{
	pthread_t tmp_photo;
	int ret = -1;

	ret = pthread_create(&tmp_photo,NULL,zx_get_tmp_photo_value,NULL);  

	if(ret != 0)
	{
		dzlog_error(" fail to create thread ,close conncet sockfd"); 
		return -1;
	}
	pthread_detach(tmp_photo);
	
	return 0;
}


int zx_hisi_judge_day_or_night(void)
{
	int ret = -1;
	int i = 0;

LSENSOR_VALUE:
	ret  = hal_lsensor_value();

	if(ret < 0)
	{
		dzlog_error("get lsensor value error : %d",ret);
		return -1;
	}

	if(ret <= NIGHT_PHOTOSENSI_VALUE)		//黑夜
	{
		//dzlog_info("now is night...");
		return CUR_NIGHT;
	}
	else if(ret >= DAY_PHOTOSENSI_VALUE)
	{
		//dzlog_info("now is daylight...");
		
		return CUR_DAY;
	}
	else
	{
		//dzlog_info("photo senvition value : 0x%x",ret);

		if(hisi_cam_data->photo_sensor_value <= NIGHT_PHOTOSENSI_VALUE)		//黑夜
		{
			//dzlog_info("now is night...");
			return CUR_NIGHT;
		}
		else if(hisi_cam_data->photo_sensor_value >= DAY_PHOTOSENSI_VALUE)
		{
			//dzlog_info("now is day...");
			return CUR_DAY;
		}
		else
		{
			++i;
			if(i <= 3)
			{
				//dzlog_info("get photosen value try again.");
				goto LSENSOR_VALUE;
				
			}else{
				
				return CUR_NIGHT;				//暂定返回黑夜
				
			}
		}
		
	}
	
}


void *zx_hisi_day_or_night_ircut(void *data)
{
	int nready = -1;
	int ret = -1;
	struct timeval tv;

	while(grunning)
	{
		//tv.tv_sec = 0;    
       // tv.tv_usec = 50000;

		tv.tv_sec = 1;    
        tv.tv_usec = 0;
		
		nready = select(0, NULL, NULL, NULL, &tv);		
		
	    if (nready < 0)
	    {
	        dzlog_error("select error");
			break;
	    }

		ret = zx_hisi_judge_day_or_night();

		if( ret == CUR_DAY )

		{
			//dzlog_info("【now is day.】hisi_cam_data->ircut_set_mode = %d",hisi_cam_data->ircut_set_mode);
			
			if(hisi_cam_data->ircut_set_mode == HISI_IRLEDMODE_AUTO)
			{
				ret = zx_hisi_set_ircut_off();

				if(ret != 0)
				{
					dzlog_error("【hisi set ircut off error : %d】",ret);
					break;
				}
			}
		}
		else if( ret == CUR_NIGHT )
		{
			//dzlog_info("【now is night.】 hisi_cam_data->floodlight_state = %d",hisi_cam_data->floodlight_state);

			if(hisi_cam_data->floodlight_state == OFF_STATE)
			{
				if( hisi_cam_data->ircut_set_mode == HISI_IRLEDMODE_AUTO )
				{
					ret = zx_hisi_set_ircut_on();
					
					if(ret != 0)
					{
						dzlog_error("【hisi set ircut on error : %d】",ret);
						break;
					}
				}
			}
			else{
				
				ret = zx_hisi_set_ircut_off();
				
				if(ret != 0)
				{
					dzlog_error("【hisi set ircut off error : %d】",ret);
					break;
				}
			}
		}
		else
		{
			dzlog_error("ircut error");
			break;
		}

		ret = hal_sd_exist();				//获取sd卡状态 

		if(ret == -1)
		{
			if(tfcard_free_mb > 0)
			{	
				dzlog_warn("【TF card output.】");
			}
			
			tfcard_free_mb = 0;			//无TF卡
		}
		else if(ret == 0)
		{
			if(tfcard_free_mb == 0)
			{
				dzlog_info("【TF card input.】");
			}
			
			tfcard_free_mb = get_system_tf_free(0);

			if(tfcard_free_mb == 0)
			{
				dzlog_error("【get system tf free error】");
			}
		}
		else{
			dzlog_error("【hal sd exist error】");
		}
	
	}
	
	dzlog_info("【 day or night ircut pthread exit...】");
	pthread_exit(0);
	return;
}



int zx_hisi_cam_day_or_night_pthread(void)
{
	pthread_t day_or_night;
	int ret = -1;

	ret = pthread_create(&day_or_night,NULL,zx_hisi_day_or_night_ircut,NULL);  

	if(ret != 0)
	{
		dzlog_error(" fail to create thread ,close conncet sockfd"); 
		return -1;
	}
	pthread_detach(day_or_night);
	
	return 0;
}


void zx_hisi_hal_dzlog(char *plogstr, int size, int logtype, int lvtype, long reserve)
{
	switch (lvtype)
    {
		case HAL_LEVEL_INFO:	        //一般信息
			dzlog_info(plogstr);
			break;
		case HAL_LEVEL_WARN:	        //告警信息
			dzlog_warn(plogstr);
			break;
		case HAL_LEVEL_DEBUG:	        //debug信息
			dzlog_debug(plogstr);
			break;
		case HAL_LEVEL_ERROR:	        //错误信息
			dzlog_error(plogstr);
			break;
		case HAL_LEVEL_MAX:	        	//错误信息
			dzlog_error(plogstr);
			break;
	}
}


void zx_hisi_set_hal_log_print(int print_type)
{
	
	if(print_type == 1)
	{
		dzlog_info("open hisi log callback");
		hal_log_register_out_cb(zx_hisi_hal_dzlog);
	}
	else
	{
		dzlog_info("not set hisi log printf");
	}
}


void *hisi_wifi_connect_network(void *uset_data)
{
	int ret = -1;
	
	HISI_CAMERA_WIFI_DATA *wifi_data = (HISI_CAMERA_WIFI_DATA *)uset_data;
	
	if(wifi_data->wifi_mode == HISI_WIFI_AP_MODE)
		dzlog_info("hisi wifi current mode status is AP mode");
	else if(wifi_data->wifi_mode == HISI_WIFI_STA_MODE)
		dzlog_info("hisi wifi current mode status is STA mode");
	else
	{
		dzlog_error("hisi wifi mode status error wifi_mode = %d",wifi_data->wifi_mode);
		goto PTHREAD_EXIT;
	}

	dzlog_info("ssid = %s , password = %s",wifi_data->wifi_ssid,wifi_data->wifi_password);

#if 1
	if(wifi_data->wifi_mode == HISI_WIFI_STA_MODE)
	{
		dzlog_info("【wifi is sta mode wifi connect and udhcpc】");
		
		ret = hal_wifi_connect(wifi_data->wifi_ssid,wifi_data->wifi_password);

		if(ret != 0)
		{
			dzlog_error("wifi connect error");
			goto PTHREAD_EXIT;
		}
		
		dzlog_info("wifi connect ok");
		
		ret = hal_wifi_udhcpc();

		if(ret != 0)
		{
			dzlog_error("wifi connect error");
			goto PTHREAD_EXIT;
		}

		dzlog_info("wifi udhcpc ok");
	
	}
	else if(wifi_data->wifi_mode == HISI_WIFI_AP_MODE)
	{
	
		dzlog_info("【wifi is not sta mode so set wifi sta mode and connect】");
#if 1
		ret = hal_set_wifi_sta_mode();

		if(ret != 0)
		{
			dzlog_error("set wifi sta mode error");
			goto PTHREAD_EXIT;
		}

		dzlog_info("set wifi sta mode ok");

		wifi_data->wifi_mode = HISI_WIFI_STA_MODE;
	
		ret = hal_wifi_connect(wifi_data->wifi_ssid,wifi_data->wifi_password);

		if(ret != 0)
		{
			dzlog_error("wifi connect error");
			goto PTHREAD_EXIT;
		}
		
		dzlog_info("wifi connect ok");
		
		ret = hal_wifi_udhcpc();

		if(ret != 0)
		{
			dzlog_error("wifi connect error");
			goto PTHREAD_EXIT;
		}
		
		dzlog_info("wifi udhcpc ok");
#endif

	}
	else
	{
		dzlog_error("hisi wifi mode status error wifi_mode = %d",wifi_data->wifi_mode);
	}

#endif
PTHREAD_EXIT:
	pthread_exit(0);
	return;
}


HISI_CAMERA_WIFI_DATA* zx_hisi_camera_wifi_data_init(void)
{
	HISI_CAMERA_WIFI_DATA *cam_wifi_info = NULL;

	cam_wifi_info = (HISI_CAMERA_WIFI_DATA *)malloc(sizeof(HISI_CAMERA_WIFI_DATA));

	if(!cam_wifi_info)
	{
		dzlog_error("cam wifi info malloc error.");
		return NULL;
	}
	memset(cam_wifi_info,0,sizeof(HISI_CAMERA_WIFI_DATA));

	cam_wifi_info->wifi_signal = 0;
	cam_wifi_info->wifi_enc = 0;
	cam_wifi_info->wifi_auth = 0;
	cam_wifi_info->wifi_mode = 0;
	cam_wifi_info->wifi_channel = 0;

	memset(cam_wifi_info->wifi_dev_name,0,sizeof(cam_wifi_info->wifi_dev_name));
	memset(cam_wifi_info->wifi_ssid,0,sizeof(cam_wifi_info->wifi_ssid));
	memset(cam_wifi_info->wifi_password,0,sizeof(cam_wifi_info->wifi_password));
	memset(cam_wifi_info->wifi_ip,0,sizeof(cam_wifi_info->wifi_ip));
	memset(cam_wifi_info->wifi_mac,0,sizeof(cam_wifi_info->wifi_mac));

	return cam_wifi_info;
}


int zx_hisi_camera_connect_network(const char*wifi_ssid,const char*wifi_password)
{
	int ret = -1;
	int count = 0, i = 0;
	pthread_t network_tid;

	char ssid_data[HISI_WIFI_DATA_LEN] = {0};
	char password_data[HISI_WIFI_DATA_LEN] = {0};
	
	if(!wifi_ssid || !wifi_password || strlen(wifi_ssid) <= 0 || strlen(wifi_password) <= 0)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("hisi camera connect network start");

	memcpy(ssid_data,wifi_ssid,strlen(wifi_ssid));
	memcpy(password_data,wifi_password,strlen(wifi_password));
	

	memset(hisi_cam_wifi->wifi_ssid,0,sizeof(hisi_cam_wifi->wifi_ssid));
	memcpy(hisi_cam_wifi->wifi_ssid,ssid_data,strlen(ssid_data));

	memset(hisi_cam_wifi->wifi_password,0,sizeof(hisi_cam_wifi->wifi_password));
	memcpy(hisi_cam_wifi->wifi_password,password_data,strlen(password_data));
	
	
NETWORK_AGAIN:
	ret = pthread_create(&network_tid,NULL,hisi_wifi_connect_network,hisi_cam_wifi);  //开线程接收数据

	if(ret != 0)
	{
		dzlog_error(" fail to create thread  ret = %d",ret); 
		return -1;
	}
	
	while(hisi_bind_dev_grunning)
	{
		zx_mgw_setTimer(1,0);
	
		ret = hal_wifi_check_link(hisi_cam_wifi->wifi_ssid);
		
		if(ret == 2)
		{
			dzlog_info("【wifi network connect is success.】");

			if( ON_STATE != hisi_cam_data->white_led_state )
			{
				if((zx_hisi_set_white_led_on()) != 0)
				{
					dzlog_error("set white on error");
				}
			}
			
			wifi_connect_status = WIFI_CONNECTED;		//wifi已经连接

	#if HISI_AUDIO_PLAY
			ret = hal_audio_play_file("/etc/en/connect_success_en.wav");		//wifi连接成功

			if(ret != 0)
			{
				dzlog_error("hisi audio play connect success error");
				return;
			}

			dzlog_info("【---audio play connect_success_en.wav ok---】");
	#endif

			break;
			
		}else{

			if(ret == 0)
			{
				dzlog_error("hal wifi check link not connect");
			}
			else if(ret == 1)
			{
				dzlog_warn("hal wifi check link is connecting");
			}
			else
			{
				dzlog_error("hal wifi check link is error ret : %d",ret);
			}
		}
		
		++count;
		
		if(count > HISI_WIFI_CONNECT_TIME )	//检测60秒
		{
			
			count = 0;
			++i;
			
			dzlog_info("******wifi connect checkout count = %d******",i);
			
			if(i >= 3)		//重试三次
			{
				
				wifi_connect_status = WIFI_NO_CONNECT;		//wifi 未连接
				
#if HISI_AUDIO_PLAY
				ret = hal_audio_play_file("/etc/en/connect_failed_en.wav");

				if(ret != 0)
				{
					dzlog_error("hal audio play connect network failed error ");
					return -1;
				}

				dzlog_info("【---audio play connect_failed_en.wav ok---】");
#endif
				dzlog_info("wifi connect timeout wifi mode %d, please press key and Reconfigure wifi...",wifi_connect_status);
				break;
			}
		
			pthread_join(network_tid,NULL);
			
			goto NETWORK_AGAIN;
			
		
		}
		else{
			
			wifi_connect_status = WIFI_CONNECTTING; 		//WIFI正在连接
			dzlog_info("wait network connect time : %ds",count);
		}

		if(HISI_WIFI_AP_MODE == hisi_cam_wifi->wifi_mode && count >= 2)
		{
			dzlog_info("wifi set AP mode please Reconfigure wifi... ");
			break;
		}
	}
	
	zx_hisi_stop_tcp_server();			//TCP 停止

	pthread_join(network_tid,NULL);

	dzlog_info("hisi camera connect network end");

	return 0;
	
}



void zx_hisi_camera_dev_info_printf(HISI_CAMERA_INFO_DATA *cam_info)
{	
	dzlog_info("channel : %d",cam_info->channel);				//视频通道 0
	dzlog_info("brightness : %d",cam_info->brightness);			//亮度
	dzlog_info("contrast : %d",cam_info->contrast);				//对比度
	dzlog_info("chroma : %d",cam_info->chroma);					//色度
	dzlog_info("saturation : %d",cam_info->saturation);			//饱和度
	
	switch(cam_info->angle)				//视频角度
	{
		case VIDEO_FLIP_NORMAL:
			dzlog_info("angle : 0°");
			break;
		case VIDEO_FLIP_H:
			dzlog_info("angle : 90°");
			break;
		case VIDEO_FLIP_V:
			dzlog_info("angle : 180°");
			break;
		case VIDEO_FLIP_HV:
			dzlog_info("angle : 270°");
			break;
		default:
			dzlog_info("angle is error");
			break;
	}

	if(cam_info->colormode == 0)				//图像模式
		dzlog_info("colormode is colorful ");
	else if(cam_info->colormode == 1)
		dzlog_info("colormode is black_white");
	else
		dzlog_info("colormode is error");
		
	switch(cam_info->sensitivity)		//移动侦测灵敏度
	{
		case HAL_MD_LOW:
			dzlog_info("low sensitivity");
			break;
		case HAL_MD_NORMAL:
			dzlog_info("normal sensitivity");
			break;
		case HAL_MD_HIGHT:
			dzlog_info("hight sensitivity ");
			break;
		case HAL_MD_HIGHTEST:
			dzlog_info(" hightest sensitivity");
			break;
		default:
			dzlog_info("sensitivity is error");
			break;
	}
	
	if(cam_info->resolution == 0)					//视频分辨率
		dzlog_info("video resolution is  VGA");
	else if(cam_info->resolution == 1)
		dzlog_info("video resolution is  720P");
	else if(cam_info->resolution == 2)
		dzlog_info("video resolution is  1080P");
	else
		dzlog_info("video resolution is  error");
	
	dzlog_info("fps : %d",cam_info->fps);				//帧率
	
	dzlog_info("gop : %d",cam_info->gop);				//I帧间隔
	
	if(cam_info->pwfreq == 0)							//电力线频率
		dzlog_info("pwfreq is 50HZ");
	else if(cam_info->pwfreq == 1)
		dzlog_info("pwfreq is 60HZ");
	else
		dzlog_info("pwfreq is error");

	dzlog_info("bitrate : %d",cam_info->bitrate);		//码率

	if(cam_info->bit_mode == 0)							//码率模式
		dzlog_info("bit_mode is VBR");
	else if(cam_info->bit_mode == 1)
		dzlog_info("bit_mode is CBR");
	else
		dzlog_info("bit_mode is error");

	dzlog_info("tem sensor value : 0x%x",cam_info->tem_sensor_value);		//温度传感器

	dzlog_info("photo sensor value : 0x%x",cam_info->photo_sensor_value);	//光敏传感器

	dzlog_info("mic volume value : %d",cam_info->mic_volume);			//mic音量

	dzlog_info("speaker volume value : %d",cam_info->speaker_volume);	//speaker音量

	dzlog_info("irled value : %d",cam_info->irled_value);				//IR led亮度

	dzlog_info("flood led value : %d",cam_info->floodlight_value);		//floodlight灯亮度

	dzlog_info("flash data value : %d",cam_info->flash_data_len);		//flash数据长度
	
	if(cam_info->version || strlen(cam_info->version) > 0)				//卓翼库的版本
		dzlog_info("HAL LIB verdion : %s",cam_info->version);
	else
		dzlog_info("HAL LIB verdion is empty.");
	
	if(cam_info->pir_version || strlen(cam_info->pir_version) > 0)		//PIR库的版本
		dzlog_info("PIR verdion : %s",cam_info->pir_version);
	else
		dzlog_info("PIR verdion is empty.");

	if(cam_info->pir_sen_state[HISI_LEFT_PIR] == 1)					//PIR的开关状态
		dzlog_info("left PIR sen state is ENABLE");
	else
		dzlog_info("left PIR sen state is DISABLE");
	
	if(cam_info->pir_sen_state[HISI_MIDDLE_PIR] == 1)
		dzlog_info("left PIR sen state is ENABLE");
	else
		dzlog_info("left PIR sen state is DISABLE");
	
	if(cam_info->pir_sen_state[HISI_RIGHT_PIR] == 1)
		dzlog_info("left PIR sen state is ENABLE");
	else
		dzlog_info("left PIR sen state is DISABLE");
	
	dzlog_info("left PIR sensitivity value : %d",cam_info->pir_sen_value[HISI_LEFT_PIR]);		//PIR的灵敏度
	dzlog_info("middle PIR sensitivity value : %d",cam_info->pir_sen_value[HISI_MIDDLE_PIR]);
	dzlog_info("right PIR sensitivity value : %d",cam_info->pir_sen_value[HISI_RIGHT_PIR]);

	dzlog_info("key holdtime value : %dms",cam_info->key_holdtime_ms);				//按键时长
	dzlog_info("red led flash freq value : %dms",cam_info->red_led_flash_freq);		//红LED的闪烁频率
	dzlog_info("white led flash freq value : %dms",cam_info->white_led_flash_freq);	//白LED的闪烁频率

	if(cam_info->ircut_state == 1)					//IRCUT开关状态
		dzlog_info("ircut state is ENABLE");
	else
		dzlog_info("ircut state is DISABLE");
	
	if(cam_info->mic_state == 1)					//mic的状态
		dzlog_info("ircut state is ENABLE");
	else
		dzlog_info("ircut state is DISABLE");
	
	if(cam_info->osd_state == 1)					//osd的状态
		dzlog_info("ircut state is ENABLE");
	else
		dzlog_info("ircut state is DISABLE");

	dzlog_info("red_led_state = %d",cam_info->red_led_state);
	dzlog_info("white_led_state = %d",cam_info->white_led_state);
	dzlog_info("floodlight_state = %d",cam_info->floodlight_state);
	dzlog_info("floodlight_last_tigger = %d",cam_info->floodlight_last_tigger);
	
}



HISI_CAMERA_INFO_DATA* zx_hisi_camera_info_data_init(void)
{
	HISI_CAMERA_INFO_DATA *cam_info = NULL;
	int i = 0;
	
	cam_info = (HISI_CAMERA_INFO_DATA *)malloc(sizeof(HISI_CAMERA_INFO_DATA));

	if( !cam_info )
	{
		dzlog_error("hisi camera info data malloc error");
		return NULL;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi camera info data malloc ok");
#endif

	memset(cam_info,0,sizeof(HISI_CAMERA_INFO_DATA));

	cam_info->channel = HISI_CH0;				//通道：0
	cam_info->brightness = 0;					//亮度
	cam_info->contrast = 0;						//对比度
	cam_info->chroma = 0;						//色度
	cam_info->saturation = 0;					//饱和度
	cam_info->angle = VIDEO_FLIP_NORMAL;		//0°
	cam_info->colormode = 0;					//彩色
	cam_info->sensitivity = HAL_MD_LOW;			//移动侦测的灵敏度
	cam_info->resolution = RES_720P;			//分辨率720p
	cam_info->fps = 0;							//15帧
	cam_info->gop = 0;							//I帧间隔
	cam_info->pwfreq = FREQ_50HZ;				//电力线频率
	cam_info->bitrate = 0;						//码率
	cam_info->bit_mode = MODE_VBR;				//VBR

	cam_info->tem_sensor_value = 0;				//板子的温度值
	cam_info->photo_sensor_value = 0;			//光敏传感器值
	cam_info->tem_sensor_adc_value = 0;			//温度传感器值
	cam_info->white_led_tigger = 0;				//

	cam_info->irled_value = 0;					//夜视灯值，红外
	
	cam_info->floodlight_value = 0;				//floodlight灯的值
	cam_info->red_led_flash_freq = 0;			//红LED 闪烁频率
	cam_info->white_led_flash_freq = 0;			//白LED 闪烁频率
	cam_info->flash_data_len = 0;				//分区数据的大小
	cam_info->key_holdtime_ms = 0;				//按键时长	ms
	cam_info->mic_volume = 0;					//mic 音量
	cam_info->speaker_volume = 0;				//speaker 音量
	cam_info->ircut_state = 0;					//ircut开关状态
	cam_info->ircut_set_mode = 0;				//设置ircut模式为自动
	cam_info->mic_state = 0;					//mic的开关状态
	cam_info->osd_state = 0;					//osd的开关状态
	cam_info->red_led_state = 0;				//红led的开关状态
	cam_info->white_led_state = 0;				//白led的开关状态
	cam_info->floodlight_state = 0;				//floodlight灯的状态
	cam_info->floodlight_last_tigger = 0;		//floodlight灯最后的触发条件
	cam_info->pir_floodlight_tigger_time = 30;	//pir触发floodlight灯的延时时间

	for(i=0;i<HISI_PIR_COUNT;i++)				//pir灵敏度的初始值
	{
		cam_info->pir_sen_value[i] =0;
	}

	for(i=0;i<HISI_PIR_COUNT;i++)				//pir灵敏度的状态
	{	
		cam_info->pir_sen_state[i] =0;
	}

	memset(cam_info->version,0,sizeof(cam_info->version));			//库的版本信息
	memset(cam_info->pir_version,0,sizeof(cam_info->pir_version));	//PIR的版本信息
	memset(cam_info->dev_sn,0,sizeof(cam_info->dev_sn));			//设备sn号
	memset(cam_info->account_id,0,sizeof(cam_info->account_id));			//设备sn号

	return cam_info;
}


int zx_hisi_get_camera_info_data(HISI_CAMERA_INFO_DATA *cam_info)
{
	int ret = -1;
	int fps_value = 0;

	if(!cam_info)
	{
		dzlog_error("The function parameter is NULL.");
		return ret;
	}
	
	dzlog_info("get video parameter value start");					

	cam_info->colormode = hal_get_video_color_mode();							//获取摄像头色彩模式

	if(cam_info->colormode != 0 && cam_info->colormode != 1)
	{
		dzlog_error("hal get video color mode error colormode = %d",cam_info->colormode);
		return -1;
	}
	
#if 1
	dzlog_info("get camera color mode ok : %d",cam_info->colormode);							//0是彩色，1是黑白
#endif	

	ret = hal_video_get_csc(SENSER_BRIGHTNESS,&cam_info->brightness);			//获取摄像头亮度

	if(ret != 0)
	{
		dzlog_error("video get csc is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get brightness ok value : %d",cam_info->brightness);
#endif

	ret = hal_video_get_csc(SENSER_CONTRAST,&cam_info->contrast);				//获取摄像头对比度

	if(ret != 0)
	{
		dzlog_error("video get csc is error ret: %d",ret);
		return ret;
	}

	
#if 1
	dzlog_info("get contrast ok value : %d",cam_info->contrast);
#endif

	ret = hal_video_get_csc(SENSER_CHROMA,&cam_info->chroma);					//获取摄像头色度

	if(ret != 0)
	{
		dzlog_error("video get csc is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get chroma ok value : %d",cam_info->chroma);
#endif

	ret = hal_video_get_csc(SENSER_SATURATION,&cam_info->saturation);			//获取摄像头饱和度

	if(ret != 0)
	{
		dzlog_error("video get csc is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get saturation ok value : %d",cam_info->saturation);
#endif

	ret = hal_video_get_torate(&cam_info->angle);								//获取摄像头视频角度
	
	if(ret != 0)
	{
		dzlog_error("video get torate is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get video torate ok value : %d",cam_info->angle);
#endif

	ret = hal_video_get_fps(HISI_CH0,&cam_info->fps);							//获取摄像头帧率
	if(ret != 0)
	{
		dzlog_error("video get fps is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get fps ok value : %d",cam_info->fps);
#endif

	ret = hal_video_get_pwrfreq(&cam_info->pwfreq);								//获取电力线频率

	if(ret != 0)
	{
		dzlog_error("video get pwrfreq is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get pwrfreq ok value : %d",cam_info->pwfreq);
#endif

	ret = hal_video_get_fpsAndgop(HISI_CH0,&fps_value,&cam_info->gop);			//获取帧率和I帧间隔

	if(ret != 0)
	{
		dzlog_error("video get fpsandgop is error ret: %d",ret);
		return ret;
	}

	if(fps_value != cam_info->fps)
	{
		dzlog_error("get camera fps two times is deffient cam_info->fps = %d , fps_value = %d",cam_info->fps,fps_value);
		return -1;
	}else{
		dzlog_info("get camera fps two times same");
	}
	
#if 1
	dzlog_info("get fps and gop ok fps_value : %d  gop_value : %d",fps_value,cam_info->gop);
#endif

	ret = hal_video_get_bitrate(HISI_CH0,&cam_info->bitrate,&cam_info->bit_mode);			//码率和码率模式
	
	if(ret != 0)
	{
		dzlog_error("video get bitrate is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get bitrate and bit_mode ok bitrate_vlaue : %d  bit_mode : %d",cam_info->bitrate,cam_info->bit_mode);
#endif

	ret = hal_video_get_resolution(HISI_CH0,&cam_info->resolution);							//分辨率
	
	if(ret != 0)
	{
		dzlog_error("video get reslution is error ret: %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get resolution ok value : %d ",cam_info->resolution);
#endif

	cam_info->tem_sensor_adc_value = hal_tsensor_value();		//获取温度传感器值

	if(cam_info->tem_sensor_value < 0)						//温敏ADC的值
	{
		dzlog_error("get tem sensor value is error ret : %d",cam_info->tem_sensor_value);
		ret = -1;
		return ret;
	}
	
#if 1
	dzlog_info("get tem sensor ok value: %d",cam_info->tem_sensor_adc_value);
#endif

	cam_info->tem_sensor_value = hal_get_temperature();		//获取板子温度

	cam_info->photo_sensor_value = hal_lsensor_value();		//获取光敏传感器值

	if(cam_info->photo_sensor_value < 0)					//光敏ADC的值
	{
		dzlog_error("get tem sensor value is error ret : %d",cam_info->photo_sensor_value);
		ret = -1;
		return ret;
	}
	
#if 1
	dzlog_info("get photo sensor ok value: %d",cam_info->photo_sensor_value);
#endif

	cam_info->irled_value = hal_get_irled_bright();				//获取红外的灯的值

	if(ret < 0)
	{
		dzlog_error("get irled bright is error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get irled bright ok value: %d",cam_info->irled_value);
#endif

#if 0
	cam_info->floodlight_value = hal_get_floodlight_bright();		//获取floodlight灯的值

	if(ret < 0)
	{
		dzlog_error("get floodlight bright is error ret : %d",ret);
		return ret;
	}
#endif
	
#if 1
	dzlog_info("get floodlight bright ok value: %d",cam_info->floodlight_value);
#endif

#if 1
	ret = hal_get_param_partition_datasize(&cam_info->flash_data_len);		//获取flash数据的长度

	if(ret != 0)
	{
		dzlog_error("get flash data len error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get flash data ok value: %d",cam_info->flash_data_len);
#endif
#endif

	ret = hal_get_version(cam_info->version);							//获取库的版本信息
	
	if(ret != 0)
	{
		dzlog_error("get HAL LIB version error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get 【HAL LIB version ok value: %s】",cam_info->version);
#endif

	ret = zx_get_system_soft_version(base_param->hub_info.hub_software_main_ver);			//获取基站版本号

	if(ret != 0)
	{
		dzlog_error("get system soft version error %d",ret);
		return -1;
	}

	dzlog_info("get system soft 【version = %s】",base_param->hub_info.hub_software_main_ver);

#if 1
	ret = hal_get_pir_softversions(cam_info->pir_version,HISI_VERSION_NAME_LEN);		//获取PIR的版本信息
	
	if(ret != 0)
	{
		dzlog_error("get pir soft version error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get 【pir soft version = %s】",cam_info->pir_version);
#endif

#if 0
	ret = hal_pir_get_sensivity(HISI_LEFT_PIR);			//获取左PIR的灵敏度

	if(ret < 0)
	{
		dzlog_error("get left pir sen error ret : %d",ret);
		return ret;
	}
	
	cam_info->pir_sen_value[HISI_LEFT_PIR] = ret;
	
#if 1
	dzlog_info("get left pir sen ok value: %d",cam_info->pir_sen_value[HISI_LEFT_PIR]);
#endif

	ret = hal_pir_get_sensivity(HISI_MIDDLE_PIR);		//获取中间PIR的灵敏度

	if(ret < 0)
	{
		dzlog_error("get middle pir sen error ret : %d",ret);
		return ret;
	}
	
	cam_info->pir_sen_value[HISI_MIDDLE_PIR] = ret;
	
#if 1
	dzlog_info("get middle pir sen ok value: %d",cam_info->pir_sen_value[HISI_MIDDLE_PIR]);
#endif

	ret = hal_pir_get_sensivity(HISI_RIGHT_PIR);		//获取右边的PIR的灵敏度

	if(ret < 0)
	{
		dzlog_error("get right pir sen error ret : %d",ret);
		return ret;
	}
	
	cam_info->pir_sen_value[HISI_RIGHT_PIR] = ret;


#if 1
	dzlog_info("get right pir sen ok value: %d",cam_info->pir_sen_value[HISI_RIGHT_PIR]);
#endif
#endif

  	ret = hal_pir_get_sensivity(HISI_LEFT_PIR);

	if(ret < 0)
	{
		dzlog_error("get  pir sen error ret : %d",ret);
		return ret;
	}
	
	cam_info->pir_sen_value[HISI_LEFT_PIR] = ret;
	cam_info->pir_sen_value[HISI_MIDDLE_PIR] = ret;
	cam_info->pir_sen_value[HISI_RIGHT_PIR] = ret;

	dzlog_info("get pir sen ok value: %d",cam_info->pir_sen_value[HISI_MIDDLE_PIR]);

#endif

	ret = hal_audio_get_vout(&cam_info->speaker_volume);			//获取speaker音量

	if(ret != 0)
	{
		dzlog_error("get audio vout error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get speaker volume : %d",cam_info->speaker_volume);		//speaker 音量
#endif

#if 1
	ret = hal_audio_get_vin(&cam_info->mic_volume);					//获取mic的音量
	
	if(ret != 0)
	{
		dzlog_error("get audio vin error ret : %d",ret);
		return ret;
	}
#endif
	
#if 1
	dzlog_info("get mic volume : %d",cam_info->mic_volume);				//mic 音量
#endif

	ret = hal_video_get_md_sensitivity(&cam_info->sensitivity);			//获取移动侦测

	if(ret != 0)
	{
		dzlog_error("get video sensitivity error ret : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("get video sensitivity : %d",cam_info->sensitivity);
#endif

	ret = hisi_get_flash_ssid_and_password(hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password);		//获取flash里面的wifi名称和密码

	if(ret != 0)
	{
		dzlog_error("get flash ssid and password error.");
		return -1;
	}

	dzlog_info("【get flash data : [ssid:%s ----- password:%s]】",hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password);

#if 0
	ret = zx_hisi_get_flash_account_id(base_param->hub_info.account_id,sizeof(base_param->hub_info.account_id));

	if(ret <= 0)
	{
		dzlog_error("get flash account id error");
		return -1;	
	}
#endif

#if 0
	ret = zx_hisi_get_device_sn(base_param->hub_info.hub_sn,DEVICE_SN_LEN);

	if(ret <= 0)
	{
		dzlog_error("get flash account id error");
		return -1;	
	}
#endif

	zx_get_system_soft_version(base_param->hub_info.hub_software_main_ver);			//获取基站版本号

	dzlog_info("software main ver = %s",base_param->hub_info.hub_software_main_ver);

#if 0
	ret = zx_hisi_get_device_sn(hisi_cam_data->dev_sn, DEVICE_SN_LEN); //获取设备sn，
	if(ret <= 0)
	{
		dzlog_error("get device sn fail.");
		return -1;
	}
	
	dzlog_info("【get flash dev sn = %s】" , hisi_cam_data->dev_sn);
#endif

	ret = zx_hisi_cam_get_tmp_photo_value_pthread();				//获取光敏和板子温度的值

	if(ret != 0)
	{
		dzlog_error("hisi cam get photo value pthread error");
		return ret;
	}

#if 1
	dzlog_info("hisi cam get tmp and photo pthread running");
#endif

#if 1
	ret = zx_hisi_cam_day_or_night_pthread();				//判断白天还是晚上，ircut切换线程
	if(ret != 0)
	{
		dzlog_error("hisi day or night pthread error");
		return ret;
	}

#if 1
	dzlog_info("hisi cam day or night pthread running");
#endif
#endif
	
	dzlog_info("get video parameter value end");
	
	return ret;
}


int zx_hisi_set_camera_senser_parameter(
	int brightness,					//亮度				[0-100]
	int contrast,					//对比度				[0-100]
	int chroma,						//色度				[0-100]
	int saturation,					//饱和度				[0-100]
	VIDEO_FLIP_E angle,				//视频角度  			[0:0°, 90:90°, 180:180°, 270:270° ]
	int colormode,					//色彩模式				[0:彩色,1:黑白]
	MD_LEVEL_E sensitivity,			//移动侦测灵敏度			[0-3]
	RESOLUTION_DEF_E resolution,	//视频分辨率				[0:RES_VGA , 1:RES_720P , 2:RES_1080P] 
	int fps,						//帧率
	int gop,						//I帧间隔
	POWER_FREQ_E pwfreq,			//电力线频率				[0:F50HZ, 1:F60HZ]
	int bitrate,					//码率
	BITRATE_MODE_E bit_mode			//码率模式				[0:VBR,1:CBR]	//CBR不能设置
	)
{
	int ret = -1;

	dzlog_info("set camera senser parameter info start");

	ret = hal_video_set_csc(SENSER_BRIGHTNESS,brightness);		//设置亮度

	if(ret != 0)
	{
		dzlog_error("camera set brightness is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->brightness = brightness;
	
#if HISI_LOG_SWITCH
	dzlog_info("set brightness is ok");
#endif

	ret = hal_video_set_csc(SENSER_CONTRAST,contrast);		//设置对比度

	if(ret != 0)
	{
		dzlog_error("video set contrast is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->contrast = contrast;
	
#if HISI_LOG_SWITCH
	dzlog_info("set contrast is ok");
#endif

	ret = hal_video_set_csc(SENSER_CHROMA,chroma);			//设置色度

	if(ret != 0)
	{
		dzlog_error("video set chroma is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->chroma = chroma;
	
#if HISI_LOG_SWITCH
	dzlog_info("set chroma is ok");
#endif

	ret = hal_video_set_csc(SENSER_SATURATION,saturation);		//设置饱和度

	if(ret != 0)
	{
		dzlog_error("video set saturation is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->saturation = saturation;
	
#if HISI_LOG_SWITCH
	dzlog_info("set saturation is ok");
#endif

	ret = hal_video_set_torate(angle);		//设置角度

	if(ret != 0)
	{
		dzlog_error("video set angle is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->angle = angle;
	
#if HISI_LOG_SWITCH
	dzlog_info("set angle is ok");
#endif

	ret = hal_set_video_color_mode(colormode);		//设置图像色彩
	
	if(ret != 0)
	{
		dzlog_error("video set color mode is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->colormode = colormode;
	
#if HISI_LOG_SWITCH
	dzlog_info("set color mode is ok");
#endif

	ret = hal_video_set_md_sensitivity(sensitivity);		//设置移动侦测灵敏度
	if(ret != 0)
	{
		dzlog_error("video set md sensitivity error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->sensitivity = sensitivity;
	
#if HISI_LOG_SWITCH
	dzlog_info("set video sensitivity is ok");
#endif

	ret = hal_video_set_resolution(HISI_CH0,resolution);		//设置视频分辨率

	if(ret != 0)
	{
		dzlog_error("video set resolution is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->resolution = resolution;
	
#if HISI_LOG_SWITCH
	dzlog_info("set resolution is ok");
#endif

	ret = hal_video_set_fpsAndgop(HISI_CH0,fps,gop);			//设置帧率和I帧间隔

	if(ret != 0)
	{
		dzlog_error("video set fps and gop is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->fps = fps;
	hisi_cam_data->gop = gop;
	
#if HISI_LOG_SWITCH
	dzlog_info("set fps and gop is ok");
#endif

	ret = hal_video_set_pwrfreq(pwfreq);						//设置电力线频率

	if(ret != 0)
	{
		dzlog_error("hisi set video pwrfreq is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->pwfreq = pwfreq;
	
#if HISI_LOG_SWITCH
	dzlog_info("set pwrfreq is ok");
#endif

	ret = hal_video_set_bitrate(HISI_CH0,bitrate,bit_mode);		//设置码率和码率模式
	
	if(ret != 0)
	{
		dzlog_error("video set bit and bit mode is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->bitrate = bitrate;
	hisi_cam_data->bit_mode = bit_mode;
	
#if HISI_LOG_SWITCH
	dzlog_info("set bit and bit mode is ok");
#endif

#if 0
	ret = hal_set_irled_bright(irled_value);			//IR curt 亮度

	if(ret != 0)
	{
		dzlog_error("video set irled bright error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->irled_value = irled_value;

#if HISI_LOG_SWITCH
	dzlog_info("set irled bright is ok");
#endif
#endif

	dzlog_info("set camera senser parameter info end");

	return ret;
}



int zx_hisi_set_pir_sensivity_value(int left_pir, int middle_pir, int right_pir)
{
	int ret = -1;

	dzlog_info("set pir sensivity start");

#if 0
	ret = hal_pir_set_sensivity(HISI_LEFT_PIR,left_pir);

	if(ret != 0)
	{
		dzlog_error("pir set left pir sensivity is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->pir_sen_value[HISI_LEFT_PIR] = left_pir;
	
#if HISI_LOG_SWITCH
	dzlog_info("left pir set sensivity is ok");
#endif	

	ret = hal_pir_set_sensivity(HISI_MIDDLE_PIR,middle_pir);

	if(ret != 0)
	{
		dzlog_error("pir set middle pir sensivity is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->pir_sen_value[HISI_MIDDLE_PIR] = middle_pir;
	
#if HISI_LOG_SWITCH
	dzlog_info("middle pir set sensivity is ok");
#endif

	ret = hal_pir_set_sensivity(HISI_RIGHT_PIR,right_pir);

	if(ret != 0)
	{
		dzlog_error("pir set right pir sensivity is error ret : %d",ret);
		return -1;
	}

	hisi_cam_data->pir_sen_value[HISI_RIGHT_PIR] = right_pir;
	
#if HISI_LOG_SWITCH
	dzlog_info("right pir set sensivity is ok");
#endif
#endif

	ret = hal_pir_set_sensivity(0,middle_pir);

	if(ret != 0)
	{
		dzlog_error("pir set pir sensivity is error ret : %d",ret);
		return -1;
	}
	hisi_cam_data->pir_sen_value[HISI_LEFT_PIR] = middle_pir;
	hisi_cam_data->pir_sen_value[HISI_MIDDLE_PIR] = middle_pir;
	hisi_cam_data->pir_sen_value[HISI_RIGHT_PIR] = middle_pir;

	dzlog_info("set pir sensivity end");
	
	return ret;
}


/***************************************
设置pir灵敏度
返回值：返回值：成功返回 0 ，失败返回 -1
***************************************/
int zx_hisi_set_pir_on(void)
{
	int ret = -1;

	int enbale[3] = {1,1,1};

#if 0
	ret = hal_pir_enable(HISI_LEFT_PIR,HISI_ENABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR enable error.");
		return -1;
	}
	
	ret = hal_pir_enable(HISI_MIDDLE_PIR,HISI_ENABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR enable error.");
		return -1;
	}
	
	ret = hal_pir_enable(HISI_RIGHT_PIR,HISI_ENABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR enable error.");
		return -1;
	}
#endif

	ret = hal_pir_enable(enbale);					//pir全部使能

	if(ret != 0)
	{
		dzlog_error("left PIR enable error.");
		return -1;
	}

	hisi_cam_data->pir_sen_state[HISI_LEFT_PIR] = ON_STATE;
	hisi_cam_data->pir_sen_state[HISI_MIDDLE_PIR] = ON_STATE;
	hisi_cam_data->pir_sen_state[HISI_RIGHT_PIR] = ON_STATE;

	return 0;
}


/***************************************
设置pir灵敏度
返回值：返回值：成功返回 0 ，失败返回 -1
***************************************/
int zx_hisi_set_pir_off(void)
{
	int ret = -1;
	int disable[3] = {0,0,0};
#if 0
	ret = hal_pir_enable(HISI_LEFT_PIR,HISI_DISABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR disable error.");
		return -1;
	}
	
	ret = hal_pir_enable(HISI_MIDDLE_PIR,HISI_DISABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR disable error.");
		return -1;
	}
	
	ret = hal_pir_enable(HISI_RIGHT_PIR,HISI_DISABLE);

	if(ret != 0)
	{
		dzlog_error("left PIR disable error.");
		return -1;
	}
#endif

	ret = hal_pir_enable(disable);					//pir全部不使能
	
	if(ret != 0)
	{
		dzlog_error("left PIR disable error.");
		return -1;
	}

	hisi_cam_data->pir_sen_state[HISI_LEFT_PIR] = OFF_STATE;
	hisi_cam_data->pir_sen_state[HISI_MIDDLE_PIR] = OFF_STATE;
	hisi_cam_data->pir_sen_state[HISI_RIGHT_PIR] = OFF_STATE;

	return 0;
	
}


int zx_hisi_set_camera_volume(int mic_volume,int speaker_volume)
{
	int ret = -1;
	
	dzlog_info("hisi set camera volume start");

	ret = hal_audio_set_vin(mic_volume);

	if(ret != 0)
	{
		dzlog_error("hal audio set vin error ret: %d",ret);
		return -1;
	}

	hisi_cam_data->mic_volume = mic_volume;
	
	ret = hal_audio_set_vout(speaker_volume);

	if(ret != 0)
	{
		dzlog_error("hal audio set vout error ret: %d",ret);
		return -1;
	}

	hisi_cam_data->speaker_volume = speaker_volume;

	dzlog_info("hisi set camera volume end");
	
	return ret;
}

int zx_hisi_get_camera_wifi_data(HISI_CAMERA_WIFI_DATA* cam_wifi_info)
{
	if(!cam_wifi_info )
	{
		dzlog_error("The function parameter is NULL.");
		return -1;
	}
	
	dzlog_info("get current wifi info start");

	HISI_WIFI_LIST_DATA *wifi_list = NULL;

	wifi_list = hisi_wifi_list;

	if( !wifi_list )
	{
		dzlog_error("The wifi_list parameter is NULL.");
		return -1;
	}

	
	
	while(1)
	{
		if((strlen(wifi_list->wifi_list_info.ssid) > 0) && (strlen(cam_wifi_info->wifi_ssid) > 0))
		{
			if(strcmp(wifi_list->wifi_list_info.ssid,cam_wifi_info->wifi_ssid ) == 0 )
			{
				cam_wifi_info->wifi_signal = wifi_list->wifi_list_info.signal;
				cam_wifi_info->wifi_enc = wifi_list->wifi_list_info.enc;
				cam_wifi_info->wifi_auth = wifi_list->wifi_list_info.auth;
				cam_wifi_info->wifi_channel = wifi_list->wifi_list_info.channel;
				break;
			}
			
		}else{

			if(wifi_list->wifi_list_info.ssid)
				dzlog_error("【 wifi_list->wifi_list_info.ssid = %s】",wifi_list->wifi_list_info.ssid);
			else
				dzlog_error("【wifi_list->wifi_list_info.ssid is NULL 】");

			if(cam_wifi_info->wifi_ssid)
				dzlog_error("【 cam_wifi_info->wifi_ssid = %s】",cam_wifi_info->wifi_ssid);
			else
				dzlog_error("【cam_wifi_info->wifi_ssid is NULL 】");
			
			//return -1;
		}

		wifi_list = wifi_list->next;
		
		if(!wifi_list)
		{
			zx_hisi_wifi_list_printf_ssid(wifi_list);
			
			dzlog_error("wifi list not this wifi_ssid : %s",cam_wifi_info->wifi_ssid);
			break;
		}
		
		
	}

	if(hal_get_wifi_dev_name(&cam_wifi_info->wifi_dev_name) != 0)
	{
		dzlog_error("get wifi dev name error");
		return -1;
	}
	
#if 1
	dzlog_info("get wifi dev name ok");
#endif

	memset(cam_wifi_info->wifi_ip,0,sizeof(cam_wifi_info->wifi_ip));
	if(zx_hisi_get_wifi_localip(&cam_wifi_info->wifi_ip) != 0)
	{
		dzlog_error("get wifi localip error");
		return -1;
	}
	
#if 1
	dzlog_info("get wifi localip ok");
#endif

	memset(cam_wifi_info->wifi_mac,0,sizeof(cam_wifi_info->wifi_mac));
	if(zx_hisi_get_wifi_mac(&cam_wifi_info->wifi_mac) != 0)
	{
		dzlog_error("get wifi mac error");
		return -1;
	}
	
#if 1
	dzlog_info("get wifi mac ok");
#endif
	
	dzlog_info("hisi printf wifi list info end");
	
	return 0;
}

void zx_hisi_camera_wifi_info_printf(HISI_CAMERA_WIFI_DATA *cam_wifi_info)
{
	dzlog_info("hisi printf camera wifi info start");
	
	dzlog_info("wifi info signal : %d",cam_wifi_info->wifi_signal);
	dzlog_info("wifi info enc : %d",cam_wifi_info->wifi_enc);
	dzlog_info("wifi info auth : %d",cam_wifi_info->wifi_auth);
	dzlog_info("wifi info channel freq : %d",cam_wifi_info->wifi_channel);
	dzlog_info("wifi info channel freq : %d",cam_wifi_info->wifi_mode);

	
	if(cam_wifi_info->wifi_dev_name)
		dzlog_info("wifi dev name : %s",cam_wifi_info->wifi_dev_name);
	else
		dzlog_info("wifi dev name is NULL");
	
	if(cam_wifi_info->wifi_ssid)
		dzlog_info("wifi info ssid : %s",cam_wifi_info->wifi_ssid);
	else
		dzlog_info("wifi ssid is NULL");

	if(cam_wifi_info->wifi_password)
		dzlog_info("wifi info password : %s",cam_wifi_info->wifi_password);
	else
		dzlog_info("wifi pasword is NULL");

	if(cam_wifi_info->wifi_ip)
		dzlog_info("wifi info ip : %s",cam_wifi_info->wifi_ip);
	else
		dzlog_info("wifi ip is NULL");

	if(cam_wifi_info->wifi_mac)
		dzlog_info("wifi info mac : %s",cam_wifi_info->wifi_mac);
	else
		dzlog_info("wifi mac is NULL");

	dzlog_info("hisi printf camera wifi info end");
}



int zx_hisi_floodlight_init()
{

	dzlog_info("zx hisi floodlight init start");
	
	hisi_cam_data = zx_hisi_camera_info_data_init();

	if(!hisi_cam_data)
	{
		dzlog_error("hisi camera info data init error");
		return -1;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi camera info data init ok");
#endif

	hisi_wifi_list = zx_hisi_wifi_list_init();

	if(!hisi_wifi_list)
	{
		dzlog_error("zx hisi wifi list init error");
		return -1;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi wifi list init ok");
#endif

	hisi_cam_wifi = zx_hisi_camera_wifi_data_init();

	if(!hisi_cam_wifi)
	{
		dzlog_error("zx hisi camera wifi data init error");
		return -1;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi camera wifi data init ok");
#endif

	dzlog_info("zx hisi floodlight init end");

	return 0;

}



int zx_hisi_floodlight_deinit(void)
{
	int ret = -1;

	if(hisi_cam_data)
	{
		free(hisi_cam_data);
		hisi_cam_data = NULL;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi camera info data free ok");
#endif

	ret = zx_hisi_wifi_list_free(hisi_wifi_list);

	if(ret != 0)
	{
		dzlog_error("hisi wifi list free error : %d",ret);
		return -1;
	}

#if HISI_LOG_SWITCH
	dzlog_info("hisi wifi list free ok");
#endif

	if(hisi_cam_wifi)
	{
		free(hisi_cam_wifi);
		hisi_cam_wifi = NULL;
	}
	
#if 1
	dzlog_info("【hisi camera wifi info data free ok...】");
#endif

	return 0;
}

int hisi_flash_read_camera_sector(char *section_name, char *buf, off_t from, size_t len)
{
	int ret = -1;
	
	if(!section_name || !buf)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("hisi flash read sector start,form = %d,len = %d",from,len);

	if(strcmp(section_name,HISI_SECTION_NAME_INFO) == 0)
	{
		dzlog_info("hisi flash read %s start",section_name);

		if(from >= HISI_OFFSET_FACTORY_OTP)
		{
			dzlog_error("read flash data more than partition");
			return -1;
		}

		ret = hal_read_param_partition(buf,from,len);

		if(ret != len)
		{
			dzlog_error("flash read %s param partition error from = %d, ret = %d,len = %d",section_name,from,ret,len);
			return -1;
		}
			
		dzlog_info("hisi flash read %s end buf = %s",section_name,buf);
		
	}
	else if(strcmp(section_name,HISI_FACTORY_NAME_OTP) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);
		
		ret = hal_read_param_partition(buf,from,len);

		if(ret != len)
		{
			dzlog_error("flash read %s param partition error from = %d,len = %d,ret = %d",section_name,from,len,ret);
			return -1;
		}
			
		dzlog_info("hisi flash read %s end buf = %s",section_name,buf);
		
	}
	else
	{
		dzlog_error("hisi read flash data error ret = %d",ret);
		return -1;
	}

	dzlog_info("hisi flash read sector end.");
	
	return ret;
}


int hisi_flash_write_camera_sector(char * section_name,  char *buf, off_t to, size_t len)
{
	int ret = -1;
	
	if(!section_name || !buf)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("【hisi write flash data partition start,to = %d,len = %d】",to,len);

	if(strcmp(section_name,HISI_SECTION_NAME_INFO) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);

		if(to >= HISI_OFFSET_FACTORY_OTP)
		{
			dzlog_error("write flash data more than partition to = %d",to);
			return -1;
		}
		
		ret = hal_write_param_partition(buf,to,len);

		if(ret != 0)
		{
			dzlog_error("flash write %s param partition error ret = %d",section_name,ret);
			return -1;
		}
	
		dzlog_info("hisi flash write %s end",section_name);
		
	}
	else if(strcmp(section_name,HISI_FACTORY_NAME_OTP) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);
		
		ret = hal_write_param_partition(buf,to,len);

		if(ret != 0)
		{
			dzlog_error("flash write %s param partition error ret = %d",section_name,ret);
			return -1;
		}
				
		dzlog_info("hisi flash write %s end",section_name);
		
	}
	else
	{
		dzlog_error("hisi flash write sector error ret = %d",ret);
		return ret;
	}
	
	dzlog_info("hisi flash write sector end buf = %s",buf);
	
	return len;
}


int zx_hisi_flash_write_sector( char * section_name,  char *buf, off_t to, size_t len)
{
	int ret = -1;
	
	if(!section_name || !buf)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("【hisi write flash data partition start,to = %d,len = %d】",to,len);

	if(strcmp(section_name,HISI_SECTION_NAME_INFO) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);

		if(to >= HISI_OFFSET_FACTORY_OTP)
		{
			dzlog_error("write flash data more than partition to = %d",to);
			return -1;
		}
		
		ret = hal_write_param_partition(buf,to,len);

		if(ret != 0)
		{
			dzlog_error("flash write %s param partition error ret = %d",section_name,ret);
			return -1;
		}
	
		dzlog_info("hisi flash write %s end",section_name);
		
	}
	else if(strcmp(section_name,HISI_FACTORY_NAME_OTP) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);

		to += HISI_OFFSET_FACTORY_OTP;
		
		ret = hal_write_param_partition(buf,to,len);

		if(ret != 0)
		{
			dzlog_error("flash write %s param partition error ret = %d",section_name,ret);
			return -1;
		}
				
		dzlog_info("hisi flash write %s end",section_name);
		
	}
	else
	{
		dzlog_error("hisi flash write sector error ret = %d",ret);
		return ret;
	}
	
	dzlog_info("hisi flash write sector end buf = %s",buf);
	
	return len;


}


int zx_hisi_flash_read_sector(char *section_name, char *buf, off_t from, size_t len)
{
	int ret = -1;
	
	if(!section_name || !buf)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("hisi flash read sector start,form = %d,len = %d",from,len);

	if(strcmp(section_name,HISI_SECTION_NAME_INFO) == 0)
	{
		dzlog_info("hisi flash read %s start",section_name);

		if(from >= HISI_OFFSET_FACTORY_OTP)
		{
			dzlog_error("read flash data more than partition");
			return -1;
		}

		ret = hal_read_param_partition(buf,from,len);

		if(ret != len)
		{
			dzlog_error("flash read %s param partition error from = %d, ret = %d,len = %d",section_name,from,ret,len);
			return -1;
		}
			
		dzlog_info("hisi flash read %s end buf = %s",section_name,buf);
		
	}
	else if(strcmp(section_name,HISI_FACTORY_NAME_OTP) == 0)
	{
		dzlog_info("hisi flash write %s start",section_name);

		from += HISI_OFFSET_FACTORY_OTP;
		
		ret = hal_read_param_partition(buf,from,len);

		if(ret != len)
		{
			dzlog_error("flash read %s param partition error from = %d,len = %d,ret = %d",section_name,from,len,ret);
			return -1;
		}
			
		dzlog_info("hisi flash read %s end buf = %s",section_name,buf);
		
	}
	else
	{
		dzlog_error("hisi read flash data error ret = %d",ret);
		return -1;
	}

	dzlog_info("hisi flash read sector end.");
	
	return ret;

}




int zx_hisi_camera_flash_read_fac_otp ( HISI_OUT  char *buf, HISI_IN  size_t len)
{
	return hisi_flash_read_camera_sector(HISI_FACTORY_NAME_OTP, buf, HISI_OFFSET_FACTORY_OTP, len);
}


int zx_hisi_camera_flash_write_fac_otp( HISI_OUT  char *buf, HISI_IN  size_t len)
{
	return hisi_flash_write_camera_sector(HISI_FACTORY_NAME_OTP, buf, HISI_OFFSET_FACTORY_OTP, len);
}


int zx_hisi_camera_flash_read_dev_info( HISI_OUT  char *buf, HISI_IN  size_t len)
{
	return hisi_flash_read_camera_sector(HISI_SECTION_NAME_INFO ,buf, HISI_OFFSET_SECTION_INFO , len);
}


int zx_hisi_camera_flash_write_dev_info( HISI_OUT  char *buf, HISI_IN  size_t len)
{
	return hisi_flash_write_camera_sector(HISI_SECTION_NAME_INFO, buf, HISI_OFFSET_SECTION_INFO, len);
}


int zx_hisi_get_device_sn( char * buf, size_t len )
{
	if( !buf || len < HISI_DEV_SN_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for read.\n", HISI_DEV_SN_LEN);
		return -1;
	}

	return zx_hisi_flash_read_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_SN_OFFSET, len  );
}


/*******************************************************************
 *  write device SN to factory sector   return -1 for fail.
 * ****************************************************************/
int zx_hisi_set_device_sn( char * buf, size_t len )
{
	if( !buf || len < HISI_DEV_SN_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for write.\n", HISI_DEV_SN_LEN);
		return -1;
	}

	return zx_hisi_flash_write_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_SN_OFFSET, len  );
}


int zx_hisi_get_flash_account_id( char * buf, size_t len )
{
	if( !buf || len < HISI_DEV_SN_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for read.\n", HISI_DEV_SN_LEN);
		return -1;
	}

	return zx_hisi_flash_read_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_ACCOUNT_ID_OFFSET, len  );
}


/*******************************************************************
 *  write device SN to factory sector   return -1 for fail.
 * ****************************************************************/
int zx_hisi_set_flash_account_id( char * buf, size_t len )
{
	if( !buf || len < HISI_DEV_SN_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for write.\n", HISI_DEV_SN_LEN);
		return -1;
	}

	return zx_hisi_flash_write_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_ACCOUNT_ID_OFFSET, len  );
}



int zx_hisi_get_flash_wifi_ssid( char * buf, size_t len )
{
	if( !buf || len < HISI_WIFI_DATA_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for read.\n", HISI_WIFI_DATA_LEN);
		return -1;
	}

	return zx_hisi_flash_read_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_WIFI_SSID_OFFSET, len  );
}


/*******************************************************************
 *  write device SN to factory sector   return -1 for fail.
 * ****************************************************************/
int zx_hisi_set_flash_wifi_ssid( char * buf, size_t len )
{
	if( !buf || len < HISI_WIFI_DATA_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for write.\n", HISI_WIFI_DATA_LEN);
		return -1;
	}

	return zx_hisi_flash_write_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_WIFI_SSID_OFFSET , len  );
}

int zx_hisi_get_flash_wifi_password( char * buf, size_t len )
{
	if( !buf || len < HISI_WIFI_DATA_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for read.\n", HISI_WIFI_DATA_LEN);
		return -1;
	}

	return zx_hisi_flash_read_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_WIFI_PASSWORD_OFFSET, len  );
}


/*******************************************************************
 *  write device SN to factory sector   return -1 for fail.
 * ****************************************************************/
int zx_hisi_set_flash_wifi_password( char * buf, size_t len )
{
	if( !buf || len < HISI_WIFI_DATA_LEN  )
	{
		fprintf(stderr, "fail of !buf || len < %d. for write.\n", HISI_WIFI_DATA_LEN);
		return -1;
	}

	return zx_hisi_flash_write_sector( HISI_FACTORY_NAME_OTP, buf, HISI_DEV_WIFI_PASSWORD_OFFSET , len  );
}





void *zx_hisi_bind_camera_mode(void *data)
{
	int ret = -1;
	int num = 0;
	
	dzlog_info("set camera bind mode start");

#if 0
	ret = zx_hisi_set_white_led_flash();

	if(ret != 0)
	{
		dzlog_error("hisi set white led flash error ret = %d",ret);
		return NULL;
	}
#endif

#if HISI_LOG_SWITCH
	dzlog_info(" 【set wifi ap mode ......】");
#endif

AP_MODE_AGAIN:
	ret = hal_set_wifi_ap_mode(HISI_WIFI_SSID_AP_MODE,HISI_WIFI_PASSWORD_AP_MODE,HISI_WIFI_AP_OPEN);
	
	if(ret != 0)
	{
		dzlog_error("【set wifi ap mode error ret: %d】",ret);

		if(num > 3)
		{
			dzlog_error("【set wifi ap mode error count: %d】",num);
			goto PTHREAD_EXIT;
		}
		++num;
		zx_mgw_setTimer(1,0);
		goto AP_MODE_AGAIN;
	}

PTHREAD_EXIT:	
	dzlog_info("【camera ap mode end and pthead_exit......】");  

	pthread_exit(0);
	return NULL;
	
}

void *zx_hisi_system_reboot(void *data)
{
	dzlog_info("***hisi system start reboot*** ");
	
	zx_ota_system("reboot");
	pthread_exit(0);
	return NULL;
}



int zx_hisi_parsing_data_connect_network(char *buf_data)
{
	cJSON *json_data = NULL;
	int ret = -1;
	char *wifi_ssid = NULL;
	char *wifi_password = NULL;

	if(!buf_data || strlen(buf_data) < 12 )
	{
		dzlog_info("recv data len less");
		return -1;
	}

	dzlog_info("buf_data = %s",buf_data);
	
	json_data = cJSON_Parse(buf_data);

	if(!json_data)
	{
		dzlog_error("cJSON_Parse error");
		return -1;
	}

	wifi_ssid = zx_MyJson_GetString(json_data,"ssid","");

	if(!wifi_ssid)
	{
		dzlog_error("hisi_cam_wifi->wifi_ssid is NULL");
		ret = -1;
		goto EXIT_FREE;
	}

	wifi_password = zx_MyJson_GetString(json_data,"password","");

	if(!wifi_password)
	{
		dzlog_error("hisi_cam_wifi->wifi_password is NULL");
		ret = -1;
		goto EXIT_FREE;
	}

	ret = zx_hisi_camera_connect_network(wifi_ssid,wifi_password);	

	if(ret != 0)
	{
		dzlog_error("hisi camera connect network error : %d",ret);
		ret = -1;
		goto EXIT_FREE;
	   
	}else{

		ret = zx_hisi_get_camera_wifi_data(hisi_cam_wifi);

		if(ret != 0)
		{
			dzlog_error("hisi get camera wifi data error: %d",ret);
			ret = -1;
			goto EXIT_FREE;
		}

		ret = zx_hisi_set_white_led_on();

		if(ret != 0)
		{
			dzlog_error("set white on error");
			ret = -1;
			goto EXIT_FREE;
		}

		wifi_connect_status = WIFI_CONNECTED;		//wifi已经连接

#if HISI_AUDIO_PLAY
		ret = hal_audio_play_file("/etc/en/add_cam_ready.wav");		//wifi连接成功,正在配对

		if(ret != 0)
		{
			dzlog_error("hisi audio play connect success error");
			ret = -1;
			goto EXIT_FREE;
		}

		dzlog_info("【---audio play add_cam_ready.wav ok---】");
#endif

		ret = zx_hisi_set_flash_ssid_and_password(hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password);

		if(ret != 0)
		{
			dzlog_error("hisi set flash ssid and password error");
			ret = -1;
			goto EXIT_FREE;
		}
	
		dzlog_info("hisi camera connect network ok");
		ret = 0;
		
	}

EXIT_FREE:

	if(wifi_ssid)
	{
		free(wifi_ssid);
		wifi_ssid = NULL;
	}

	if(wifi_password)
	{
		free(wifi_password);
		wifi_password = NULL;
	}

	return ret;
}



int zx_hisi_get_flash_wifi_data_connect_network(void)
{
	int ret = -1;
	char wifi_ssid[HISI_WIFI_DATA_LEN] = {0};
	char wifi_password[HISI_WIFI_DATA_LEN] = {0};


	ret = hisi_get_flash_ssid_and_password(wifi_ssid,wifi_password);		//获取flash里面的wifi名称和密码

	if(ret != 0)
	{
		dzlog_error("get flash ssid and password error.");
		return -1;
	}

	ret = zx_hisi_camera_connect_network(wifi_ssid,wifi_password);	

	if(ret != 0)
	{
		dzlog_error("hisi camera connect network error : %d",ret);
		return -1;
	   
	}else{

		ret = zx_hisi_get_camera_wifi_data(hisi_cam_wifi);

		if(ret != 0)
		{
			dzlog_error("hisi get camera wifi data error: %d",ret);
			return -1;
		}

		ret = zx_hisi_set_white_led_on();

		if(ret != 0)
		{
			dzlog_error("set white on error");
			return -1;
		}

		wifi_connect_status = WIFI_CONNECTED;		//wifi已经连接

#if HISI_AUDIO_PLAY
		ret = hal_audio_play_file("/etc/en/add_cam_ready.wav");		//wifi连接成功,正在配对

		if(ret != 0)
		{
			dzlog_error("hisi audio play connect success error");
			return -1;
		}

		dzlog_info("【---audio play add_cam_ready.wav ok---】");
#endif

		ret = zx_hisi_set_flash_ssid_and_password(hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password);

		if(ret != 0)
		{
			dzlog_error("hisi set flash ssid and password error");
			return -1;
		}
	
		dzlog_info("hisi camera connect network ok");
		
	}

	return 0;
}



int zx_hisi_Accept(int fd, struct sockaddr *sa, socklen_t *salenptr)
{
	int n = -1;

again:
	if ((n = accept(fd, sa, salenptr)) < 0)
	{
		if ((errno == ECONNABORTED) || (errno == EINTR))
			goto again;
		else
			dzlog_error("accept error");
	}
	return n;
}


cJSON *zx_hisi_cjson_send_data(void)
{

	int i = 0;
	cJSON *param_root = NULL, *pJsonArry = NULL, *pJsonsub = NULL;
	HISI_WIFI_LIST_DATA *wifi_data_list = NULL;

	dzlog_info("hisi cjson data start");

	wifi_data_list = hisi_wifi_list;
	
#if HISI_LOG_SWITCH
	dzlog_info("printf wifi list");
	zx_hisi_wifi_list_all_printf(wifi_data_list);
#endif

	param_root = cJSON_CreateObject();

	if(!param_root)
	{
		dzlog_error("cJSON CreateObject is error");
		return NULL;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi cjson create object ok");
#endif

	pJsonArry=cJSON_CreateArray();   						

	if(!pJsonArry)
	{
		dzlog_error("cjson create array error");
		return NULL;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("hisi cJSON_CreateArray ok");
#endif

	while(1)
	{
		pJsonsub = cJSON_CreateObject(); 							

		if(!param_root)
		{
			dzlog_error("cJSON CreateObject is error");
			return NULL;
		}
		
		++i;
		
		if((i > (wifi_data_list->wifi_info_count)) || !wifi_data_list)
		{
			dzlog_info("wifi data assignment ok");
			break;
		}
		
		cJSON_AddStringToObject(pJsonsub,"ssid",wifi_data_list->wifi_list_info.ssid);  			
		cJSON_AddNumberToObject(pJsonsub,"signal",wifi_data_list->wifi_list_info.signal);  		
		cJSON_AddNumberToObject(pJsonsub,"channel",wifi_data_list->wifi_list_info.channel);  	

		cJSON_AddItemToArray(pJsonArry,pJsonsub);   				

		wifi_data_list = wifi_data_list->next;
		
	}
	
	cJSON_AddItemToObject(param_root,"data",pJsonArry); 		

	dzlog_info("hisi cjson data end");

	return param_root;

}


void *zx_hisi_tcp_read_write(void *confd)
{
	int connfd = *(int *)confd;
	unsigned int n = -1;
	char buf_data[128] = {0};
	char *send_data = NULL;
	char *s_json_param = NULL;
	cJSON *param_root_json = NULL;

	dzlog_info("【hisi tcp read write start ......】");	

	param_root_json = zx_hisi_cjson_send_data();

	if(!param_root_json)
	{
		dzlog_error("hisi cjson send data error");
		goto PTHREAD_EXIT;
	}

	s_json_param = cJSON_PrintUnformatted(param_root_json);

	if(!s_json_param)
	{
		dzlog_error("cJSON_PrintUnformatted is error");
		goto PTHREAD_EXIT;
	}
	
#if HISI_LOG_SWITCH
	dzlog_info("s_json_param = %s",s_json_param);
#endif

	send_data = (char *)malloc(strlen(s_json_param) + 1);

	if(!send_data)
	{
		dzlog_info("malloc error");
		goto PTHREAD_EXIT;
	}

	memset(send_data,0,strlen(s_json_param) + 1);

	memcpy(send_data,s_json_param,strlen(s_json_param));

	dzlog_info("camera send_data = %s",send_data);
	
#if HISI_AUDIO_PLAY
	if(hal_audio_play_file("/etc/en/wifi_configuration_en.wav") != 0)		//配置wifi
	{
		dzlog_error("audio play file wifi configuration error");
		goto PTHREAD_EXIT;
	}

	dzlog_info("【---audio play wifi_configuration_en.wav ok---】");
#endif

	while(hisi_bind_dev_grunning)
	{
		n = mgw_Read(connfd, buf_data, sizeof(buf_data));
		
		if( 0 == n)
		{
			dzlog_error("【client is close】");
			break;
			
		}else{
			
			dzlog_info("recv data  = %s",buf_data);
			n = mgw_Write(connfd, send_data, strlen(send_data));

			if(0 == n)
			{
				dzlog_error("【write error】");
				break;
			}

			if(strlen(buf_data) > 12)
			{
				if((zx_hisi_parsing_data_connect_network(buf_data)) != 0)
				{
					dzlog_error("hisi parsing data connect network error");
				}
				break;
			}
			
		}
			
	}
	
PTHREAD_EXIT:
	if(connfd > 0)
		close(connfd);

	if(send_data)
	{
		free(send_data);
		send_data = NULL;
	}

	if(param_root_json)
	{
		cJSON_Delete(param_root_json);
		param_root_json = NULL;
	}

	if(s_json_param)
	{
		free(s_json_param);
		s_json_param = NULL;
	}

	pthread_exit(0);
	return NULL;
	
}


void *zx_hisi_tcp_server_pthread(void *wifi_info)
{
	
    int n = -1;
    int nready = -1;                 
    int maxfd = -1, listenfd = -1, connfd = -1;
	int ret = -1;
	pthread_t read_write;
	char str[16] = {0};
	int opt = 1;
	unsigned int bind_count = 0;
	
    struct sockaddr_in clie_addr, serv_addr;
    socklen_t clie_addr_len;
    fd_set rset, allset; 
	struct timeval tv; 

	HISI_CAMERA_WIFI_DATA *wifi_data = (HISI_CAMERA_WIFI_DATA *)wifi_info;
	
	dzlog_info("*** hisi tcp server pthread start ip = %s, port=%d ***",wifi_data->wifi_ip,HISI_TCP_PORT);

    listenfd = socket(AF_INET, SOCK_STREAM, 0);

	if(listenfd < 0)
	{
		dzlog_error("socket error fd = %d",listenfd);
		pthread_exit(0);
		return NULL;
	}

BIND_AGAIN:
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));		

    bzero(&serv_addr, sizeof(serv_addr));
	
    serv_addr.sin_family= AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	//serv_addr.sin_addr.s_addr = htonl(wifi_data->wifi_ip);
    serv_addr.sin_port= htons(HISI_TCP_PORT);

	if((bind(listenfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr))) < 0)
	{
		zx_mgw_setTimer(1,0);
		
		++bind_count;
		
		if(bind_count <= 6)
		{
			dzlog_info("bind again");
			goto BIND_AGAIN;
		}
		else
		{
			dzlog_error("error bind %d count...",bind_count);
			dzlog_error("【bind error errno:%d===>[%s]】",errno,strerror(errno));
			goto PTHREAD_EXIT;
		}
	}

	dzlog_info("【bind ok......】");

	if( (listen(listenfd, 128)) < 0)
	{
		dzlog_error("listen error");
		goto PTHREAD_EXIT;
	}

    maxfd = listenfd;                                           

    FD_ZERO(&allset);
    FD_SET(listenfd, &allset);    

    while (hisi_bind_dev_grunning) 
	{   
		tv.tv_sec = 0;    
        tv.tv_usec = HISI_TCP_REUSEADDR_LEN*1000;
		
        rset = allset;                                          
        nready = select(maxfd+1, &rset, NULL, NULL, &tv);		//监控写事件，不阻塞监控
	
        if (nready < 0)
        {
            dzlog_error("select error");
			goto PTHREAD_EXIT;
        }

        if (FD_ISSET(listenfd, &rset) && nready > 0) 
		{                       
            clie_addr_len = sizeof(clie_addr);
			
            connfd = zx_hisi_Accept(listenfd, (struct sockaddr *)&clie_addr, &clie_addr_len); 
		
            dzlog_info("【received from %s at PORT %d】",
                    inet_ntop(AF_INET, &clie_addr.sin_addr, str, sizeof(str)),
                    ntohs(clie_addr.sin_port));

			zx_stop_broadcase();		//关闭广播

			ret = pthread_create(&read_write,NULL,zx_hisi_tcp_read_write,&connfd);  

			if(ret != 0)
			{
				dzlog_error(" create tcp read write thread fail"); 
				goto PTHREAD_EXIT;
			}
			
			pthread_detach(read_write);

			if (--nready == 0)
            {
				dzlog_info("select continue...");
				continue;
            }
                
        } 

    }
	
PTHREAD_EXIT:

	if(listenfd > 0)
    	close(listenfd);
	
	pthread_exit(0);
    return;

}


int zx_hisi_app_bind_tcp_server()
{
	pthread_t tcp_server;
	int ret = -1;
	hisi_bind_dev_grunning = 1;
	
	ret = pthread_create(&tcp_server,NULL,zx_hisi_tcp_server_pthread,hisi_cam_wifi);  

	if(ret != 0)
	{
		dzlog_error(" fail to create thread ,close conncet sockfd"); 
		return -1;
	}
	
	pthread_detach(tcp_server);

	return 0;
}


int zx_hisi_camera_app_bind_module(void)
{
	int ret = -1;
	int num = 0;
	char localip[HISI_WIFI_IP_LEN] = {0};
	char localmac[HISI_WIFI_MAC_LEN] = {0};
	char sn[HISI_CAM_SN_LEN + 1] = {0};

	dzlog_info("hisi camera app bind module start");
	
AGAIN:
	++num; 

	if(num > 60)		//60秒内没有获取到IP或者mac就退出
	{
		dzlog_error("get wifi localip or localmac error");
		return -1;
	}
	
	ret = zx_hisi_get_wifi_localip(localip);

	if(ret != 0)
	{
		dzlog_info("hisi no get wifi localip ,try again ret: %d",ret);
		zx_mgw_setTimer(1,0);
		goto AGAIN;
	}

	dzlog_info("******localip = %s******",localip);

	memset(hisi_cam_wifi->wifi_ip,0,sizeof(hisi_cam_wifi->wifi_ip));
	memcpy(hisi_cam_wifi->wifi_ip,localip,strlen(localip));

	ret = zx_hisi_get_wifi_mac(localmac);
	
	if(ret != 0)
	{
		dzlog_info("hisi no get wifi localmac , try again ret: %d",ret);
		goto AGAIN;
	}

	dzlog_info("******localmac = %s******",localmac);

	memset(hisi_cam_wifi->wifi_mac,0,sizeof(hisi_cam_wifi->wifi_mac));
	memcpy(hisi_cam_wifi->wifi_mac,localmac,strlen(localmac));

#if 1
	if((zx_hisi_get_device_sn(sn, HISI_CAM_SN_LEN)) <= 0) //  //获取设备sn，
	{
		dzlog_error("get device sn fail.");
		return -1;
		
	}else{
		
		dzlog_info("sn=%s" , sn);
	}
#endif

#if 0
	if((hal_get_sn(sn)) != 0)			//获取SN
	{
		dzlog_error("【hal get hisi dev sn fail.】");	
	}

	if(strlen(sn) <= 0)
	{
		dzlog_warn("hisi get dev sn len is zero.");
		memcpy(sn,FLOODLIGHT_DEV_SN,DEVICE_SN_LEN);
	}
#endif

	dzlog_info("sn=%s" , sn);

	dzlog_info("local IP = %s,local mac = %s,port = %d,sn= %s",hisi_cam_wifi->wifi_ip,hisi_cam_wifi->wifi_mac,HISI_TCP_PORT,sn);

	//端口9009，
	if(localip && sn)
	{
		dzlog_info("localip = %s ,sn= %s , port= %d",localip,sn,HISI_TCP_PORT);
		
		if((zx_send_boradcast(HISI_TCP_PORT,sn,localip)) != 0)		//发广播
		{
			dzlog_error("send borad cast error");
			return -1;
		}

		dzlog_info("【send boradcast ok】");
	
		if((zx_hisi_app_bind_tcp_server()) != 0)
		{
			dzlog_error("hisi app bind tcp server error");
			return -1;
		}

		dzlog_info("【bind tcp server start】");
		
	}else{
		
		dzlog_error("parameter localip or sn is NULL ");
	}

	return 0;
}


#if 0
int zx_hisi_set_flash_wifi_data(char *wifi_ssid, size_t ssid_len, char *wifi_password,size_t pw_len)
{
	int ret = -1;

	if(!wifi_ssid || !wifi_password)
	{
		dzlog_error("The function paremeter is NULL");
		return -1;
	}
	
	ret = zx_hisi_set_flash_wifi_ssid(wifi_ssid,ssid_len);

	if(ret <= 0)
	{
		dzlog_error("hisi set flash wifi ssid error : %d",ret);
		return -1;
	}

	ret = zx_hisi_set_flash_wifi_password(wifi_password,pw_len);

	if(ret <= 0)
	{
		dzlog_error("hisi set flash wifi password error : %d",ret);
		return -1;
	}
	return 0;
	
}


int zx_hisi_get_flash_wifi_data(char *wifi_ssid, size_t ssid_len, char *wifi_password,size_t pw_len)
{
	int ret = -1;

	if(!wifi_ssid || !wifi_password)
	{
		dzlog_error("The function paremeter is NULL");
		return -1;
	}
		
	ret = zx_hisi_get_flash_wifi_ssid(wifi_ssid,ssid_len);
	
	if(ret <= 0)
	{
		dzlog_error("hisi get flash wifi ssid error : %d",ret);
		return -1;
	}

	ret = zx_hisi_get_flash_wifi_password(wifi_password,pw_len);
	
	if(ret <= 0)
	{
		dzlog_error("hisi get flash wifi password error : %d",ret);
		return -1;
	}
	return 0;
}
#endif



void zx_hisi_stop_tcp_server(void)
{
	dzlog_info("【stop tcp server...】");
	hisi_bind_dev_grunning = 0;
}


int zx_hisi_wifi_dev_info_clear()
{
	int ret = -1;
	char buf[HISI_WIFI_DATA_LEN];

	dzlog_info("hisi wifi dev info clear start.");

	memset(buf,0,sizeof(buf));

	zx_stop_broadcase();
	zx_hisi_stop_tcp_server();
	
	zx_mgw_setTimer(1,0);

	ret = zx_hisi_set_flash_wifi_ssid(buf,HISI_WIFI_DATA_LEN);

	if(ret <= 0)
	{
		dzlog_error("clear flash wifi ssid error : %d",ret);
		return -1;
	}
	dzlog_info("clear flash wifi ssid ok");

	ret = zx_hisi_set_flash_wifi_password(buf,HISI_WIFI_DATA_LEN);

	if(ret <= 0)
	{
		dzlog_error("clear flash wifi password error : %d",ret);
		return -1;
	}
	dzlog_info("clear flash wifi password ok");
	
	if(p2p_status)
	{
		
		ret = zx_hisi_deinit_camera_sdk();

		if(ret != 0)
		{
			dzlog_error("hisi deinit camera sdk error : %d",ret);
			return -1;
		}
		dzlog_info("hisi deinit camera sdk ok");

#if 0
		ret = zx_deinit_p2p_server();

		if(ret != 0)
		{
			dzlog_error("hisi deinit P2P server error : %d",ret);
			return -1;
		}
		dzlog_info("hisi deinit P2P server ok");
#endif

	}

	return 0;
	
}



void zx_hisi_key_event_cb(int keycode)
{
	int ret = -1;
	pthread_t bind_pid;
	pthread_t reboot_pid;
	
	dzlog_info("key event is start keycode : %d",keycode);
	
#if 1
	if(keycode == 1)
	{
		dzlog_info("***hisi camera bind mode start*** ");

#if HISI_AUDIO_PLAY
		ret = hal_audio_play_file("/etc/en/ap_mode_en.wav");

		if(ret != 0)
		{
			dzlog_error("hisi audio play file ap_mode_ch.wav error");
			return;
		}

		dzlog_info("【---audio play ap_mode_en.wav ok---】");
#endif
		hisi_cam_wifi->wifi_mode = HISI_WIFI_AP_MODE;	//提前设置
		wifi_connect_status = WIFI_NO_CONNECT;
		hisi_cam_data->white_led_state = OFF_STATE;
		hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_AUTO;
		
		gsystem_init = 0;

		ret = zx_hisi_set_white_led_flash();		//白灯闪烁

		if(ret != 0)
		{
			dzlog_error("hisi white led flash error ret = %d",ret);
			return;
		}

		ret = zx_hisi_wifi_dev_info_clear();

		if(ret != 0)
		{
			dzlog_error("hisi wifi dev info clear error");
			return;
		}

		ret = pthread_create(&bind_pid,NULL,zx_hisi_bind_camera_mode,NULL);  

		if(ret != 0)
		{
			dzlog_error(" create bind camera mode thread fail"); 
			return;
		}
		
		pthread_detach(bind_pid);

		if((zx_hisi_camera_app_bind_module()) != 0)
		{
			dzlog_error("hisi camera app bind module error");
			return;
		}
	}

	else if(keycode == 2)
	{
		dzlog_info("***system reboot*** ");
		
#if HISI_AUDIO_PLAY
		ret = hal_audio_play_file("/etc/en/reset_ok_en.wav");

		if(ret != 0)
		{
			dzlog_error("hisi audio play file reset_ok_en.wav error");
			return;
		}

		dzlog_info("【---audio play reset_ok_en.wav ok---】");
#endif
		zx_mgw_setTimer(1,0);

		ret = pthread_create(&reboot_pid,NULL,zx_hisi_system_reboot,NULL);  

		if(ret != 0)
		{
			dzlog_error(" fail to create thread ,close conncet sockfd"); 
			return;
		}
		pthread_detach(reboot_pid);
		
	}
	else
	{
		dzlog_error("key event error keycode : %d",keycode);
	}
#endif

	return;

}

void zx_hisi_camera_key_event(void)
{
	dzlog_info("【zx hisi key cb running.】");
	hal_key_register_detect_cb(zx_hisi_key_event_cb);
}



void hisi_video_push_stream_cb(int ch, char *data, int len, 
unsigned int stream_type, unsigned int frame_type, 
unsigned int  u32Width , unsigned int  u32Height, long long pts)
{
	int frame_rate = 0;
	int gop = 0;
	int i = 0;

//	dzlog_info("【camera video stream cb push start】");
	
	int ret = hal_video_get_fpsAndgop(ch,&frame_rate,&gop);		//获取帧率和I帧间隔
	if(ret != 0)
	{
		dzlog_error("video get fps and gop");
		return;
	}
	
	if(stream_type == 1)								//判断视频流是否为H264
	{
		STREAM_CONNECT_INFO *stream_info = NULL;
		
		stream_info = zx_get_stream(ch);				//通过视频流通道获取流结构体信息
		
	    if (stream_info)			/*reserve != TFCARD_RD_FLAG && */
	    {
			
	      memset(&stream_info->videoInfo,0,sizeof(VIDEO_INFO));			//先清零，每次回调都会清0
	      
	      stream_info->videoInfo.frame_rate   = frame_rate;			//帧率
	      stream_info->videoInfo.width = u32Width;					//宽度
	      stream_info->videoInfo.height = u32Height;				//高度
	      stream_info->videoInfo.frame_type = frame_type;			//帧方式，有I帧或P帧，只有I帧和P帧
	      
	      stream_info->videoInfo.ntimestamp = zx_LocalTime_ms();	//时间戳，得到系统时间，单位ms

	      if( len > VIDEO_FRAME_SIZE )				//判断视频长度是否过大
	      {
	        int sendCnt = len/VIDEO_FRAME_SIZE;		//计算需要发送的次数，每次发64*1024*2
	        
	        for(i = 0; i < sendCnt; i++)
	        {
	          stream_info->videoInfo.frame_size = VIDEO_FRAME_SIZE;			//发送数据长度
	          zx_stream_send_video_frame(ch,data + VIDEO_FRAME_SIZE*i);		//发生数据，每次发送64*1024*2
	        }
	        
	        if((stream_info->videoInfo.frame_size = len - VIDEO_FRAME_SIZE*sendCnt) > 0)	//判断是否已经全部发送完成
	        {
	        	zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*sendCnt);			//发送最后剩余的数据
	        }
			
	      }
	      else
	      {
	        stream_info->videoInfo.frame_size = len;		//视频长度赋值
	        zx_stream_send_video_frame(ch,data);			//发送数据
	      }
	      
	    }
	//	dzlog_info("【camera video stream cb push ok......】");
	}
}



void hisi_audio_push_stream_cb(char *data, int len, unsigned int pts, void *user_data)
{
	
	int audio_ch = HISI_CH0;
	int result = 0;
	
//	dzlog_info("【camera Audio stream cb push start】");
	
	STREAM_CONNECT_INFO *info = zx_get_stream(audio_ch);		//通过音频通道获取流结构体信息
	 
      if(info)			//判断获取信息ok
      {
        if(info->iControlThreadRun)		//判断视频流是否正常
        {
          info->iAudioCallBackRunState = 1;
		  
          QUEUE *aqueue = (QUEUE *)info->audio_queue;  
		  
          if (aqueue)
          {
		  	
            if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE))	//判断队列是否可用
			{
				
              ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf; //消息结构体指向队列节点
			  
              memset(comm_head, 0, COMM_HEARD_LEN);			//消息结构体清0
			  
              comm_head->head_tag = PAG_HEARD_TAG;				//消息头
              comm_head->command_id = APP_CMD_AUDIO_FRAME;		//音频传输
              
              comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;		//音频的长度，音频结构体减一个固定音频长度加上会调返回的音频长度
			  
              comm_head->version = COMM_VERSION;		//获取随机数
              
              comm_head->channel_id = audio_ch;				//通道号
			  
              comm_head->sign_code = NO_SEC_KEY;			//不加密
              
              AUDIO_FRAME *audio = (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];		//将音频结构体指向队列的数据
			  
              audio->frame_size = len;		//帧大小
              audio->channel = audio_ch;	//音频通道
              
              audio->ntimestamp = pts;  	//时间戳
              
              audio->ntimestamp = zx_LocalTime_ms();	//时间戳，重新赋值系统时间
              
              memcpy(audio->buf, data, len);			//将音频数据放入audio结构体数据中
              
              aqueue->frame_size = COMM_HEARD_LEN + comm_head->param_len; //队列节点的大小
			  
              aqueue->nUseFlag = ADDTOQUEUE;	//将使用队列做标记
			  
              result = write(info->audio_pipe[1], &aqueue, sizeof(aqueue));		//将队列节点的数据往管道里面写，即写音频数据
			  
            //  dzlog_info("【audio_size=%d write=%d audio_pipe=%d...... ok】", len, result, info->audio_pipe[1]);                      
            }
            else
              dzlog_error("QUEUE FULL......");
          }
        }  
        info->iAudioCallBackRunState = 0;
      }
}



void zx_hisi_video_push_stream(void)
{
	hal_video_register_stream_cb(hisi_video_push_stream_cb);
}


void zx_hisi_audio_push_stream(void)
{
	hal_audio_register_cb(hisi_audio_push_stream_cb,NULL);
}

void zx_hisi_alarm_cb(int num)  //num为信号参数
{  

	if(SCHEDULE_CONDITION == hisi_cam_data->floodlight_last_tigger || MANUAL_CONDITION == hisi_cam_data->floodlight_last_tigger)
	{
		dzlog_info("flood light tigger is schedule or manual.");
		return;
	}
	
	dzlog_info("alarm end flood light off");  
	
	int ret = zx_hisi_flood_light_off();

	if(ret != 0)
	{
		dzlog_error("close flood light error");
		return;
	}


    return;   
}

int zx_hisi_set_flood_bright()
{
	int ret = -1;
	int day_or_night = -1;

	day_or_night = zx_hisi_judge_day_or_night();

	if(day_or_night == -1)
	{
		dzlog_error("hisi judge day or night error.");
		return -1;
	}

	if(SCHEDULE_CONDITION == hisi_cam_data->floodlight_last_tigger || MANUAL_CONDITION == hisi_cam_data->floodlight_last_tigger)
	{
		dzlog_info("flood light tigger is schedule or manual.");
		return 0;
	}

	if( CUR_NIGHT == day_or_night )
	{
		//dzlog_info("【day now is night day hisi_cam_data->floodlight_last_tigger = %d】",hisi_cam_data->floodlight_last_tigger);
		
		if(PIR_TIGGER_CONDITION == hisi_cam_data->floodlight_last_tigger || INIT_CONDITION == hisi_cam_data->floodlight_last_tigger)
		{
			if(signal(SIGALRM , zx_hisi_alarm_cb) == SIG_ERR)  
			{  
				dzlog_error("register alarm fail");  
				return -1;  
			} 
			
			alarm(hisi_cam_data->pir_floodlight_tigger_time);		//定时三秒
			
			ret = zx_hisi_flood_light_on();

			if(ret != 0)
			{
				dzlog_error("open flood light error  %d",ret);
				return -1;
			}

			hisi_cam_data->floodlight_last_tigger = PIR_TIGGER_CONDITION;		//pir触发
		}
		
	}else{
		
//		dzlog_info("【now is During the day.】");
	}

	return 0;
}



void zx_hisi_cam_pir_detect_cb(int ch)
{
	
	int ret = -1;
	
	dzlog_info("【pir cb is ok ch : %d】",ch);

#if 1
	ret = zx_hisi_set_flood_bright();
	
	if(ret != 0)
	{
		dzlog_error("hisi alarm flood bright error");
		return;
	}
#endif

#if 0
	switch (ch)
	{
		case 0:
			dzlog_info("pir trigger left ok ch : %d",ch);		//pir的位置 0
			break;
		case 1:
			dzlog_info("pir trigger middle ok ch : %d",ch);		//pir的位置 1
			break;
		case 2:
			dzlog_info("pir trigger right ok ch : %d",ch);		//pir的位置 2
			break;
		default:
			dzlog_error("pir trigger error ch : %d",ch);
			break;
	}
#endif
	return;
}

void zx_hisi_cam_pir_detect_event(void)
{
	dzlog_info("【zx hisi pir detect cb running】");
	hal_pir_register_detect_cb(zx_hisi_cam_pir_detect_cb);
}


int zx_hisi_cam_enble_dev(void)
{
	int ret = -1;

	dzlog_info("hisi enble start");

	ret = hal_audio_vin_enable(HISI_DISABLE);		//mic关闭

	if(ret != 0)
	{
		dzlog_error("mic disable error : %d",ret);
		return ret;
	}

	hisi_cam_data->mic_state = OFF_STATE;
	
#if 1
	dzlog_info("mic disable ok");
#endif

#if 0
	ret = hal_pir_enable(HISI_LEFT_PIR,HISI_DISABLE);		//左pir关闭
	
	if(ret != 0)
	{
		dzlog_error("left pir disable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_LEFT_PIR] = OFF_STATE;
	
#if 1
	dzlog_info("left pir disable ok");
#endif

	ret = hal_pir_enable(HISI_MIDDLE_PIR,HISI_DISABLE);	//中pir关闭

	if(ret != 0)
	{
		dzlog_error("middle pir disable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_MIDDLE_PIR] = OFF_STATE;
	
#if 1
	dzlog_info("middle pir disable ok");
#endif

	ret = hal_pir_enable(HISI_RIGHT_PIR,HISI_DISABLE);	//右pir关闭
	
	if(ret != 0)
	{
		dzlog_error("right pir disable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_RIGHT_PIR] = OFF_STATE;
	
#if 1
	dzlog_info("right pir disable ok");
#endif
#endif
	ret = zx_hisi_set_pir_off();		//pir关闭			

	if(ret != 0)
	{
		dzlog_error(" pir disable error : %d",ret);
		return ret;
	}

	dzlog_info(" pir disable ok");

	ret = hal_video_osd_time(HISI_DISABLE);		//osd关闭

	if(ret != 0)
	{
		dzlog_error("video osd time disable error : %d",ret);
		return ret;
	}
	
	hisi_cam_data->osd_state = HISI_DISABLE;
	
#if 1
	dzlog_info("osd time disable ok");
#endif

#if 1
	ret = hal_ircut_ctrl(IRCUT_CTRL_ON);		//ircut打开
	
	if(ret != 0)
	{
		dzlog_error("ircut disable error : %d",ret);
		return ret;
	}

	hisi_cam_data->ircut_state = IRCUT_CTRL_ON;
	
#if 1
	dzlog_info("ircut disable ok");
#endif
#endif

	ret = hal_set_floodlight_bright(HISI_FLOOD_LIGHT_VALUE);		//打开floodlight灯

	if(ret != 0)
	{
		dzlog_error("set flood light error : %d",ret);
		return ret;
	}
	
#if 1
	dzlog_info("set flood light ok");
#endif

	hisi_cam_data->floodlight_value = HISI_FLOOD_LIGHT_VALUE;
	hisi_cam_data->floodlight_state = ON_STATE;
	hisi_cam_data->floodlight_last_tigger = MANUAL_CONDITION;

	zx_mgw_setTimer(1, 0);

	ret = hal_set_floodlight_bright(HISI_FLOOD_LIGHT_OFF);		//关闭floodlight灯

	if(ret != 0)
	{
		dzlog_error("close flood light error : %d",ret);
		return ret;
	}
	
#if 1 
	dzlog_info("close flood light ok");
#endif

	hisi_cam_data->floodlight_value = HISI_FLOOD_LIGHT_OFF;
	hisi_cam_data->floodlight_state = OFF_STATE;
	hisi_cam_data->floodlight_last_tigger = INIT_CONDITION;

	ret = hal_audio_vin_enable(HISI_ENABLE);		//mic使能

	if(ret != 0)
	{
		dzlog_error("mic enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->mic_state = HISI_ENABLE;

	dzlog_info("mic enable ok");

#if 0
	ret = hal_pir_enable(HISI_LEFT_PIR,HISI_ENABLE);		//左pir使能

	if(ret != 0)
	{
		dzlog_error("left pir enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_LEFT_PIR] = HISI_ENABLE;

	dzlog_info("left pir enable ok");

	ret = hal_pir_enable(HISI_MIDDLE_PIR,HISI_ENABLE);	//中间pir使能

	if(ret != 0)
	{
		dzlog_error("middle pir enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_MIDDLE_PIR] = HISI_ENABLE;

	dzlog_info("middle pir enable ok");

	ret = hal_pir_enable(HISI_RIGHT_PIR,HISI_ENABLE);		//右pir使能

	if(ret != 0)
	{
		dzlog_error("right pir enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->pir_sen_state[HISI_RIGHT_PIR] = HISI_ENABLE;
#endif

#if 1
	ret = zx_hisi_set_pir_on();						//PIR打开

	if(ret != 0)
	{
		dzlog_error(" pir enable error : %d",ret);
		return ret;
	}

	dzlog_info(" pir enable open");
#endif

	ret = hal_video_osd_time(HISI_ENABLE);	//设置osd时间

	if(ret != 0)
	{
		dzlog_error("video osd time enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->osd_state = HISI_ENABLE;

	dzlog_info("osd time enable ok");

#if 1
	ret = hal_ircut_ctrl(IRCUT_CTRL_OFF);	//ircut关闭
	if(ret != 0)
	{
		dzlog_error("ircut enable error : %d",ret);
		return ret;
	}

	hisi_cam_data->ircut_state = IRCUT_CTRL_OFF;

	hisi_cam_data->ircut_set_mode = HISI_IRLEDMODE_AUTO;

	dzlog_info("ircut enable ok");
#endif

	dzlog_info("hisi enble end");
	
	return 0;
}


int zx_hisi_set_camera_parameter(void)
{
	int ret = -1;
	FILE *fp = NULL;
	char ver_buf[HISI_VERSION_NAME_LEN] = {0};

	dzlog_info("hisi set video is start");

	ret = zx_hisi_cam_enble_dev();		//设置使能

	if(ret != 0)
	{
		dzlog_error("hisi enble dev error ret = %d",ret);
		return ret;
	}

	ret = zx_hisi_set_camera_senser_parameter(
		50,							//亮度			[0-100]
		50,							//对比度			[0-100]
		50,							//色度			[0-100]
		50,							//饱和度			[0-100]
		VIDEO_FLIP_NORMAL,			//视频角度  		[0:0°, 1:90°, 2:180°, 3:270° ]
		HISI_COLORFUL_MODE,			//图像色彩			[0:彩色,1:黑白]
		HAL_MD_HIGHT,				//移动侦测灵敏度
		RES_1080P,					//分辨率			[0:RES_VGA , 1:RES_720P , 2:RES_1080P]
		15,							//帧率
		15,							//I帧间隔
		FREQ_50HZ,					//电力线频率
		HISI_CAMERA_1080P_BITRATE,	//码率
		MODE_VBR					//码率模式			[0:VBR,1:CBR]
		);

	if(ret != 0)
	{
		dzlog_error("hisi set video parameter info is error ret : %d",ret);
		return ret;
	}
	dzlog_info("set video parameter is ok");

	ret = hal_audio_set_vout(HISI_SPEAKER_VOLUME);		//设置speaker音量

	if(ret != 0)
	{
		dzlog_error("hisi set speaker volume is error ret : %d",ret);
		return ret;
	}

	dzlog_info("set speaker volume ok");

	hisi_cam_data->speaker_volume = HISI_SPEAKER_VOLUME;

	ret = hal_audio_set_vin(HISI_MIC_VOLUME);		//设置mic声音

	if(ret != 0)
	{
		dzlog_error("hisi set mic volume is error ret : %d",ret);
		return ret;
	}

	hisi_cam_data->mic_volume = HISI_MIC_VOLUME;

	dzlog_info("set mic volume ok");

	ret = hal_set_wifi_sta_mode();		//设置wifi为sta模式

	if(ret != 0)
	{
		dzlog_error("hal set wifi sta mode error : %d",ret);
		return ret;
	}

#if 1
	dzlog_info("hal set wifi sta mode is ok");
#endif

	hisi_cam_wifi->wifi_mode = HISI_WIFI_STA_MODE;
	
#if 1
	ret = zx_hisi_set_pir_sensivity_value(PIR_SIX_LEVEL,PIR_SIX_LEVEL,PIR_SIX_LEVEL);	//设置PIR灵敏度
	
	if(ret != 0)
	{
		dzlog_error("hisi set pir sensivity is error ret : %d",ret);
		return ret;
	}

	dzlog_info("set pir sensivity ok");
#endif

#if 1
	ret = hal_set_keyhold_time(HISI_KEY_HOLDTIME_MS);		//设置按键时长

	if(ret != 0)
	{
		dzlog_error("hisi set press key time is error ret : %d",ret);
		return ret;
	}
	hisi_cam_data->key_holdtime_ms = HISI_KEY_HOLDTIME_MS;

	dzlog_info("set press key time ok");

	hisi_cam_data->pir_floodlight_tigger_time = HISI_FLOODLIGHT_ALARM_TIME;		//设置pir触发告警时间
#endif

#if 1
	ret = hal_led_SetFlashFreq(HAL_LED_TYPE_RED,HISI_RED_LED_FLASH_FREQ);	//设置红灯闪烁频率

	if(ret != 0)
	{
		dzlog_error("hisi set red flash freq is error ret : %d",ret);
		return ret;
	}
	hisi_cam_data->red_led_flash_freq = HISI_RED_LED_FLASH_FREQ;

	dzlog_info("set red flash freq ok");

	ret = hal_led_SetFlashFreq(HAL_LED_TYPE_WHITE,HISI_WHITE_LED_FLASH_FREQ);		//设置白灯闪烁频率

	if(ret != 0)
	{
		dzlog_error("hisi set red flash freq is error ret : %d",ret);
		return ret;
	}
	hisi_cam_data->white_led_flash_freq = HISI_WHITE_LED_FLASH_FREQ;

	dzlog_info("set white flash freq ok");	
#endif

	ret = zx_hisi_set_flood_light_value(HISI_FLOOD_LIGHT_VALUE);				//设置floodlight灯的亮度

	if(ret != 0)
	{
		dzlog_error("hisi set flood light value error %d",ret);
		return ret;
	}

	dzlog_info("set flood light bright ok");

#if 0
	ret = zx_hisi_set_device_sn(hisi_cam_data->dev_sn,DEVICE_SN_LEN);
	
	if(ret <= 0)
	{
		dzlog_error("set device sn fail.");
		return -1;
	}
#endif

	fp = fopen(SOFTWARE_VERSION_FILE,"w");

	if( !fp )
	{
		dzlog_error("fopen is error.");
		return -1;
	}

	sprintf(ver_buf,"%s%s",SOFTWARE_PREFIX,HISI_VER_NAME);

	//dzlog_info("ver_buf = %s",ver_buf);

	fwrite(ver_buf,1,strlen(ver_buf) ,fp);		//写版本号

	if(fp)
	{
		fclose(fp);
		fp = NULL;
	}

	dzlog_info("hisi set video is end");

	ret = zx_hisi_open_camera(HISI_CH0,CLIENT_P2P);				//打开摄像头

	if(ret != 0)
	{
		dzlog_error("open camera error.");
	}
	
	dzlog_info("open camera ok.");
	return ret;
}


void zx_hisi_floodlight_update_flash_dev_info(void)
{
	
	if(hisi_cam_wifi->wifi_ip)
	{
		memcpy(base_param->hub_info.hub_wlan_ip_addr,hisi_cam_wifi->wifi_ip,strlen(hisi_cam_wifi->wifi_ip));
		memcpy(base_param->dev_param[0].dev_ipaddr,hisi_cam_wifi->wifi_ip,strlen(hisi_cam_wifi->wifi_ip));
	}

	if(hisi_cam_wifi->wifi_mac)
		memcpy(base_param->dev_param[0].dev_mac,hisi_cam_wifi->wifi_mac,strlen(hisi_cam_wifi->wifi_mac));
	
	base_param->hub_info.wifi_channel = hisi_cam_wifi->wifi_channel;


	base_param->dev_param[0].dev_mic_volume = hisi_cam_data->mic_volume;
	base_param->dev_param[0].dev_mic_status = hisi_cam_data->mic_state;
	base_param->dev_param[0].dev_speaker_volume = hisi_cam_data->speaker_volume;
	
	base_param->dev_param[0].dev_pir_sensitivity = hisi_cam_data->pir_sen_value[HISI_MIDDLE_PIR];

	dzlog_info("hisi floodlight update flash dev info config start.");
	write_config_param(SET_DEV_PARAM);		//写flash
	dzlog_info("hisi floodlight update flash dev info config end.");

	return;
}


int zx_hisi_wifi_update_data(void)
{
	int ret = -1;
	char wifi_ssid[HISI_WIFI_DATA_LEN] = {0};
	char wifi_password[HISI_WIFI_DATA_LEN] = {0};
	char localip[HISI_WIFI_IP_LEN] = {0};
	char localmac[HISI_WIFI_MAC_LEN] = {0};
	
	dzlog_info("hisi wifi update data start.");
	
	ret = zx_hisi_get_wifi_localip(localip);

	if(ret != 0)
	{
		dzlog_error("hisi get wifi localip error.");
		return -1;
	}

	dzlog_info("hisi get wifi localip = %s",localip);

	ret = zx_hisi_get_wifi_mac(localmac);

	if(ret != 0)
	{
		dzlog_error("hisi get wifi localip error.");
		return -1;
	}

	dzlog_info("hisi get wifi localmac = %s",localmac);

	memset(hisi_cam_wifi->wifi_ip,0,sizeof(hisi_cam_wifi->wifi_ip));
	memset(hisi_cam_wifi->wifi_mac,0,sizeof(hisi_cam_wifi->wifi_mac));
	
	memcpy(hisi_cam_wifi->wifi_ip,localip,strlen(localip));
	memcpy(hisi_cam_wifi->wifi_mac,localmac,strlen(localmac));
	
	ret = zx_hisi_get_camera_wifi_data(hisi_cam_wifi);

	if(ret != 0)
	{
		dzlog_error("hisi get camera wifi data error");
		return -1;
	}

	//zx_hisi_camera_wifi_info_printf(hisi_cam_wifi);

	ret = zx_hisi_set_flash_ssid_and_password(hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password);

	if(ret != 0)
	{
		dzlog_error("hisi set flash ssid and password error");
		return -1;
	}

	dzlog_info("hisi set flash ssid and password ok.");

	ret = hisi_get_flash_ssid_and_password(wifi_ssid,wifi_password);		//获取flash里面的wifi名称和密码

	if(ret != 0)
	{
		dzlog_error("get flash ssid and password error.");
		return -1;
	}

	dzlog_info("【get flash data : [ssid:%s ----- password:%s]】",wifi_ssid,wifi_password);

	zx_hisi_floodlight_update_flash_dev_info();

	dzlog_info("hisi wifi update data end.");
	return 0;
}



int zx_hisi_wifi_list_send_app_data(char *send_data,int data_len)
{
	int ret = -1,ap_count = -1;
	char *s_json_param = NULL;
	cJSON *param_root_json = NULL;

	if(!send_data)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}

	dzlog_info("hisi wifi list send app data start.");

	if(hisi_cam_wifi->wifi_mode == HISI_WIFI_STA_MODE)
	{
		ap_count = zx_hisi_wifi_list_upgrade_insert(hisi_wifi_list);

		if(ap_count <= 0)
		{
			dzlog_error("hisi upgrade info list insert error");
			return -1;
		}

		param_root_json = zx_hisi_cjson_send_data();

		if(!param_root_json)
		{
			dzlog_error("hisi cjson send data error");
			goto END;
		}

		s_json_param = cJSON_PrintUnformatted(param_root_json);

		if(!s_json_param)
		{
			dzlog_error("cJSON_PrintUnformatted is error");
			goto END;
		}
		
#if HISI_LOG_SWITCH
		dzlog_info("s_json_param = %s",s_json_param);
#endif

		data_len = strlen(s_json_param);
		

		memcpy(send_data,s_json_param,strlen(s_json_param));

		dzlog_info("camera send_data = %s",send_data);
		
#if HISI_AUDIO_PLAY
		if(hal_audio_play_file("/etc/en/wifi_configuration_en.wav") != 0)		//配置wifi
		{
			dzlog_error("audio play file wifi configuration error");
			goto END;
		}

		dzlog_info("【---audio play wifi_configuration_en.wav ok---】");
#endif
		
	}
	else{

		dzlog_info("【wifi mode is AP mode .】");
		return -1;
	}

END:

	if(param_root_json)
	{
		cJSON_Delete(param_root_json);
		param_root_json = NULL;
	}

	if(s_json_param)
	{
		free(s_json_param);
		s_json_param = NULL;
	}
	
	dzlog_info("hisi wifi list send app data end.");
	return 0;

}



int zx_hisi_ota_callback(unsigned int state, 		     	/* ota状态 */
                           unsigned int err_code,   		/* 错误代码 */
                           long reserve)           			/* 保留 */

{
	dzlog_info("state %d ,err_code : %u , reserve : %ld",state,err_code,reserve);
	
	zx_mgw_setTimer(1,0);

	if(err_code == 0)
	{
		dzlog_info("update version OK, reboot.");
		zx_ota_system("reboot");
		
	}else{
		
		dzlog_error("ota update error : %u",err_code);
		return -1;
	}
	return 0;
}



int zx_hisi_ota_updata_version(char *file_path)
{
	int ret = -1;

	unsigned long file_len = 0;

	if(!file_path)
	{
		dzlog_error("The function parameter is NULL.");
		return -1;
	}

	dzlog_info("【ota update version start...】");
	
	hal_ota_register_cb(zx_hisi_ota_callback);			//升级回调函数

	file_len = get_file_size(file_path);			//获取文件大小

	if(file_len <= 0)
	{
		dzlog_error("get file size is error");
		return -1;
	}
	
	dzlog_info("get file size %lu",file_len);
	
	ret = hal_ota_update(file_path,file_len,0);			//开始升级

	if(ret != 0)
	{
		dzlog_error("ota update is error ret :%d",ret);
		return ret;
	}
	
	dzlog_info("【ota update version success...】");
	
	return 0;
}




void zx_hisi_send_packet (int fd)
{
  unsigned int data[12];
  int ret;
  struct timeval now;

#define LI 0			//协议头中的元素
#define VN 3
#define MODE 3
#define STRATUM 0
#define POLL 4
#define PREC -6
  if (sizeof (data) != 48)
    {
      printf ("data size error!\n");
      _exit (1);
    }
  memset ((char *) data, 0, sizeof (data));
  data[0] =
    htonl ((LI << 30) | (VN << 27) | (MODE << 24) | (STRATUM << 16) |
	   (POLL << 8) | (PREC & 0xff));
  data[1] = htonl (1 << 16);
  data[2] = htonl (1 << 16);
//int gettimeofday(struct timeval *tv, struct timezone *tz);
  gettimeofday (&now, NULL);
//data[6] = htonl(new.tv_sec + JAN_1970);
//data[7] = htonl(NTPFRAC(new.tv_usec)); 

  data[10] = htonl (now.tv_sec + HISI_JAN_1970);
  data[11] = htonl (NTPFRAC (now.tv_usec));

  ret = send (fd, data, 48, 0);
  printf ("send packet to ntp server, ret: %d\n", ret);
}

void zx_hisi_rfc1305print (unsigned int *data, HISI_NTP_TIME *firsttime, HISI_NTP_TIME *arrival, struct timeval *newtime)
{
  struct tm *ltm = NULL;
  int li, vn, mode, stratum, poll, prec, delay, disp, refid;
  HISI_NTP_TIME reftime, orgtime, rectime, xmttime;
  HISI_NTP_TIME diftime, delaytime;
  struct timeval;

  printf ("prepare to settime!\n");

#define Data(i) ntohl(((unsigned int *)data)[i])

  li = Data (0) >> 30 & 0x03;
  vn = Data (0) >> 27 & 0x07;
  mode = Data (0) >> 24 & 0x07;
  stratum = Data (0) >> 16 & 0xff;
  poll = Data (0) >> 8 & 0xff;
  prec = Data (0) & 0xff;
  
  if (prec & 0x80)
  {
    prec |= 0xffffff00;
  }
  
  delay = Data (1);
  disp = Data (2);
  refid = Data (3);
  reftime.coarse = Data (4);
  reftime.fine = Data (5);
  orgtime.coarse = Data (6);
  orgtime.fine = Data (7);
  rectime.coarse = Data (8);
  rectime.fine = Data (9);
  xmttime.coarse = Data (10);
  xmttime.fine = Data (11);
#undef Data

//Originate Timestamp       T1        time request sent by client
//Receive Timestamp         T2        time request received at server
//Transmit Timestamp        T3        time reply sent by server
//Destination Timestamp     T4        time reply received at clien
// d = (T2 - T1) + (T4 - T3); t = [(T2 - T1) + (T3 - T4)] / 2;
//=((newpack.recvtimestamphigh-firsttimestamp)+(newpack.trantimestamphigh-finaltimestamp))>>1;
  diftime.coarse =((int)((reftime.coarse - firsttime->coarse) + (xmttime.coarse - arrival->coarse))) / 2;

  delaytime.coarse =(int) ((reftime.coarse - firsttime->coarse) + (arrival->coarse - xmttime.coarse));
/*
printf("%d\n",reftime.coarse);
printf("%d\n",arrival->coarse);
printf("%d\n",xmttime.coarse);
printf("diftime:%d\n",(int)diftime.coarse);
printf("delay:%d\n",delaytime.coarse);
*/

//粗略校时
  newtime->tv_sec = xmttime.coarse - HISI_JAN_1970;
  newtime->tv_usec = HISI_USEC (xmttime.fine);
//精确校时
// newtime->tv_sec = arrival->coarse - JAN_1970 + diftime.coarse + delaytime.coarse;
// newtime->tv_usec = USEC (arrival->fine);


//need root user to fix
  if (getuid () != 0 && geteuid () != 0)
    {
      printf ("need root user!\n");
      _exit(1);
    }
  if (settimeofday (newtime, NULL) == -1)
    {
      printf ("settime error!\n");
      return;
    }
  else
      printf("set time successful!\n");
//struct tm  *ltm;
    ltm = localtime (&newtime->tv_sec);
  printf ("current local time: %.4d_%.2d_%.2d %.2d:%.2d:%.2d\n",
	  ltm->tm_year + 1900, ltm->tm_mon + 1, ltm->tm_mday, ltm->tm_hour,
	  ltm->tm_min, ltm->tm_sec);

}



int zx_hisi_ntp_time (int argc, char **argv)
{

  int sock;
  int ret;
  socklen_t svr_len = sizeof (struct sockaddr);
  int addr_len = sizeof (struct sockaddr_in);
  unsigned int buf[12];
  memset (buf, 0, sizeof (buf));
  struct timeval timeout;	//<sys/time.h>
  struct timeval newtime;
  struct timeval now;
//struct sockaddr_in
//  {
//      __SOCKADDR_COMMON (sin_);  #define      __SOCKADDR_COMMON(sa_prefix) 
//
//        sa_family_t sa_prefix##family    typedef unsigned short int sa_family_t;
//
//          in_port_t sin_port;                 Port number.  
//         struct in_addr sin_addr;              Internet address.  
//               Pad to size of `struct sockaddr'.  
//          unsigned char sin_zero[sizeof (struct sockaddr) -
//              __SOCKADDR_COMMON_SIZE -
//              sizeof (in_port_t) -
//             sizeof (struct in_addr)];
//                       }; 

  struct sockaddr_in addr_src;	//本地socket  <netinet/in.h>
  struct sockaddr_in addr_dst;	//服务器socket
  struct sockaddr server;
  HISI_NTP_TIME arrival_ntp;
  HISI_NTP_TIME firsttime;

// int socket(int domain, int type, int protocol);  <sys/socket.h> <sys/sype.h>
  sock = socket (PF_INET, SOCK_DGRAM, 0);
  if (sock == -1)
    {
      printf ("establish socket was failed ! \n");
      _exit (1);
    }
  else
    printf ("establish socket successful!\n");
  memset (&addr_src, 0, addr_len);
  addr_src.sin_family = AF_INET;
  addr_src.sin_port = htons (0);
  addr_src.sin_addr.s_addr = htonl (INADDR_ANY);	//<arpa/inet.h>
//int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
  if (-1 == bind (sock, (struct sockaddr *) &addr_src, addr_len))	//绑定本地地址
    {
      printf ("bind failed!\n");
      _exit (1);
    }
  else
    printf ("bind successful!\n");
  memset (&addr_dst, 0, addr_len);
  addr_dst.sin_family = AF_INET;
  addr_dst.sin_port = htons (HISI_NTP_PORT);
//  addr_dst.sin_addr.s_addr = inet_addr(NTP_SERVER);  

  {
//struct hostent
// { 　　
// char *h_name; 　
//　char **h_aliases;
//  int h_addrtype; 
//　int h_length; 
//　char **h_addr_list; 
//　};   

    struct hostent *host = gethostbyname (HISI_NTP_SERVER);	//<netdb.h>
    if (host == NULL)
    {
		printf ("get hostname is wrong!\n");
		_exit (1);
    }
    if (host->h_length != 4)
    {
		fprintf (stderr, "host->h_length is not 4!\n");
		_exit (1);
    }
    memcpy (&(addr_dst.sin_addr.s_addr), host->h_addr_list[0], 4);
  }
  addr_dst.sin_port = htons (HISI_NTP_PORT);
  printf ("Connecting to NTP_SERVER: %s ip: %s  port: %d...\n", HISI_NTP_SERVER,
	  inet_ntoa (addr_dst.sin_addr), HISI_NTP_PORT);
//int connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen);
  if (-1 == connect (sock, (struct sockaddr *) &addr_dst, addr_len))
  {
      printf ("connect is failed!\n");
      _exit (1);
  }
  else
    printf ("connect successful!\n");

  while (1)
  {
//struct timeval 
//{ 　
//　time_t tv_sec; /* seconds */ 　
//　suseconds_t tv_usec; /* microseconds */ 　　}; 
      	fd_set fds_read;
      	int len;
      	FD_ZERO (&fds_read);
     	FD_SET (sock, &fds_read);

      	timeout.tv_sec = 6;
     	 timeout.tv_usec = 0;
// int select(int nfds, fd_set *readfds, fd_set *writefds,
// fd_set *exceptfds, struct timeval *timeout);
      	ret = select (sock + 1, &fds_read, NULL, NULL, &timeout);
		if (ret == -1)
		{
			printf ("select was failed!\n");
			_exit (0);
		}
		printf("select = %d\n",ret);
		
		if (ret == 0 || !FD_ISSET (sock, &fds_read))
		{
		//向服务器发送数据
		//        gettimeofday(&now, NULL);
		//        firsttime.coarse = now.tv_sec + JAN_1970;
		//        firsttime.fine = NTPFRAC(now.tv_usec);
			zx_hisi_send_packet (sock);
			continue;
		}
      gettimeofday (&now, NULL);
      firsttime.coarse = now.tv_sec + HISI_JAN_1970;
      firsttime.fine = HISI_NTPFRAC (now.tv_usec);



//ssize_t recvfrom(int s, void *buf, size_t len, int flags,
//                struct sockaddr *from, socklen_t *fromlen);                        
      len = recvfrom (sock, buf, sizeof (buf), 0, &server, &svr_len);

		if (len == -1)
		{
			printf ("recvfrom was failed!\n");
			_exit (1);
		}
		
		if (len == 0)
		{
			continue;
		}

//取得本地时间

      gettimeofday (&now, NULL);
      arrival_ntp.coarse = now.tv_sec + HISI_JAN_1970;
      arrival_ntp.fine = HISI_NTPFRAC (now.tv_usec);

//校对时间
      zx_hisi_rfc1305print (buf, &firsttime, &arrival_ntp, &newtime);

    }

  close (sock);

  _exit (0);
}



