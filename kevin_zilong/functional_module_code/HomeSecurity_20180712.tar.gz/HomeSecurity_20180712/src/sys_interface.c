/*============================================================================
 Name        : sys_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-10-30 
 Description : 
 ============================================================================*/

#include <stdio.h>  
#include <sys/types.h>  
#include <sys/socket.h>
#include <sys/resource.h>  
#include <stdlib.h>
#include <string.h>  
#include <netinet/in.h>  
#include <netdb.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/sysinfo.h>
//#include "ralink_gpio.h"
//#include "debug.h"
#include <dirent.h> 


#include "comm_protocol_define.h"
#include "sys_interface.h"
#include "ppcs_interface.h"
//#include "nvram.h"
#include "circular_buffer.h"
#include "as_interface.h"
#include "ota_interface.h"
#include "cloud_storage_interface.h"
#include "hal.h"
#include "if.h"
#include "hal_wifi.h"
#include "mgw_interface.h"
#include "hisi_interface.h"
#include "floodlight_interface.h"



THREAD_INFO *gthread_info = NULL;
HUB_BASE_PARAM *gbase_param = NULL;
extern unsigned char grunning;
int gkey_index = 0;
extern HISI_CAMERA_WIFI_DATA *hisi_cam_wifi;

//#define IF_NAMESIZE 16

zx_Uint64 zx_Tm_LocalTime(void) 
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec;
} // zx_Tm_LocalTime


int get_current_channel(void)
{
#if 0
	int  skfd = -1;
	struct iwreq wrq;
	int channel = 0;
	struct iw_range range;

	// Create a channel to the NET kernel. 
	if((skfd = iw_sockets_open()) < 0)
	{
		dzlog_warn("fail to iw_sockets_open()");
		return -1;
	}

	if(iw_get_range_info(skfd, WIFI_DEVICE, &range) < 0)
	{
		dzlog_warn("%s  no frequency information.", WIFI_DEVICE );
		return -1;
	}

	// Get current frequency / channel and display it 
	if(iw_get_ext(skfd, WIFI_DEVICE, SIOCGIWFREQ, &wrq) >= 0)
	{
		channel = wrq.u.freq.m;
		dzlog_warn("channel:%d." , wrq.u.freq.m );
		
		// Close the socket. 
		iw_sockets_close(skfd);
		return channel;
	}
	else
	{
		dzlog_error("fail to get freq.");

		// Close the socket. 
		iw_sockets_close(skfd);
		return -1;
	}
	return -1;
#endif
	return 0;
}


int zx_eth_state_get(void)
{
	int fd = 0;
	int result = 0;
	int value = 0;
#if 0
	if ((fd = open(GPIO_DEV, O_RDWR)) < 0)
	{
		dzlog_error("Error while opening /dev/gpio");
		return -1;
	}

	result = ioctl(fd, RALINK_ETH_GET_STATE, &value);
	//dzlog_info("ethernet port 0 state is: %d", value);

	close(fd);
#endif

	return value;
}

int zx_hisi_wifi_state_get(char *ssid)
{

	int value = -1;
	int i = 0;
	char wifi_ssid[HISI_WIFI_DATA_LEN + 2] = {0};

	if(!ssid)
	{
		dzlog_error("wifi ssid is NULL");
		return -1;
	}

	memcpy(wifi_ssid,ssid,strlen(ssid));

	//dzlog_info("wifi ssid = %s",wifi_ssid);

	if( HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode )
	{
	WIFI_CHECK_AGAIN:
		value = hal_wifi_check_link(wifi_ssid);
		
		if(value < 2)
		{
			++i;
			
			if(i <= 1)
			{
				zx_mgw_setTimer(1,0);
				goto WIFI_CHECK_AGAIN;
			}
			
			if(value == 0)
			{
				dzlog_warn("hal wifi check link not connect");
			}
			else if(value == 1)
			{
				dzlog_warn("hal wifi check link is connecting");
				zx_mgw_setTimer(1,0);
				goto WIFI_CHECK_AGAIN;
			}
			else
				dzlog_error("hal wifi check link is error ret : %d",value);
		}
		//dzlog_info("hal wifi check link end value : %d",value);
	}
	else{
		
		dzlog_info("wifi mode is ap mode... ");
	}
	
	return value;
}



int get_wifi_info(WIFI_INFO *info)
{
	char *wifi_ssid = NULL;
	char *wifi_pwd = NULL;
	char mac[MAC_LEN_BYTE+1] = {0};
	if (info)
	{
		memset(info, 0, sizeof(WIFI_INFO));
		info->channel = get_current_channel();
		if (info->channel > 0)
		{
		#if 0
			if(get_wifi_mac(mac, MAC_LEN_BYTE) > 0)
			{
				memcpy(info->hub_wifi_mac, mac, MAC_LEN_BYTE);
				printf_hex(info->hub_wifi_mac, MAC_LEN_BYTE);
			#if 0	
				nvram_init(RT2860_NVRAM);
			
				wifi_ssid = nvram_bufget(RT2860_NVRAM, SSID);
				if (wifi_ssid)
				{
					memcpy(info->hub_wifi_ssid, wifi_ssid, strlen(wifi_ssid));
					dzlog_info("SSID=%s", info->hub_wifi_ssid);
					wifi_pwd = nvram_bufget( RT2860_NVRAM, WPAPSK);
					if (wifi_pwd)
					{
						memcpy(info->hub_wifi_pwd, wifi_pwd, strlen(wifi_pwd));
						dzlog_info("WIFI_PWD=%s", info->hub_wifi_pwd);
						return info->channel;
					}
				}
			#endif
			}
		#endif
		}
	
	}
	return -1;
}


static void *flash_write_thread(void *argv)
{
	//HUB_BASE_PARAM *base_param = (HUB_BASE_PARAM *)argv;
	dzlog_info("flash write thread is start");
	
	int msg_id = zx_get_msgid_by_type(PARAM_WRITE); 	//根据线程类型获取线程间通信的MSGID
	
	dzlog_info("get msgid by type is ok ,msg_id = %d",msg_id);
	
	ZX_PARAM_DATA param_data;
    int msgflg = 0; //阻塞式接收消息
    dzlog_info("flash_write_thread msgid = %d, PID=%d", msg_id, getpid());
    while (grunning)
    {  
        memset(&param_data, 0, sizeof(ZX_PARAM_DATA));        
        if(msgrcv(msg_id, (void*)&param_data, sizeof(ZX_PARAM_DATA), 0, msgflg) == -1)  
        {
            if (errno == ENOMSG)
            {
                if (msgflg == IPC_NOWAIT) 				// 队列读空,再write,减少擦写次数
                {
                    if (write_base_param(gbase_param) == -1)
                    {
                        dzlog_error("write_base_param Error!\n");
                        sleep(2);
                        write_base_param(gbase_param);   //重试一次
                    }
                }
                msgflg = 0;
            }
            else
            {
                dzlog_error("msgrcv failed with errno: %d", errno);
                break; // 退出线程
            }
        }
        else
        {
            dzlog_info("param_type: %d ", param_data.param_type);
            msgflg = IPC_NOWAIT;
        }
    }
    if(msgctl(msg_id, IPC_RMID, 0) == -1)
    {  
        dzlog_error("msgctl(IPC_RMID) failed");  
    } 
    dzlog_info("exit...... "); 
    return 0;
}


int write_config_param(int param_type)
{
	dzlog_info("write config param is start");
	int ret = -1;	
	
	int msg_id = zx_get_msgid_by_type(PARAM_WRITE);  //获取消息队列的句柄
	
	if (msg_id >= 0)
	{
		
		dzlog_info("write config param is:%d ",msg_id);
		ZX_PARAM_DATA send_data; 
		
		memset(&send_data, 0, sizeof(ZX_PARAM_DATA));
		
		send_data.msg_type = PARAM_WRITE;
		send_data.param_type = param_type;

		dzlog_info("write config param is end");
		
		if(msgsnd(msg_id, (void*)&send_data, sizeof(ZX_PARAM_DATA) , 0) == -1)  //往消息队列写数据
        {  
         	dzlog_info("【...msgsnd failed...】");  
       	} 
		else
		{
			dzlog_info("【msgsnd success】");
			ret = 0;
		}
	}
	dzlog_info("write config param is end");
	return 0;
}


int zx_init_sys_interface(THREAD_INFO *thread_info, HUB_BASE_PARAM *base_param)
{
	unsigned char i = 0;
	gthread_info = thread_info;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		gthread_info[i].msg_id = -1;	
		gthread_info[i].thread_id = -1;
	}
	gbase_param = base_param;
	zx_create_thread(LOW_PRIORITY, flash_write_thread, gbase_param, -1, PARAM_WRITE, -1);
	return 0;
}

int zx_set_thread_info(int channel, int thread_type, pthread_t thread_id, int session_handle)
{
	int ret = -1;
	unsigned char i = 0;
	//int key_index = 0;
	key_t index_get;
	int msgid = -1;
	//QUEUE * queue = NULL;

	if (thread_type >= PUSH_INFO)
	{
		gkey_index++;
		index_get = ftok(".", gkey_index);		//IPC 键值 成功返回key_t的key值，失败返回-1
		msgid = msgget(index_get, 0666 | IPC_CREAT);  //建立消息队列，成功返回消息队列的ID，失败返回-1
		//dzlog_info("index: %d msgid=%d key_index=%d" , index_get, msgid, gkey_index);  
		if(msgid == -1)
		{
			dzlog_error("msgget failed with error: %d" , errno);
			return -1;
		}
	}
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		//dzlog_info("thread_type: %d msgid=%d thread_id=%d", gthread_info[i].thread_type, gthread_info[i].msg_index, gthread_info[i].thread_id);  
		if (gthread_info[i].msg_id == -1 && gthread_info[i].thread_id == -1) // 
		{
			gthread_info[i].msg_index = gkey_index;
			gthread_info[i].thread_id = thread_id;
			gthread_info[i].msg_id = msgid;
			gthread_info[i].thread_type = thread_type;
			//gthread_info[i].channel = channel;
			gthread_info[i].session_handle = session_handle;
			ret = msgid;
			//dzlog_info("thread_type: %d msgid=%d thread_id=%d session=%d" , thread_type, msgid, thread_id, gthread_info[i].session_handle);  
			break;
		}
	}
	return ret;
}


THREAD_INFO *zx_get_thread_list(void)
{
	return gthread_info;
}

#if 0
//根据会话ID更新该会话的所有线程的通道
int zx_update_channel_by_session(int session_handle, int channel)
{	
	int i = 0, ret = -1;	
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].session_handle == session_handle)
		{
			gthread_info[i].channel = channel;
			ret = 0;
		}
	}
	return ret;
}
#endif

//对于支持线程间通信的线程，根据进程间通信的MSGID获取线程ID
int zx_update_tid_by_msgid(int msgid, int tid)
{	
	unsigned char i = 0;
	int ret = -1;	
	//dzlog_info("msgid=%d tid=%d" , msgid, tid);
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].msg_id == msgid)
		{
			gthread_info[i].thread_id = tid;
			ret = 0;
		}
	}
	return ret;
}


//对于不支持线程间通信的线程，根据线程类型获取线程ID
int zx_get_tid_by_type(int type, int tid)
{	
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].thread_type == type)
		{
			return gthread_info[i].thread_id;
		}
	}
	return -1;
}

//对于根据线程类会话和线程类型获取消息ID 用于P2P线程的获取MSGid
int zx_get_msgid_by_session_type(int session, int thread_type)
{	
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].thread_type == thread_type && gthread_info[i].session_handle == session)
		{
			return gthread_info[i].msg_id;
		}
	}
	return -1;
}

#if 0
//当P2P有多个连接时，用该接口根据摄像头通道获取P2P的会话列表，摄像头根据会话分发数据给相应APP
int zx_get_session_handle_by_channel(int channel, int *session_list, int *session_num)
{
	int i = 0;
	int count = 0;	
	if (session_list)
	{
		for (i = 0; i < MAX_THREAD_COUNT; i++)
		{
			if (gthread_info[i].channel == channel)
			{
				if (count < MAX_CONNECT_NUM)
					session_list[count] = gthread_info[i].session_handle;
				count++;
			}
		}
		*session_num = count;
	}
	return 0;
}
#endif

//根据线程类型获取线程间通信的MSGID
int zx_get_msgid_by_type(int type)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].thread_type == type)	//判断线程类型
		{
			dzlog_info("get_msgid_by_type is ok");
			return gthread_info[i].msg_id;
		}
	}
	return -1;
}


//根据MSGID清除线程信息
int zx_clear_thread_info_by_msgid(int msgid)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].msg_id == msgid)
		{
			gthread_info[i].msg_id = -1;
			gthread_info[i].session_handle = -1;
			gthread_info[i].msg_index = -1;
			gthread_info[i].thread_id = -1;
			gthread_info[i].thread_type = -1;
			//gthread_info[i].channel = -1;			
			return 0;
		}
	}
	return -1;
}

int zx_clear_thread_info_by_sessionid(int session_id)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].session_handle == session_id)
		{
			gthread_info[i].msg_id = -1;
			gthread_info[i].session_handle = -1;
			gthread_info[i].msg_index = -1;
			gthread_info[i].thread_id = -1;
			gthread_info[i].thread_type = -1;
			//gthread_info[i].channel = -1;
			return 0;
		}
	}
	return -1;
}

int zx_clear_thread_info_by_type(int type)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		if (gthread_info[i].thread_type == type)
		{
			gthread_info[i].msg_id = -1;
			gthread_info[i].session_handle = -1;
			gthread_info[i].msg_index = -1;
			gthread_info[i].thread_id = -1;
			gthread_info[i].thread_type = -1;
			//gthread_info[i].channel = -1;
			return 0;
		}
	}
	return -1;
}


int zx_update_dev_version(char *main_sw_version, char *sec_sw_version, char *hw_version, int channel)
{
	unsigned char i = 0;
	int str_len = 0;
	if (main_sw_version == NULL || sec_sw_version == NULL || hw_version == NULL|| channel < 0)
		return ERROR_NULL_POINT;
	//dzlog_info("enter addr_code=%d",  shortadd);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gbase_param->dev_param[i].channle_id == channel)
		{	
			str_len = strlen(main_sw_version);	
			memcpy(gbase_param->dev_param[i].dev_software_main_ver, main_sw_version, str_len > SMALL_STR_LEN ? SMALL_STR_LEN : str_len);
			str_len = strlen(hw_version);	
			memcpy(gbase_param->dev_param[i].dev_hardware_main_ver, hw_version, str_len > SMALL_STR_LEN ? SMALL_STR_LEN : str_len);
			str_len = strlen(sec_sw_version);	
			memcpy(gbase_param->dev_param[i].dev_software_sec_ver, sec_sw_version, str_len > SMALL_STR_LEN ? SMALL_STR_LEN : str_len);
			write_config_param(SET_DEV_PARAM);	
			dzlog_info("devsn=%s hubsn=%s account_id=%s main_sw=%s sec_sw=%s", gbase_param->dev_param[i].dev_sn, gbase_param->hub_info.hub_sn, gbase_param->hub_info.account_id, main_sw_version, sec_sw_version);
			zx_update_devs_version(gbase_param->dev_param[i].dev_sn, gbase_param->hub_info.hub_sn, gbase_param->hub_info.account_id, main_sw_version, sec_sw_version,hw_version );		
			return 0;
		}
	}
	return 0;
}

#if 0
void *zx_get_queue_by_session_type(int session)
{
	int i = 0;	
	for (i = 0; i < MAX_THREAD_COUNT; i++)
	{
		dzlog_info("queue=0x%X session=%d in=%d", gthread_info[i].data_queue, gthread_info[i].session_handle, session);
		if (gthread_info[i].session_handle == session)
		{
			dzlog_info("session=%d queue=0x%X", session, gthread_info[i].data_queue);
			return gthread_info[i].data_queue;
		}
	}
	return NULL;
}
#endif

//根据通道、线程类型、会话ID、优先级创建线程
int zx_create_thread(int priority, void *(*function)(void*), void *arg, int channel, int thread_type, int session_handle)
{
	int err,inher;//,policy;
    pthread_t tid = 0;
    pthread_attr_t attr;
        
    pthread_attr_init(&attr);
    pthread_attr_getinheritsched(&attr, &inher);

//    if(inher != PTHREAD_EXPLICIT_SCHED)
//        dzlog_info("PTHREAD_EXPLICIT_SCHED");
//    else 

#if 0
	struct sched_param param;
	if(inher == PTHREAD_INHERIT_SCHED)
	{
        //dzlog_info("PTHREAD_INHERIT_SCHED");
        inher = PTHREAD_EXPLICIT_SCHED;
    }
	pthread_attr_setinheritsched(&attr, inher);
    
	policy = SCHED_FIFO;  //SCHED_RR
    pthread_attr_setschedpolicy(&attr, policy);

	pthread_attr_getschedparam(&attr, &param);
    param.sched_priority = priority;
    pthread_attr_setschedparam(&attr, &param);

#if 0
	int pri = sched_get_priority_max(policy);
    dzlog_info("max_priority = %d", pri);
    pri = sched_get_priority_min(policy);
    dzlog_info("min_priority = %d", pri);
#endif  
	
#endif
	//pthread_attr_setstacksize(&attr, THREAD_STACK_SIZE);
	//dzlog_info("priority = %d", param.__sched_priority);
    if (thread_type >= PUSH_INFO)
    {
        int imsgid = zx_set_thread_info(channel, thread_type, tid, session_handle); // 先取到 imsgid, 再启线程
        err = pthread_create(&tid, &attr, function, arg);
        if (err != 0)
        {
            dzlog_info("can't create thread: %s" , strerror(err));
        }
        else
        {
            if (imsgid >= 0)
            {
                zx_update_tid_by_msgid(imsgid, tid);
            }
            pthread_detach(tid);
        }
    }
	else
	{
		err = pthread_create(&tid, &attr, function, arg);
		if (err != 0)
		{
			dzlog_info("can't create thread: %s" , strerror(err));
		}
		else
		{
			//zx_set_thread_info(channel, thread_type, tid, session_handle);
			pthread_detach(tid);
		}
	}

	pthread_attr_destroy(&attr);	
	return tid;
}

int zx_thread_exit(int thread_id)
{
	return 0;
}


int write_base_param(HUB_BASE_PARAM *param)
{
	dzlog_info("enter....");
#if 0
	return ocean_flash_write_info((char *)param, sizeof(HUB_BASE_PARAM));
#endif

	return zx_hisi_camera_flash_write_dev_info((char *)param, sizeof(HUB_BASE_PARAM));		
}


int read_base_param(HUB_BASE_PARAM *param)
{
	int param_len = 0;
#if 0
	return ocean_flash_read_info((char *)param, sizeof(HUB_BASE_PARAM));
#endif

	return zx_hisi_camera_flash_read_dev_info((char *)param, sizeof(HUB_BASE_PARAM));
}

int clean_base_param(void)
{
	dzlog_info("enter....");
	
	memset(gbase_param, 0xFF, sizeof(HUB_BASE_PARAM));
#if 0
	return ocean_flash_write_info(gbase_param, sizeof(HUB_BASE_PARAM));
#endif

	return zx_hisi_camera_flash_write_dev_info(gbase_param, sizeof(HUB_BASE_PARAM));		
}

/*
Confusingly, the offset in the TZ value specifies the time value you must add to the local time to get a UTC value,
so this is positive if the local time zone is west of the Prime Meridian and negative if it is east. As a result, TZ
must be set to GMT-8 for a timezone that is GMT+8.
*/
int zx_set_timetone(char *timetone)
{
	if (timetone)
	{
		int index = 0;
		dzlog_info("input timetone %s", timetone);
		if (strlen(timetone) > SMALL_STR_LEN)
			return -1;

		char buf[SMALL_STR_LEN];
		char tmp[SMALL_STR_LEN];
		memset(buf, 0, sizeof(buf));
		memset(tmp, 0, sizeof(buf));
		strcpy(tmp, timetone);

		if (strncmp(tmp,"GMT", 3) == 0)
		{
			char *p = strchr(tmp, ':'); // GMT+8:00
			if (p)
			{
				*p = 0;	// 截断
				if (tmp[3] == '+')	// TZ的值同APP相反
				{
					tmp[3] = '-';
				}
				else if (tmp[3] == '-')
				{
					tmp[3] = '+';
				}
			}
			sprintf(buf, "TZ=%s", tmp);
		}
		else
		{
			sprintf(buf, "TZ=%s", tmp);
		}

		//dzlog_info("env timetone %s", buf);
		if (putenv(buf) == -1)
		{
	  		dzlog_error("putenv failed.");
			return -1;
		}
    	tzset();
		//dzlog_info("daylight = %d", daylight );
   		//dzlog_info("timezone = %ld", timezone );
   		//dzlog_info("tzname[0] = %s", tzname[0] );
	#if 0
		index = getNvramIndex("2860");	
		if( index  == -1 )
		{
			dzlog_error("getNvramIndex failed.");
			return -2;
		}
		char *ptz = nvram_bufget(index, "TZ");
		
		if (strcmp(ptz,tmp) != 0)
		{
			dzlog_info("nvram old TZ(%s)->new TZ(%s)",ptz, tmp);
			nvram_set(index, "TZ", tmp);

			FILE *fp = fopen("/etc/TZ", "wb");
			if (fp != NULL)
			{
				fwrite(tmp, 1, strlen(tmp), fp);
				tmp[0] = '\n';	// 要加换行符才可能识别
				fwrite(tmp, 1, 1, fp);
				fclose(fp);
			}
		}
#endif
		FILE *fp = fopen("/etc/TZ", "wb");
		if (fp != NULL)
		{
			fwrite(tmp, 1, strlen(tmp), fp);
			tmp[0] = '\n';	// 要加换行符才可能识别
			fwrite(tmp, 1, 1, fp);
			fclose(fp);
		}

		return 0;
	}
	return ERROR_NULL_POINT;
}


char *zx_get_hub_ipaddr(char *ifname)
{
#if 1
	struct ifreq ifr;
	int skfd = 0;
	static char if_addr[16];

	if((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
	{
		dzlog_error("open socket error");
		return "";
	}

	strncpy(ifr.ifr_name, ifname, IF_NAMESIZE);
	if (ioctl(skfd, SIOCGIFADDR, &ifr) < 0) 
	{
		close(skfd);
		dzlog_error("ioctl SIOCGIFADDR error for %s", ifname);
		return "";
	}
	strcpy(if_addr, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
	close(skfd);

	return if_addr;
#endif
}


void zx_do_system(char *fmt, ...)
{
	va_list ap;
	char cmd[LONG_STR_LEN] = {0};
	va_start(ap, fmt);
	vsprintf(cmd, fmt, ap);
	dzlog_info("cmd = %s", cmd);
	va_end(ap);
	system(cmd);
	return;
}

int zx_get_program_version(void)
{
	return PROGRAM_VER;
}



int zx_get_system_soft_version(char *version) 
{
	FILE *fp = NULL;
	char *lp = NULL;
	char readBuffer[NORMAL_STR_LEN] = { 0 };

	if(!version)
	{
		dzlog_error("version == NULL.");
		return ERROR_NULL_POINT;
	}

	fp = fopen(SOFTWARE_VERSION_FILE, "r");		

	if (!fp)	
	{
		dzlog_error("open file:%s fail.", SOFTWARE_VERSION_FILE);
		return ERROR_OPEN_FILE_FAIL;
	}

	while(!feof(fp))
	{
		memset(readBuffer, 0, NORMAL_STR_LEN);
		fgets(readBuffer, NORMAL_STR_LEN, fp);
		//dzlog_info("read data:%s.", readBuffer );

		if(lp = strstr(readBuffer, SOFTWARE_PREFIX))
		{
			//dzlog_info("get software version");
			lp += strlen(SOFTWARE_PREFIX);
			//dzlog_info("【VER:%s】", lp);
			strncpy(version, lp, SMALL_STR_LEN);
			int len = strlen(version);
			if ( len > 0 )
				version[len-1] = 0x00;
			fclose(fp);
			return 0;
		}
/*
		if(strchr(readBuffer, '-') && strchr(readBuffer, ':') )
		{
			strncpy( lpData->u_data.ver.compile_time, readBuffer, COMPILE_TIME_LEN );
			continue;			
		}
*/
	}
	fclose(fp);
	return 0;
}

int zx_create_dir(const char *path)
{
    int i,len;
    char DirName[128];
    if (path)
    {
        if( access(path, 0) == 0 )  //存在了
        {
            return 0;
        }
        memset(DirName, 0, 128);
        len = strlen(path);
        if (len > 128)
        {
            return -1;
        }
        strcpy(DirName, path);
        if(DirName[len-1] != '/')
        {
            strcat(DirName, "/");
        }

        len = strlen(DirName);
        for( i=1; i<len; i++ )
        {
            if( DirName[i] == '/' )
            {
                DirName[i] = '\0';
                if( access(DirName, 0) != 0 )
                {
                    if (mkdir( DirName, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH ) == -1)
                    {
                        //dzlog_error("cat't mkdir %s, %s", DirName, strerror(errno));
                        return -1;
                    }
                    dzlog_info("mkdir %s", DirName);
                }
                DirName[i] = '/';
            }
        }
        return 0;
    }

    return ERROR_NULL_POINT;
}


int zx_send_ota_msg(const char *file_path)
{
	MSG_WIFI_ROUTER_UPGRADE_INFO msg;
	long index_get = ftok("/tmp/", MSG_ID_UPGRADE_7628 );	
	long msgid = msgget( index_get, 0666 | IPC_CREAT );   // |IPC_EXCL : if create fail. error occort. 
	
	dzlog_info("index_get:%d, index: (0x%08X)h = %ld msgid=%ld." , index_get, MSG_ID_UPGRADE_7628, MSG_ID_UPGRADE_7628, msgid);	  
	if( -1  == msgid ) 
	{  
		dzlog_error("msgget failed with error:%s ( %d )", strerror( errno ), errno);  
		return 0;  
	}
		
	memset(&msg, 0, sizeof(MSG_WIFI_ROUTER_UPGRADE_INFO));	
	// set magic number
	strncpy( msg.magic_num, MSG_MAGIC_NUM, MSG_UPGRADE_MAGIC_NUM_LEN_MAX );	
	// set image file full path
	strncpy( msg.image_path, file_path, MSG_UPGRADE_FILE_PATH_LEN_MAX);	
	
	// set file size
	//msg.file_size = get_file_size( MSG_IMAGE_FULL_PATH );	
	msg.file_size = get_file_size( file_path );	
	
	dzlog_info("get ota file:%s, file size:%ld.", file_path, msg.file_size );
	
	if(msgsnd(msgid, (void*)&msg, sizeof(MSG_WIFI_ROUTER_UPGRADE_INFO) , 0) == -1)  
    {  
        dzlog_error("msgsnd failed");  
        return 0;
    } 
	
	dzlog_info("success!");
	return 1;	
}


int zx_hub_ota_process(void *version, const char *new_ver, const char *cur_ver)
{
	if (new_ver && cur_ver && version && strlen(cur_ver) > 0)
	{
		VERSION_UPGRADE *tmp_version = (VERSION_UPGRADE *)version;
		int ret = -1;
		struct sysinfo info;
		
		dzlog_error("new_ver[%d]=%s cur_ver[%d]=%s", strlen(new_ver), new_ver, strlen(cur_ver), cur_ver);
		//if(strcmp(new_ver, cur_ver) != 0)
		if(strcmp(new_ver, cur_ver) > 0) // yuxw modify it for not upgrade if my version not equ server version.2018-04-28
		{
			char save_path[NORMAL_STR_LEN] = {0};
			//FILE *fd = fopen(VERSION_TF_PATH, "r");   //判断TF卡是否存在
			
			FILE *fd = fopen(SD_DEV_EXIST_FILE, "r");   //判断TF卡是否存在
			
			if (fd)
				memcpy(save_path, VERSION_TF_PATH, strlen(VERSION_TF_PATH));
			else
			{	
				//dzlog_error("****** file [%s] open error******", VERSION_TF_PATH);
				dzlog_error("****** file [%s] open error******", SD_DEV_EXIST_FILE );

				sysinfo(&info);

				if(info.freeram <= tmp_version->file_size)
				{
					dzlog_error("system free not enough");
					return -1;
				}

				dzlog_info("system speace = %ld",info.freeram);
				
				fd = fopen(VERSION_PATH, "r"); 	//没有TF卡就存储到tmp
				if (fd)
					memcpy(save_path, VERSION_PATH, strlen(VERSION_PATH));	
			}
			if (fd)  
			{  
				fclose(fd);
				
                #if 0
                if (gbase_param->hub_info.have_bind_app == 0)
                {
                    ai_play_wav(0, "/etc_ro/upgrade_new_sw.wav");
                }
                #endif
				
				dzlog_info("upgrade version down : %s",save_path);
				
				zx_do_system("rm %s/%s", save_path, FLOODLIGHT_VER_NAME);
				
		    	ret = zx_dnload_upgrade_version(save_path, tmp_version, FLOODLIGHT_VER_NAME);
				if(ret != 0)
				{
                    dzlog_error("****** zx_dnload_upgrade_version is error******");
					
                    #if 0
                    if (gbase_param->hub_info.have_bind_app == 0)
                    {
                        ai_play_wav(0, "/etc_ro/upgrade_fail.wav");
                    }
                    #endif
					
                    return -1;
				}

				char file_path[NORMAL_STR_LEN] = {0};
				sprintf(file_path, "%s/%s", save_path, FLOODLIGHT_VER_NAME);
				sync();
				zx_hub_update_info_by_infoname(gbase_param->hub_info.hub_sn, gbase_param->hub_info.account_id, "main_sw_version", new_ver);
                gbase_param->hub_info.update_status = 1;
				//zx_send_ota_msg(file_path);

				dzlog_info("【ota updata file_path = %s】",file_path);

				if((zx_hisi_ota_updata_version(file_path)) != 0)
				{
					dzlog_error("hisi ota update verdion error");
					return -1;
				}

                #if 0 // 系统重启后播放升级成功
                FILE *fp = fopen("/mnt/upgrade_new_sw.txt", "wb");
                
                if( fp )
                {
                    fwrite("1", 1, 1, fp);
                    fclose(fp);
                }else
                {
					dzlog_error("fail to open file:/mnt/upgrade_new_sw.txt. for system upgrade.");
				}
                #endif
				
			}
			else
			{
				dzlog_error("****** file [%s] open error******", VERSION_PATH);
				return -1;
			}	
			
		   	return 0; 
		}  		
	}
	return ERROR_NULL_POINT;
}


int zx_check_process_runing(const char *process_name)
{
	int pid_num = 0;
	char cmd_buf[NORMAL_STR_LEN] = {0};
	sprintf(cmd_buf, "%s%s%s", "ps -e | grep \"", process_name, "\" | wc -l");
    dzlog_info("%s", cmd_buf);
	FILE *fp = popen(cmd_buf, "r");
	if (fp)
	{
    	char buffer[SMALL_STR_LEN] = {0};
    	fgets(buffer, SMALL_STR_LEN, fp); 
    	pclose(fp); 
		pid_num = atoi(buffer);
		//dzlog_info("cmd_buf=%s pid num:%d", cmd_buf, pid_num);	
	}
	return pid_num;
}


char zx_reg_gpio_int(int gpio_num)
{
#if 0
	int fd = -1;
	int gpio_bit = 0;
	ralink_gpio_reg_info info;
	
	info.pid = getpid();
	info.irq = gpio_num;	
	dzlog_info("gpio_num=%d", gpio_num);
	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) 
	{
		dzlog_error("open %s fali!", GPIO_DEV);
		return -1;
	}
		
	if(gpio_num <= 31)
	{
		ioctl(fd, RALINK_GPIO_SET_DIR_IN, (0x1 << gpio_num));
	}
	else if(gpio_num > 31 && gpio_num <= 63)
	{
		gpio_bit = 0x1 << ( gpio_num - 32);
		ioctl(fd, RALINK_GPIO6332_SET_DIR_IN, gpio_bit);
	}
	else if( gpio_num > 63 && gpio_num <= 95 )
	{
		gpio_bit 	= 0x1 <<  ( gpio_num - 64 );
		ioctl(fd, RALINK_GPIO9564_SET_DIR_IN, gpio_bit);
	}
	
	//enable gpio interrupt
	if (ioctl(fd, RALINK_GPIO_ENABLE_INTP) < 0)
		goto ioctl_err;

	//register my information
	if (ioctl(fd, RALINK_GPIO_REG_IRQ, &info) < 0)
		goto ioctl_err;
	
	close(fd);
	
	return 0;

ioctl_err:
	dzlog_error("***ioctl error***");
	close(fd);
#endif

	return -1;	
}


int zx_write_pid_file(void)
{
	FILE *fp_pid = NULL;
	fp_pid = fopen(HOME_SEC_PID_PATH, "wb");
	if(fp_pid == NULL)
	{
		dzlog_error("open %s fail!", HOME_SEC_PID_PATH);
		return -1;
	}
	char c_pid[SMALL_STR_LEN] = {0};
	sprintf(c_pid, "%d", getpid());
	dzlog_info("pid=%s", c_pid);
	fwrite(c_pid, 1, strlen(c_pid), fp_pid);	
	fclose(fp_pid);
	return 0;
}

void zx_set_stack_limits(unsigned int limits)  
{  
    struct rlimit limit;   
    if(getrlimit(RLIMIT_STACK, &limit) < 0)  
        dzlog_error("getrlimit error %d", errno);  
	else
	{
		//dzlog_info("cur=%10ld max=%10ld", limit.rlim_cur, limit.rlim_max);
		limit.rlim_cur = limits;
		if(setrlimit(RLIMIT_STACK, &limit) < 0)
			dzlog_error("setrlimit error %d", errno);
		else
		{
			if(getrlimit(RLIMIT_STACK, &limit) < 0)  
        		dzlog_error("getrlimit error %d", errno); 
			else
				dzlog_info("cur=%10ld max=%10ld", limit.rlim_cur, limit.rlim_max);
		}
	}
     
}  

char zx_gpio_dir( int gpio_num, GPIO_DIR dir )
{
	int fd,   gpio_pin 	= 0;
#if 0
	if ((fd = open(GPIO_DEV, O_RDWR)) < 0)
	{
		dzlog_error("Error while opening /dev/gpio\n");
		return -1;
	}

	if( GPIO_DIR_IN == dir )
	{
		if(  gpio_num <= 31 )
		{
			ioctl(fd, RALINK_GPIO_SET_DIR_IN, ( 0x1 << gpio_num ) );
		}else if( gpio_num > 31 && gpio_num <= 63 )
		{
			gpio_pin 	=  0x1 << ( gpio_num - 32 );
			ioctl(fd, RALINK_GPIO6332_SET_DIR_IN, ( gpio_pin ) );
		}else if( gpio_num > 63 && gpio_num <= 95 )
		{
			gpio_pin 	= 0x1 << ( gpio_num - 64 );
			ioctl(fd, RALINK_GPIO9564_SET_DIR_IN, (  gpio_pin ) );
		}
	}
    else
	{
		if(  gpio_num <= 31 )
		{
			ioctl(fd, RALINK_GPIO_SET_DIR_OUT, 0x1 << gpio_num );
		}else if( gpio_num > 31 && gpio_num <= 63 )
		{
			gpio_pin 	= 0x1 << ( gpio_num - 32 );
			dzlog_info( "gpio_pin = 0x%08X\r\n", gpio_pin );
			ioctl(fd, RALINK_GPIO6332_SET_DIR_OUT, ( gpio_pin ) );
		}else if( gpio_num > 63 && gpio_num <= 95 )
		{
			gpio_pin 	= 0x1 << ( gpio_num - 64 );
			ioctl(fd, RALINK_GPIO9564_SET_DIR_OUT, (  gpio_pin ) );
		}		
	}
	close(fd);
#endif
	return 0;
}

char zx_gpio_set_value( int gpio_num, int set_value )
{
	int fd = 0;

#if 0
	if ((fd = open(GPIO_DEV, O_RDWR)) < 0)
	{
		dzlog_error("Error while opening /dev/gpio\n");
		return -1;
	}

	if( set_value )
	{
		if( gpio_num <= 31  )
		{
			ioctl(fd, RALINK_GPIO_SET, gpio_num );
		}
		else if( gpio_num > 31 && gpio_num <= 63 )
		{
			ioctl(fd, RALINK_GPIO6332_SET, gpio_num );
		}else if( gpio_num > 63 && gpio_num <= 95 )
		{
			ioctl(fd, RALINK_GPIO9564_SET, gpio_num );
		}
		
	}
    else
	{
 		if( gpio_num <= 31  )
		{
			ioctl(fd, RALINK_GPIO_CLEAR, gpio_num);
		}
		else if( gpio_num > 31 && gpio_num <= 63 )
		{
			ioctl(fd, RALINK_GPIO6332_CLEAR, gpio_num );
		}else if( gpio_num > 63 && gpio_num <= 95 )
		{
			ioctl(fd, RALINK_GPIO9564_CLEAR, gpio_num );
		}		
	}
	close(fd);
#endif

	return 0;
}

/***************************************************************************************************
*
*  return value:
*   -1 : fail
*  0 or 1: get value.  1: heigh level
*                      0: low level
****************************************************************************************************/
char zx_gpio_get_value( int gpio_num )
{
	int value = 0;
	char ret = 0;
	int fd = 0;
#if 0
	if ((fd = open(GPIO_DEV, O_RDWR)) < 0)
	{
		dzlog_error("Error while opening /dev/gpio\n");
		return -1;
	}

	if( gpio_num <= 31  )
	{
		ioctl(fd, RALINK_GPIO_READ, &value);
		dzlog_info("Pin %d is %d\n", gpio_num, (value & ( 0x01 << gpio_num ) ) ? 1:0);
		ret = (value & ( 0x01 << gpio_num ) ) ? 1:0 ;
	}
    else if( gpio_num > 31 && gpio_num <= 63 )
	{
		ioctl(fd, RALINK_GPIO6332_READ, &value);
		dzlog_info("Pin %d is %d\n", gpio_num, (value & (0x01<< (gpio_num - 32 ) )) ? 1:0);
		ret = (value & (0x01<< (gpio_num - 32 ) )) ? 1:0 ;
	}
	else if( gpio_num > 63 && gpio_num <= 95 )
	{
		ioctl(fd, RALINK_GPIO9564_READ, &value);
		dzlog_info("Pin %d is %d\n", gpio_num, (value & (0x01<< (gpio_num - 64 ) )) ? 1:0);
		ret = (value & (0x01<< (gpio_num - 64 ) )) ? 1:0 ;
	}
	
	close(fd);
#endif

	return ret ;	
}

//版本格式 *.*.*
int zx_ver_cmp(const char *new_ver, const char *cur_ver)
{
    int i,len, inew_ver,icur_ver;
    char ver_str[12];

    if (new_ver == NULL || cur_ver == NULL)
    {
        return -1;
    }

    len = strlen(new_ver);
    if (len > 12)
    {
        return -1;
    }
    memset(ver_str, 0, 12);
    strcpy(ver_str, new_ver);
    len = strlen(ver_str);
    for( i=0; i<len; i++ )
    {
        if( ver_str[i] == '.' )
        {
            ver_str[i] = '0';
        }
    }
    inew_ver = atoi(ver_str);

    len = strlen(cur_ver);
    if (len > 12)
    {
        return -1;
    }
    memset(ver_str, 0, 12);
    strcpy(ver_str, cur_ver);
    len = strlen(ver_str);
    for( i=0; i<len; i++ )
    {
        if( ver_str[i] == '.' )
        {
            ver_str[i] = '0';
        }
    }
    icur_ver = atoi(ver_str);

    //dzlog_info("inew_ver:%d, icur_ver:%d", inew_ver, icur_ver);
    if (inew_ver == icur_ver)
    {
        return 0;
    }
    else if (inew_ver > icur_ver)
    {
        return 1;
    }
    else
    {
        return -1;
    }
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/  
int zx_check_new_log(const char *log_key, char *outfile)
{
    char cmd_buf[64] = {0};
    sprintf(cmd_buf, "%s%s%s", "ls ", log_key, " | head -n 1");
    dzlog_info("%s", cmd_buf);
    FILE *fp = popen(cmd_buf, "r");
    if (fp)
    {
        memset(outfile, 0, FILENAMEMAX);
        fgets(outfile, FILENAMEMAX, fp);
        pclose(fp);
        int ilen = strlen(outfile);        
        //printf_hex(outfile, ilen);
        if ( ilen > 6)
        {
            if (outfile[ilen-1] < 0x20)
            {
                outfile[ilen-1] = 0;
            }
            ilen = strlen(outfile);
            dzlog_info("log: %s", outfile);
            return ilen;
        }
    }
    return -1;
}

/********************************************************
    funcname:
    Description: 把log文件压缩
    intput:
    output:
********************************************************/
int compressed_log_for_s3( char * filepath )
{
    int ret = -1;

    FILE *fp_src = fopen(filepath, "r"); // 以只读方式打开文件
    if(fp_src == NULL)
    {
        dzlog_error("open file %s failed", filepath);
        goto exit_save_log;
    }
    
    FILE *fp_dest = fopen(LOG_FILE, "w"); // 以只写方式打开或新建一个文件
    if(fp_dest == NULL)
    {
        dzlog_error("open file %s failed", filepath);
        goto exit_save_log;
    }

    char *pdata = (char *)malloc(5000+1);
    if (pdata == NULL)
    {
        goto exit_save_log;
    }

    fseek(fp_src, -20000, SEEK_END); //回退20K
    int readnum = fread(pdata, 1, 5000, fp_src);
    fwrite(pdata, 1, readnum, fp_dest);

    remove(LOG_FILE_BZ2);
    zx_do_system("%s%s", "bzip2 ", LOG_FILE);
    
exit_save_log:
    if (fp_src)
    {
        fclose(fp_src);
        fp_src = NULL;
    }
    if (fp_dest)
    {
        fclose(fp_dest);
        fp_dest = NULL;
    }
    if (pdata)
    {
        free(pdata);
        pdata = NULL;
    }

    return ret;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/    
void zx_upload_test_log(ZX_LOG_PARAM * log)
{
    char filepath[FILENAMEMAX+1];
    char *pdevtype;
    char *keyword;

    switch(log->devtype)
    {
		 case FLOODLIGHT:
            pdevtype = "FLOODLIGHT",
            keyword = "/mnt/sdcard/sec*.log";
            break;
			
        case XM_CAMERA:
            pdevtype = "XM CAMERA",
            keyword = "/mnt/sdcard/sec*.log";
            break;
            
        case DOOR_SENSOR:
            pdevtype = "DOOR SENSOR",
            keyword = "/mnt/sdcard/sec*.log";
            break;

        case SUB1G_MODULE:
            pdevtype = "SUB1G MODULE",
            keyword = "/mnt/sdcard/collector*.log";
            break;

        case AI_MODULE:
            pdevtype = "AI MODULE",
            keyword = "/mnt/sdcard/ai*.log";
            break;    

        case PUSHMUXER:
            pdevtype = "pushMuxer",
            keyword = "/mnt/sdcard/pushMuxer*.log";
            break;

        default:
            pdevtype = "Unknow",
            keyword = "/mnt/sdcard/*.log";
            break;
    }

    memset(filepath, 0, sizeof(filepath));    
    if (zx_check_new_log(keyword, filepath) != -1)
    {
        // 这里加上文件压缩
        compressed_log_for_s3(filepath);
        
        char * log_url = zx_putdata_aws_s3(gbase_param->hub_info.account_id, LOG_FILE_BZ2,
                                           gbase_param->hub_info.hub_sn, STATION_ABNORMAL);
        if (log_url)
        {
            zx_upload_hub_log(gbase_param->hub_info.account_id,
                              gbase_param->hub_info.hub_sn,
                              gbase_param->hub_info.hub_software_main_ver,
                              log->sn, log->level, log->module, log_url, log->key_prefix, log->err_str, pdevtype);
            free(log_url);
        }
    }
}

/********************************************************
 funcname:
 Description:
 intput:
 output:
********************************************************/    
void zx_upload_crash_log(const char* path_file, ZX_LOG_PARAM * log)
{
    char newlog_path[FILENAMEMAX+1];
    
    memset(newlog_path, 0, sizeof(newlog_path));    
    if (zx_check_new_log(path_file, newlog_path) != -1)
    {
        // 这里加上文件压缩
        zx_do_system("%s%s", "bzip2 ", newlog_path);

        strcat(newlog_path, ".bz2"); // bzip2压缩后的文件名
        char * log_url = zx_putdata_aws_s3(gbase_param->hub_info.account_id, newlog_path,
                                           gbase_param->hub_info.hub_sn, STATION_ABNORMAL);
        if (log_url)
        {
            zx_Error err;
            err.code = -1;
            if (log->msg_type == HUB_CRASH)
            {
                err = zx_upload_hub_log(gbase_param->hub_info.account_id,
                                        gbase_param->hub_info.hub_sn,
                                        gbase_param->hub_info.hub_software_main_ver,
                                        "", log->level, log->module, log_url, "",log->err_str, "Hub");
            }
            else if (log->msg_type == AI_CRASH)
            {
                err = zx_upload_hub_log(gbase_param->hub_info.account_id,
                                        gbase_param->hub_info.hub_sn,
                                        gbase_param->hub_info.hub_software_main_ver,
                                        "", log->level, log->module, log_url, "",log->err_str, "AI");
            }
            free(log_url);
            if (err.code == 0)
            {
                remove(newlog_path); // 删除压缩文件
            }
        }
    }
}

void *log_upload_thread(void *argv)
{
    int msg_id = zx_get_msgid_by_type(LOG_UPLOAD); 
    ZX_LOG_PARAM log_param;
    dzlog_info("log_upload_thread msgid = %d, PID=%d", msg_id, getpid());
    while (grunning)
    {
        memset(&log_param, 0, sizeof(ZX_LOG_PARAM));
        if(msgrcv(msg_id, (void*)&log_param, sizeof(ZX_LOG_PARAM), 0, 0) == -1)  
        {
            dzlog_error("msgrcv failed with errno: %d\n", errno);
            break;
        }
        else
        {            
            switch(log_param.msg_type)
            {
                case HUB_CRASH:
                {
                    //zx_upload_crash_log("/media/mmcblk0p1/CoreDump/core*", &log_param);
					zx_upload_crash_log("/mnt/sdcard/CoreDump/core*", &log_param);
                }
                break;
                case AI_CRASH:
                {
                    //zx_upload_crash_log("/media/mmcblk0p1/ai_crash.dump*", &log_param);
					zx_upload_crash_log("/mnt/sdcard/ai_crash.dump*", &log_param);
                }
                break;
                case LOG_NORMAL:
                {
                    zx_upload_test_log(&log_param);
                }
                break;
					 
                default:
                {
                    dzlog_info("log_type: %d ", log_param.msg_type);
                }
                break;
            }
        }
    }
    if(msgctl(msg_id, IPC_RMID, 0) == -1)
    {  
        dzlog_error("msgctl(IPC_RMID) failed");  
    } 
    dzlog_info("exit...... "); 

    return 0;
}

int upload_log_param(int log_type, int devtype,
                         const char* sn,
                         const char* level,
                         const char* module,
                         const char* key_prefix,
                         const char* err_str)
{
    int ret = -1;

    int msg_id = zx_get_msgid_by_type(LOG_UPLOAD);
    dzlog_info("upload_log.msg_id = %d", msg_id); 
    if (msg_id >= 0)
    {
        ZX_LOG_PARAM send_data; 
        memset(&send_data, 0, sizeof(ZX_LOG_PARAM));
        send_data.msg_type = log_type;
        send_data.devtype = devtype;
        send_data.sn = sn;
        send_data.level = level;
        send_data.module = module;
        send_data.key_prefix = key_prefix;
        send_data.err_str = err_str;
        if(msgsnd(msg_id, (void*)&send_data, sizeof(ZX_LOG_PARAM), 0) == -1)  
        {
            dzlog_error("msgsnd failed: %d\n", errno);
        } 
        else
        {
            ret = 0;
        }
    }
    return ret;
}

