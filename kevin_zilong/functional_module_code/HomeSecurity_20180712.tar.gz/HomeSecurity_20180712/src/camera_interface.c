/*
 ============================================================================
 Name        : sub1g_interface.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-28 
 Description :
 ============================================================================
 */

#include "compiler.h"
#include "ini_file.h"       /* This reads our ini file */
#include "log.h"            /* Our logging scheme */
#include "timer.h"
#include "fatal.h"
#include "stream.h"
#include "stream_socket.h"  /* We use a socket in our app */
#include "appsrv.pb-c.h"
#include "threads.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "camera_interface.h"
#include "comm_protocol_define.h"
#include "push_interface.h"
#include "PPCS/PPCS_Error.h"
#include "sys_interface.h"
#include "ppcs_interface.h"
#include "as_interface.h"
#include "ota_interface.h"


//DEV_BASE_PARAM *gdev_base_param = NULL;
P2P_CONNECT_INFO *hisi_con_list = NULL;
HUB_BASE_PARAM *hisi_gdev_base_param = NULL;
unsigned int hisi_msgid = -1;
int hisi_gsession_id = -1;
int hisi_pipe[2] = {-1};
extern int grunning;
extern short gbopen_p2p;



#if 0
AppclientDeviceDescriptor * zx_hisi_get_dev_descriptor_by_channel(unsigned int channel)
{
	int i = 0;
	//dzlog_info("enter addr_code=%d",  channel);
	for (i = 0; i < MAX_HISI_CONNECT; i++)
	{
		if (hisi_gdev_base_param->dev_param[i].channle_id == channel)
		{		
			//dzlog_info("short_addr=%d channel=%d",  hisi_gdev_base_param->dev_param[i].sub1g_info.shortaddress, hisi_gdev_base_param->dev_param[i].channle_id);	
			//return &hisi_gdev_base_param->dev_param[i].sub1g_info;	
			
		}
	}
	return NULL;
}



int zx_hisi_send_command(int command_type, int channel, int value, int value1)
{
	#if 1
	dzlog_info("enter channel=%d...... ", channel);
	
	ZX_COMMUNICATION_PACKET send_data;
	
	AppclientDeviceDescriptor * dest_dev_info = NULL;
	
	memset(&send_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
	
	send_data.msg_head.head_tag = PAG_HEARD_TAG;

	//获取设备描述
	dest_dev_info = zx_hisi_get_dev_descriptor_by_channel(channel);	
	
	if (dest_dev_info)
	{
		if (dest_dev_info->shortaddress > 0)
		{
			send_data.msg_head.command_id = command_type; 
			
			/*++ yuxw add for wifi connect. */
			if( SUB1G_CMD_WAKEUP == command_type )
			{
				system("iwpriv ra0 set DisConnectAllSta=1"); // yuxw add for debug. test only.2018-03-30
			}
			/*-- yuxw add for wifi connect. */
			 
			switch (command_type)  
			{
				case SUB1G_CMD_SLEEP:                   //基站请求设备休眠
				case SUB1G_CMD_CHECK_STATUS:            //检查设备是否在线
				case SUB1G_CMD_OPEN_PIR:                //打开PIR
				case SUB1G_CMD_CLOSE_PIR:               //关闭PIR
				case SUB1G_CMD_OPEN_GSENSOR:            //打开GSENSOR
				case SUB1G_CMD_CLOSE_GSENSOR:           //关闭GSENSOR
				case SUB1G_CMD_GET_VOLTAGE:             //获取电池电量
				case SUB1G_CMD_GET_RSSI:                //获取SUB1G信号强度
				case SUB1G_CMD_OPEN_AUDIO_DEC:          //打开音频侦测
				case SUB1G_CMD_CLOSE_AUDIO_DEC:         //关闭音频侦测
				case SUB1G_CMD_OPEN_LIGHT_DEC:          //打开光感
				case SUB1G_CMD_CLOSE_LIGHT_DEC:         //关闭光感
				case SUB1G_CMD_AUDIO_LOOPTEST:          //麦克、喇叭回环测试
				case SUB1G_CMD_OPEN_WIFI:               //打开WIFI
				case SUB1G_CMD_CLOSE_WIFI:              //关闭WIFI
				{
					send_data.msg_head.param_len = 0; 
					send_data.msg_head.dev_type = 0x01;
					//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD));	
					
					dzlog_info("%s [%d] shortaddress=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress);
					
					if (command_type == SUB1G_CMD_SLEEP)
					{
						//清摄像头的标志
						int ret = clear_camera_clientmark(channel, value);
						
						if (ret == 0) // 投票可以关闭
						{
							//appclient 发送数据
							appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD));
						}
                        else
                        {
                            dzlog_info("this camera %d is busy, can't close!", channel);
                            return ERROR_DEV_BUSY;
                        }
					}
					else
					{
						//appclient 发送数据
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD));
					}
					
					return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
				}
				break;

				case SUB1G_CMD_WAKEUP:                  //基站唤醒设备
				case SUB1G_CMD_SET_PIR_SENSITIVITY:     //设置PIR灵密度
				case SUB1G_CMD_SET_GSENSOR_SENSITIVITY: //设置GSENSOR灵密度
				case SUB1G_CMD_OPER_IRCUT:              //操作IRCUT
				case SUB1G_CMD_OPEN_LED:                 //打开指示灯
				case SUB1G_CMD_CLOSE_LED:                //关闭指示灯
				case SUB1G_CMD_SWITCH_SERIAL:           //USB口切换3518串口		
				case SUB1G_CMD_SET_IRLED_POWER:         //设置红外灯亮度		
					{
						SUB1G_DEV_CONTROL *sub1g_dev_ctl = &send_data.param_body.sub1g_dev_ctl;
						send_data.msg_head.param_len = sizeof(SUB1G_DEV_CONTROL); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_dev_ctl->value = value;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;

				case SUB1G_CMD_SET_LIGHT_SENSITIVITY:    //设置光感灵敏度
					{
						SUB1G_LIGHT_SENSITIVITY *sub1g_light_ctl = &send_data.param_body.light_sensitivity;
						send_data.msg_head.param_len = sizeof(SUB1G_LIGHT_SENSITIVITY); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_light_ctl->value = value;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;

				case SUB1G_CMD_UPDATE_WIFI_INFO:        //基站更新设备wifi信息
					break;

				case SUB1G_CMD_DISASSOC_DEV:
					appclient_SendDisassocDevReq(dest_dev_info);
					dzlog_info("%s [%d] shortaddress=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress);	
					return 0;//zx_sub1g_wait_res(gsub1g_pipe[0]);					

				case SUB1G_CMD_GET_DEV_COUNT:
					appclient_GetDeviceNum();					
					return 0;

				case SUB1G_CMD_WIFI_TXTEST:              //WIFI发射功率测试
				case SUB1G_CMD_WIFI_RXTEST:              //WIFI接收灵敏度测试
					{
						SUB1G_DEV_WIFI_CONTROL *sub1g_dev_ctl = &send_data.param_body.wifi_ctl;
						send_data.msg_head.param_len = sizeof(SUB1G_DEV_WIFI_CONTROL); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_dev_ctl->channel = value;
						sub1g_dev_ctl->type = value1;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_WIFI_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;
				

				default:
					break;
			}         
		}
	}
	return ERROR_DEV_OFFLINE;
	#endif
}
#endif


