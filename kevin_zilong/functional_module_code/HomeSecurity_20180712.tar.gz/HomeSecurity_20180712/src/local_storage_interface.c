/*============================================================================
 Name        : local_storage_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-12-05
 Description : PIR: Passive Infrared 被动红外
 ============================================================================*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/select.h>
#include <errno.h>

#include "base.h"
#include "comm_protocol_define.h"
#include "sys_interface.h"
#include "local_storage_interface.h"
#include "as_interface.h"
#include "circular_buffer.h"
#include "hisi_interface.h"
#include "ppcs_interface.h"
#include "cloud_storage_interface.h"
#include "push_interface.h"
#include "PPCS/PPCS_Error.h"
//#include "ai_interface.h"
//#include "sub1g_interface.h"
#include "enc_decrypt_interface.h"
#include "hisi_interface.h"
#include "floodlight_interface.h"


#if RUN_AI_MODULE
AI_FRAME_ST   ai_frame = {0};
extern int recv_frame_No;
extern int algo_id;
extern int ai_clientfd;
extern int body_face_num;
extern int ai_checkface;

//extern AI_FACE_FEATURE bs_face_feature[FACE_NUM_MAX];

extern int get_jpg_feature;
#endif

LOCAL_FP_INFO local_fp_list[MAX_CAMERA_NUM];
static struct filelist *local_file_list_head = NULL; // 用文件链表来记录收藏的文件和生成顺序
static struct filelist *local_file_list_tail = NULL; // 已收藏文件不能自动删除, 10000个文件730K

static struct resend_filelist *resend_list_head = NULL;
static struct resend_filelist *resend_list_tail = NULL;

static unsigned int pri_channel = 0;     // 保存当前触发的PRI
static RSA*  local_rsa_pubkey = NULL;    // RSA加密公钥;

PLAYCTRL_ST playctrl_info[MAX_CONNECT_NUM];
int h264_download = 0;  // H264 文件正在下载标记

extern unsigned char grunning;
extern HUB_BASE_PARAM *base_param;
extern unsigned int tfcard_free_mb;
extern QUEUE* xm_video_queue;
//extern int ai_module_update;
extern int gdev_bind_type;
extern unsigned char gsystem_init;

extern HISI_CAMERA_INFO_DATA * hisi_cam_data;

extern HISI_CAMERA_WIFI_DATA *hisi_cam_wifi;

extern int zx_maxint(int a, int b);
extern int zx_video_callback(char *buff, int size, int stream_type, int frame_type, int frame_rate,
                             int width, int height, long long ntimestamp, int channel, long reserve);
extern int zx_audio_callback(char *buff, int size, long long ntimestamp, int channel, long reserve);
extern int connect_video_server(void);
static void * pir_schedule_thread(void *argv);
extern int *  zx_get_p2p_session_handle(int session_id);

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
void sleepus(unsigned long uSec)
{
    struct timeval tv;
    tv.tv_sec=0;
    tv.tv_usec=uSec;
    int err;
    do{
        err=select(0,NULL,NULL,NULL,&tv);
    }while(err<0 && errno==EINTR);
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
const char ascii_str[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz<!#?$>"; // 68
char *rand_str(char *str, const int len)
{
    int i;
    srand((unsigned int)time(NULL));
    for(i=0; i<len; i++)
    {
        str[i] = ascii_str[ rand() % (sizeof(ascii_str)-1)];
    }
    str[len] = '\0';
    dzlog_info("rand_str: %s", str);
    return str;
}

/********************************************************
    funcname:
    Description:  将指定元素插入到链表尾部
    intput:
            node : 表示要插入到链表中的元素
    output:
********************************************************/
static void resend_filelist_add(struct resend_filelist *node)
{
    if (node)
    {
        node->next = NULL;
        /* 判断链表是否为空 */
        if(NULL == resend_list_tail)
        {
            resend_list_tail = node;
            resend_list_tail->next = NULL;
            resend_list_head = resend_list_tail;
        }
        else
        {
            resend_list_tail->next = node;
            resend_list_tail = node;
            resend_list_tail->next = NULL;
        }
    }
}

/********************************************************
    funcname:
    Description:  将指定元素从链表尾部删除
    intput:
            pfilename : 要删除的文件，全路径
    output:
            0-成功，-1-失败
********************************************************/
int resend_filelist_del(void)
{
    struct resend_filelist *temp = NULL;
    int ret = -1;

    if(NULL == resend_list_head)
    {
        dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        temp = resend_list_head;
        resend_list_head = resend_list_head->next;
        temp->next = NULL;

        if (temp->resend.thumbnail)
        {
            free(temp->resend.thumbnail);  // 释放缩略图内存
            temp->resend.thumbnail = NULL;
        }
        free(temp);
        ret = 0;
    }

    return ret;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int free_all_resend_filelist(void)
{
    struct resend_filelist *temp = NULL;

    if(NULL == resend_list_head)
    {
        //dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        while(resend_list_head->next)
        {
            temp = resend_list_head;
            resend_list_head = resend_list_head->next;
            temp->next = NULL;
            free(temp);
        }
        free(resend_list_head);
        resend_list_head = NULL;
    }
    return 0;
}

/********************************************************
    funcname:
    Description:  将指定元素插入到链表尾部
    intput:
            node : 表示要插入到链表中的元素
    output:
********************************************************/
static void file_list_add(struct filelist *node)
{
    /* 判断链表是否为空 */
    if(NULL == local_file_list_tail)
    {
        local_file_list_tail = node;
        local_file_list_tail->next = NULL;
        local_file_list_head = local_file_list_tail;
    }
    else
    {
        local_file_list_tail->next = node;
        local_file_list_tail = node;
        local_file_list_tail->next = NULL;
    }
}

/********************************************************
    funcname:
    Description:  将指定元素从链表尾部删除
    intput:
            pfilename : 要删除的文件，全路径
    output:
            0-成功，-1-失败
********************************************************/
int file_list_del(char *pfilename)
{
    struct filelist *temp = NULL;
    struct filelist *p = NULL;
    int ret = -1;
    if (pfilename == NULL)
    {
        return -1;
    }

    dzlog_info("input del local file: %s\n", pfilename);
    remove(pfilename);

    if(NULL == local_file_list_head)
    {
        dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        temp = local_file_list_head;
        // 判断匹配的元素是否为链表头部的元素
        if(strcmp(pfilename, temp->info.filename) == 0) // 相等
        {
            dzlog_info("del local file: %s\n", pfilename);
            local_file_list_head = local_file_list_head->next;
            temp->next = NULL;
            free(temp);
            ret = 0;
        }
        else
        {
            while(temp->next)
            {
                p = temp;
                temp = temp->next;
                if(strcmp(pfilename, temp->info.filename) == 0)
                {
                    dzlog_info("del local file: %s\n", pfilename);
                    p->next = temp->next;
                    temp->next = NULL;
                    free(temp);
                    ret= 0;
                    break;
                }
            }
        }
    }

    if (ret == 0)   //保存新文件表
    {
        save_all_link_to_flash();
    }
    return ret;
}

/********************************************************
    funcname:
    Description:  删除多个文件
    intput:
    output:
            0-成功，-1-失败
********************************************************/
int batch_del_files(REC_BATCH_DEL     *pdel)
{
    struct filelist *temp = NULL;
    struct filelist *p = NULL;
    int ret = -1;
    int i = 0;
    char *pfilename = NULL;

    if(NULL == local_file_list_head || pdel == NULL)
    {
        dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        for (i=0; i<pdel->record_count; i++)  //循环删除
        {
            pfilename = pdel->record_list[i].file_path;
			
            if (pfilename)
            {
                remove(pfilename);
                dzlog_info("del local file: %s\n", pfilename);

                temp = local_file_list_head;
                if (temp == NULL)
                {
                    continue;
                }
                // 判断匹配的元素是否为链表头部的元素
                if(strcmp(pfilename, temp->info.filename) == 0)
                {
                    local_file_list_head = local_file_list_head->next;
                    free(temp);
                    ret = 0;
                }
                else
                {
                    while(temp->next)
                    {
                        p = temp;
                        temp = temp->next;
                        if(strcmp(pfilename, temp->info.filename) == 0)
                        {
                            p->next = temp->next;
                            temp->next = NULL;
                            free(temp);
                            ret= 0;
                            break;
                        }
                    }
                }
            }
        }
    }

    if (ret == 0)   //保存新文件表
    {
        save_all_link_to_flash();
    }
    return ret;
}

/********************************************************
    funcname:
    Description:  查找文件的framenum
    intput:
            pfilename :
    output:
            0-成功，-1-失败
********************************************************/
int get_file_framenum(char *pfilename)
{
    struct filelist *temp = NULL;

    int framenum = 0;

    dzlog_info("input del local file: %s\n", pfilename);

    temp = local_file_list_head;
    while(temp)
    {
        if(strcmp(pfilename, temp->info.filename) == 0)
        {
            framenum = temp->info.frame_num;
            break;
        }
        temp = temp->next;
    }

    return framenum;
}

/********************************************************
    funcname:
    Description:  更新收藏标记
    intput:
            pfilename :
    output:
            0-成功，-1-失败
********************************************************/
int update_file_favorite(char *pfilename, int favorite)
{
    struct filelist *temp = NULL;
    int ret = ERROR_OPEN_FILE_FAIL;

    temp = local_file_list_head;
    while(temp)
    {
        if(strcmp(pfilename, temp->info.filename) == 0)
        {
            temp->info.flag = favorite;
            ret = 0;
            break;
        }
        temp = temp->next;
    }
    if (ret == 0)
    {
        dzlog_info("update favorite file: %s to %d", pfilename, favorite);
        save_all_link_to_flash();
    }
    return ret;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int remove_old_file_note(void)
{
    struct filelist *temp = NULL;
    struct filelist *p = NULL;
    int ret = 0;

    if(NULL == local_file_list_head)
    {
        //dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        temp = local_file_list_head;
        // 判断匹配的元素是否为链表头部的元素
        if(temp->info.flag == 0) // 不是收藏
        {
            remove(temp->info.filename);
            local_file_list_head = local_file_list_head->next;
            ret = 1;
        }
        else
        {
            while(temp->next)
            {
                p = temp;
                temp = temp->next;
                if(temp->info.flag == 0)
                {
                    remove(temp->info.filename);
                    p->next = temp->next;
                    ret = 1;
                    break;
                }
            }
        }
    }

    if (ret == 1)
    {
        save_all_link_to_flash();
        dzlog_info("rm local file: %s\n", temp->info.filename);
        zx_delete_hub_history_record_by_file(base_param->hub_info.account_id,
                                             base_param->hub_info.hub_sn,
                                             temp->info.filename);
        free(temp); // 释放这个note
    }

    return ret;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int free_all_link_node(void)
{
    struct filelist *temp = NULL;

    if(NULL == local_file_list_head)
    {
        //dzlog_error("local_file_list_head is NULL");
        return -1;
    }
    else
    {
        while(local_file_list_head->next)
        {
            temp = local_file_list_head;
            local_file_list_head = local_file_list_head->next;
            temp->next = NULL;
            free(temp);
        }
        free(local_file_list_head);
        local_file_list_head = NULL;
    }
    return 0;
}

/********************************************************
    funcname:
    Description: 把所用链表节点存入flash
    intput:
    output:
********************************************************/
int save_all_link_to_flash( void )
{
    FILE *fp;
    struct filelist *node;

    fp = fopen(LOCAL_LINK_FILE, "wb"); // 以只写方式打开或新建一个二进制文件
    if(fp == NULL)
    {
        dzlog_error("open file %s failed", LOCAL_LINK_FILE);
        return -1;
    }

    node = local_file_list_head;
	
    while (node)
    {
        fwrite((char *)&node->info, 1, sizeof(struct filenode), fp);
        node = node->next;
    }

    fflush(fp);
    fsync(fileno(fp));
    fclose(fp);
    return 0;
}

/********************************************************
    funcname:
    Description: 把链表节点存入falsh文件尾
    intput:
    output:
********************************************************/
int save_node_link_to_flash(struct filelist *pnode)
{
    FILE *fp;

    fp = fopen(LOCAL_LINK_FILE, "ab+"); // 以读/写方式打开一个二进制文件，允许读或在文件末追加数据
    if(fp == NULL)
    {
        dzlog_error("open file %s failed", LOCAL_LINK_FILE);
        return -1;
    }

    fwrite((char *)&pnode->info, 1, sizeof(struct filenode), fp);

    fflush(fp);
    fsync(fileno(fp));
    fclose(fp);
    return 1;
}

/********************************************************
    funcname:
    Description: 把所用链表节点存入flash
    intput:
    output:
********************************************************/
int get_all_link_from_flash(void)
{
    FILE *fp;
    struct filelist *pnote;
    unsigned int readnum;
    unsigned int file_sum = 0;
	
    fp = fopen(LOCAL_LINK_FILE, "rb"); // 以只读方式打开文件
    
    if(fp == NULL)
    {
        return -1;
    }

    fseek(fp, 0L, SEEK_END);
    readnum = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    file_sum = readnum % sizeof(struct filenode);
	
    if (file_sum != 0)  // 不是整数倍，文件结构或数据损坏
    {
        remove(LOCAL_LINK_FILE);
        fclose(fp);
        dzlog_error("len err, del %s", LOCAL_LINK_FILE);
        return -1;
    }

    while (1)
    {
        pnote = malloc(sizeof(struct filelist));
		
        if(NULL == pnote)
        {
            dzlog_error("malloc error!\n");
            fclose(fp);
            return -1;
        }

        readnum = fread(&pnote->info, 1, sizeof(struct filenode), fp);
		
        pnote->next = NULL;

        if (readnum == sizeof(struct filenode))
        {
            //dzlog_info("local file: %s, frame_num =%d", pnote->info.filename, pnote->info.frame_num);
            file_sum++;
            file_list_add( pnote); // 把文件名加入表尾
        }
        else
        {
            dzlog_info("get storage link: %s, file num:%d", LOCAL_LINK_FILE, file_sum);
            break; // 文件结束
        }
    }

    fclose(fp);

    return 1;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
unsigned int get_system_tf_free(unsigned int *ptotalsize)
{
    struct statfs diskInfo;
    int freeMbyte = 0;
    if (ptotalsize != NULL)
    {
        *ptotalsize = 0;
    }
    if(access(LOCAL_SAVE_DIR, W_OK) == 0)
    {
        if (statfs(LOCAL_SAVE_DIR, &diskInfo) != -1)
        {
            unsigned long long blocksize     = diskInfo.f_bsize; // 每个block里包含的字节数
            unsigned long long totalsize     = blocksize * diskInfo.f_blocks;   // 文件系统数据块总数
            unsigned long long availableDisk = blocksize * diskInfo.f_bavail;   // 非root用户可获取的块数
          //unsigned long long freeDisk      = blocksize * diskInfo.f_bfree;    // 可用块数,root用户多占5%
            freeMbyte = availableDisk>>20;
            if (ptotalsize != NULL)
            {
                *ptotalsize = totalsize>>20;
            }
        }
    }
    return freeMbyte;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
long long zx_LocalTime_ms(void)
{
    struct timeval tv;
    long long ms;

    gettimeofday(&tv, NULL);

    ms = (long long)tv.tv_sec * (long long)1000 + (long long)tv.tv_usec / (long long)1000;
    return ms;
}


/********************************************************
    funcname:     zx_get_time_str
    Description:
    intput:       *time_str
                  time_str_size
    output:       *time_str
********************************************************/
void zx_get_time_str(char *time_str, size_t time_str_size)
{
    time_t tt;
    struct tm local_time;

    time(&tt);
    localtime_r(&tt, &local_time);

    strftime(time_str, time_str_size, "%Y%m%d%H%M%S", &local_time);
}

/********************************************************
    funcname:     get_local_fp_by_channel
    Description:
    intput:       channel
    output:       *fp
********************************************************/
FILE * get_local_fp_by_channel(unsigned int channel)
{
    if (channel < MAX_CAMERA_NUM)
    {
       return local_fp_list[channel].fp;
    }
    else
    {
        return NULL;
    }
}


/********************************************************
    funcname:     get_local_filerecord_by_channel
    Description:
    intput:       channel
    output:       LOCAL_FP_INFO*
********************************************************/
LOCAL_FP_INFO* get_local_filerecord_by_channel(unsigned int channel)
{
    if (channel < MAX_CAMERA_NUM)
    {
        return &local_fp_list[channel];
    }
    else
    {
        return NULL;
    }
}

/*
沒有一定需要再寫回 0，
主要是因為 kernel 只有在 proc file system 的 handler 觸發時才會做對應的清理工作
*/
void clear_system_file_caches(void)
{
    int i = 0;
    for (i = 0; i < MAX_CAMERA_NUM; i++)
    {
        if (local_fp_list[i].fp != NULL)
        {
            break;
        }
    }
    if (i >= MAX_CAMERA_NUM)    //没有文件在写入时
    {
        //sync();
        zx_do_system("%s", "echo 1 > /proc/sys/vm/drop_caches");
        //zx_do_system("%s", "echo 0 >/proc/sys/vm/drop_caches");   // 不释放
    }
}



#if RUN_AI_MODULE
/********************************************************
    funcname:     update_storage_status_by_channel
    Description:
    intput:       channel
    output:       int
********************************************************/
int update_storage_status_by_channel(unsigned char channel, char status)
{
    if (channel < MAX_CAMERA_NUM)
    {
        if (status > local_fp_list[channel].record_flag && local_fp_list[channel].record_flag != STORAGE_IDLE)
        {
            local_fp_list[channel].record_flag = status;
            dzlog_info("update_storage_status to: %d", status);
        }
        return 0;
    }
    else
    {
        return -1;
    }
}

/********************************************************
    funcname:     update_storage_status_by_channel
    Description:
    intput:       channel
    output:       int
********************************************************/
int update_record_time_by_channel(unsigned char channel)
{
    if (channel < MAX_CAMERA_NUM)
    {
        local_fp_list[channel].end_time = zx_LocalTime_ms() + base_param->hub_info.record_time_out;
        return 0;
    }
    else
    {
        return -1;
    }
}

/********************************************************
    funcname:     update_ai_warning_by_channel
    Description:
    intput:       channel
    output:       int
********************************************************/
int update_ai_warning_by_channel(unsigned char channel, char status)
{
    if (channel < MAX_CAMERA_NUM)
    {
        if (local_fp_list[channel].ai_warning_time == 0) // 只发送一次
        {
            dzlog_info("ai_warning delay: %d", status);
            if (status == 1)
            {
				
			#if 0
                ai_upload_stranger_avatar(channel, 0); // 识别过程中上传陌生人脸数据
			#endif
			
                local_fp_list[channel].ai_warning_time = zx_LocalTime_ms() + 3000; // 3秒后发通知
            }
            else if (status == 0) // 立即告警
            {
                local_fp_list[channel].ai_warning_time = 1;
            }

            if ((local_fp_list[channel].arming_action&PRI_ALARM) == PRI_ALARM) // Camera play alarm tong
            {
				
			#if 0
                char alarm_tong = ALARM_1_TOME;
                dzlog_info("Camera play tone: %d", alarm_tong);
                zx_send_command(COMMON_TYPE_PLAY_ALARMSOUND, (char *)&alarm_tong, channel);
			#endif
			
            }
            return 0;
        }
        else if (local_fp_list[channel].ai_warning_time == 0x7fffffffffffffff)
        {
            return 1;
        }
    }

    return -1;
}

/********************************************************
    funcname:     update_ai_record_faceid
    Description:  记录当前录像能取到多少个人脸ID
    intput:       channel
    output:       int
********************************************************/
int update_ai_record_faceid(unsigned char channel, int id)
{
    int i;
    if (id == 0)
    {
        return -1;
    }
    if (channel < MAX_CAMERA_NUM)
    {
        for (i=0; i<FACEMAX; i++)
        {
            if (local_fp_list[channel].faceid[i] == 0 || local_fp_list[channel].faceid[i] == id)
            {
                local_fp_list[channel].faceid[i] = id;
                dzlog_info("channel %d, get face_id:【%d】", channel, id);
                return 0;
            }
        }
    }

    return -1;
}

/********************************************************
    funcname:     check_ai_module_status
    Description:  camera打开时，检查是否可以占用AI,并使状态转移
    intput:       channel
    output: -1: AI busy
********************************************************/
int check_ai_module_status(void)
{
    int i;
    for (i=0; i<MAX_CAMERA_NUM; i++)
    {
        switch(local_fp_list[i].record_flag)
        {
            case STORAGE_AI_RECOGNITION: // 正在做人脸人形检测
            {
                return -1;
            }

            case STORAGE_AI_TRACK:      // 正在做人脸跟踪
            {
                local_fp_list[i].record_flag = STORAGE_AI_WRITE;         // 停止跟踪
            }
            break;

            case STORAGE_AI_DETECTION:  // 已做完一轮以上的人脸人形检测
            {
                // 停止检测,结束录像,如果还有PRI触发，重新申请AI资源
                local_fp_list[i].record_flag = STORAGE_AI_END_DETECTION;
            }
            break;

            default:
                break;
        }
    }

    return 0;   // 抢占到AI控制权
}

#endif

/********************************************************
    funcname:
    Description:
    intput:       channel
    output:       int
********************************************************/
int zx_update_dev_pri_action_by_channel(int channel, int action)
{
    if (channel < MAX_CAMERA_NUM)
    {
        local_fp_list[channel].arming_action = action;
        dzlog_info("pri_action = %d", action);
        return 0;
    }
    else
    {
        return -1;
    }
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int zx_check_local_rsa_pubkey( void )
{
    int ret = -1;
    dzlog_info("local_rsa, pub_id = %d", base_param->hub_info.rsa_pub_id);
    if (base_param->hub_info.rsa_pub_id)
    {
        zx_update_local_rsa_pubkey(base_param->hub_info.rsa_pub_id, base_param->hub_info.rsa_pubkey_n);
    }
    else if (base_param->hub_info.account_id[0] != 0)
    {
        zx_Error err = zx_get_RSA_pubkey(base_param->hub_info.account_id, base_param->hub_info.hub_sn,
                                         base_param->hub_info.rsa_pubkey_n, &base_param->hub_info.rsa_pub_id);
        if (err.code == 0)
        {
            base_param->hub_info.rsa_pubkey_n[256] = 0;
            ret = zx_update_local_rsa_pubkey(base_param->hub_info.rsa_pub_id, base_param->hub_info.rsa_pubkey_n);
            write_config_param(SET_HUB_PARAM);
        }
    }

    return ret;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int zx_update_local_rsa_pubkey( unsigned char key_id, char *nkey )
{
    int ret = -1;
    //dzlog_info("rsa_pubkey[%d]: %s", key_id, nkey);
    if (strlen(nkey) == 256 && key_id)
    {
        base_param->hub_info.rsa_pub_id = key_id;
        memcpy(base_param->hub_info.rsa_pubkey_n, nkey, 256);
        base_param->hub_info.rsa_pubkey_n[256] = 0;

        if (local_rsa_pubkey)
        {
            RSA_free(local_rsa_pubkey);
        }
        local_rsa_pubkey = rsa_get_pubKey(nkey);
        if (local_rsa_pubkey)
        {
            ret = 0;
        }
    }
    return ret;
}


/********************************************************
    funcname:     zx_set_playclt_by_session
    Description:
    intput:       session_id, framenum
    output:
********************************************************/
void zx_set_playclt_by_session(int session_id, PLAYBACK_CONTROL_PARAM playctrl)
{
    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        if (playctrl_info[i].session_id == session_id)
        {
            playctrl_info[i].playctrl = playctrl;
            dzlog_info("RECORD_PLAY_CTRL: session_id %d control_type %d, fram_num %d", session_id, playctrl.control_type, playctrl.fram_num);
            return;
        }
    }
}

/********************************************************
    funcname:     zx_set_playclt_by_session
    Description:
    intput:       session_id
    output:
********************************************************/
void zx_clear_playclt_by_session(int session_id)
{
    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        if (playctrl_info[i].session_id == session_id)
        {
            playctrl_info[i].session_id = -1;
            return;
        }
    }
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int zx_creat_mp4_file(int sockfd, char * pfilename, int channel)
{
    ZX_COMMUNICATION_PACKET msg_packet;
    ZX_COMM_HEAD *comm_head = NULL;
    int readnum;

    if (sockfd < 0 || pfilename == NULL)
    {
        return -1;
    }

    memset(&msg_packet,0,sizeof(ZX_COMMUNICATION_PACKET));

    comm_head  = (ZX_COMM_HEAD *)&msg_packet;
    comm_head->head_tag         = PAG_HEARD_TAG;
    comm_head->command_id       = APP_CMD_STREAM_MSG;
    comm_head->param_len        = 2 + strlen(pfilename) + 1;
    comm_head->version          = COMM_VERSION;
    comm_head->channel_id       = channel;
    comm_head->sign_code        = NO_SEC_KEY;

    ZX_STREAN_MSG *msg          = (ZX_STREAN_MSG *)(&msg_packet.param_body.stream_msg);
    strncpy(msg->fileName, pfilename, MAX_FILE_NAME - 1);
    msg->channel                = channel;
    msg->stream_type            = AV_STREAM_START;

    int sendLen = COMM_HEARD_LEN + comm_head->param_len;
    readnum = send(sockfd, &msg_packet,sendLen, 0);
    if ( readnum == sendLen )
    {
        return 0;
    }
    else
    {
        dzlog_error("send start mp4 msg fail! (r:%d != s:%d)\n",readnum, sendLen);
        return -1;
    }
}

int zx_close_mp4_file(int sockfd, char * pfilename, int channel)
{
    ZX_COMMUNICATION_PACKET msg_packet;
    ZX_COMM_HEAD *comm_head = NULL;
    int sendLen, readnum;
    int ret = -1;

    if (sockfd < 0 || pfilename == NULL)
    {
        return -1;
    }
    memset(&msg_packet,0,sizeof(ZX_COMMUNICATION_PACKET));

    comm_head                   = (ZX_COMM_HEAD *)&msg_packet;
    comm_head->head_tag         = PAG_HEARD_TAG;
    comm_head->command_id       = APP_CMD_STREAM_MSG;
    comm_head->param_len        = 2 + strlen(pfilename) + 1;
    comm_head->version          = COMM_VERSION;
    comm_head->channel_id       = channel;
    comm_head->sign_code        = NO_SEC_KEY;

    ZX_STREAN_MSG *msg          = (ZX_STREAN_MSG *)(&msg_packet.param_body.stream_msg);
    strncpy(msg->fileName, pfilename, MAX_FILE_NAME - 1);
    msg->channel                = channel;
    msg->stream_type            = AV_STREAM_STOP;

    sendLen = COMM_HEARD_LEN + comm_head->param_len;
    readnum = send(sockfd, &msg_packet, sendLen, 0);
    if ( readnum == sendLen )
    {
        dzlog_info("send stop stream msg ok!");
        do
        {
            readnum = recv(sockfd, &msg_packet, sendLen, 0);
            if (readnum < 0)
            {
                dzlog_error("pushMuxer server error!\n");
            }
            else if (readnum == 0)
            {
                ret = 0;
                dzlog_info("pushMuxer server disconnect!\n");
            }
        } while (readnum > 0);
    }
    else
    {
        dzlog_error("send stop mp4 msg fail! (r:%d != s:%d)\n",readnum, sendLen);
    }

    if (ret != 0)
    {
		dzlog_info("close mp4 file upload log");
        upload_log_param(LOG_NORMAL, PUSHMUXER, base_param->hub_info.hub_sn, "Warn", "pushMuxer", "", "create mp4 fail");
    }
    return ret;
}

/********************************************************
    funcname:     pir_triger_handle_by_channel
    Description:
    intput:       channel
    output:       0:sucess -1:fail
********************************************************/
int pir_triger_handle_by_channel(unsigned int channel)
{
    LOCAL_FP_INFO * file_info = NULL;
    long long now_time;
    //int i = 0;
    int clientmark;
    zx_Uint32 pass_time = 0;

#if 0
    if (gsystem_init == 0 || channel >= MAX_CAMERA_NUM || ai_module_update || gdev_bind_type == XM_CAMERA)
    {
        return -1;  // XM初始化未完成或在升级、绑定过程
    }
#endif

	if (gsystem_init == 0 )
	 {
		 return -1;  // XM初始化未完成或在升级、绑定过程
	 }

	dzlog_info("pir triger handle start.");

    file_info = &local_fp_list[channel];
	
    if ((file_info->arming_action&PRI_RECORD) != PRI_RECORD)
    {
        dzlog_warn("Camera: %d, action: 0x%x, APP disable recording!", channel, file_info->arming_action);
        return -1;
    }

	dzlog_info("pir triger PRI_RECORD = %d",PRI_RECORD);

    file_info->triger_pir_count += 1;			//触发次数
    now_time = zx_LocalTime_ms();				//获取当前时间

    if (file_info->triger_pir_count >= 2)
    {
        pass_time = now_time - file_info->start_time;
    }
    else
    {
        pass_time = 0;
    }

    if (file_info->record_flag) //已开始录像，只要更新结束时间
    {
        if (pass_time >= RECORD_TIME_OUT)
        {   // 在录像时如果实时视频打开，提前结束录像时间
            dzlog_info("Camera: %d record time: %dms, waiting stop record!", channel, pass_time);
            if (file_info->end_time > now_time)
            {
                file_info->end_time = now_time;
            }
        }
        else if (file_info->frame_num > 0) // 出流
        {
            // 因为wifi信息干扰PIR误触发, 不再使用PIR来延长录像计时
            // 对于AI版版本，用AI检测人形来判定
            // 无AI版本，采用移动侦测来判定(待XM接口)
            //#if RUN_AI_MODULE  // 在AI不可用时暂时还是PIR
			#if 0
            if (ai_clientfd == -1 ||
                file_info->record_flag == STORAGE_AI_WRITE ||
                file_info->record_flag == STORAGE_TF_WRITE)
            {
                file_info->end_time = now_time + base_param->hub_info.record_time_out;
            }
            #else
                file_info->end_time = now_time + base_param->hub_info.record_time_out;
            #endif
            //dzlog_info("Camera channel: %d, pri_count %d, Record time: %dms", channel, file_info->triger_pir_count, pass_time);
        }
        else
        {
            dzlog_info("Camera: %d, waiting stream...", channel);
        }
        return 1;
    }

    clientmark = hisi_get_camera_clientmark(channel);
    if (clientmark != 0 )
    { // camera实时视频关闭时才触发录像
        file_info->triger_pir_count = 0;
        return -1;
    }

    if (file_info->triger_pir_count == PIR_TRIGER_NUM)			//触发三次才开始录像
    {
        if (pass_time <= PIR_TRIGER_SLOT )		//小于3秒
        { // n秒内收到 PIR_TRIGER_NUM个包
            dzlog_info("Camera: %d, PIR trigger: 3, elapsed: %dms, action: %d, record_time: %dS",
            channel, pass_time, file_info->arming_action, base_param->hub_info.record_time_out/1000);

            file_info->end_time = now_time + base_param->hub_info.record_time_out;
            pri_channel = channel; // 在线程创建时，pri_channel值不能被改写
            zx_create_thread(HIGH_PRIORITY, zx_storage_write_thread, &pri_channel, -1, TFCARD_WRITE, -1);
            usleep(1000); // wait thread runing
            return 0;     // triger_pir_count 不要复位
        }
        else
        {
            dzlog_info("Camera: %d, PIR trigger 3, elapsed %dms, restart", channel, pass_time);
            file_info->triger_pir_count = 1;
        }
    }
    else if ( file_info->triger_pir_count < PIR_TRIGER_NUM )
    {
        if (pass_time > PIR_TRIGER_SLOT )
        {
            dzlog_info("Camera: %d, PIR trigger %d, elapsed %dms, restart",
                        channel, file_info->triger_pir_count, pass_time);
            file_info->triger_pir_count = 1;
        }
    }

    if (file_info->triger_pir_count == 1)
    {
        dzlog_info("Camera: %d, PIR trigger 1 ----->", channel);
        file_info->frame_num = 0;
        file_info->start_time = now_time;
    }
    else if (file_info->triger_pir_count > PIR_TRIGER_NUM)
    {
        if (file_info->end_time != 0)
        {
            dzlog_info("Camera: %d, PIR trigger %d", channel, file_info->triger_pir_count);
            if (now_time > (file_info->end_time + 10*1000))
            {
                file_info->triger_pir_count = 0; // 重新开始
            }
        }
    }

    return -1;
}



void * zx_hisi_storage_write_thread( void *argv )
{
    fd_set rfds;
    struct timeval tv;
    int channel = *(int *)argv;
    char* thumb_data = NULL;
    int read_storage_pipe;

    QUEUE * queue = NULL;
    ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_FRAME  *video = NULL;

    long long now_time;
    int sendnum;
    int get_snapshot = 0;
    int ret;        // AI模块
    int i;

    char dev_sn[SHORT_STR_LEN] = {0};
    AES_KEY aes_key;
    char aes_key_Plaintext[AES_BLOCK_SIZE+1];
    char aes_key_encrypt[NORMAL_STR_LEN+1];
	
	dzlog_info("hisi storage pthread start.");

    VIDEO_ENCRYPT *encrypt_video = (VIDEO_ENCRYPT *)malloc(sizeof(VIDEO_ENCRYPT));
	
    LOCAL_FP_INFO * plocal_fileinfo = get_local_filerecord_by_channel(channel);
	
    if (plocal_fileinfo == NULL || encrypt_video == NULL)
    {
        goto storage_write_thread_exit;
    }

    if (plocal_fileinfo->storage_pipe[0] == -1)
    {
        if (pipe(plocal_fileinfo->storage_pipe) != 0)
        {
            dzlog_error("storage_pipe create fail...\n");
            goto storage_write_thread_exit;
        }
		
        int flags = fcntl(plocal_fileinfo->storage_pipe[0], F_GETFL);
        fcntl(plocal_fileinfo->storage_pipe[0], F_SETFL, flags|O_NONBLOCK); // 非阻塞
    }
    read_storage_pipe = plocal_fileinfo->storage_pipe[0];

    if (open_local_file_by_channel(plocal_fileinfo, channel) == -1)
    {
        goto storage_write_thread_exit; // 没有TF卡
    }

    dzlog_info("zx_open_camera(%d)----->", channel);

	zx_get_dev_sn_by_channel(channel, dev_sn);		//获取sn
   	
    plocal_fileinfo->record_flag = STORAGE_TF_WRITE;        // 出流后写文件;
    zx_push_message("home_security", "warning", channel);

#if ZX_RSA_EN
    if (local_rsa_pubkey)
    {
        // 生成key字符串
        rand_str(aes_key_Plaintext, 16);
        if (rsa_encrypt(local_rsa_pubkey, aes_key_Plaintext, aes_key_encrypt) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
        else if (int_aes_encryptkey(aes_key_Plaintext, &aes_key) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
    }
    else
    {
        aes_key_Plaintext[0] = 0;
        aes_key_encrypt[0] = 0;
        dzlog_info("local_rsa_pubkey is NULL!");
    }
#endif

    dzlog_info("storage_write_thread(pid:%d,ch:%d) is runing----->", getpid(), channel);
    while (grunning)
    {
read_pipe_again:
        FD_ZERO(&rfds);
        FD_SET(read_storage_pipe, &rfds);

        tv.tv_sec = 30;
        tv.tv_usec = 0;
        // select返回后会把以前加入的但并无事件发生的fd清空
        switch(select(read_storage_pipe + 1, &rfds, NULL, NULL, &tv))
        {
            case -1:
                dzlog_warn("storage_write_thread select error");
                //break;

            case 0:
            {
                dzlog_warn("Camera:%d not stream 30S timeout,close!\n", channel);
                if (plocal_fileinfo->filename[0] > ' ')
                {
                    remove(plocal_fileinfo->filename);
                }
                if (plocal_fileinfo->sockfd >= 0)
                {
                    zx_close_mp4_file(plocal_fileinfo->sockfd, plocal_fileinfo->cloudfile, channel);
                }
				
				dzlog_info("storage write thread");

				upload_log_param(LOG_NORMAL, FLOODLIGHT, base_param->hub_info.hub_sn, "Warn", "Camera", "", "timeout");

                goto storage_write_thread_exit;
            }
            break;

        default:
        {
            if(FD_ISSET(read_storage_pipe, &rfds))
            {
                FD_CLR(read_storage_pipe, &rfds);
                queue = NULL;
                if (read(read_storage_pipe, &queue, sizeof(queue)) == -1)   // 4字节的指针
                {
                    if (errno == EAGAIN)
                    {
                        goto read_pipe_again;
                    }
                    else
                    {
                        dzlog_error("read video_pipe err:%s\n", strerror(errno));
                        goto storage_write_thread_exit;
                    }
                }
                if (queue == NULL)
                {
                    dzlog_error("read queue == NULL!\n");
                    goto storage_write_thread_exit;
                }

                comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
                if ( comm_head == NULL )
                {
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }
                else if (comm_head->head_tag != PAG_HEARD_TAG)
                {
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }

                now_time = zx_LocalTime_ms();

                if ( comm_head->command_id == APP_CMD_VIDEO_FRAME)
                {
                    plocal_fileinfo->frame_num += 1;
                    if (plocal_fileinfo->frame_num == 1)
                    {
                        plocal_fileinfo->start_time = now_time;   // 更新开始record时间
                        plocal_fileinfo->end_time = now_time + base_param->hub_info.record_time_out;
                    }
                    if (plocal_fileinfo->frame_num % 100 == 1)
                    {
                        dzlog_info("channel: %d, record frame_num=%d", channel, plocal_fileinfo->frame_num);
                    }
                    if (get_snapshot != 1)
                    {
						
					#if 0
                        zx_get__snapshot_img(channel, 360, 240); // XM_RESOLUTION_240P, 16:9
                        get_snapshot = 1; // 只发一次
					#endif
					
                    }
					
                }
// 缩略图 ----------------------------------------------------------------------------------------
                else if (comm_head->command_id == XM_SNAPSHOT_FRAME )
                {
                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                    if (thumb_data != NULL)
                    {
                        free(thumb_data);   //多次取图，先把以前的free;
                    }
                    thumb_data = zx_Memory_Encode(video->buf, video->frame_size);
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }
// 云存储 ----------------------------------------------------------------------------------------
                if (plocal_fileinfo->sockfd >= 0)
                {
                    sendnum = send(plocal_fileinfo->sockfd, queue->pFrameBuf, queue->frame_size, 0);
                    if (sendnum != queue->frame_size)
                    {
                        if (sendnum == -1)
                        {
                            dzlog_error("pushMuxer sock error %d: %s\n", errno, strerror(errno));
                            close(plocal_fileinfo->sockfd);
                            plocal_fileinfo->sockfd = -1;
                        }
                        else if (sendnum == 0) // disconnect
                        {
                            dzlog_error("pushMuxer sock disconnect!\n");
                            close(plocal_fileinfo->sockfd);
                            plocal_fileinfo->sockfd = -1;
                        }
                        else
                        {
                            dzlog_error("send pushMuxer error, %d!=%d\n", sendnum, queue->frame_size);
                        }
                        if (plocal_fileinfo->fp == NULL)
                        {
                            plocal_fileinfo->end_time = now_time;
                        }
						
						dzlog_info("creat mp4 Fail");
                        upload_log_param(LOG_NORMAL, PUSHMUXER, base_param->hub_info.hub_sn, "Warn", "pushMuxer", "", "creat mp4 Fail");
                    }
                }

// 本地存储 -------------------------------------------------------------------------------------
                if (plocal_fileinfo->fp != NULL)
                {
					dzlog_info("【start local stroge.】");
                  #if ZX_RSA_EN
                  if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
                  {
                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                    if (video->frame_type == FRAME_TYPE_I && aes_key_Plaintext[0] != 0)
                    {
                        memcpy((char *)encrypt_video, (char*)video, VIDEO_HEAD_SIZE);    // 加密前的视频头部
                        memcpy(encrypt_video->buf, video->buf, video->frame_size);       // 加密前的视频
                        ret = aes_encrypt(&aes_key, video->buf, 128, encrypt_video->buf);// 部份数据加密
                        if (ret == 128)
                        {
                            memcpy(encrypt_video->aes_key, aes_key_encrypt, NORMAL_STR_LEN);
                            encrypt_video->aes_key[NORMAL_STR_LEN] = 0;

                            comm_head->sign_code = base_param->hub_info.rsa_pub_id; // 加密的公钥号
                            comm_head->param_len = (sizeof(VIDEO_ENCRYPT) - VIDEO_ENCRYPT_SIZE) + video->frame_size;
                            dzlog_info("aes_encrypt,rsa_pub_id: %d", comm_head->sign_code);
                            fwrite(queue->pFrameBuf, 1, COMM_HEARD_LEN, plocal_fileinfo->fp);
                            sendnum = fwrite((char *)encrypt_video, 1, comm_head->param_len, plocal_fileinfo->fp);
                            if (sendnum != comm_head->param_len)
                            {
                                plocal_fileinfo->end_time = now_time;
                                dzlog_error("fwrite error %d!=%d\n", sendnum, comm_head->param_len);
                            }
                        }
                      }
                    }
                    #endif
                    if (comm_head->sign_code == NO_SEC_KEY)   //P帧和音频不加密
                    {
                        sendnum = fwrite(queue->pFrameBuf, 1, queue->frame_size, plocal_fileinfo->fp);
                        if (sendnum != queue->frame_size)
                        {
                            plocal_fileinfo->end_time = now_time;
                            dzlog_error("fwrite error %d!=%d\n", sendnum, queue->frame_size);
                        }
                    }
                }

// 并发冲突 --------------------------------------------------------------------------------------------------
                if (hisi_get_camera_clientmark(channel) & (~CLIENT_PIR))
                {   // 在录像时如果实时视频打开，提前结束录像时间
                    dzlog_info("Camera: %d, other client open, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
                else if (gdev_bind_type == XM_CAMERA )
                {
                    dzlog_info("Camera: %d, rebind dev, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
				else if (gdev_bind_type == FLOODLIGHT)
                {
                    dzlog_info("Camera: %d, rebind dev, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
//结束处理 ----------------------------------------------------------------------------------------------------
                queue->frame_size = 0;
                queue->nUseFlag = NOTUSE;
                if(now_time >= plocal_fileinfo->end_time)
                {
                    int upload_cloud = 0;

                    plocal_fileinfo->record_flag = STORAGE_IDLE; // 不再接收stream
                    dzlog_info("storage record end!\n");

				#if 0
				 	if( hisi_cam_data->white_led_tigger != HISI_IRLEDMODE_OFF && HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode)
					{
						ret = zx_hisi_set_white_led_on();

						if(ret != 0)
						{
							dzlog_error("hisi white len on error ret = %d",ret);
							break;
						}
					}
				#endif

								
#if 0
                    zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PIR, 0);
#endif

                    if (plocal_fileinfo->sockfd >= 0)
                    {
                        if (zx_close_mp4_file(plocal_fileinfo->sockfd, plocal_fileinfo->cloudfile, channel) == 0)
                        {
                            upload_cloud = 1;
                        }
                    }
                #if RUN_P2P_SERVER
                if (plocal_fileinfo->frame_num >= FRAME_RATE_720) // 1秒钟以上，太短上传无意义
                {
                    char* file_key = NULL;
                    char* local_path = NULL;
                    char* cloud_path = NULL;
                    int storagetype = LOCAL_STORGE;

                    if (upload_cloud == 1 )
                    {
                        // push to aws
                        file_key = zx_putdata_aws_s3(base_param->hub_info.account_id,
                                                plocal_fileinfo->cloudfile, dev_sn, DEVICE_MONITORING_VIDEO);
                        if (file_key == NULL)
                        {
							dzlog_info("put cloud fail");
                            upload_log_param(LOG_NORMAL, FLOODLIGHT, base_param->hub_info.hub_sn, "Warn", "Camera", "", "put cloud fail");
                        }
                    }

                    if (file_key)
                    {
                        if (plocal_fileinfo->fp != NULL)
                        {
                            local_path = plocal_fileinfo->filename;
                            cloud_path = file_key;
                            storagetype = LOACL_AND_CLOUD;
                        }
                        else
                        {
                            local_path = "";
                            cloud_path = file_key;
                            storagetype = CLOUD_STORGE;
                        }
                    }
                    else
                    {
                        if (plocal_fileinfo->fp != NULL)
                        {
                            local_path = plocal_fileinfo->filename;
                            cloud_path = "";
                            storagetype = LOCAL_STORGE;
                        }
                    }
					
				
                    zx_Error err = zx_upload_hub_history_record(base_param->hub_info.account_id,
                                                       base_param->hub_info.hub_sn,
                                                       dev_sn,
                                                       local_path,
                                                       plocal_fileinfo->start_time,
                                                       plocal_fileinfo->end_time,
                                                       plocal_fileinfo->frame_num,
                                                       cloud_path,
                                                       storagetype,
                                                       base_param->hub_info.rsa_pub_id,
                                                       thumb_data,
                                                       plocal_fileinfo->faceid );
                    if (file_key)
                    {
                        free(file_key);
                        file_key = NULL;
                    }
                    if (err.code == 0)
                    {
                        struct filelist *pnode = malloc(sizeof(struct filelist));
                        if(pnode == NULL)
                        {
                            dzlog_error("malloc error!\n");
                            goto storage_write_thread_exit;
                        }
                        pnode->info.flag = 0;
                        memset(pnode->info.filename, 0, sizeof(pnode->info.filename));
                        memcpy(pnode->info.filename, plocal_fileinfo->filename, strlen(plocal_fileinfo->filename));
                        pnode->info.frame_num = plocal_fileinfo->frame_num; // 无用
                        pnode->next = NULL;
                        file_list_add(pnode); // 把文件名加入表尾
                        save_node_link_to_flash(pnode);
                    }
                    else
                    {
                        struct resend_filelist *resend_node = malloc(sizeof(struct resend_filelist));
                        if(resend_node == NULL)
                        {
                            dzlog_error("malloc error!\n");
                            goto storage_write_thread_exit;
                        }
                        resend_node->resend.thumbnail = thumb_data;
                        thumb_data = NULL; // 不要释放缩略图内存,上传成功后再释放
                        resend_node->resend.storagetype = storagetype;
                        resend_node->resend.frame_num = plocal_fileinfo->frame_num;
                        resend_node->resend.start_time = plocal_fileinfo->start_time;
                        resend_node->resend.end_time = plocal_fileinfo->end_time;
                        memcpy(resend_node->resend.faceid, plocal_fileinfo->faceid, sizeof(resend_node->resend.faceid));
                        memcpy(resend_node->resend.filename, plocal_fileinfo->filename, FILENAMEMAX);
                        memcpy(resend_node->resend.cloudfile, plocal_fileinfo->cloudfile, FILENAMEMAX);
                        memcpy(resend_node->resend.dev_sn, dev_sn, SHORT_STR_LEN);
                        resend_node->next = NULL;
                        dzlog_error("waiting resent history_record!\n");
                        resend_filelist_add(resend_node); // 把文件名加入表尾
                    }
                }
                else // 空视频,删除它
                {
                    if (plocal_fileinfo->filename[0] > ' ')
                    {
                        remove(plocal_fileinfo->filename);
                        dzlog_info("No people detected: %s, del", plocal_fileinfo->filename);
                    }
                }
                #endif

                    goto storage_write_thread_exit; // 退出线程
                }
            }
        break;
        }
      }
    }

storage_write_thread_exit:
    if (thumb_data != NULL)
    {
        free(thumb_data);
        thumb_data = NULL;
        dzlog_info("free thumb_data");
    }
    if (encrypt_video)
    {
        free(encrypt_video);
        encrypt_video = NULL;
    }
    if (plocal_fileinfo->record_flag)
    {
		
	#if 0
        zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PIR, 0);
	#endif
	
    }

    //-----可能pipe里面还有数据,清空(O_NONBLOCK)------------------------------------------------
    sendnum = HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE;
    while(sendnum)
    {
        if (read(read_storage_pipe, &queue, sizeof(queue)) <= 0)   // 4字节的指针
        {
           break;
        }
        else if (queue->nUseFlag != NOTUSE)
        {
            queue->frame_size = 0;
            queue->nUseFlag = NOTUSE;
            sendnum--;
        }
    }
    if (sendnum != (HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE))
    {
        dzlog_info("clear storage_pipe: %d", HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE - sendnum);
    }
    //------------------------------------------------------------------------------------------

    close_local_fp_by_channel(plocal_fileinfo);
    //clear_system_file_caches();

    zx_clear_thread_info_by_type(TFCARD_WRITE);
    dzlog_info("storage_write_thread(pid:%d,ch:%d) exit...\n", getpid(), channel);
    return NULL;
}


#if 0
void zx_hisi_local_storage_write()
{
	fd_set rfds;
    struct timeval tv;
    int channel = *(int *)argv;
    char* thumb_data = NULL;
    int read_storage_pipe;

    QUEUE * queue = NULL;
    ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_FRAME  *video = NULL;

    long long now_time;
    int sendnum;
    int get_snapshot = 0;
    int ret;        // AI模块
    int i;

    char dev_sn[SHORT_STR_LEN] = {0};
    AES_KEY aes_key;
    char aes_key_Plaintext[AES_BLOCK_SIZE+1];
    char aes_key_encrypt[NORMAL_STR_LEN+1];
	
	channel = HISI_CH0;

    VIDEO_ENCRYPT *encrypt_video = (VIDEO_ENCRYPT *)malloc(sizeof(VIDEO_ENCRYPT));
	
    LOCAL_FP_INFO * plocal_fileinfo = get_local_filerecord_by_channel(channel);
	
    if (plocal_fileinfo == NULL || encrypt_video == NULL)
    {
        goto storage_write_thread_exit;
    }

    if (plocal_fileinfo->storage_pipe[0] == -1)
    {
        if (pipe(plocal_fileinfo->storage_pipe) != 0)
        {
            dzlog_error("storage_pipe create fail...\n");
            goto storage_write_thread_exit;
        }
		
        int flags = fcntl(plocal_fileinfo->storage_pipe[0], F_GETFL);
        fcntl(plocal_fileinfo->storage_pipe[0], F_SETFL, flags|O_NONBLOCK); // 非阻塞
    }
    read_storage_pipe = plocal_fileinfo->storage_pipe[0];

    if (open_local_file_by_channel(plocal_fileinfo, channel) == -1)
    {
        goto storage_write_thread_exit; // 没有TF卡
    }

    dzlog_info("zx_open_camera(%d)----->", channel);

	zx_get_dev_sn_by_channel(channel, dev_sn);		//获取sn
   	
    plocal_fileinfo->record_flag = STORAGE_TF_WRITE;        // 出流后写文件;
    zx_push_message("home_security", "warning", channel);

#if ZX_RSA_EN
    if (local_rsa_pubkey)
    {
        // 生成key字符串
        rand_str(aes_key_Plaintext, 16);
        if (rsa_encrypt(local_rsa_pubkey, aes_key_Plaintext, aes_key_encrypt) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
        else if (int_aes_encryptkey(aes_key_Plaintext, &aes_key) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
    }
    else
    {
        aes_key_Plaintext[0] = 0;
        aes_key_encrypt[0] = 0;
        dzlog_info("local_rsa_pubkey is NULL!");
    }
#endif

    dzlog_info("storage_write_thread(pid:%d,ch:%d) is runing----->", getpid(), channel);
	
	if (plocal_fileinfo->fp != NULL)
	{
		dzlog_info("start local stroge.");
#if ZX_RSA_EN
		if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
		{
		video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
		if (video->frame_type == FRAME_TYPE_I && aes_key_Plaintext[0] != 0)
		{
		    memcpy((char *)encrypt_video, (char*)video, VIDEO_HEAD_SIZE);    // 加密前的视频头部
		    memcpy(encrypt_video->buf, video->buf, video->frame_size);       // 加密前的视频
		    ret = aes_encrypt(&aes_key, video->buf, 128, encrypt_video->buf);// 部份数据加密
		    if (ret == 128)
		    {
		        memcpy(encrypt_video->aes_key, aes_key_encrypt, NORMAL_STR_LEN);
		        encrypt_video->aes_key[NORMAL_STR_LEN] = 0;

		        comm_head->sign_code = base_param->hub_info.rsa_pub_id; // 加密的公钥号
		        comm_head->param_len = (sizeof(VIDEO_ENCRYPT) - VIDEO_ENCRYPT_SIZE) + video->frame_size;
		        //dzlog_error("aes_encrypt,rsa_pub_id: %d", comm_head->sign_code);
		        fwrite(queue->pFrameBuf, 1, COMM_HEARD_LEN, plocal_fileinfo->fp);
		        sendnum = fwrite((char *)encrypt_video, 1, comm_head->param_len, plocal_fileinfo->fp);
		        if (sendnum != comm_head->param_len)
		        {
		            plocal_fileinfo->end_time = now_time;
		            dzlog_error("fwrite error %d!=%d\n", sendnum, comm_head->param_len);
		        }
		    }
		  }
		}
#endif
		if (comm_head->sign_code == NO_SEC_KEY)   //P帧和音频不加密
		{
		    sendnum = fwrite(queue->pFrameBuf, 1, queue->frame_size, plocal_fileinfo->fp);
		    if (sendnum != queue->frame_size)
		    {
		        plocal_fileinfo->end_time = now_time;
		        dzlog_error("fwrite error %d!=%d\n", sendnum, queue->frame_size);
		    }
		}
	}
}
#endif

int zx_motion_and_pir_triger_local_storage(unsigned int channel)
{

	LOCAL_FP_INFO * file_info = NULL;
    long long now_time;
    int clientmark;
    zx_Uint32 pass_time = 0;

	if (gsystem_init == 0 )
	{
		 return -1;  // XM初始化未完成或在升级、绑定过程
	}

    file_info = &local_fp_list[channel];

	dzlog_info("motion and pir triger local storage start.");

	zx_create_thread(HIGH_PRIORITY, zx_hisi_storage_write_thread, &channel, -1, TFCARD_WRITE, -1);

    return 0;
}






/********************************************************
    funcname:     zx_check_cloud_storage
    Description:  临时测试云存储开通标记,后期用后台push
    intput:       session_id
    output:
********************************************************/
void zx_check_cloud_storage(void)
{
    int i;
    char dev_sn[SHORT_STR_LEN];
    zx_Error err;
    unsigned char channel;
	
    for (i = 0; i < MAX_SUB1G_CONNECT; i++)
    {
        channel = base_param->dev_param[i].channle_id;
        base_param->dev_param[i].dev_storage_type = 0;
        if (  channel < MAX_CAMERA_NUM )
        {
            memset(dev_sn, 0, sizeof(dev_sn));
            zx_get_dev_sn_by_channel(channel, dev_sn);
            if (strlen(dev_sn) == DEVICE_SN_LEN)
            {
                err = zx_get_cloud_storage_flag(base_param->hub_info.account_id, dev_sn);
                if (err.code == 0) // 开通了云存储
                {
                    base_param->dev_param[i].dev_storage_type = CLOUD_STORGE;
                }
            }
        }
    }

 
}

/********************************************************
    funcname:     open_local_file_by_channel
    Description:  有camera数据上报时打开本地记录文件
    intput:       channel
    output:       NULL or LOCAL_FP_INFO
********************************************************/
int open_local_file_by_channel(LOCAL_FP_INFO *file_info, int channel)
{
    int ret = -1;
    if (file_info != NULL)
    {
        char time_str[32] = {0};
        char filename[FILENAMEMAX] = {0}; // filepath + time

        sprintf(filename, "%s%s%02d/", SDCARD_DEV, SEC_CAMERA_NAME, channel);
        if (tfcard_free_mb == 0 || zx_create_dir(filename) != 0 )
        {
            dzlog_error("can't mkdir: %s, %s\n", filename, strerror(errno));
            zx_push_message("home_security", "warning", channel);
            return -1;    //文件系统错误
        }

        memset(time_str, 0, sizeof(time_str));
        zx_get_time_str(time_str, sizeof(time_str));
        strcat(filename, time_str);
        strcat(filename, ".dat");

        FILE *fp = fopen(filename, "wb");
        if (NULL == fp)
        {
            dzlog_error("can't creat file: %s, %s\n", filename, strerror(errno));
            return -1;    //文件系统错误
        }

        dzlog_info("creat local file: %s", filename);
        file_info->fp = fp;
        memset(file_info->filename, 0, FILENAMEMAX);
        memcpy(file_info->filename, filename, strlen(filename));

        int freedisk = get_system_tf_free(NULL);
        if (freedisk < 200) // MB
        {
            remove_old_file_note();
        }

        if (base_param->dev_param[channel].dev_storage_type == CLOUD_STORGE) // 开通了云存储
        {
            file_info->sockfd = connect_video_server();
            if (file_info->sockfd == -1)
            {
                dzlog_error("connect_pushmuxer_server Fail\n");
                upload_log_param(LOG_NORMAL, PUSHMUXER, base_param->hub_info.hub_sn, "Warn", "pushMuxer", "", "creat mp4 Fail");
            }
            else
            {
                memset(filename, 0, sizeof(filename));
                sprintf(filename, "%s%s%02d_%s.mp4", MP4_SAVE_PATH, SEC_CAMERA_NAME, channel, time_str);
                if (zx_create_dir(MP4_SAVE_PATH) == 0 )
                {
                    if (zx_creat_mp4_file(file_info->sockfd, filename, channel) == 0)
                    {
                        dzlog_info("creat cloud file: %s", filename);
                        memset(file_info->cloudfile, 0, FILENAMEMAX);
                        memcpy(file_info->cloudfile, filename, strlen(filename));
                    }
                    else
                    {
                        dzlog_error("can't creat cloud file: %s\n", filename);
                        close(file_info->sockfd);
                        file_info->sockfd = -1;
                        upload_log_param(LOG_NORMAL, PUSHMUXER, base_param->hub_info.hub_sn, "Warn", "pushMuxer", "", "creat mp4 Fail");
                    }
                }
                else
                {
                    dzlog_error("can't mkdir: %s, %s\n", MP4_SAVE_PATH, strerror(errno));
                }
            }
        }

        ret = 0;
    }

    return ret;
}

/********************************************************
    funcname:     close_local_fp_by_channel
    Description:
    intput:       channel
    output:
********************************************************/
void close_local_fp_by_channel(LOCAL_FP_INFO * file_info)
{
    if (file_info != NULL)
    {
        //dzlog_info("close_local_fp: 0x%x", file_info);
        if (file_info->fp != NULL)
        {
            if (fflush(file_info->fp))    // 将用户缓存中的内容写入内核缓冲区
            {
                dzlog_error("fflush fail: %p, %s\n", file_info->fp, strerror(errno));
            }
            if (fsync(fileno(file_info->fp))) // 将内核缓冲写入T card
            {
                dzlog_error("fsync fail: %s\n", strerror(errno));
            }
            fclose(file_info->fp);
            file_info->fp = NULL;
            dzlog_info("close file: %s", file_info->filename);
        }
        if (file_info->sockfd >= 0)
        {
            close(file_info->sockfd);
            file_info->sockfd = -1;
        }
        if (file_info->cloudfile[0] > 0x20)
        {
            remove(file_info->cloudfile); // del mp4
            dzlog_info("del cloud file: %s", file_info->cloudfile);
            file_info->cloudfile[0] = 0;
        }
        memset(file_info->faceid, 0 ,sizeof(file_info->faceid));
        memset(file_info->short_url, 0 ,sizeof(file_info->short_url));
        file_info->end_time = 0;
        file_info->start_time = 0;
        file_info->ai_warning_time = 0;
        file_info->record_flag = 0;
        file_info->filename[0] = 0;
        file_info->triger_pir_count = 0;
        file_info->channel = -1;    // 退出前才清除
    }
}

int socket_send(int sockfd, char *buf, int size)
{
    int write_len = 0;
    int sendnum;
    do
    {
        sendnum = send(sockfd, buf, size - write_len, MSG_DONTWAIT);
        if (sendnum == -1)
        {
            if(errno == EAGAIN)
            {// buff已满
                usleep(5*1000);
                continue;
            }
            else if(errno == EINTR)
            { // signal internal
                continue;
            }
            else if(errno == ECONNRESET)
            {
                dzlog_info("sock send fail: %s\n", strerror(errno));
                return -1;
            }
        }
        else if (sendnum == 0)
        {
            dzlog_info("sock send fail: 0\n");
            return -1;
        }

        write_len += sendnum;
    }while (write_len < size);

    return 0;
}


/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
void * zx_storage_write_thread( void *argv )
{
    fd_set rfds;
    struct timeval tv;
    int channel = *(int *)argv;
    char* thumb_data = NULL;
    int read_storage_pipe;

    QUEUE * queue = NULL;
    ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_FRAME  *video = NULL;

    long long now_time;
    int sendnum;
    int get_snapshot = 0;
    int ret;        // AI模块
    int i;

    char dev_sn[SHORT_STR_LEN] = {0};
    AES_KEY aes_key;
    char aes_key_Plaintext[AES_BLOCK_SIZE+1];
    char aes_key_encrypt[NORMAL_STR_LEN+1];
	
	channel = HISI_CH0;

    VIDEO_ENCRYPT *encrypt_video = malloc(sizeof(VIDEO_ENCRYPT));
    LOCAL_FP_INFO * plocal_fileinfo = get_local_filerecord_by_channel(channel);
    if (plocal_fileinfo == NULL || encrypt_video == NULL)
    {
        goto storage_write_thread_exit;
    }

    if (plocal_fileinfo->storage_pipe[0] == -1)
    {
        if (pipe(plocal_fileinfo->storage_pipe) != 0)
        {
            dzlog_error("storage_pipe create fail...\n");
            goto storage_write_thread_exit;
        }
        int flags = fcntl(plocal_fileinfo->storage_pipe[0], F_GETFL);
        fcntl(plocal_fileinfo->storage_pipe[0], F_SETFL, flags|O_NONBLOCK); // 非阻塞
    }
    read_storage_pipe = plocal_fileinfo->storage_pipe[0];

    if (open_local_file_by_channel(plocal_fileinfo, channel) == -1)
    {
        goto storage_write_thread_exit; // 没有TF卡
    }

    dzlog_info("zx_open_camera(%d)----->", channel);
	
#if 0
	zx_open_camera(channel, CLIENT_PIR);
#endif

	
   // zx_hisi_open_camera(channel, CLIENT_PIR);

   // zx_get_dev_sn_by_channel(channel, dev_sn);

   
   zx_hisi_get_device_sn(dev_sn,SHORT_STR_LEN/2);
	
   // #if RUN_AI_MODULE
	#if 0
    if ((plocal_fileinfo->arming_action&PRI_AI) == PRI_AI)
    {
        plocal_fileinfo->record_flag = STORAGE_OPEN_CAMERA;     // 出流后做人脸识别;
    }
    else
    {
        plocal_fileinfo->record_flag = STORAGE_TF_WRITE;        // 出流后写文件;
        zx_push_message("home_security", "warning", channel);
    }
    #else
    plocal_fileinfo->record_flag = STORAGE_TF_WRITE;        // 出流后写文件;
    zx_push_message("home_security", "warning", channel);
    #endif

#if ZX_RSA_EN
    if (local_rsa_pubkey)
    {
        // 生成key字符串
        rand_str(aes_key_Plaintext, 16);
        if (rsa_encrypt(local_rsa_pubkey, aes_key_Plaintext, aes_key_encrypt) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
        else if (int_aes_encryptkey(aes_key_Plaintext, &aes_key) == -1)
        {
            aes_key_Plaintext[0] = 0;
            aes_key_encrypt[0] = 0;
        }
    }
    else
    {
        aes_key_Plaintext[0] = 0;
        aes_key_encrypt[0] = 0;
        dzlog_info("local_rsa_pubkey is NULL!");
    }
#endif

    dzlog_info("storage_write_thread(pid:%d,ch:%d) is runing----->", getpid(), channel);
    while (grunning)
    {
read_pipe_again:
        FD_ZERO(&rfds);
        FD_SET(read_storage_pipe, &rfds);

        tv.tv_sec = 30;
        tv.tv_usec = 0;
        // select返回后会把以前加入的但并无事件发生的fd清空
        switch(select(read_storage_pipe + 1, &rfds, NULL, NULL, &tv))
        {
            case -1:
                dzlog_warn("storage_write_thread select error");
                //break;

            case 0:
            {
                dzlog_warn("Camera:%d not stream 30S timeout,close!\n", channel);
                if (plocal_fileinfo->filename[0] > ' ')
                {
                    remove(plocal_fileinfo->filename);
                }
                if (plocal_fileinfo->sockfd >= 0)
                {
                    zx_close_mp4_file(plocal_fileinfo->sockfd, plocal_fileinfo->cloudfile, channel);
                }

                //#if RUN_AI_MODULE
				#if 0
                if (plocal_fileinfo->record_flag >= STORAGE_AI_TRACK
                 || plocal_fileinfo->record_flag == STORAGE_AI_RECOGNITION )
                {
                    if ( body_face_num == 0)
                    {
                        ai_play_pcm(0, "/media/mmcblk0p1/nopeople.pcm");
                    }
                }
                #endif
#if 0
                upload_log_param(LOG_NORMAL, XM_CAMERA, base_param->hub_info.hub_sn, "Warn", "Camera", "", "timeout");
#endif
				dzlog_info("storage write thread");

				upload_log_param(LOG_NORMAL, FLOODLIGHT, base_param->hub_info.hub_sn, "Warn", "Camera", "", "timeout");

                goto storage_write_thread_exit;
            }
            break;

        default:
        {
            if(FD_ISSET(read_storage_pipe, &rfds))
            {
                FD_CLR(read_storage_pipe, &rfds);
                queue = NULL;
                if (read(read_storage_pipe, &queue, sizeof(queue)) == -1)   // 4字节的指针
                {
                    if (errno == EAGAIN)
                    {
                        goto read_pipe_again;
                    }
                    else
                    {
                        dzlog_error("read video_pipe err:%s\n", strerror(errno));
                        goto storage_write_thread_exit;
                    }
                }
                if (queue == NULL)
                {
                    dzlog_error("read queue == NULL!\n");
                    goto storage_write_thread_exit;
                }

                comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
                if ( comm_head == NULL )
                {
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }
                else if (comm_head->head_tag != PAG_HEARD_TAG)
                {
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }

                now_time = zx_LocalTime_ms();

                if ( comm_head->command_id == APP_CMD_VIDEO_FRAME)
                {
                    plocal_fileinfo->frame_num += 1;
                    if (plocal_fileinfo->frame_num == 1)
                    {
                        plocal_fileinfo->start_time = now_time;   // 更新开始record时间
                        plocal_fileinfo->end_time = now_time + base_param->hub_info.record_time_out;
                    }
                    if (plocal_fileinfo->frame_num % 100 == 1)
                    {
                        dzlog_info("channel: %d, record frame_num=%d", channel, plocal_fileinfo->frame_num);
                    }
                    if (get_snapshot != 1)
                    {
						
					#if 0
                        zx_get__snapshot_img(channel, 360, 240); // XM_RESOLUTION_240P, 16:9
                        get_snapshot = 1; // 只发一次
					#endif
					
                    }
//#if RUN_AI_MODULE
#if 0

                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                    if (plocal_fileinfo->record_flag == STORAGE_OPEN_CAMERA)
                    {
                        dzlog_warn("camera %d, check AI and wait idle...", channel);
                        // AI模块在跟踪模式时, 等待AI识别完成, recv video to queue

                        plocal_fileinfo->record_flag = STORAGE_AI_WAIT;
                        sendnum = 0;
                        while (grunning)
                        {
						#if 0
                            ret = check_ai_module_status();
                            if (ret == 0)   //取到AI资源
                            {
                                plocal_fileinfo->record_flag = STORAGE_AI_RECOGNITION;  // 发送数据到AI人脸识别
                                dzlog_warn("camera %d, check AI is ok! %d", channel, sendnum);
                                break;
                            }
                            else
                            {
                                sendnum++;
                                if (sendnum > 20)
                                {
                                    break;
                                }
                                usleep(100*1000);
                            }
						#endif
							break;
                        }

                        if (plocal_fileinfo->record_flag == STORAGE_AI_WAIT)
                        {
                            plocal_fileinfo->record_flag = STORAGE_AI_WRITE;           // AI busy
                            dzlog_warn("camera %d, check AI is busy! %d", channel, sendnum);
                        }
                        else
                        {
                            ai_frame.len = 0;
                            zx_set_ai_workmode(MODE_FACE_BODY_RECOGNITION, channel);

                            ret = send_packet_to_ai(AI_CMD_START, channel, &(comm_head->ir_mode));
                            if ( ret <= 0)
                            {
                                plocal_fileinfo->record_flag = STORAGE_AI_WRITE;       // AI模块失败
                            }
                            else
                            {
                                ret = zx_wait_AI_res(AI_REPLY_START, channel, 2);
                                if ( ret != 0)
                                {
                                    plocal_fileinfo->record_flag = STORAGE_AI_WRITE;   // AI模块失败
                                    dzlog_error("get AI_CMD_START(%d) fail: %d\n", channel, ret);
                                }
                            }
                        }
                    }

                if (get_jpg_feature == 0) // 不做图片人脸识别
                {
                    if (plocal_fileinfo->record_flag == STORAGE_AI_RECOGNITION
                     || plocal_fileinfo->record_flag == STORAGE_AI_TRACK
                     || plocal_fileinfo->record_flag == STORAGE_AI_DETECTION )
                    {
                        //if(plocal_fileinfo->frame_num < 5)
                        //{
                        //    dzlog_info("AT recv_frame_No=%d, ai_frame.len=%d", recv_frame_No, ai_frame.len);
                        //}
                        if (ai_frame.len == 0 || ai_frame.len == VIDEO_FRAME_SIZE)
                        {// not pcm data sending
                            if ((ai_frame.len + video->frame_size) <= AI_DATA_SIZE)
                            {
                                memcpy(&ai_frame.buf[ai_frame.len], video->buf, video->frame_size);
                                ai_frame.len += video->frame_size;
                                if (ai_frame.len != VIDEO_FRAME_SIZE)
                                {// 不需要拼接
                                    if (video->frame_type == FRAME_TYPE_I || plocal_fileinfo->frame_num < 3)
                                    {// IPP..或I (因为缺失一些P帧会解花屏)
                                        ai_frame.frame_No = plocal_fileinfo->frame_num;
                                        send_packet_to_ai(AI_CMD_TRANSFORH264, channel, &ai_frame);
                                    }
                                    ai_frame.len = 0;
                                }
                            }
                            else
                            {
                                dzlog_error("I frame %d+%d > 100K\n", ai_frame.len, video->frame_size);
                            }
                        }
                    }
                    else if (plocal_fileinfo->record_flag == STORAGE_AI_END_DETECTION)
                    {
                        plocal_fileinfo->end_time = now_time;
                        dzlog_warn("AI can't find face\n");
                    }

                    if(plocal_fileinfo->ai_warning_time > 0 && now_time >= plocal_fileinfo->ai_warning_time)
                    {
                        plocal_fileinfo->ai_warning_time = 0x7fffffffffffffff;
                        zx_push_message("home_security", "warning", channel);
                    }
                }
#endif
                }
// 缩略图 ----------------------------------------------------------------------------------------
                else if (comm_head->command_id == XM_SNAPSHOT_FRAME )
                {
                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                    if (thumb_data != NULL)
                    {
                        free(thumb_data);   //多次取图，先把以前的free;
                    }
                    thumb_data = zx_Memory_Encode(video->buf, video->frame_size);
                    queue->frame_size = 0;
                    queue->nUseFlag = NOTUSE;
                    break;
                }
// 云存储 ----------------------------------------------------------------------------------------
                if (plocal_fileinfo->sockfd >= 0)
                {
                    sendnum = send(plocal_fileinfo->sockfd, queue->pFrameBuf, queue->frame_size, 0);
                    if (sendnum != queue->frame_size)
                    {
                        if (sendnum == -1)
                        {
                            dzlog_error("pushMuxer sock error %d: %s\n", errno, strerror(errno));
                            close(plocal_fileinfo->sockfd);
                            plocal_fileinfo->sockfd = -1;
                        }
                        else if (sendnum == 0) // disconnect
                        {
                            dzlog_error("pushMuxer sock disconnect!\n");
                            close(plocal_fileinfo->sockfd);
                            plocal_fileinfo->sockfd = -1;
                        }
                        else
                        {
                            dzlog_error("send pushMuxer error, %d!=%d\n", sendnum, queue->frame_size);
                        }
                        if (plocal_fileinfo->fp == NULL)
                        {
                            plocal_fileinfo->end_time = now_time;
                        }
						
						dzlog_info("creat mp4 Fail");
                        upload_log_param(LOG_NORMAL, PUSHMUXER, base_param->hub_info.hub_sn, "Warn", "pushMuxer", "", "creat mp4 Fail");
                    }
                }

// 本地存储 -------------------------------------------------------------------------------------
                if (plocal_fileinfo->fp != NULL)
                {
                  #if ZX_RSA_EN
                  if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
                  {
                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                    if (video->frame_type == FRAME_TYPE_I && aes_key_Plaintext[0] != 0)
                    {
                        memcpy((char *)encrypt_video, (char*)video, VIDEO_HEAD_SIZE);    // 加密前的视频头部
                        memcpy(encrypt_video->buf, video->buf, video->frame_size);       // 加密前的视频
                        ret = aes_encrypt(&aes_key, video->buf, 128, encrypt_video->buf);// 部份数据加密
                        if (ret == 128)
                        {
                            memcpy(encrypt_video->aes_key, aes_key_encrypt, NORMAL_STR_LEN);
                            encrypt_video->aes_key[NORMAL_STR_LEN] = 0;

                            comm_head->sign_code = base_param->hub_info.rsa_pub_id; // 加密的公钥号
                            comm_head->param_len = (sizeof(VIDEO_ENCRYPT) - VIDEO_ENCRYPT_SIZE) + video->frame_size;
                            //dzlog_error("aes_encrypt,rsa_pub_id: %d", comm_head->sign_code);
                            fwrite(queue->pFrameBuf, 1, COMM_HEARD_LEN, plocal_fileinfo->fp);
                            sendnum = fwrite((char *)encrypt_video, 1, comm_head->param_len, plocal_fileinfo->fp);
                            if (sendnum != comm_head->param_len)
                            {
                                plocal_fileinfo->end_time = now_time;
                                dzlog_error("fwrite error %d!=%d\n", sendnum, comm_head->param_len);
                            }
                        }
                      }
                    }
                    #endif
                    if (comm_head->sign_code == NO_SEC_KEY)   //P帧和音频不加密
                    {
                        sendnum = fwrite(queue->pFrameBuf, 1, queue->frame_size, plocal_fileinfo->fp);
                        if (sendnum != queue->frame_size)
                        {
                            plocal_fileinfo->end_time = now_time;
                            dzlog_error("fwrite error %d!=%d\n", sendnum, queue->frame_size);
                        }
                    }
                }

// 并发冲突 --------------------------------------------------------------------------------------------------
                if (hisi_get_camera_clientmark(channel) & (~CLIENT_PIR))
                {   // 在录像时如果实时视频打开，提前结束录像时间
                    dzlog_info("Camera: %d, other client open, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
                else if (gdev_bind_type == XM_CAMERA )
                {
                    dzlog_info("Camera: %d, rebind dev, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
				else if (gdev_bind_type == FLOODLIGHT)
                {
                    dzlog_info("Camera: %d, rebind dev, stop record!", channel);
                    plocal_fileinfo->end_time = now_time;
                }
//结束处理 ----------------------------------------------------------------------------------------------------
                queue->frame_size = 0;
                queue->nUseFlag = NOTUSE;
                if(now_time >= plocal_fileinfo->end_time)
                {
                    int upload_cloud = 0;
                    #if RUN_AI_MODULE
                    if ( plocal_fileinfo->record_flag == STORAGE_AI_RECOGNITION
                      || plocal_fileinfo->record_flag == STORAGE_AI_DETECTION
                      || plocal_fileinfo->record_flag == STORAGE_AI_END_DETECTION)
                    {
                        if (body_face_num == 0 )
                        {
                            //plocal_fileinfo->frame_num = 0; // 不上传，删除文件, (AI测试期间都上报)
                            ai_play_pcm(0, "/media/mmcblk0p1/nopeople.pcm");
                        }
                    }
                    ai_checkface = 0; // 停止发送人脸查询

                    if(plocal_fileinfo->ai_warning_time > 0 && plocal_fileinfo->ai_warning_time != 0x7fffffffffffffff)
                    {
                        zx_push_message("home_security", "warning", channel);
                    }
                    #endif

                    plocal_fileinfo->record_flag = STORAGE_IDLE; // 不再接收stream
                    dzlog_info("storage record end!\n");
					
#if 0
                    zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PIR, 0);
#endif

                    if (plocal_fileinfo->sockfd >= 0)
                    {
                        if (zx_close_mp4_file(plocal_fileinfo->sockfd, plocal_fileinfo->cloudfile, channel) == 0)
                        {
                            upload_cloud = 1;
                        }
                    }
                #if RUN_P2P_SERVER
                if (plocal_fileinfo->frame_num >= FRAME_RATE_720) // 1秒钟以上，太短上传无意义
                {
                    char* file_key = NULL;
                    char* local_path = NULL;
                    char* cloud_path = NULL;
                    int storagetype = LOCAL_STORGE;

                    if (upload_cloud == 1 )
                    {
                        // push to aws
                        file_key = zx_putdata_aws_s3(base_param->hub_info.account_id,
                                                plocal_fileinfo->cloudfile, dev_sn, DEVICE_MONITORING_VIDEO);
                        if (file_key == NULL)
                        {
							dzlog_info("put cloud fail");
                            upload_log_param(LOG_NORMAL, FLOODLIGHT, base_param->hub_info.hub_sn, "Warn", "Camera", "", "put cloud fail");
                        }
                    }

                    if (file_key)
                    {
                        if (plocal_fileinfo->fp != NULL)
                        {
                            local_path = plocal_fileinfo->filename;
                            cloud_path = file_key;
                            storagetype = LOACL_AND_CLOUD;
                        }
                        else
                        {
                            local_path = "";
                            cloud_path = file_key;
                            storagetype = CLOUD_STORGE;
                        }
                    }
                    else
                    {
                        if (plocal_fileinfo->fp != NULL)
                        {
                            local_path = plocal_fileinfo->filename;
                            cloud_path = "";
                            storagetype = LOCAL_STORGE;
                        }
                    }
					
				#if 0
                    ai_upload_stranger_avatar(channel, 1); // 识别结束上传陌生人脸数据
				#endif
				
                    zx_Error err = zx_upload_hub_history_record(base_param->hub_info.account_id,
                                                       base_param->hub_info.hub_sn,
                                                       dev_sn,
                                                       local_path,
                                                       plocal_fileinfo->start_time,
                                                       plocal_fileinfo->end_time,
                                                       plocal_fileinfo->frame_num,
                                                       cloud_path,
                                                       storagetype,
                                                       base_param->hub_info.rsa_pub_id,
                                                       thumb_data,
                                                       plocal_fileinfo->faceid );
                    if (file_key)
                    {
                        free(file_key);
                        file_key = NULL;
                    }
                    if (err.code == 0)
                    {
                        struct filelist *pnode = malloc(sizeof(struct filelist));
                        if(pnode == NULL)
                        {
                            dzlog_error("malloc error!\n");
                            goto storage_write_thread_exit;
                        }
                        pnode->info.flag = 0;
                        memset(pnode->info.filename, 0, sizeof(pnode->info.filename));
                        memcpy(pnode->info.filename, plocal_fileinfo->filename, strlen(plocal_fileinfo->filename));
                        pnode->info.frame_num = plocal_fileinfo->frame_num; // 无用
                        pnode->next = NULL;
                        file_list_add(pnode); // 把文件名加入表尾
                        save_node_link_to_flash(pnode);
                    }
                    else
                    {
                        struct resend_filelist *resend_node = malloc(sizeof(struct resend_filelist));
                        if(resend_node == NULL)
                        {
                            dzlog_error("malloc error!\n");
                            goto storage_write_thread_exit;
                        }
                        resend_node->resend.thumbnail = thumb_data;
                        thumb_data = NULL; // 不要释放缩略图内存,上传成功后再释放
                        resend_node->resend.storagetype = storagetype;
                        resend_node->resend.frame_num = plocal_fileinfo->frame_num;
                        resend_node->resend.start_time = plocal_fileinfo->start_time;
                        resend_node->resend.end_time = plocal_fileinfo->end_time;
                        memcpy(resend_node->resend.faceid, plocal_fileinfo->faceid, sizeof(resend_node->resend.faceid));
                        memcpy(resend_node->resend.filename, plocal_fileinfo->filename, FILENAMEMAX);
                        memcpy(resend_node->resend.cloudfile, plocal_fileinfo->cloudfile, FILENAMEMAX);
                        memcpy(resend_node->resend.dev_sn, dev_sn, SHORT_STR_LEN);
                        resend_node->next = NULL;
                        dzlog_error("waiting resent history_record!\n");
                        resend_filelist_add(resend_node); // 把文件名加入表尾
                    }
                }
                else // 空视频,删除它
                {
                    if (plocal_fileinfo->filename[0] > ' ')
                    {
                        remove(plocal_fileinfo->filename);
                        dzlog_info("No people detected: %s, del", plocal_fileinfo->filename);
                    }
                }
                #endif

                    goto storage_write_thread_exit; // 退出线程
                }
            }
        break;
        }
      }
    }

storage_write_thread_exit:
    if (thumb_data != NULL)
    {
        free(thumb_data);
        thumb_data = NULL;
        dzlog_info("free thumb_data");
    }
    if (encrypt_video)
    {
        free(encrypt_video);
        encrypt_video = NULL;
    }
    if (plocal_fileinfo->record_flag)
    {
		
	#if 0
        zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PIR, 0);
	#endif
	
    }

    //-----可能pipe里面还有数据,清空(O_NONBLOCK)------------------------------------------------
    sendnum = HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE;
    while(sendnum)
    {
        if (read(read_storage_pipe, &queue, sizeof(queue)) <= 0)   // 4字节的指针
        {
           break;
        }
        else if (queue->nUseFlag != NOTUSE)
        {
            queue->frame_size = 0;
            queue->nUseFlag = NOTUSE;
            sendnum--;
        }
    }
    if (sendnum != (HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE))
    {
        dzlog_info("clear storage_pipe: %d", HISI_AUDIO_MAX_QUEUE + HISI_VIDEO_MAX_QUEUE - sendnum);
    }
    //------------------------------------------------------------------------------------------

    close_local_fp_by_channel(plocal_fileinfo);
    //clear_system_file_caches();

    zx_clear_thread_info_by_type(TFCARD_WRITE);
    dzlog_info("storage_write_thread(pid:%d,ch:%d) exit...\n", getpid(), channel);
    return NULL;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
int zx_local_storage_ini( void )
{
    int result = -1;
    int i;
    unsigned char channel;

#if 0
    //Linux性能优化,尽量使用内存(减少swap),同时,尽早flush到外存,早点释放内存给写cache使用。
    zx_do_system("%s", "sysctl -w vm.min_free_kbytes=12800"); // 系统保留给内核用的内存,占系统总内存的10%
    zx_do_system("%s", "sysctl -w vm.vfs_cache_pressure=500"); // 值越大，则linux尽可能早回收内存
    zx_do_system("%s", "sysctl -w vm.swappiness=10"); // swappiness=0的时候表示最大限度使用物理内存
    zx_do_system("%s", "sysctl -w vm.dirty_ratio=10"); // 10%,同步刷脏页,会阻塞
    zx_do_system("%s", "sysctl -w vm.dirty_background_ratio=5"); // 5%,异步刷脏页,不会阻塞
    zx_do_system("%s", "sysctl -w vm.dirty_expire_centisecs=500");// 单位10ms，5秒的数据就算旧，将会刷新磁盘
#endif

    memset(local_fp_list, 0 , sizeof(local_fp_list));		//清零

    for (i = 0; i < MAX_CAMERA_NUM; i++)			//初始化
    {
        local_fp_list[i].channel = -1;
        local_fp_list[i].fp = NULL;
        local_fp_list[i].sockfd = -1;
        local_fp_list[i].storage_pipe[0] = -1;
    }

    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        playctrl_info[i].session_id = -1;		//初始化	
    }

    for (i = 0; i < MAX_SUB1G_CONNECT; i++)
    {
        channel = base_param->dev_param[i].channle_id;
        if (channel < MAX_CAMERA_NUM)
        {
            base_param->dev_param[i].pri_action |= PRI_AI; // 接口没调试完,默认打开AI
            local_fp_list[channel].arming_action = base_param->dev_param[i].pri_action;
        }
    }

    tfcard_free_mb = get_system_tf_free(NULL);			//获取TF卡的容量
    
    if (tfcard_free_mb > 0)
    {
        dzlog_info("Tcard diskInfo, freeDisk=%dMB", tfcard_free_mb);
		
        get_all_link_from_flash();				//?
    }

	//创建pir触发线程
    zx_create_thread(LOW_PRIORITY, pir_schedule_thread, NULL, -1, SCHEDULE_CHECK, -1);

    return result;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
void zx_deinit_local_storage( void )
{
    int i;
    free_all_link_node();
    free_all_resend_filelist();

    for (i = 0; i < MAX_CAMERA_NUM; i++)
    {
        if (local_fp_list[i].storage_pipe[0] >= 0)
        {
            close(local_fp_list[i].storage_pipe[0]);
        }
        if (local_fp_list[i].storage_pipe[1] >= 0)
        {
            close(local_fp_list[i].storage_pipe[1]);
        }
    }

    if (local_rsa_pubkey)
    {
        RSA_free(local_rsa_pubkey);
        local_rsa_pubkey = NULL;
    }
    dzlog_info(" 【deinit_local_storage exit...】");
}

int zx_notify_playback_stop(int session_id, int channel)
{
    ZX_COMMUNICATION_PACKET comm_data;
    PLAYBACK_CONTROL_PARAM *playctrl;
    UINT32 WriteSize = 0;
    int ret;
    int i = 0;

    while(grunning && i<30) // waiting 3s for P2P_MEDIA_CHANNEL send data
    {
        ret = PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &WriteSize, NULL);
        if (ret == ERROR_PPCS_SUCCESSFUL)
        {
            if (WriteSize == 0)
            {
                break;
            }
            i++;
            usleep(100*1000);
        }
        else
        {
            break;
        }
    }

    memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
    playctrl = &comm_data.param_body.palyback_ctrl;

    comm_data.msg_head.head_tag = PAG_HEARD_TAG;
    comm_data.msg_head.command_id = APP_CMD_RECORD_PLAY_CTRL;
    comm_data.msg_head.param_len = sizeof(PLAYBACK_CONTROL_PARAM);
    comm_data.msg_head.version = COMM_VERSION;
    comm_data.msg_head.sign_code = NO_SEC_KEY;
    comm_data.msg_head.channel_id = 0;
    comm_data.msg_head.dev_type = 0x01;

    playctrl->control_type = PLAYBACK_STOP;
    playctrl->fram_num = 0;
    dzlog_info("notify playback stop!\n");
    zx_write_notify(channel, (uint8_t *)&comm_data, COMM_HEARD_LEN + sizeof(PLAYBACK_CONTROL_PARAM), session_id);

    return 0;
}


/********************************************************
    funcname:
    Description:
    intput: argv 文件件全路径
    output:
********************************************************/
void * zx_tfcard_h264_playback_thread(void *argv)
{
    PARAM_SESSION_FILE *psessiion_info = NULL;
    char *file_path = NULL;
    FILE *fp = NULL;
    UINT32 readnum;
    struct timeval tv;
    char *pFrameBuf = NULL;
    ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_FRAME *pvideo = NULL;
    AUDIO_FRAME *paudio = NULL;
    long long pre_timestamp = 0;
    int session_id;
    int channel = -1;

    psessiion_info = (PARAM_SESSION_FILE *)argv;
    session_id = psessiion_info->session_id;
    file_path = psessiion_info->filename;

    dzlog_info("p2p session: %d, read TFcard file = %s", session_id, file_path);

    fp = fopen(file_path, "rb"); // 以只读方式打开文件
    if(fp == NULL)
    {
        dzlog_error(" %s err! exit read thread", file_path);
        return NULL;
    }

    pFrameBuf = (char *)malloc(COMM_HEARD_LEN + sizeof(VIDEO_ENCRYPT));
    if (pFrameBuf == NULL)
    {
        dzlog_error(" malloc err!");
        goto exit_playback_thread;
    }

    readnum = fread(pFrameBuf, 1, COMM_HEARD_LEN, fp);
    if (readnum != COMM_HEARD_LEN)
    {
        goto exit_playback_thread;  // 读空了退出
    }
    comm_head = (ZX_COMM_HEAD *)pFrameBuf;

    if ( comm_head->head_tag == PAG_HEARD_TAG &&
        (comm_head->command_id == APP_CMD_AUDIO_FRAME || comm_head->command_id == APP_CMD_VIDEO_FRAME ))
    {
        channel = comm_head->channel_id;
        readnum = fread(&pFrameBuf[COMM_HEARD_LEN], 1, comm_head->param_len, fp);
        if (readnum != comm_head->param_len)
        {
            goto exit_playback_thread;  // 读空了退出
        }
    }
    else
    {
        dzlog_warn("command_id Error: %d\n", comm_head->command_id);
        goto exit_playback_thread;
    }

    PLAYBACK_CONTROL_PARAM * playctrl = NULL;
    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        if ((playctrl_info[i].session_id == -1) || (playctrl_info[i].session_id == session_id))
        {
            playctrl_info[i].session_id = session_id;
            playctrl_info[i].playctrl.control_type = PLAYBACK_NORMAL;
            playctrl_info[i].playctrl.fram_num = 0;
            playctrl = &playctrl_info[i].playctrl;
            break;
        }
    }

    int * p_p2p_statue = zx_get_p2p_session_handle(session_id);
    if (p_p2p_statue == NULL || playctrl == NULL)
    {
        goto exit_tfcard_read_thread;
    }

    int readframecnt = 0;
    long timeslot = MEDIA_CB_TIME;

    while(grunning)
    {
h264_playback_thread:
        tv.tv_sec = 0;
        tv.tv_usec = timeslot;
        switch(select(0, NULL, NULL, NULL, &tv))
        {
            case -1:
                dzlog_info("select Error!");
                goto exit_playback_thread;
                break;

            case 0:  //TIMEOUT
                {
                    //回放控制
                    if (playctrl->control_type == PLAYBACK_STOP)
                    {
                        goto exit_tfcard_read_thread; // 不用发送 notify
                    }
                    else if (playctrl->control_type == PLAYBACK_PAUSE)
                    {
                        timeslot = 300*1000;
                        goto h264_playback_thread;
                    }

                    if (*p_p2p_statue == -1) // p2p close
                    {
                        dzlog_error("session[%d] disconnect!\n", session_id );
                        goto exit_tfcard_read_thread;
                    }
                    if ((hisi_get_camera_clientmark(channel)&CLIENT_P2P) == CLIENT_P2P)
                    { // 当前camera实时视频打开，关闭回放
                        goto exit_tfcard_read_thread;
                    }

                    if (PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &readnum, NULL) == ERROR_PPCS_SUCCESSFUL)
                    {
                        if (readnum > MAX_P2P_BUF_SIZE)
                        {
                            timeslot = 100*1000;    // 看测试网速,调读数据delay
                            goto h264_playback_thread;
                        }
                    }

                    if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
                    {
                        pvideo = (VIDEO_FRAME *)&pFrameBuf[COMM_HEARD_LEN];
                        pre_timestamp = pvideo->ntimestamp;
                        #if 0
                        zx_video_callback(  pvideo->buf,
                                            pvideo->frame_size,
                                            0,   // stream_type
                                            pvideo->frame_type,
                                            pvideo->frame_rate,
                                            pvideo->width,
                                            pvideo->height,
                                            pvideo->ntimestamp,
                                            -1,
                                            TFCARD_RD_FLAG);
                        #else
                        PPCS_Write(session_id, P2P_MEDIA_CHANNEL, (char *)pFrameBuf, COMM_HEARD_LEN+comm_head->param_len);
                        #endif
                        readframecnt += 1;
                    }
                    else if (comm_head->command_id == APP_CMD_AUDIO_FRAME)
                    {
                        paudio = (AUDIO_FRAME *)&pFrameBuf[COMM_HEARD_LEN];
                        pre_timestamp = paudio->ntimestamp;
                        #if 0
                        zx_audio_callback( paudio->buf,
                                           paudio->frame_size,
                                           paudio->ntimestamp,
                                           -1,
                                           TFCARD_RD_FLAG);
                        #else
                        PPCS_Write(session_id, P2P_MEDIA_CHANNEL, (char *)pFrameBuf, COMM_HEARD_LEN+comm_head->param_len);
                        #endif
                    }

                    // get next frame timestamp-----------------------------------
                    while(grunning)
                    {
                        readnum = fread(pFrameBuf, 1, COMM_HEARD_LEN, fp);
                        if (readnum != COMM_HEARD_LEN)
                        {
                            dzlog_info("readnum = %d", readnum );
                            goto exit_playback_thread;  // 读空了退出
                        }
                        comm_head = (ZX_COMM_HEAD *)pFrameBuf;

                        if ( comm_head->head_tag == PAG_HEARD_TAG &&
                            (comm_head->command_id == APP_CMD_AUDIO_FRAME || comm_head->command_id == APP_CMD_VIDEO_FRAME ))
                        {
                            readnum = fread(&pFrameBuf[COMM_HEARD_LEN], 1, comm_head->param_len, fp);
                            if (readnum != comm_head->param_len)
                            {
                                dzlog_info("readnum = %d", readnum );
                                goto exit_playback_thread;  // 读空了退出
                            }
                        }
                        else
                        {
                            dzlog_warn("command_id Error: %d\n", comm_head->command_id);
                            goto exit_playback_thread;
                        }

                        if (playctrl->control_type == PLAYBACK_DRAG)
                        {
                            if (readframecnt < playctrl->fram_num)
                            {// 快进
                                if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
                                {
                                    readframecnt += 1;
                                    if (readframecnt >= playctrl->fram_num)
                                    {
                                        pvideo = (VIDEO_FRAME *)&pFrameBuf[COMM_HEARD_LEN];
                                        if (pvideo->frame_type == FRAME_TYPE_I)
                                        {
                                            pre_timestamp = pvideo->ntimestamp;
                                            playctrl->control_type = PLAYBACK_NORMAL;
                                            goto calculate_timeslot;
                                        }
                                        else
                                        {
                                            readframecnt -= 1; // 再找 FRAME_TYPE_I
                                        }
                                    }
                                }
                            }
                            else if (readframecnt > playctrl->fram_num)
                            {// 快退
                                fseek(fp, 0, SEEK_SET);
                                readframecnt = 0;
                            }
                            else
                            {
                                playctrl->control_type = PLAYBACK_NORMAL;
                                goto calculate_timeslot;
                            }
                        }
                        else
                        {
                            goto calculate_timeslot;
                        }
                    }
                    if (grunning == 0) goto exit_tfcard_read_thread;
calculate_timeslot:
                    if (comm_head->command_id == APP_CMD_VIDEO_FRAME)
                    {
                        pvideo = (VIDEO_FRAME *)&pFrameBuf[COMM_HEARD_LEN];
                        timeslot = pvideo->ntimestamp - pre_timestamp;
                        if (timeslot > 1)
                        {
                            timeslot *= 1000; //ms->us;
                        }
                        else
                        {
                            timeslot = 1000;
                        }
                    }
                    else if (comm_head->command_id == APP_CMD_AUDIO_FRAME)
                    {
                        paudio = (AUDIO_FRAME *)&pFrameBuf[COMM_HEARD_LEN];
                        timeslot = paudio->ntimestamp - pre_timestamp;
                        if (timeslot > 1)
                        {
                            timeslot *= 1000; //ms->us;
                        }
                        else
                        {
                            timeslot = 1000;
                        }
                    }
                    //dzlog_info("play frameNo = %d, timeslot = %d, ppcs buf[%d]", readframecnt, timeslot, readnum);
                }
                break;

            default:
                break;
        }
    }

exit_playback_thread:
    zx_notify_playback_stop(session_id, channel);

exit_tfcard_read_thread:
    if(fp != NULL)
    {
        fclose(fp);
    }
    if (pFrameBuf != NULL)
    {
        free(pFrameBuf);
        pFrameBuf = NULL;
    }
    zx_clear_playclt_by_session(session_id);
    zx_clear_thread_info_by_type(RECORD_SEND);
    dzlog_info("zx_tfcard_h264_playback_thread exit\n");
    return NULL;
}


int zx_notify_mp4_upload_start(int session_id, unsigned int size)
{
    ZX_COMMUNICATION_PACKET comm_data;
    memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
    PLAYBACK_CONTROL_PARAM *playctrl = &comm_data.param_body.palyback_ctrl;

    comm_data.msg_head.head_tag = PAG_HEARD_TAG;
    comm_data.msg_head.command_id = APP_CMD_CONVERT_MP4_OK;
    comm_data.msg_head.param_len = sizeof(PLAYBACK_CONTROL_PARAM);
    comm_data.msg_head.version = COMM_VERSION;
    comm_data.msg_head.sign_code = NO_SEC_KEY;
    comm_data.msg_head.channel_id = 0;
    comm_data.msg_head.dev_type = 0x01;

    playctrl->control_type = PLAYBACK_NORMAL;
    playctrl->fram_num = size;
    dzlog_info("upload MP4 size=%d, start!", size);
    zx_write_notify(0, (uint8_t *)&comm_data, COMM_HEARD_LEN + sizeof(PLAYBACK_CONTROL_PARAM), session_id);

    return 0;
}

int zx_notify_mp4_upload_finish(int session_id)
{
    ZX_COMM_HEAD comm_data;
    memset(&comm_data, 0, sizeof(ZX_COMM_HEAD));

    comm_data.head_tag = PAG_HEARD_TAG;
    comm_data.command_id = APP_CMD_DOENLOAD_FINISH;
    comm_data.param_len = 0;
    comm_data.version = COMM_VERSION;
    comm_data.sign_code = NO_SEC_KEY;
    comm_data.channel_id = 0;
    comm_data.dev_type = 0x01;

    dzlog_info("notify MP4 upload finish!");
    zx_write_notify(0, (uint8_t *)&comm_data, COMM_HEARD_LEN, session_id);

    return 0;
}

/********************************************************
    funcname: 本地H264转为MP4
    Description: 因为不能解密,业务流程改为上传加密文件
    intput: argv 文件件全路径
    output:
********************************************************/
void * zx_h264tomp4_thread(void *argv)
{
    PARAM_SESSION_FILE *psessiion_info = NULL;
    FILE *fp_dat = NULL;
    UINT32 readnum;
    UINT32 writebuf;
    struct timeval tv;
    char *pFrameBuf = NULL;
    ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_ENCRYPT *pvideo = NULL;

    int session_id;
    int ret;

    psessiion_info = (PARAM_SESSION_FILE *)argv;
    session_id = psessiion_info->session_id;
    dzlog_info("session:%d, read file = %s", session_id, psessiion_info->filename);

    fp_dat = fopen(psessiion_info->filename, "rb"); // 以只读方式打开文件
    if(fp_dat == NULL)
    {
        dzlog_error("read  %s err! exit read thread", psessiion_info->filename);
        goto exit_h264tomp4_thread;
    }

    pFrameBuf = (char *)malloc(COMM_HEARD_LEN + sizeof(VIDEO_ENCRYPT));
    if (pFrameBuf == NULL)
    {
        dzlog_error(" malloc err!");
        goto exit_h264tomp4_thread;
    }

    int * p_p2p_statue = zx_get_p2p_session_handle(session_id);
    if (p_p2p_statue == NULL)
    {
        goto exit_h264tomp4_thread;
    }

    // 计算文件大小
    fseek(fp_dat, 0L, SEEK_END);
    readnum = ftell(fp_dat);
    fseek(fp_dat, 0L, SEEK_SET);
    if (readnum)
    {
        zx_notify_mp4_upload_start(session_id, readnum);
    }
    else
    {
        dzlog_error("file: %s size=0! exit ...", psessiion_info->filename);
        goto exit_h264tomp4_thread;
    }

    // 发送加密文件
    readnum = 1;
    writebuf = 1;
    h264_download = 1;

    tv.tv_sec = 0;
    tv.tv_usec = 0;
    while(grunning && h264_download)
    {

Check_Buffer_again:
        if (*p_p2p_statue == -1)
        {
            dzlog_error("p2p disconnect!\n");
            goto exit_h264tomp4_thread;
        }
        switch(select(0, NULL, NULL, NULL, &tv))
        {
            case -1:
                goto exit_h264tomp4_thread;
                break;

            case 0:
            {
                ret = PPCS_Check_Buffer(session_id, P2P_DOWNLOAD_CHANNEL, &writebuf, NULL);
                if (ret == ERROR_PPCS_SUCCESSFUL)
                {
                    if (writebuf > MAX_P2P_BUF_SIZE)
                    {
                        tv.tv_sec = 0;
                        tv.tv_usec = 100*1000;
                        goto Check_Buffer_again;
                    }
                    else if (writebuf == 0 && readnum == 0) // 发送完成
                    {
                        dzlog_info("upload mp4 end!!!");
                        sleep(1);
                        goto send_mp4_stop;
                    }
                }
                else
                {
                    dzlog_error("PPCS_Check_Buffer err=%d, %s\n", ret, get_p2p_err_info(ret));
                    goto exit_h264tomp4_thread;
                }

                readnum = fread(pFrameBuf, 1, COMM_HEARD_LEN, fp_dat);
                if (readnum == COMM_HEARD_LEN)
                {
                    comm_head = (ZX_COMM_HEAD *)pFrameBuf;
                    if ( comm_head->head_tag == PAG_HEARD_TAG &&
                        (comm_head->command_id == APP_CMD_AUDIO_FRAME || comm_head->command_id == APP_CMD_VIDEO_FRAME ))
                    {
                        readnum = fread(&pFrameBuf[COMM_HEARD_LEN], 1, comm_head->param_len, fp_dat);
                        if (readnum == comm_head->param_len)
                        {
                            ret = zx_download_data_send(pFrameBuf, COMM_HEARD_LEN+comm_head->param_len, session_id);
                            if (ret < ERROR_PPCS_SUCCESSFUL)
                            {
                                dzlog_error("mp4 data upload fail\n");
                            }
                        }
                        #if 0 // test only
                        if (comm_head->sign_code)
                        {
                            pvideo = (VIDEO_ENCRYPT *)&pFrameBuf[COMM_HEARD_LEN];
                            dzlog_info("upload sign_code: %d",comm_head->sign_code);
                        }
                        #endif
                    }
                    else
                    {
                        dzlog_warn("command_id Error: %d\n", comm_head->command_id);
                    }
                }
                break;
            }

            default:
            {
                break;
            }
        }
    }

send_mp4_stop:
    // 发达mp4 stop
    zx_notify_mp4_upload_finish(session_id);

exit_h264tomp4_thread:

    if(fp_dat != NULL)
    {
        fclose(fp_dat);
        fp_dat = NULL;
    }
    if (pFrameBuf != NULL)
    {
        free(pFrameBuf);
        pFrameBuf = NULL;
    }
    h264_download = 0;
    zx_clear_thread_info_by_type(RECORD_TO_MP4);
    dzlog_info("h264tomp4_thread exit\n");
    return NULL;
}

static void * pir_schedule_thread(void *argv)
{
    struct timeval tv;
    struct tm *ptm = NULL;
    int i,j;
    time_t curtime,schtime;

    DEV_SCHEDULE *pschedule = NULL;
    LOOP_SCHEDULE *ploop_schedule;
    BS_ONCE_SCHEDULE *ponce_schedule;
    int action;
    unsigned char channel;
	
    dzlog_info("pir_schedule_thread, PID %d", getpid());

    while(grunning)
    {
        tv.tv_sec = SCHEDULE_DETCTION;				//60
        tv.tv_usec = 0;

        switch(select(0, NULL, NULL, NULL, &tv))
        {
            case -1:
                dzlog_info("select Error!");
                break;
            case 0:
            {
                //#if RUN_AI_MODULE
				#if 0
                zx_init_ai_model(); // AI异常时把AI重新启动
                #endif

                // 检测布防撤防配置--------------------------------------------------------------------
                
                for (i = 0; i < MAX_CAMERA_NUM; i++) // MAX_SUB1G_CONNECT
                {
					
                    if ((base_param->dev_param[i].pri_action&0x03) != PRI_IDLE)
                    {
                        continue;   //当前camera手动管理
                    }

                    channel = base_param->dev_param[i].channle_id;
					
                    if (channel >= MAX_CAMERA_NUM)
                    {
                        continue;  //无效
                    }

                    pschedule = (DEV_SCHEDULE *)base_param->dev_param[i].dev_schedule;
                    action = -1;
					
                    if (pschedule->loop_sch_count && pschedule->loop_sch_count <= LOOP_SCH_COUNT)
                    {
                        curtime = time(NULL);			//当前时间
                        ptm = localtime(&curtime);		//本地时间

                        for (j=0; j<pschedule->loop_sch_count; j++ ) // 有多少个时间段?
                        {
                            ploop_schedule = &pschedule->loop_sch[j];

                            if (ploop_schedule->tm_weekday == ptm->tm_wday)
                            {
                                ptm->tm_min = ploop_schedule->start_m;
                                ptm->tm_hour = ploop_schedule->start_h;
                                schtime = mktime(ptm); // 开始时间
                                
                                if (curtime < schtime)
                                {
                                    action = pschedule->defult_action; // 还没有到时间
                                    //dzlog_info("loop[%d] schedule strart at: hour=%d, min=%d", j, ptm->tm_hour, ptm->tm_min);
                                }
                                else if (curtime >= schtime)
                                {
                                    ptm->tm_min = ploop_schedule->end_m;
                                    ptm->tm_hour = ploop_schedule->end_h;
                                    schtime = mktime(ptm);
									
                                    if (curtime < schtime) // 时间段内
                                    {
                                        action = ploop_schedule->action;
                                        //dzlog_info("loop[%d] schedule stop at: hour=%d, min=%d", j, ptm->tm_hour, ptm->tm_min);
                                        break; // 不再找后面的时间段
                                    }
                                    else
                                    {
                                        action = pschedule->defult_action;
                                        //dzlog_info("loop[%d] schedule stop!", j);
                                    }
                                }
                            }
                        }
                    }

                    if (action == -1)
                    {
                        if (pschedule->once_sch_count && pschedule->once_sch_count <= ONCE_SCH_COUNT)
                        {
                            curtime = time(NULL);
                            ptm = localtime(&curtime);

                            for (j=0; j<pschedule->once_sch_count; j++ )
                            {
                                ponce_schedule = (BS_ONCE_SCHEDULE *)&pschedule->once_sch[j];
                                schtime = ponce_schedule->start_time;
                                if (curtime < schtime )
                                {
                                    action = pschedule->defult_action;
                                    //dzlog_info("once[%d] schedule < start", j);
                                }
                                else if (curtime >= schtime)
                                {
                                    schtime = ponce_schedule->end_time;
                                    if (curtime < schtime)
                                    {
                                        action = ponce_schedule->action;
                                        //dzlog_info("once[%d] schedule start...", j);
                                        break; // 不再找后面的时间段
                                    }
                                    else
                                    {
                                        action = pschedule->defult_action;
                                        //dzlog_warn("once[%d] schedule stop!", j);
                                    }
                                }
                            }
                        }
                    }

                    if (action == -1)
                    {
                        action = pschedule->defult_action;
                    }
                    local_fp_list[channel].arming_action = (local_fp_list[channel].arming_action&0xFC)|action;
                    //dzlog_warn("arming_action = %d, %d", local_fp_list[channel].arming_action, action);
                }

           }
           break;

            default:
                break;
        }
    }
    dzlog_info("pir_schedule_thread exit......");
    return NULL;
}

/********************************************************
    funcname:
    Description:
    intput:
    output:
********************************************************/
void zx_resend_hub_history_record( void )
{
    if (resend_list_head != NULL)
    {
        zx_Error err;
        err.code = -1;
        LOCAL_RESEND_INFO * resend_fileinfo = &resend_list_head->resend;
        err = zx_upload_hub_history_record(base_param->hub_info.account_id,
                                           base_param->hub_info.hub_sn,
                                           resend_fileinfo->dev_sn,
                                           resend_fileinfo->filename,
                                           resend_fileinfo->start_time,
                                           resend_fileinfo->end_time,
                                           resend_fileinfo->frame_num,
                                           resend_fileinfo->cloudfile,
                                           resend_fileinfo->storagetype,
                                           base_param->hub_info.rsa_pub_id,
                                           resend_fileinfo->thumbnail,
                                           resend_fileinfo->faceid );
        if (err.code == 0)
        {
            //更新文件记录
            struct filelist *pnode = malloc(sizeof(struct filelist));
            if(pnode != NULL)
            {
                pnode->info.flag = 0;
                memset(pnode->info.filename, 0, sizeof(pnode->info.filename));
                memcpy(pnode->info.filename, resend_fileinfo->filename, strlen(resend_fileinfo->filename));
                pnode->info.frame_num = resend_fileinfo->frame_num; // 无用
                pnode->next = NULL;
                file_list_add(pnode); // 把文件名加入表尾
                save_node_link_to_flash(pnode);
                dzlog_info("del resend msg......");
                resend_filelist_del();
            }
        }
    }
}

