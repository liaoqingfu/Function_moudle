
#include "push_stream.h"
#include "hal_video.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>



#if RUN_PUSH_STREAM

static STREAM_CONNECT_INFO gStream_info[MAX_CAMERA_NUM];
extern unsigned char grunning;

static int maxint(int a, int b)
{
	return (a>b) ? a : b;
}

STREAM_CONNECT_INFO *zx_get_stream(int channel)
{
	int i 										= 0;
	
	for (i = 0;i < MAX_CAMERA_NUM; i ++)
	{
		if(gStream_info[i].invalid && (gStream_info[i].channel == channel))
		{
			return &gStream_info[i];
		}
	}

	return NULL;
}


int zx_stream_send_start_msg(STREAM_CONNECT_INFO * ctx,char *fileName)
{
	if(ctx == NULL || NULL == fileName)
	{
		dzlog_error("stream param ctx is NULL");
		return -1;
	}

	ZX_COMMUNICATION_PACKET msg_packet;
	memset(&msg_packet,0,sizeof(ZX_COMMUNICATION_PACKET));

	ZX_COMM_HEAD *comm_head 	= (ZX_COMM_HEAD *)&msg_packet;
	comm_head->head_tag 		= PAG_HEARD_TAG;
	comm_head->command_id 		= APP_CMD_STREAM_MSG;
	comm_head->param_len 		= 2 + strlen(fileName) + 1;
	printf("fileName:%s,strlen:%d,param_len:%d\n",fileName,strlen(fileName),comm_head->param_len);
	comm_head->version 			= COMM_VERSION;
	comm_head->channel_id 		= ctx->channel;
	comm_head->sign_code 		= NO_SEC_KEY;

	ZX_STREAN_MSG *msg 			= (ZX_STREAN_MSG *)(&msg_packet.param_body.stream_msg);
	strncpy(msg->fileName,fileName,MAX_FILE_NAME - 1);
	msg->channel 				= ctx->channel;
	msg->stream_type			= AV_STREAM_START;

	int sendLen = COMM_HEARD_LEN + comm_head->param_len;
	int readlen = send(ctx->sendFd, &msg_packet,sendLen, 0);
	if ( readlen == sendLen ) 
	{
		dzlog_info("send start stream msg ok!");
	}
	else
	{
		return -1;
	}

	return 0;
	
}


int zx_stream_send_video_frame(int channel,char *buff)
{
	if(  NULL == buff)
	{
		dzlog_error("video frame param is NULL [buff:%#x]",(unsigned int)buff);
		return -1;
	}
	
	STREAM_CONNECT_INFO *info 		= zx_get_stream(channel);
	QUEUE 				*vqueue 	= NULL;
	int result						= 0;
	
	if(info)
	{
		if(info->iControlThreadRun)
		{
			info->iVideoCallBackRunState = 1;
			vqueue = info->video_queue;
			if(vqueue)
			{
				if (query_queue(vqueue->pNextQueue, &vqueue, NOTUSE, MAXVIDEOQUEUE))
				{
					ZX_COMM_HEAD *comm_head 	= (ZX_COMM_HEAD *)vqueue->pFrameBuf; 
					memset(comm_head, 0, COMM_HEARD_LEN);
					comm_head->head_tag 		= PAG_HEARD_TAG;
					comm_head->command_id		= APP_CMD_VIDEO_FRAME;

					comm_head->param_len		= sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + info->videoInfo.frame_size;
					comm_head->version			= COMM_VERSION;
					comm_head->channel_id		= channel;
					comm_head->sign_code		= NO_SEC_KEY;
					comm_head->dev_type         = FLOODLIGHT;

					VIDEO_FRAME *video			= (VIDEO_FRAME *)&vqueue->pFrameBuf[COMM_HEARD_LEN];
					video->frame_rate			= info->videoInfo.frame_rate;
					video->frame_size			= info->videoInfo.frame_size;
					video->width				= info->videoInfo.width;
					video->height				= info->videoInfo.height;
					video->frame_type			= info->videoInfo.frame_type;
					video->ntimestamp			= info->videoInfo.ntimestamp;
					
					memcpy(video->buf, buff, info->videoInfo.frame_size);
					
					vqueue->frame_size			= COMM_HEARD_LEN + comm_head->param_len;	
					vqueue->nUseFlag			= ADDTOQUEUE;
					result						= write(info->video_pipe[1], &vqueue, sizeof(vqueue));					
				}
				else
				{
					dzlog_error("QUEUE FULL......");
				}
				
			}
			
		}
		
		info->iVideoCallBackRunState = 0;
		
	}

	return 0;
	
}


int zx_stream_send_audio_frame(int channel,AUDIO_FRAME *audioFrame)
{
	if( NULL == audioFrame )
	{
		dzlog_error("audio frame param is NULL");
		return -1;
	}

	if(audioFrame->frame_size > AUDIO_FRAME_SIZE)
	{
		dzlog_error("audio frame size:%d is too big",audioFrame->frame_size);
		return -1;
	}
	
	STREAM_CONNECT_INFO *info 		= zx_get_stream(channel);
	int result						= 0;
	
	if(info)
	{
		if(info->iControlThreadRun)
		{
			info->iAudioCallBackRunState = 1;
			QUEUE *aqueue = (QUEUE *)info->audio_queue;
			if (aqueue)
			{
				if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE))
				{
					ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf; 
					memset(comm_head, 0, COMM_HEARD_LEN);
					comm_head->head_tag 	= PAG_HEARD_TAG;
					comm_head->command_id   = APP_CMD_AUDIO_FRAME;
					comm_head->param_len 	= sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + audioFrame->frame_size;
					comm_head->version 		= COMM_VERSION;
					comm_head->channel_id 	= audioFrame->channel;
					comm_head->sign_code 	= NO_SEC_KEY;
					//comm_head->dev_type     = XM_CAMERA;
					comm_head->dev_type     = FLOODLIGHT;

					AUDIO_FRAME *audio 		= (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];
					audio->frame_size 		= audioFrame->frame_size;
					audio->channel 			= audioFrame->channel;
					audio->ntimestamp 		= audioFrame->ntimestamp;	
					//audio->ntimestamp 		= zx_LocalTime_ms();
					
					memcpy(audio->buf, audioFrame->buf, audioFrame->frame_size);
					
					aqueue->frame_size 		= COMM_HEARD_LEN + comm_head->param_len; 
					aqueue->nUseFlag 		= ADDTOQUEUE;
					result 					= write(info->audio_pipe[1], &aqueue, sizeof(aqueue));
					
				}
				else
				{
					dzlog_error("QUEUE FULL......");
				}
				
			}
			
		}
		
		info->iAudioCallBackRunState = 0;
		
	}

	return 0;
	
}

int zx_stream_send_stop_msg(STREAM_CONNECT_INFO *ctx)
{
	if(ctx == NULL)
	{
		dzlog_error("stream param ctx is NULL");
		return -1;
	}

	ZX_COMMUNICATION_PACKET msg_packet;
	memset(&msg_packet,0,sizeof(ZX_COMMUNICATION_PACKET));
	
	ZX_COMM_HEAD *comm_head 	= (ZX_COMM_HEAD *)&msg_packet;
	comm_head->head_tag 		= PAG_HEARD_TAG;
	comm_head->command_id 		= APP_CMD_STREAM_MSG;
	comm_head->param_len 		= 2;
	comm_head->version 			= COMM_VERSION;
	comm_head->channel_id 		= (unsigned char)ctx->channel;
	comm_head->sign_code 		= NO_SEC_KEY;

	ZX_STREAN_MSG *msg 			= (ZX_STREAN_MSG *)(&msg_packet.param_body.stream_msg);
	msg->channel 				= ctx->channel;
	msg->stream_type			= AV_STREAM_STOP;

	int sendLen = COMM_HEARD_LEN + comm_head->param_len;
	int readlen = send(ctx->sendFd, &msg_packet,sendLen, 0);
	if ( readlen == sendLen ) 
	{
		dzlog_info("send stop stream msg ok!");
	}
	else
	{
		//return -1;
	}
	
	return 0;
	
}


int zx_close_stream(int channel)
{
	STREAM_CONNECT_INFO *info 		= zx_get_stream(channel);
	int 				ret   		= 0;
	int 				iTryCnt		= 0;
	
	if(info)
	{
		do
		{
			info->iControlThreadRun = 0;
			usleep(100);
		}while ( (  info->iSendThreadRunState 	 != 0  || 
					info->iVideoCallBackRunState != 0  || 
					info->iAudioCallBackRunState != 0  ) && (iTryCnt++ < 1000) );
		
		info->invalid = 0;
		
		ret = zx_stream_send_stop_msg(info);
		if(ret < 0)
		{
			dzlog_error("send stop msg failed");
			return -1;
		}
		
		if(info->audio_queue)
		{
			clear_queue(info->audio_queue,MAXAUDIOQUEUE);
		}
		
		if(info->video_queue)
		{
			clear_queue(info->video_queue,MAXVIDEOQUEUE);
		}
		
		if(info->sendFd >= 0)
		{
			dzlog_info("close client fd : %d",info->sendFd);
			close(info->sendFd);
			info->sendFd = -1;
		}

		if(info->video_pipe[0] >= 0)
		{
			close(info->video_pipe[0]);
			info->video_pipe[0] = -1;
		}

		if(info->video_pipe[1] > 0)
		{
			close(info->video_pipe[1]);
			info->video_pipe[1] = -1;
		}

		if(info->audio_pipe[0] >= 0)
		{
			close(info->audio_pipe[0]);
			info->audio_pipe[0] = -1;
		}

		if(info->audio_pipe[1])
		{
			close(info->audio_pipe[1]);
			info->audio_pipe[1] = -1;
		}

		memset(info->szFileName,0,sizeof(info->szFileName));
		memset(info->iPushStreamState,0,sizeof(info->iPushStreamState));
		
		dzlog_info("close camera channel=%d...", channel);
		
	}
	
	return 0;
	
}

void *zx_send_thread(void *arg)
{
	int readlen 					= 0;
	int ret  						= 0;
	sem_t *psem						= NULL;
	
	char fileName[MAX_FILE_NAME]	= "";
	void **param					= (void **)arg;
	
	STREAM_CONNECT_INFO * ctx 		= (STREAM_CONNECT_INFO  *)param[0];
	strncpy(fileName,(char *)param[1],MAX_FILE_NAME -1 );
	psem							= (sem_t *)param[2];
	
	int sock						= ctx->sendFd;
	int channel						= ctx->channel;

	sem_post(psem);
	pthread_detach(pthread_self());
	
	fd_set rfds;
	int *ivideo_fdp 			= NULL;
	int *iaudio_fdp 			= NULL;
    int imax_fdp 				= -1;

	QUEUE * queue 				= NULL;
	QUEUE * audio_queue 		= NULL;
	
	struct timeval tv; 

	iaudio_fdp 					= ctx->audio_pipe;
	ivideo_fdp 					= ctx->video_pipe;
	imax_fdp   					= maxint(iaudio_fdp[0], ivideo_fdp[0]);
	ctx->iSendThreadRunState	= 1;

	ret = zx_stream_send_start_msg(ctx,fileName);
	if(ret < 0)
	{
		dzlog_error("send start msg failed");
		return NULL;
	}
	
	while (grunning)
	{
	
		if(0 == ctx->iControlThreadRun)	
		{
			dzlog_info("iControlThreadRun is be 0");
			break;
		}
		
		FD_ZERO(&rfds);
		FD_SET(iaudio_fdp[0], &rfds);
		FD_SET(ivideo_fdp[0], &rfds);

		tv.tv_sec  					= 0;    
    	tv.tv_usec 					= 5000; 
		
		switch(select(imax_fdp + 1, &rfds, NULL, NULL, &tv))
		{
			case -1: 
				goto exit; 

			case 0:
			{
				break;
			}
 
			default: 
			{
				if(FD_ISSET(ivideo_fdp[0], &rfds)) 
				{
					FD_CLR(ivideo_fdp[0], &rfds);
					read(ivideo_fdp[0], &queue, sizeof(queue));
					readlen 			= send(sock, queue->pFrameBuf, queue->frame_size, 0);				

/*					ZX_COMM_HEAD *head	= (ZX_COMM_HEAD *)queue->pFrameBuf;
					if ( readlen == queue->frame_size )
					{
						//dzlog_info("send video ok, command_id:%d ,send size:%d",head->command_id,readlen);
						//usleep(5);
					}
					else
					{
						//dzlog_info("send video failed, command_id:%d ,send size:%d",head->command_id,readlen);
					}
*/
					queue->frame_size = 0;
					queue->nUseFlag = NOTUSE;
				}
				else if(FD_ISSET(iaudio_fdp[0], &rfds))
				{					
					FD_CLR(iaudio_fdp[0], &rfds);
					read(iaudio_fdp[0], &audio_queue, sizeof(audio_queue));
					readlen 			= send(sock, audio_queue->pFrameBuf, audio_queue->frame_size, 0);

/*					ZX_COMM_HEAD *head	= (ZX_COMM_HEAD *)audio_queue->pFrameBuf;
					if ( readlen == audio_queue->frame_size ){
						//dzlog_info("send audio ok, command_id:%d ,send size:%d",head->command_id,readlen);
						//usleep(5);
					}
					else{
						//dzlog_info("send audio failed, command_id:%d ,send size:%d",head->command_id,readlen);
					}
*/
					audio_queue->frame_size = 0;
					audio_queue->nUseFlag = NOTUSE;
				
				}
				
				break;
			}
			
		}  
		
	}

exit:
	dzlog_info("============ send thread quit ============");
	ctx->iSendThreadRunState		= 0;
	zx_close_stream(ctx->channel);
	
#if 0
	zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PUSH, 0);
#endif

	return NULL;
}

int connect_video_server(void)
{
	int sockfd;
	struct sockaddr_in dest_addr;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
	{
		dzlog_error("create socket error");
		return -1;
	}

    //阻塞式发送
	int nSendBuf = COMM_HEARD_LEN+sizeof(VIDEO_FRAME);
	if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const char*)&nSendBuf, sizeof(int)) < 0)
	{
		dzlog_error("setsockopt error");
		close(sockfd);
		return -1;
	}

	bzero(&dest_addr,sizeof(dest_addr));
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(9000);
	inet_pton(AF_INET,IP_ADDR_REMOTE, &dest_addr.sin_addr);
	if (connect(sockfd, (struct sockaddr*)&dest_addr, sizeof(dest_addr)) != 0)
	{
		dzlog_error("connect error");
		close(sockfd);
		return -1;
	}

	dzlog_info("connect the server=%s success",IP_ADDR_REMOTE);
	return sockfd;

}


int zx_start_stream(int channel,char *url)
{
	int i 										= 0;
	int result									= 0;
	int sock									= 0;
	int invilid									= 0;
	STREAM_CONNECT_INFO *info					= NULL;
	STREAM_PROTOCAL_TYPE stream_type			= ZX_STREAM_TYPE_NONE;

	void *args[3];
	sem_t sem;
	sem_init(&sem, 0, 0);

	if(channel < 0 || channel >= MAX_CAMERA_NUM)
	{
		dzlog_error("channel=%d is error",channel);
		return -1;
	}	

	if( NULL == url )
	{
		dzlog_error("url is NULL");
		return -1;
	}
	
	dzlog_info("################## channel %d, url:%s",channel,url);
	
	if( ZX_STREAM_TYPE_NONE == (stream_type = zx_stream_get_push_type(url)))
	{
		dzlog_error("stream type is invilid");
		return -1;
	}
	
	if( NULL != (info = zx_get_stream(channel)) )
	{
		zx_stream_add_new_push(info,url);
		
		dzlog_info("use channel=%d stream ctx",channel);
		return 0;
	}
#if 0
	if(zx_open_camera(channel, CLIENT_PUSH) < 0)
	{
		dzlog_error("open stream channel failed err",channel);
	}
#endif

#if 0
	if(hal_open_camera() != 0)			//打开摄像头
	{
		dzlog_error("open stream %d channel failed ",channel);
		goto exit;
	}
#endif
	//dzlog_info("open camera ok");
	
	for (i = 0;i < MAX_CAMERA_NUM; i ++)
	{	
		info 									= &gStream_info[i];
		invilid 								= gStream_info[i].invalid;
		
		if(invilid == 0)
		{
			info->channel						= channel;
			info->iControlThreadRun 			= 1;

			sock = connect_video_server();
			if (sock < 0) 
			{
				dzlog_error("connect the server=%s error",IP_ADDR_REMOTE);
				goto exit;
			}

			info->sendFd = sock;
			
			result = pipe(info->audio_pipe);
			if (result != 0) 
			{
				dzlog_error("audio_pipe create fail... error=%d", errno);
				goto exit;
			}
			
			result = pipe(info->video_pipe);
			if (result != 0)
			{
				dzlog_error("video_pipe create fail... error=%d", errno);
				goto exit;
			}
			
			dzlog_info("send sockfd=%d audio_pipe[0]=%d audio_pipe[1]=%d vido_pipe[0]=%d vido_pipe[1]=%d......",\
											 sock,info->audio_pipe[0], info->audio_pipe[1], \
											 info->video_pipe[0], info->video_pipe[1]);

			if( zx_stream_set_push_type(info,url) < 0 )
			{
				dzlog_error("stream media type is unrecognize");
				goto exit;
			}
			
			if (info->video_queue == NULL)
			{
				info->video_queue = (void *)create_queue(MAXVIDEOQUEUE, COMM_HEARD_LEN + sizeof(VIDEO_FRAME));
				info->audio_queue = (void *)create_queue(MAXAUDIOQUEUE, COMM_HEARD_LEN + sizeof(AUDIO_FRAME));
			}
			else
			{
				clear_queue(info->video_queue, MAXVIDEOQUEUE);
				clear_queue(info->audio_queue, MAXAUDIOQUEUE);
			}

			args[0] = (void *)info;
			args[1] = (void *)url;
			args[2] = (void *)&sem;
			result = zx_create_thread(LOW_PRIORITY, zx_send_thread, args, -1, STREAM_SEND, info->channel);
			
			if(result > 0){
				sem_wait(&sem);
				sem_destroy(&sem);
			}
			
			info->invalid						= 1;
			
			break;
			
		}		
	}

	return 0;	

exit:
	info->iSendThreadRunState		= 0;
	zx_close_stream(info->channel);
	
#if 0
	zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_PUSH, 0);
#endif
	
	return -1;
	
}


int zx_stream_add_new_push(STREAM_CONNECT_INFO * ctx,char *url)
{
	STREAM_PROTOCAL_TYPE stream_type	= ZX_STREAM_TYPE_NONE;

	if(NULL == ctx || NULL == url )
	{
		dzlog_error("stream param is NULL");
		return -1;
	}

	if( ZX_STREAM_TYPE_NONE == (stream_type = zx_stream_get_push_type(url)))
	{
		dzlog_error("stream type is invilid");
		return -1;
	}
	
	if(ctx->iPushStreamState[stream_type])
	{
		dzlog_info("stream type :%d is current push already",(int)stream_type);
		return 0;
	}
	
	ZX_COMMUNICATION_PACKET msg_packet;
	memset(&msg_packet,0,sizeof(ZX_COMMUNICATION_PACKET));
	
	ZX_COMM_HEAD *comm_head 	= (ZX_COMM_HEAD *)&msg_packet;
	comm_head->head_tag 		= PAG_HEARD_TAG;
	comm_head->command_id 		= APP_CMD_STREAM_MSG;
	comm_head->param_len 		= 2 + strlen(url) + 1;
	comm_head->version 			= COMM_VERSION;
	comm_head->channel_id 		= ctx->channel;
	comm_head->sign_code 		= NO_SEC_KEY;
	
	ZX_STREAN_MSG *msg 			= (ZX_STREAN_MSG *)(&msg_packet.param_body.stream_msg);
	strncpy(msg->fileName,url,MAX_FILE_NAME - 1);
	msg->channel 				= ctx->channel;
	msg->stream_type			= AV_STREAM_ADD;
	
	int sendLen = COMM_HEARD_LEN + comm_head->param_len;
	int readlen = send(ctx->sendFd, &msg_packet,sendLen, 0);
	if ( readlen == sendLen )
	{
		zx_stream_set_push_type(ctx, url);
		dzlog_info("send add new stream msg ok,url:%s",url);
	}
	else
	{
		return -1;
	}
	
	return 0;
	
}


int zx_stream_get_push_type(char *url)
{
	STREAM_PROTOCAL_TYPE stream_type	= ZX_STREAM_TYPE_NONE;

	if( NULL == url)
	{
		dzlog_error("param is NULL");
		return -1;
	}
	
	if(0 ==  strncmp(url,"rtmp",4))
	{
		stream_type = ZX_STREAM_TYPE_RTMP;
	}
	else if(0 ==  strncmp(url,"rtsp",4) && 
		   (0 == strncmp(url + 7,"127.0.0.1",9)) )
	{
		stream_type = ZX_STREAM_TYPE_RTSP_LAN;
	}
	else if(0 ==  strncmp(url,"rtsp",4) && 
		   (0 != strncmp(url + 7,"127.0.0.1",9)))
	{
		stream_type = ZX_STREAM_TYPE_RTSP_WAN;
	}
	else if(0 ==  strncmp(url + strlen(url) - 3,"mp4",3))
	{
		stream_type = ZX_STREAM_TYPE_MP4;
	}

	return stream_type;
	
}


int zx_stream_set_push_type(STREAM_CONNECT_INFO *ctx,char *url)
{
	STREAM_PROTOCAL_TYPE stream_type	= ZX_STREAM_TYPE_NONE;
	
	if(NULL == ctx || NULL == url)
	{
		dzlog_error("param is NULL");
		return -1;
	}
	
	if( ZX_STREAM_TYPE_NONE != (stream_type = zx_stream_get_push_type(url))  )
	{
		ctx->iPushStreamState[stream_type] = 1;
		strncpy(ctx->szFileName[stream_type],url,MAX_FILE_NAME - 1);
		ctx->szFileName[stream_type][MAX_FILE_NAME - 1] = '\0';
	}
	
	return stream_type;
}

//检测是否在推送流种类里面
int zx_stream_check_push_type(STREAM_CONNECT_INFO *ctx,STREAM_PROTOCAL_TYPE stype)
{
	int i 								= 0;
	//STREAM_PROTOCAL_TYPE stream_type	= ZX_STREAM_TYPE_NONE;
	
	if( NULL == ctx )
	{
		dzlog_error("param is NULL");
		return -1;
	}

	for(i = 0 ; i < MAX_STREAM_TYPE; i ++)
	{
		if(ctx->iPushStreamState[i] && (i == stype) )
		{
			return 1;
		}
	}

	return 0;

}


#endif




