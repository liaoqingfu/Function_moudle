/*============================================================================
 Name        : hal_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-04-16 
 Description : 
 ============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  
#include <sys/socket.h>  
#include <string.h>  
#include <netinet/in.h>  
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <curl/curl.h>
#include <curl/easy.h>
#include <sys/stat.h>
//#include <conio.h>
#include <termio.h>


#include "hal.h"
#include "hal_audio.h"
#include "hal_interface.h"
#include "hal_pir.h"
#include "hal_video.h"
#include "cjson.h"
#include "hal_wifi.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_ircut.h"
#include "hisi_interface.h"
#include "floodlight_interface.h"

extern HISI_CAMERA_WIFI_DATA *hisi_cam_wifi;
extern short wifi_connect_status;



int zx_set_sta_wifi_and_connect()
{
	int ret = -1;
	dzlog_info("set sta wifi and connect start");
	//ret = hal_set_wifi_sta_mode();
	//if(ret == 0)
	
		dzlog_info("hal set wifi sta mode is ok");
		ret = hal_wifi_connect(WIFI_SSID,WIFI_PASSWORD);
		if(ret != 0)
		{
			dzlog_error("hal wifi connect is error ret : %d",ret);
			return ret;
		}
		char ssid[20] = {0};
		memcpy(ssid,WIFI_SSID,strlen(WIFI_SSID));
		dzlog_info("hal wifi connect is ok");
		
		ret = hal_wifi_udhcpc();
		if(ret != 0)
		{
			dzlog_error("hal wifi udhcpc is error ret : %d",ret);
			return ret;
		}
		dzlog_info("hal wifi udhcpc is ok");

		zx_mgw_setTimer(1,0);

		memcpy(hisi_cam_wifi->wifi_ssid, ssid,strlen(ssid));
		memcpy(hisi_cam_wifi->wifi_password, WIFI_PASSWORD,strlen(WIFI_PASSWORD));

		wifi_connect_status = WIFI_CONNECTED;

		#if 1
		ret = hal_wifi_check_link(ssid);
		dzlog_info("hal wifi check link is ok ret : %d",ret);
		if(ret < 2)
		{
			if(ret == 0)
			{
				dzlog_warn("hal wifi check link not connect");
				ret = -1;
			}
			else if(ret == 1)
			{
				dzlog_warn("hal wifi check link is connecting");
				ret = -1;
			}
			else
				dzlog_error("hal wifi check link is error ret : %d",ret);
			return ret;
		}
		#endif
		
		dzlog_info("hal wifi check link is ok ret : %d",ret);
	
		system("ifconfig");
		//system("ping www.baidu.com");

	dzlog_info("set sta wifi and connect end");

	return ret;
}

int zx_set_sta_wifi_and_connect_zhuoyi()
{
	int ret = -1;
	dzlog_info("set sta wifi and connect start");
	//ret = hal_set_wifi_sta_mode();
	//if(ret == 0)
	
		dzlog_info("hal set wifi sta mode is ok");
		ret = hal_wifi_connect("PHICOMM_92","12345678");
		if(ret != 0)
		{
			dzlog_error("hal wifi connect is error ret : %d",ret);
			return ret;
		}
		char ssid[20] = {0};
		memcpy(ssid,"PHICOMM_92",strlen("PHICOMM_92"));
		dzlog_info("hal wifi connect is ok");
		
		ret = hal_wifi_udhcpc();
		if(ret != 0)
		{
			dzlog_error("hal wifi udhcpc is error ret : %d",ret);
			return ret;
		}
		dzlog_info("hal wifi udhcpc is ok");

		zx_mgw_setTimer(1,0);

		memcpy(hisi_cam_wifi->wifi_ssid, ssid,strlen(ssid));
		memcpy(hisi_cam_wifi->wifi_password, "12345678",strlen("12345678"));

		#if 1
		ret = hal_wifi_check_link(ssid);
		dzlog_info("hal wifi check link is ok ret : %d",ret);
		if(ret < 2)
		{
			if(ret == 0)
			{
				dzlog_warn("hal wifi check link not connect");
				ret = -1;
			}
			else if(ret == 1)
			{
				dzlog_warn("hal wifi check link is connecting");
				ret = -1;
			}
			else
				dzlog_error("hal wifi check link is error ret : %d",ret);
			return ret;
		}
		#endif
		
		dzlog_info("hal wifi check link is ok ret : %d",ret);
	
		system("ifconfig");
		//system("ping www.baidu.com");

	dzlog_info("set sta wifi and connect end");

	return ret;
}


int zx_set_sta_wifi_and_connect_one()
{
	int ret = -1;
	dzlog_info("set sta wifi and connect one start");
	ret = hal_set_wifi_sta_mode_and_connect(WIFI_SSID,WIFI_PASSWORD);
	if(ret != 0)
	{
		dzlog_error("hal set wifi sta mode and connect is error ret : %d",ret);
		return ret;
	}
	char ssid[20] = {0};
	memcpy(ssid,WIFI_SSID,strlen(WIFI_SSID));
#if 1
	ret = hal_wifi_check_link(ssid);
	if(ret < 0)
	{
		dzlog_error("hal wifi udhcpc is error ret : %d",ret);
		return ret;
	}
	dzlog_info("hal wifi check link is ok ret : %d",ret);

	memcpy(hisi_cam_wifi->wifi_ssid, ssid,strlen(ssid));
	memcpy(hisi_cam_wifi->wifi_password, WIFI_PASSWORD,strlen(WIFI_PASSWORD));

	hisi_cam_wifi->wifi_mode = HISI_WIFI_STA_MODE;

	wifi_connect_status = WIFI_CONNECTED;


	system("ifconfig");
	//system("ping www.baidu.com");
#endif

	dzlog_info("set sta wifi and connect one end");

	return ret;
}



void zx_hisi_NTP_init()
{
  bzero(&ntppack,sizeof(ntppack));
  ntppack.li_vn_mode=0x1b;						//0|(3<<2)|(3<<5);
  
  firsttimestamp="JAN_1970"+time(NULL);		//-8*3600;
  
  ntppack.oritimestamphigh=htonl(firsttimestamp);
}




int zx_hisi_set_cur_time()
{
	fd_set  inset1;
	int32  sockfd;
	struct timeval tv,tv1;
	struct timezone tz;
	struct sockaddr_in addr;

	if((sockfd=socket(AF_INET,SOCK_DGRAM,0))<0)
	{
	 	dzlog_error("create socket error!");
	  	return -1;
	}

	addr.sin_family=AF_INET;   				  		//IPV4协议
	addr.sin_port =htons(HISI_NTPPORT);  			 //NTP专用的123端口
	addr.sin_addr.s_addr=inet_addr(HISI_NTPSVR1);   //校时服务器
	bzero(&(addr.sin_zero),8);   					//清零

	tv.tv_sec=5;    //select等待时间为5S
	tv.tv_usec=0;

	FD_ZERO(&inset1);
	FD_SET(sockfd,&inset1);

	zx_hisi_NTP_init();

	sendto(sockfd,&ntppack,sizeof(ntppack),0,(struct sockaddr *)&addr,sizeof(struct sockaddr));

	if(select(sockfd+1,&inset1,NULL,NULL,&tv)<0)
	{
		dzlog_error("select error!");
		return -1;
	}
	else
	{
		if(FD_ISSET(sockfd,&inset1))
		{

			 if(recv(sockfd,&newpack,sizeof(newpack),0)<0)        //接收数据在newpack中。
			 {
			  	dzlog_error("recv error!");
			  	return -1;
			 }
		}
	}
	
	//到达客户机时间戳T4
	finaltimestamp=time(NULL)+JAN_1970;

	dzlog_info("【 %s 】", ctime(&finaltimestamp));

	//将网络上传送的大端数据改为小端形式。
	newpack.root_delay			= ntohl(newpack.root_delay);
	newpack.root_dispersion		= ntohl(newpack.root_dispersion);
	newpack.reftimestamphigh	= ntohl(newpack.reftimestamphigh);
	newpack.reftimestamplow		= ntohl(newpack.reftimestamplow);
	newpack.oritimestamphigh	= ntohl(newpack.oritimestamphigh);
	newpack.oritimestamplow		= ntohl(newpack.oritimestamplow);
	newpack.recvtimestamphigh	= ntohl(newpack.recvtimestamphigh);
	newpack.recvtimestamplow	= ntohl(newpack.recvtimestamplow);
	newpack.trantimestamphigh	= ntohl(newpack.trantimestamphigh);
	newpack.trantimestamplow	= ntohl(newpack.trantimestamplow);

	//求出客户机跟服务器的时间差=((T2-T1)+(T3-T4))/2
	diftime=((newpack.recvtimestamphigh-firsttimestamp)+(newpack.trantimestamphigh-finaltimestamp))>>1;

	dzlog_info("【 %s 】", ctime(&diftime));
	
	//求出延时
	delaytime=((newpack.recvtimestamphigh-firsttimestamp)-(newpack.trantimestamphigh-finaltimestamp))>>1;
	
	dzlog_info("【 %s 】", ctime(&delaytime));
	
	//求出真正时间的时间戳
	tv1.tv_sec=time(NULL)+diftime+delaytime;
	tv1.tv_usec=0;

#if 1
	printf("\n\ndebug information ...\n\n");
	printf("time(NULL) is %ld\n",time(NULL));
	printf("different time is %ld\n",diftime);
	printf("delaytime is %ld\n",delaytime);
	printf("time(NULL)+diftime+delaytime=%lld\n",time(NULL)+diftime+delaytime);
	printf("tv1.tv_sec is %ld\n\n", tv1.tv_sec);
#endif

	settimeofday(&tv1,NULL);
	//diftime=diftime-From00to70;

#if 1
	//printf("different time is %ld\n",diftime);
	printf("delay  time is %ld\n",delaytime);
	//printf("firsttimestamp is %x\n",time(NULL));
	printf("newpack.tran is %ld\n",newpack.trantimestamphigh);
	printf("newpack.recv is %ld\n",newpack.recvtimestamphigh);
	printf("firsttimestamp is %ld\n",firsttimestamp);
	printf("finaltimestamp is %ld\n",finaltimestamp);
	printf("newpack.recv-firsttimestamp is %ld\n",newpack.recvtimestamphigh-firsttimestamp);
	printf("newpack.tran-finaltimestamp is %ld\n",newpack.trantimestamphigh-finaltimestamp);
	printf("(recv-first)+(ftran-final) is %ld\n",(newpack.recvtimestamphigh-firsttimestamp)+(newpack.trantimestamphigh-finaltimestamp));
	printf("((recv-first)+(ftran-final))>>1 is %ld\n",((newpack.recvtimestamphigh-firsttimestamp)+(newpack.trantimestamphigh-finaltimestamp))>>1);
	printf("different time is %ld\n\n",diftime);
	printf("sizeof(long long)  is:%d\n",sizeof(long long));
	printf("Current time is...\n");
	system("date");
#endif
	return 0;
}
















































