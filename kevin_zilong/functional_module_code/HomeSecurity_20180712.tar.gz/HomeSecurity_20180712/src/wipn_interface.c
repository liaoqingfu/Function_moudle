/*============================================================================
 Name        : wipn_interface.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-12-04 
 Description :
 ============================================================================*/

#include "PPCS/WiPN_API.h"
#include "base.h"

//// Record RecvFrom return time
time_t g_Time_ServerRet = 0;
extern unsigned char grunning;

//// Mode:	0->Sending via Both LAN and Internet
//// 		1->Sending via Internet only
////		2->Sending via LAN only.
INT32 g_SendToMode = 0;	
#if 0
char bFlagGetTickCount= 0;
struct timeval gTime_Begin;
unsigned int MyGetTickCount()
{
	if (!bFlagGetTickCount)
	{
		bFlagGetTickCount = 1;
		gettimeofday(&gTime_Begin, NULL);
		return 0;
	}
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (tv.tv_sec - gTime_Begin.tv_sec)*1000 + (tv.tv_usec - gTime_Begin.tv_usec)/1000;
}
#endif

// get Error Code Info
const char *getErrorCodeInfo(int err)
{
    if (0 < err)
	{
		return "NoError, May be a Socket handle value or Data Size!";
	}
    switch (err)
    {
		// NDT Error
        case 0: return "NDT_ERROR_NoError";
        case -1: return "NDT_ERROR_AlreadyInitialized";
        case -2: return "NDT_ERROR_NotInitialized";
        case -3: return "NDT_ERROR_TimeOut";
        case -4: return "NDT_ERROR_ScketCreateFailed";
        case -5: return "NDT_ERROR_ScketBindFailed";
        case -6: return "NDT_ERROR_HostResolveFailed";
        case -7: return "NDT_ERROR_ThreadCreateFailed";
        case -8: return "NDT_ERROR_MemoryAllocFailed";
        case -9: return "NDT_ERROR_NotEnoughBufferSize";
        case -10: return "NDT_ERROR_InvalidInitString";
        case -11: return "NDT_ERROR_InvalidAES128Key";
        case -12: return "NDT_ERROR_InvalidDataOrSize";
        case -13: return "NDT_ERROR_InvalidDID";
        case -14: return "NDT_ERROR_InvalidNDTLicense";
        case -15: return "NDT_ERROR_InvalidHandle";
        case -16: return "NDT_ERROR_ExceedMaxDeviceHandle";
        case -17: return "NDT_ERROR_ExceedMaxClientHandle";
        case -18: return "NDT_ERROR_NetworkDetectRunning";
        case -19: return "NDT_ERROR_SendToRunning";
        case -20: return "NDT_ERROR_RecvRunning";
        case -21: return "NDT_ERROR_RecvFromRunning";
        case -22: return "NDT_ERROR_SendBackRunning";
        case -23: return "NDT_ERROR_DeviceNotOnRecv";
        case -24: return "NDT_ERROR_ClientNotOnRecvFrom";
        case -25: return "NDT_ERROR_NoAckFromCS";
        case -26: return "NDT_ERROR_NoAckFromPushServer";
        case -27: return "NDT_ERROR_NoAckFromDevice";
        case -28: return "NDT_ERROR_NoAckFromClient";
        case -29: return "NDT_ERROR_NoPushServerKnowDevice";
        case -30: return "NDT_ERROR_NoPushServerKnowClient";
        case -31: return "NDT_ERROR_UserBreak";
        case -32: return "NDT_ERROR_SendToNotRunning";
        case -33: return "NDT_ERROR_RecvNotRunning";
        case -34: return "NDT_ERROR_RecvFromNotRunning";
        case -35: return "NDT_ERROR_SendBackNotRunning";
        case -36: return "NDT_ERROR_RemoteHandleClosed";
        case -99: return "NDT_ERROR_FAESupportNeeded";
        // WiPN Error
        case WiPN_ERROR_InvalidParameter: return "WiPN_ERROR_InvalidParameter";
        case WiPN_ERROR_iPNStringEncFailed: return "WiPN_ERROR_iPNStringEncFailed";
        case WiPN_ERROR_iPNStringDncFailed: return "WiPN_ERROR_iPNStringDncFailed";
        case WiPN_ERROR_GetPostServerStringItemFailed: return "WiPN_ERROR_GetPostServerStringItemFailed";
        case WiPN_ERROR_GetSubscribeServerStringItemFailed: return "WiPN_ERROR_GetSubscribeServerStringItemFailed";
        case WiPN_ERROR_GetUTCTStringItemFailed: return "WiPN_ERROR_GetUTCTStringItemFailed";
        case WiPN_ERROR_GetNumberFromPostServerStringFailed: return "WiPN_ERROR_GetNumberFromPostServerStringFailed";
        case WiPN_ERROR_GetNumberFromSubscribeServerStringFailed: return "WiPN_ERROR_GetNumberFromSubscribeServerStringFailed";
        case WiPN_ERROR_GetDIDFromPostServerStringFailed: return "WiPN_ERROR_GetDIDFromPostServerStringFailed";
        case WiPN_ERROR_GetDIDFromSubscribeServerStringFailed: return "WiPN_ERROR_GetDIDFromSubscribeServerStringFailed";
        case WiPN_ERROR_GetRETStringItemFailed: return "WiPN_ERROR_GetRETStringItemFailed";
        case WiPN_ERROR_MallocFailed: return "WiPN_ERROR_MallocFailed";
		case WiPN_ERROR_ExceedMaxSize: return "WiPN_ERROR_ExceedMaxSize";
		// WiPN Web Error
		case WiPN_ERROR_TimeOut: return "WiPN_ERROR_TimeOut";
		case WiPN_ERROR_SocketCreateFailed: return "WiPN_ERROR_SocketCreateFailed";
		case WiPN_ERROR_SocketConnectFailed: return "WiPN_ERROR_SocketConnectFailed";
		case WiPN_ERROR_InvalidSocketID: return "WiPN_ERROR_InvalidSocketID";
		case WiPN_ERROR_SetSockOptFailed: return "WiPN_ERROR_SetSockOptFailed";
		case WiPN_ERROR_SocketWriteFailed: return "WiPN_ERROR_SocketWriteFailed";
		case WiPN_ERROR_SocketReadFailed: return "WiPN_ERROR_SocketReadFailed";
		case WiPN_ERROR_RemoteSocketClosed: return "WiPN_ERROR_RemoteSocketClosed";
		case WiPN_ERROR_SelectError: return "WiPN_ERROR_SelectError";
		case WiPN_ERROR_GetContentFromHttpRetDataFailed: return "WiPN_ERROR_GetContentFromHttpRetDataFailed";
		case WiPN_ERROR_GetNDTRETItemFailed: return "WiPN_ERROR_GetNDTRETItemFailed";
		case WiPN_ERROR_DeviceTokenIsEmpty: return "WiPN_ERROR_DeviceTokenIsEmpty";
        default:
            return "Unknow, something is wrong!";
    }
}

//// ret=0 OK, ret=-1: Invalid Parameter, ret=-2: No such Item
int GetStringItem(	const char *SrcStr, 
					const char *ItemName, 
					const char Seperator, 
					char *RetString, 
					const int MaxSize)
{
    if (!SrcStr || !ItemName || !RetString || 0 == MaxSize)
	{
		return -1;
	}
    const char *pFand = SrcStr;
    while (grunning)
    {
        pFand = strstr(pFand, ItemName);
        if (!pFand)
		{
			return -2;
		} 
        pFand += strlen(ItemName);
        if ('=' != *pFand)
		{
			continue;
		}     
        else
		{
			break;
		}    
    }
    
    pFand += 1;
    int i = 0;
    while (grunning)
    {
        if (Seperator == *(pFand + i) || '\0' == *(pFand + i) || i >= (MaxSize - 1))
		{
			break;
		} 
        else
		{
			*(RetString + i) = *(pFand + i);
		}     
        i++;
    }
    *(RetString + i) = '\0';
    
    return 0;
}

// Get Number From PostServer/SubscribeServer 
int pharse_number(const CHAR *pServerString, unsigned short *Number, unsigned short *SizeOfDID)
{
    if (!pServerString || !Number)
	{
		return -1;
	}
    CHAR buf[8];
    memset(buf, 0, sizeof(buf));
    const CHAR *pS = pServerString;
    const CHAR *p1 = strstr(pServerString, ",");
    if (!p1)
	{
		return -1;
	}  
    if (p1 - pS > sizeof(buf) - 1)
	{
		return -1;
	}  
    int i = 0;
    while (grunning)
    {
        if (pS + i >= p1)
		{
			break;
		} 
        buf[i] = *(pS + i);
        i++;
    }
    buf[i] = '\0';
    *Number = atoi(buf);
    
	// Get PostServerDID length
	p1 += 1; 	// -> point the First DID
	const char *p2 = strstr(p1, ",");
	if (!p2)	// -> Only one DID -> "01,ABCD-123456-ABCDEF"
	{
		*SizeOfDID = strlen(p1);
	}	
	else
	{
		*SizeOfDID = (unsigned short)(p2 - p1);
	}	
	//dzlog_info("SizeOfDID= %d", *SizeOfDID);
    return 0;
}

// Get PostServer/SubscribeServer DID
const char *pharse_DID(const char *pServerString, int index)
{
    if (!pServerString || 0 > index)
	{
		return NULL;
	}
    const char *p1 = strstr(pServerString, ",");
    if (!p1)
	{
		return NULL;
	}  
    p1 += 1;		// -> point the First DID
    
    const char *p2 = strstr(p1, ",");
    if (!p2) // -> Only one DID -> "01,ABCD-123456-ABCDEF"
	{
		unsigned short LengthOfDID = strlen(p1);
		if (0 == LengthOfDID)
		{
			return NULL;
		}			
		//dzlog_info("LengthOfDID= %d", LengthOfDID);
		char *pDID = (char *)malloc((LengthOfDID/4+1)*4);
		if (!pDID)
		{
			dzlog_error("pharse_DID - malloc failed!!");
			return NULL;
		}
		memset(pDID, '\0', (LengthOfDID/4+1)*4);
		memcpy(pDID, p1, LengthOfDID);
		return pDID;
	}
    unsigned short SizeOfDID = (unsigned short)(p2 - p1);
    //dzlog_info("SizeOfDID= %u", SizeOfDID);
    
    p1 = pServerString;
    int i = 0;
    for (; i < index + 1; i++)
    {
        p1 = strstr(p1, ",");
        if (!p1)
		{
			 break;
		}    
        p1 += 1;
    }
    if (!p1)
	{
		return NULL;
	}  
    char *pDID = (char *)malloc((SizeOfDID/4+1)*4);
	if (!pDID)
	{
		dzlog_error("pharse_DID - Malloc failed!!");
		return NULL;
	}
    memset(pDID, '\0', (SizeOfDID/4+1)*4);
    memcpy(pDID, p1, SizeOfDID);
    //dzlog_info("p_DID = %s", p_DID);
    
    return pDID;
}

//// ------------------- WiPN API Begin -----------------
//// WiPN_Query for WiPN API
INT32 WiPN_Query(const CHAR *pDeviceDID, 
				const CHAR *QueryServerDID[], 
				CHAR *pPostServerString, 
				UINT32 SizeOfPostServerString, 
				CHAR *pSubscribeServerString, 
				UINT32 SizeOfSubscribeServerString, 
				CHAR *pUTCTString, 
				UINT32 SizeOfUTCTString)
{
    if (!pDeviceDID || 0 == strlen(pDeviceDID))
    {
        dzlog_error("WiPN_Query - DeviceDID is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
	if (!QueryServerDID)
    {
        dzlog_error("WiPN_Query - QueryServerDID Buf is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    int i = 0;
    for (; i < QUERY_SERVER_NUMBER; i++)
    {
        if (NULL == QueryServerDID[i])
        {
            dzlog_error("WiPN_Query - QueryServerDIDbuf[%d] have no DID!!", i);
            return WiPN_ERROR_InvalidParameter;
        }
    }
    if (!pPostServerString && !pSubscribeServerString)
    {
        dzlog_error("WiPN_Query - PostServerString && SubscribeServerString Buf is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pPostServerString && 0 == SizeOfPostServerString)
    {
        dzlog_error("WiPN_Query - SizeOfPostServerString= %d", SizeOfPostServerString);
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pSubscribeServerString && 0 == SizeOfSubscribeServerString)
    {
        dzlog_error("WiPN_Query - SizeOfSubscribeServerString= %d", SizeOfSubscribeServerString);
        return WiPN_ERROR_InvalidParameter;
    }
    if (!pUTCTString)
    {
        dzlog_error("WiPN_Query - pUTCTString is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pUTCTString && 0 == SizeOfUTCTString)
    {
        dzlog_error("WiPN_Query - SizeOfUTCTString= 0 !!");
        return WiPN_ERROR_InvalidParameter;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = 512;
	char CR_Buffer[512] = {0};
	/*char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_Query - Malloc Query Cmd Buf failed!!");
		return WiPN_ERROR_MallocFailed;
	}*/  
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (Not decrypt yet)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_Query - Malloc Buffer failed!!");
		//free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
	// Formatted query CMD -> CR_Buffer
    sprintf(CR_Buffer, "DID=%s&", pDeviceDID);
    //dzlog_info("QueryCmd= %s Size= %u byte", CR_Buffer, (UINT32)strlen(CR_Buffer));	
	
	// Encryption query CMD -> Buffer
    if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
    {
        dzlog_error("WiPN_Query - iPN_StringEnc: Query Cmd Enc failed!");
		//free((void *)CR_Buffer);
		free((void *)Buffer);
		return WiPN_ERROR_iPNStringEncFailed;
    }

	int ret = 0;
    int QueryServerHandle = -1;
    short retryCount_RecvFrom = 0;
	srand((UINT32)time(NULL));
	
	short index = abs(rand() % QUERY_SERVER_NUMBER);
    while (grunning)
    {
        if (0 > QueryServerHandle)
        {      
            for (i = 0; i < QUERY_SERVER_NUMBER; i++)
            {
				index = (index + 1) % QUERY_SERVER_NUMBER;
				
				unsigned short SizeOfQueryCmd = strlen(Buffer);
				//dzlog_info("send cmd to QueryServer, QueryServerDID[%d]= %s. SizeOfQueryCmd= %u byte. sending...", 
				//			index, QueryServerDID[index], SizeOfQueryCmd);
				
				//unsigned int tick = MyGetTickCount();
				
				// Send query cmd to QueryServer
				ret = NDT_PPCS_SendTo(	QueryServerDID[index], 
										Buffer, 
										SizeOfQueryCmd, 
										g_SendToMode);
				//dzlog_info("NDT_PPCS_SendTo done! TimeUsed: %ld ms", MyGetTickCount() - tick);
				
				if (0 > ret)
                {
                    dzlog_error("send cmd to QueryServer failed!! ret= %d [%s]", ret, getErrorCodeInfo(ret));
					dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
                    dzlog_info("send cmd to QueryServer success!! ");
					QueryServerHandle = ret;
                    break;
                }
            }
            if (0 > QueryServerHandle)
            {
                dzlog_error("WiPN_Query - Get QueryServerHandle failed! QueryServerDID[%d]= %s. ret= %d [%s]", 
						index, QueryServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
			//dzlog_info("Waiting for QueryServer response, NDT_PPCS_RecvFrom ...");                
			UINT16 SizeToRead = SizeOfBuffer;
			memset(Buffer, 0, SizeOfBuffer);	
			
			ret = NDT_PPCS_RecvFrom(QueryServerHandle, Buffer, &SizeToRead, 3000); 

			// Record RecvFrom return time
			time_t Time_ServerRet = time(NULL);
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);
            
            if (0 > ret)
            {
				//dzlog_info("WiPN_Query - NDT_PPCS_RecvFrom: QueryServerDID[%d]= %s. ret= %d. [%s]", index, QueryServerDID[index], ret, getErrorCodeInfo(ret));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				} 
				
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_info("WiPN_Query - QueryServer already call CloseHandle(). QueryServerDID[%d]= %s", index, QueryServerDID[index]);
				} 
                break;
            }
            else
            {
				// Decrypt received data, Save in CR_Buffer             
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_Query - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! QueryServerDID[%d]= %s. ", 
									index, QueryServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break;
                }
				
				//dzlog_info("From QueryServer(Handle:%d, DID[%d]=%s): ", QueryServerHandle, index, QueryServerDID[index]);
				//dzlog_info("Data: %s", CR_Buffer);
				//dzlog_info("Size: %u byte",(UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}		
				
                // Get PostServerString , From the end of the identifier '&'
                if (NULL != pPostServerString && 0 > GetStringItem(CR_Buffer, "Post", '&', pPostServerString, SizeOfPostServerString))
                {
					char RET[32] = {0};
                    if (0 <= GetStringItem(CR_Buffer, "RET", '&', RET, sizeof(RET)))
					{
						dzlog_error("WiPN_QueryByServer - Get PostServerString failed! -> RET=%s", RET);
					}
                    ret = WiPN_ERROR_GetPostServerStringItemFailed;
                }
				// Get SubscribeString 
                if (NULL != pSubscribeServerString && 0 > GetStringItem(CR_Buffer, "Subs", '&', pSubscribeServerString, SizeOfSubscribeServerString))
                {
                    char RET[32] = {0};
                    if (0 <= GetStringItem(CR_Buffer, "RET", '&', RET, sizeof(RET)))
					{
						dzlog_error("WiPN_QueryByServer - Get SubscribeServerString failed! -> RET=%s", RET);
					}
                    ret = WiPN_ERROR_GetSubscribeServerStringItemFailed;
                }
				// Get UTCTString 
                memset(pUTCTString, 0, SizeOfUTCTString);
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_Query - Get UTCTString failed!");
                    ret = WiPN_ERROR_GetUTCTStringItemFailed;
                }
				else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}
            } // ret > 0
            break;
        } // Handle > 0
    } // while
	if (0 <= QueryServerHandle)
	{	
		NDT_PPCS_CloseHandle(QueryServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", QueryServerHandle);
	}
	//if (CR_Buffer)
	//	free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);
	
    return ret;
} // WiPN Query

// WiPN_QueryByServer 
INT32 WiPN_QueryByServer(const CHAR *pServerString,
						const CHAR *pAES128Key,
						const CHAR *pDeviceDID, 
						const CHAR *QueryServerDID[], 
						CHAR *pPostServerString, 
						UINT32 SizeOfPostServerString, 
						CHAR *pSubscribeServerString, 
						UINT32 SizeOfSubscribeServerString, 
						CHAR *pUTCTString, 
						UINT32 SizeOfUTCTString)
{
    if (!pServerString || 0 == strlen(pServerString))
	{
		dzlog_error("WiPN_QueryByServer - ServerString is NULL!!");
        return WiPN_ERROR_InvalidParameter;
	}
	if (!pAES128Key || 0 == strlen(pAES128Key))
	{
		dzlog_error("WiPN_QueryByServer - AES128Key is NULL!!");
        return WiPN_ERROR_InvalidParameter;
	}
	if (!pDeviceDID || 0 == strlen(pDeviceDID))
    {
        dzlog_error("WiPN_QueryByServer - DeviceDID is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
	if (!QueryServerDID)
    {
        dzlog_error("WiPN_QueryByServer - QueryServerDID Buf is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    int i = 0;
    for (; i < QUERY_SERVER_NUMBER; i++)
    {
        if (NULL == QueryServerDID[i])
        {
            dzlog_error("WiPN_QueryByServer - QueryServerDIDbuf[%d] have no DID!!", i);
            return WiPN_ERROR_InvalidParameter;
        }
    }
    if (!pPostServerString && !pSubscribeServerString)
    {
        dzlog_error("WiPN_QueryByServer - PostServerString && SubscribeServerString Buf is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pPostServerString && 0 == SizeOfPostServerString)
    {
        dzlog_error("WiPN_QueryByServer - SizeOfPostServerString= %d", SizeOfPostServerString);
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pSubscribeServerString && 0 == SizeOfSubscribeServerString)
    {
        dzlog_error("WiPN_QueryByServer - SizeOfSubscribeServerString= %d", SizeOfSubscribeServerString);
        return WiPN_ERROR_InvalidParameter;
    }
    if (!pUTCTString)
    {
        dzlog_error("WiPN_QueryByServer - UTCTString Buf is NULL!!");
        return WiPN_ERROR_InvalidParameter;
    }
    if (NULL != pUTCTString && 0 == SizeOfUTCTString)
    {
        dzlog_error("WiPN_QueryByServer - SizeOfUTCTString= 0 !!");
        return WiPN_ERROR_InvalidParameter;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = 512;
	char CR_Buffer[512] = {0};
	/*char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_QueryByServer - Malloc Query Cmd Buf failed!!");
		return WiPN_ERROR_MallocFailed;
	}*/  
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_QueryByServer - Malloc Buffer failed!!");
		//free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
	// Formatted query CMD -> CR_Buffer
    sprintf(CR_Buffer, "DID=%s&", pDeviceDID);
    dzlog_info("QueryCmd= %s Size= %u byte", CR_Buffer, (UINT32)strlen(CR_Buffer));	
	
	// Encryption query CMD -> Buffer
    if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
    {
        dzlog_error("WiPN_QueryByServer - iPN_StringEnc: Query Cmd Enc failed!");
		//free((void *)CR_Buffer);
		free((void *)Buffer);
		return WiPN_ERROR_iPNStringEncFailed;
    }

	int ret = 0;
    int QueryServerHandle = -1;
    short retryCount_RecvFrom = 0;

	srand((UINT32)time(NULL));	
	short index = abs(rand() % QUERY_SERVER_NUMBER);
    while (grunning)
    {
        if (0 > QueryServerHandle)
        {      
            for (i = 0; i < QUERY_SERVER_NUMBER; i++)
            {
				index = (index + 1) % QUERY_SERVER_NUMBER;
				
				unsigned short SizeOfQueryCmd = strlen(Buffer);
				dzlog_error("send cmd to QueryServer, QueryServerDID[%d]= %s. SizeOfQueryCmd= %u byte. sending...", index, QueryServerDID[index], SizeOfQueryCmd);

				//unsigned int tick = MyGetTickCount();	
				
				// Send query cmd to QueryServer
				ret = NDT_PPCS_SendToByServer(	QueryServerDID[index], 
												Buffer, SizeOfQueryCmd, 
												g_SendToMode, 
												pServerString, 
												pAES128Key);
				//dzlog_info("NDT_PPCS_SendToByServer done! TimeUsed: %ld ms", MyGetTickCount() - tick);			

				if (0 > ret)
                {
                    dzlog_error("send cmd to QueryServer failed!! ret= %d [%s]", ret, getErrorCodeInfo(ret));
					dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
                    dzlog_info("send cmd to QueryServer Success!! ");
					QueryServerHandle = ret;
                    break;
                }
            }
            if (0 > QueryServerHandle)
            {
                dzlog_error("WiPN_QueryByServer - Get QueryServerHandle failed! QueryServerDID[%d]= %s. ret= %d [%s]", index, QueryServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
			dzlog_info("Waiting for QueryServer response, NDT_PPCS_RecvFrom ...");        
            UINT16 SizeToRead = SizeOfBuffer;
			memset(Buffer, 0, SizeOfBuffer);	
			
			ret = NDT_PPCS_RecvFrom(QueryServerHandle, Buffer, &SizeToRead, 3000);
			
			// Record RecvFrom return time
			time_t Time_ServerRet = time(NULL);
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);
            
            if (0 > ret)
            {
				dzlog_info("WiPN_QueryByServer - NDT_PPCS_RecvFrom: QueryServerDID[%d]= %s. ret= %d. [%s]", 
							index, QueryServerDID[index], ret, getErrorCodeInfo(ret));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}
				
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_QueryByServer - QueryServer already call CloseHandle(). QueryServerDID[%d]= %s", index, QueryServerDID[index]);
				} 
                break;
            }
            else
            {
				// Decrypt received data, Save in CR_Buffer              
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_QueryByServer - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! QueryServerDID[%d]= %s. ", 
							index, QueryServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break;
                }
				
				dzlog_info("From QueryServer(Handle:%d, DID[%d]=%s): ", QueryServerHandle, index, QueryServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer);
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}	
				
                // Get PostServerString , From the end of the identifier '&'
                if (NULL != pPostServerString && 0 > GetStringItem(CR_Buffer, "Post", '&', pPostServerString, SizeOfPostServerString))
                {
					char RET[32] = {0};
                    if (0 <= GetStringItem(CR_Buffer, "RET", '&', RET, sizeof(RET)))
					{
						dzlog_error("WiPN_QueryByServer - Get PostServerString failed! -> RET=%s", RET);
					}
                    ret = WiPN_ERROR_GetPostServerStringItemFailed;
                }
				// Get SubscribeString 
                if (NULL != pSubscribeServerString && 0 > GetStringItem(CR_Buffer, "Subs", '&', pSubscribeServerString, SizeOfSubscribeServerString))
                {
                    char RET[32] = {0};
                    if (0 <= GetStringItem(CR_Buffer, "RET", '&', RET, sizeof(RET)))
					{
						dzlog_error("WiPN_QueryByServer - Get SubscribeServerString failed! -> RET=%s", RET);
					}
                    ret = WiPN_ERROR_GetSubscribeServerStringItemFailed;
                }
				// Get UTCTString 
                memset(pUTCTString, 0, SizeOfUTCTString);
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_QueryByServer - Get UTCTString failed!");
                    ret = WiPN_ERROR_GetUTCTStringItemFailed;
                }
				else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}
            } // ret > 0
            break;
        } // Handle > 0
    } // while
	if (0 <= QueryServerHandle)
	{	
		NDT_PPCS_CloseHandle(QueryServerHandle);	
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", QueryServerHandle);
	}
	//if (CR_Buffer)
	//	free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);
	
    return ret;
}//WiPN_QueryByServer

#if SUBSCRIBE_FLAG
//// WiPN_Subscribe 
INT32 WiPN_Subscribe(const CHAR *pSubscribeServerString,
                     const CHAR *pSubCmd,
                     CHAR *pRETString,
                     UINT32 SizeOfRETString,
                     CHAR *pUTCTString,
                     UINT32 SizeOfUTCTString)
{
	if (   !pSubscribeServerString 
		|| !pSubCmd 
		|| !pRETString 
		|| !pUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pSubCmd) 
		|| 0 == SizeOfRETString
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	}
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_Subscribe - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
	//// -------------------------------------------------------------------------
    // Calculate the size of SubscribeCmd
    UINT32 Length_SubscribeCmd = strlen("UTCT=0x&")
										+strlen(pSubCmd)
										+strlen(pUTCTString); 
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_SubscribeCmd)
    {
        dzlog_error("WiPN_Subscribe - Length Of SubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_SubscribeCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_Subscribe - Malloc Subscribe Cmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_Subscribe - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
    int ret = 0;
    int SubscribeServerHandle = -1;
	short retryCount_RecvFrom = 0;
    srand((UINT32)time(NULL));
	unsigned short PrintfFlag = 0;
	
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;

                // Calculate UTCT time
                UINT32 UTCT_Subscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format Subscribe CMD -> CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pSubCmd, (UINT32)UTCT_Subscribe);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("SubscribeCmd= %s SubscribeCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
				
                // Encryption Subscribe CMD -> Buffer            
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_Subscribe - iPN_StringEnc: Subscribe Cmd Enc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				
				UINT16 SizeOfSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfSubscribeCmd= %d byte (Encrypted Size). sending...", j, &pSubscribeServerDID[index], SizeOfSubscribeCmd);
                
                ret = NDT_PPCS_SendTo(&pSubscribeServerDID[index], Buffer, SizeOfSubscribeCmd, g_SendToMode);
				
                if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success! ");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_Subscribe - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]", 
							j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, please wait ...");
			UINT16 SizeToRead = SizeOfBuffer;
            memset(Buffer, 0, SizeOfBuffer);
            
			ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);         
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet); 
            if (0 > ret)
            {
				dzlog_info("WiPN_Subscribe - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]", 
							j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
               	if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d]", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
   
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_info("WiPN_Subscribe - SubscribeServer already call CloseHandle(). SubscribeServerDID[%d]= %s", j, &pSubscribeServerDID[index]);
				} 
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer             
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_Subscribe - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! SubscribeServerDID[%d]= %s.", 
								j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s):", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer)); 
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
              
                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_Subscribe - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_Subscribe - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}        
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	}
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
    if (CR_Buffer)
		free((void *)CR_Buffer);	
    if (Buffer)
		free((void *)Buffer);
    
    return ret;
} // WiPN_Subscribe

//// WiPN_SubscribeByServer 
INT32 WiPN_SubscribeByServer(const CHAR *pServerString,
							const CHAR *pAES128Key,
							const CHAR *pSubscribeServerString,
							const CHAR *pSubCmd,
							CHAR *pRETString,
							UINT32 SizeOfRETString,
							CHAR *pUTCTString,
							UINT32 SizeOfUTCTString)
{
    if (   !pServerString
		|| !pAES128Key
		|| !pSubscribeServerString 
		|| !pSubCmd 
		|| !pRETString 
		|| !pUTCTString )
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pServerString) 
		|| 0 == strlen(pAES128Key) 
		|| 0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pSubCmd) 
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfRETString
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	}
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_SubscribeByServer - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
	//// -------------------------------------------------------------------------
	
    // Calculate the size of SubscribeCmd
    UINT32 Length_SubscribeCmd = strlen("UTCT=0x&")
										+strlen(pSubCmd)
										+strlen(pUTCTString);
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_SubscribeCmd)
    {
        dzlog_info("WiPN_SubscribeByServer - Length Of SubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_SubscribeCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_SubscribeByServer - Malloc SubscribeCmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_SubscribeByServer - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
	int ret = 0;
    int SubscribeServerHandle = -1;
    short retryCount_RecvFrom = 0;
	srand((UINT32)time(NULL));
	unsigned short PrintfFlag = 0;
	
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;

                // Calculate UTCT time
                UINT32 UTCT_Subscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format Subscribe CMD to CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pSubCmd, (UINT32)UTCT_Subscribe);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("SubscribeCmd= %sSubscribeCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
				
                // Encryption Subscribe CMD, Save in Buffer               
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_SubscribeByServer - iPN_StringEnc: SubscribeCmd Enc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				
				UINT16 SizeOfSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfSubscribeCmd= %u byte (Encrypted Size). sending...", 
						j, &pSubscribeServerDID[index], SizeOfSubscribeCmd);
                
				// Send CMD to SubscribeServer
				ret = NDT_PPCS_SendToByServer(&pSubscribeServerDID[index], Buffer, SizeOfSubscribeCmd, g_SendToMode, pServerString, pAES128Key);
                
                if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success! ");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_SubscribeByServer - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]", 
						j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, please wait ...");
			UINT16 SizeToRead = SizeOfBuffer;
            memset(Buffer, 0, SizeOfBuffer);
			
            ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);          
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);  
            
			if (0 > ret)
            {      
				dzlog_info("WiPN_SubscribeByServer - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]", 
					j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				} 
       
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_SubscribeByServer - SubscribeServer already call CloseHandle(). SubscribeServerDID[%d]= %s.", j, &pSubscribeServerDID[index]);
				} 
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer                
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_SubscribeByServer - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! SubscribeServerDID[%d]= %s.", 
							j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s): ", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
            
                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_SubscribeByServer - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_SubscribeByServer - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}        
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	}
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
	if (CR_Buffer)
		free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);
    
    return ret;
} // WiPN_SubscribeByServer


//// WiPN_UnSubscribe 
INT32 WiPN_UnSubscribe(const CHAR *pSubscribeServerString,
                     const CHAR *pSubCmd,
                     CHAR *pRETString,
                     UINT32 SizeOfRETString,
                     CHAR *pUTCTString,
                     UINT32 SizeOfUTCTString)
{
	if (   !pSubscribeServerString 
		|| !pSubCmd 
		|| !pRETString 
		|| !pUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pSubCmd) 
		|| 0 == SizeOfRETString
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	} 
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_UnSubscribe - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for (; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
    //// ---------------------------------------------------------------------------
    // Calculate the size of UnSubscribeCmd
    UINT32 Length_UnSubscribeCmd = 	strlen("UTCT=0x&")
											+strlen(pSubCmd)
											+strlen(pUTCTString);
    
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_UnSubscribeCmd)
    {
        dzlog_info("WiPN_UnSubscribe - Length Of UnSubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_UnSubscribeCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_UnSubscribe - Malloc UnSubscribeCmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_UnSubscribe - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
    	
    int ret = 0;
    int SubscribeServerHandle = -1;
	short retryCount_RecvFrom = 0;
	unsigned short PrintfFlag = 0;
	
	srand((UINT32)time(NULL));
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;
                
                // Calculate UTCT time
                UINT32 UTCT_UnSubscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format UnSubscribe cmd -> CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pSubCmd, (UINT32)UTCT_UnSubscribe); 
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("UnSubscribeCmd= %s Size= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}		
				
                // encryption UnSubscribe cmd -> Buffer           
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_UnSubscribe - iPN_StringEnc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				             
				UINT16 SizeOfUnSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfUnSubscribeCmd= %d byte (Encrypted Size). sending...", 
							j, &pSubscribeServerDID[index], SizeOfUnSubscribeCmd);
				
                ret = NDT_PPCS_SendTo(&pSubscribeServerDID[index], Buffer, SizeOfUnSubscribeCmd, g_SendToMode);
                
				if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success! ");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_UnSubscribe - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]", 
							j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, NDT_PPCS_RecvFrom ...");         
			UINT16 SizeToRead = SizeOfBuffer;
			memset(Buffer, 0, SizeOfBuffer);
			
            ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);          			
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);

            if (0 > ret)
            {
				dzlog_info("WiPN_UnSubscribe - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]", 
						j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				} 
              
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret 
					|| NDT_ERROR_NoAckFromDevice == ret 
					|| NDT_ERROR_TimeOut == ret) 
					&& 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_info("WiPN_UnSubscribe - SubscribeServer already call CloseHandle().  SubscribeServerDID[%d]= %s", j, &pSubscribeServerDID[index]);
				}  
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer               
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_UnSubscribe - NDT_PPCS_RecvFrom: iPN_StringDnc failed! SubscribeServerDID[%d]= %s.", j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }  
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s): ", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}   

                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_UnSubscribe - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_UnSubscribe - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}           
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	}
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
	if (CR_Buffer)
		free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);
    
    return ret;
} // WiPN_UnSubscribe
 
INT32 WiPN_UnSubscribeByServer(	const CHAR *pServerString,
								const CHAR *pAES128Key,
								const CHAR *pSubscribeServerString,
								const CHAR *pSubCmd,
								CHAR *pRETString,
								UINT32 SizeOfRETString,
								CHAR *pUTCTString,
								UINT32 SizeOfUTCTString)
{
    if (   !pServerString
		|| !pAES128Key
		|| !pSubscribeServerString 
		|| !pSubCmd 
		|| !pRETString 
		|| !pUTCTString )
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pServerString) 
		|| 0 == strlen(pAES128Key) 
		|| 0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pSubCmd) 
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfRETString
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	} 
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_UnSubscribeByServer - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for (; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
    //// ---------------------------------------------------------------------------
    // Calculate the size of UnSubscribeCmd
    UINT32 Length_UnSubscribeCmd = strlen("UTCT=0x&")
										+strlen(pSubCmd)
										+strlen(pUTCTString); 
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_UnSubscribeCmd)
    {
        dzlog_info("WiPN_UnSubscribeByServer - Length Of UnSubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	UINT32 SizeOf_CR_Buffer = (Length_UnSubscribeCmd/4+1)*4;
	CHAR *CR_Buffer = (CHAR *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_UnSubscribeByServer - Malloc UnSubscribeCmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_UnSubscribeByServer - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
    int ret = 0;
    int SubscribeServerHandle = -1;
    short retryCount_RecvFrom = 0;
	srand((UINT32)time(NULL));
	unsigned short PrintfFlag = 0;
	
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;
                
                // Calculate UTCT time
                UINT32 UTCT_UnSubscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format UnSubscribe cmd -> CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pSubCmd, (UINT32)UTCT_UnSubscribe);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("UnSubscribeCmd= %s Size= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
				
                // encryption UnSubscribe cmd -> Buffer           
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_UnSubscribeByServer - iPN_StringEnc: UnSubscribe Cmd Enc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				
				UINT16 SizeOfUnSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfUnSubscribeCmd= %u byte (Encrypted Size). sending...", 
							j, &pSubscribeServerDID[index], SizeOfUnSubscribeCmd);
                          
				// Send CMD to SubscribeServer
				ret = NDT_PPCS_SendToByServer(&pSubscribeServerDID[index], Buffer, SizeOfUnSubscribeCmd, g_SendToMode, pServerString, pAES128Key);
                
				if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success! ");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_UnSubscribeByServer - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]",
							 j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, please wait ...");        
            memset(Buffer, 0, SizeOfBuffer);
			UINT16 SizeToRead = SizeOfBuffer;
			
            ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);         
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);
            if (0 > ret)
            {
				dzlog_info("WiPN_UnSubscribeByServer - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]",
					 j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));             
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}   
               
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret 
					|| NDT_ERROR_NoAckFromDevice == ret 
					|| NDT_ERROR_TimeOut == ret) 
					&& 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_UnSubscribeByServer - SubscribeServer already call CloseHandle(), SubscribeServerDID[%d]= %s.", 
							j, &pSubscribeServerDID[index]);
				}  
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_UnSubscribeByServer - NDT_PPCS_RecvFrom - iPN_StringDnc:  RecvFrom Data Dec failed! SubscribeServerDID[%d]= %s.", 
							j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s): ", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  

                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_UnSubscribeByServer - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_UnSubscribeByServer - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}           
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	} 
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
	if (CR_Buffer)
		free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);

	
    return ret;
} // WiPN_UnSubscribe

INT32 WiPN_ChkSubscribe(const CHAR *pSubscribeServerString,
						 const CHAR *pChkSubCmd,
						 CHAR *pListString,
						 UINT32 SizeOfListString,
						 CHAR *pUTCTString,
						 UINT32 SizeOfUTCTString)
{
	if (   !pSubscribeServerString 
		|| !pChkSubCmd 
		|| !pListString 
		|| !pUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pChkSubCmd) 
		|| 0 == SizeOfListString
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	}
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_ChkSubscribe - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
	//// -------------------------------------------------------------------------
    // Calculate the size of SubscribeCmd
    UINT32 Length_ChkSubscribeCmd = strlen("UTCT=0x&")
										+strlen(pChkSubCmd)
										+strlen(pUTCTString); 
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_ChkSubscribeCmd)
    {
        dzlog_error("WiPN_ChkSubscribe - Length Of ChkSubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_ChkSubscribeCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_ChkSubscribe - Malloc ChkSubscribe Cmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_ChkSubscribe - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
    int ret = 0;
    int SubscribeServerHandle = -1;
	short retryCount_RecvFrom = 0;
    srand((UINT32)time(NULL));
	unsigned short PrintfFlag = 0;
	
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;

                // Calculate UTCT time
                UINT32 UTCT_ChkSubscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format Subscribe CMD -> CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pChkSubCmd, (UINT32)UTCT_ChkSubscribe);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("ChkSubscribeCmd= %s ChkSubscribeCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
				
                // Encryption Subscribe CMD -> Buffer            
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_ChkSubscribe - iPN_StringEnc: ChkSubscribe Cmd Enc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				
				UINT16 SizeOfChkSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfChkSubscribeCmd= %d byte (Encrypted Size). sending...", 
							j, &pSubscribeServerDID[index], SizeOfChkSubscribeCmd);
                
                ret = NDT_PPCS_SendTo(&pSubscribeServerDID[index], Buffer, SizeOfChkSubscribeCmd, g_SendToMode);
				
                if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success!");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_ChkSubscribe - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]", 
							j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, please wait ...");
			UINT16 SizeToRead = SizeOfBuffer;
            memset(Buffer, 0, SizeOfBuffer);
            
			ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);         
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet); 
            if (0 > ret)
            {
				dzlog_info("WiPN_ChkSubscribe - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]", 
						j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
               	if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d]", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
   
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_ChkSubscribe - SubscribeServer already call CloseHandle(). SubscribeServerDID[%d]= %s", j, &pSubscribeServerDID[index]);
				} 
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer             
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_ChkSubscribe - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! SubscribeServerDID[%d]= %s.", 
						j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s): ", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
              
                if (0 > GetStringItem(CR_Buffer, "List", '&', pListString, SizeOfListString))
                {
                    dzlog_error("WiPN_ChkSubscribe - Get ListString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_ChkSubscribe - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}        
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	}
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
    if (CR_Buffer)
		free((void *)CR_Buffer);	
    if (Buffer)
		free((void *)Buffer);
    
    return ret;
} // WiPN_ChkSubscribe

INT32 WiPN_ChkSubscribeByServer(const CHAR *pServerString,
								const CHAR *pAES128Key,
								const CHAR *pSubscribeServerString,
								const CHAR *pChkSubCmd,
								CHAR *pListString,
								UINT32 SizeOfListString,
								CHAR *pUTCTString,
								UINT32 SizeOfUTCTString)
{
	if (   !pServerString
		|| !pAES128Key
		|| !pSubscribeServerString 
		|| !pChkSubCmd 
		|| !pListString 
		|| !pUTCTString )
	{
		return WiPN_ERROR_InvalidParameter;
	}
    if (   0 == strlen(pServerString) 
		|| 0 == strlen(pAES128Key) 
		|| 0 == strlen(pSubscribeServerString) 
		|| 0 == strlen(pChkSubCmd) 
		|| 0 == strlen(pUTCTString)
		|| 0 == SizeOfListString
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	//// -------------------------- Get SubscribeServer DID -------------------------
    // Get Number From SubscribeServerString
    unsigned short NumberOfSubscribeServer = 0;
    unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pSubscribeServerString, &NumberOfSubscribeServer, &SizeOfDID) || 0 == NumberOfSubscribeServer)
	{
		return WiPN_ERROR_GetNumberFromSubscribeServerStringFailed;
	}
    SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
    
    // Allocate memory space according to the number of SubscribeServerDID
    CHAR *pSubscribeServerDID = (CHAR *)malloc(SizeOfDID*NumberOfSubscribeServer);
    if (!pSubscribeServerDID)
    {
        dzlog_error("WiPN_ChkSubscribeByServer - Malloc SubscribeServerDID Buf failed!!");
        return WiPN_ERROR_MallocFailed;
    }
    memset(pSubscribeServerDID, '\0', SizeOfDID*NumberOfSubscribeServer);
    
    // Get DID From SubscribeServerString
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfSubscribeServer; i++)
    {
        pDID = pharse_DID(pSubscribeServerString, i);
        if (!pDID)
        {
            free((void *)pSubscribeServerDID);
            return WiPN_ERROR_GetDIDFromSubscribeServerStringFailed;
        }
        memcpy(&pSubscribeServerDID[SizeOfDID*i], pDID, strlen(pDID));
        //dzlog_info("SubscribeServerDID[%d]= %s", i, &pSubscribeServerDID[SizeOfDID*i]);
        free((void*)pDID);
		pDID = NULL;
    }
	//// -------------------------------------------------------------------------
    // Calculate the size of SubscribeCmd
    UINT32 Length_ChkSubscribeCmd = strlen("UTCT=0x&")
										+strlen(pChkSubCmd)
										+strlen(pUTCTString); 
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
    UINT32 MaxSizeOfCmd = 630;
    if (MaxSizeOfCmd < Length_ChkSubscribeCmd)
    {
        dzlog_info("WiPN_ChkSubscribeByServer - Length Of ChkSubscribeCmd is Exceed %d bytes!!", MaxSizeOfCmd);
        free((void *)pSubscribeServerDID);
        return WiPN_ERROR_ExceedMaxSize;
    }
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_ChkSubscribeCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_ChkSubscribeByServer - Malloc ChkSubscribe Cmd Buf failed!!");
		free((void *)pSubscribeServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_ChkSubscribeByServer - Malloc Buffer failed!!");
		free((void *)pSubscribeServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
    int ret = 0;
    int SubscribeServerHandle = -1;
	short retryCount_RecvFrom = 0;
    srand((UINT32)time(NULL));
	unsigned short PrintfFlag = 0;
	
    short index = 0;
    unsigned short j = abs(rand() % NumberOfSubscribeServer);
    while (grunning)
    {
        if (0 > SubscribeServerHandle)
        {
            for (i = 0; i < NumberOfSubscribeServer; i++)
            {
                j = (j + 1) % NumberOfSubscribeServer;
                index = SizeOfDID * j;

                // Calculate UTCT time
                UINT32 UTCT_ChkSubscribe = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
                
                // Format Subscribe CMD -> CR_Buffer
                memset(CR_Buffer, 0, SizeOf_CR_Buffer);
                SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "%sUTCT=0x%X&", pChkSubCmd, (UINT32)UTCT_ChkSubscribe);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("ChkSubscribeCmd= %s ChkSubscribeCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
				
                // Encryption Subscribe CMD -> Buffer            
                if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
                {
                    dzlog_error("WiPN_ChkSubscribeByServer - iPN_StringEnc: ChkSubscribe Cmd Enc failed!");
                    free((void *)pSubscribeServerDID);
                    free((void *)CR_Buffer);
                    free((void *)Buffer);
                    return WiPN_ERROR_iPNStringEncFailed;
                }
				
				UINT16 SizeOfChkSubscribeCmd = strlen(Buffer);
                dzlog_info("send cmd to SubscribeServer, SubscribeServerDID[%d]= %s. SizeOfChkSubscribeCmd= %d byte (Encrypted Size). sending...", 
							j, &pSubscribeServerDID[index], SizeOfChkSubscribeCmd);
                
				// Send CMD to SubscribeServer
				ret = NDT_PPCS_SendToByServer(&pSubscribeServerDID[index], Buffer, SizeOfChkSubscribeCmd, g_SendToMode, pServerString, pAES128Key);
				
                if (0 > ret)
                {
                    dzlog_error("send cmd to SubscribeServer failed! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
                    continue;
                }
                else
                {
					SubscribeServerHandle = ret;
                    dzlog_info("send cmd to SubscribeServer success! ");
                    break;
                }
            }
            if (0 > SubscribeServerHandle)
            {
                dzlog_error("WiPN_ChkSubscribeByServer - Get SubscribeServerHandle failed! SubscribeServerDID[%d]= %s. ret= %d [%s]", 
							j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for SubscribeServer response, please wait ...");
			UINT16 SizeToRead = SizeOfBuffer;
            memset(Buffer, 0, SizeOfBuffer);
            
			ret = NDT_PPCS_RecvFrom(SubscribeServerHandle, Buffer, &SizeToRead, 3000);
            
            // Record RecvFrom return time
            time_t Time_ServerRet = time(NULL);         
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet); 
            if (0 > ret)
            {
				dzlog_info("WiPN_ChkSubscribeByServer - NDT_PPCS_RecvFrom: SubscribeServerDID[%d]= %s. ret= %d. [%s]", j, &pSubscribeServerDID[index], ret, getErrorCodeInfo(ret));
               	if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d]", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
   
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_ChkSubscribeByServer - SubscribeServer already call CloseHandle(). SubscribeServerDID[%d]= %s", 
							j, &pSubscribeServerDID[index]);
				} 
                break;
            }
            else
            {
                // Decrypt received data, Save in CR_Buffer             
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_ChkSubscribeByServer - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! SubscribeServerDID[%d]= %s.", 
							j, &pSubscribeServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From SubscribeServer(Handle:%d, DID[%d]=%s): ", SubscribeServerHandle, j, &pSubscribeServerDID[index]);
				dzlog_info("Data: %sn", CR_Buffer); 
				dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
              
                if (0 > GetStringItem(CR_Buffer, "List", '&', pListString, SizeOfListString))
                {
                    dzlog_error("WiPN_ChkSubscribeByServer - Get ListString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_ChkSubscribeByServer - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
                else // g_Time_ServerRet Must be synchronized with the UTCTString time update
				{
					g_Time_ServerRet = Time_ServerRet;
				}        
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    
    if (0 <= SubscribeServerHandle)
	{
		NDT_PPCS_CloseHandle(SubscribeServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", SubscribeServerHandle);
	}
	if (pSubscribeServerDID)
		free((void *)pSubscribeServerDID);
    if (CR_Buffer)
		free((void *)CR_Buffer);	
    if (Buffer)
		free((void *)Buffer);
    
    return ret;
} // WiPN_ChkSubscribeByServer

#endif // #if SUBSCRIBE_FLAG

#if POST_FLAG
//// WiPN_Post 
INT32 WiPN_Post(const CHAR *pPostServerString, 
				const CHAR *pCmd, 
				CHAR *pRETString, 
				UINT32 SizeOfRETString, 
				CHAR *pUTCTString, 
				UINT32 SizeOfUTCTString)
{
    if (!pPostServerString || !pCmd || !pRETString || !pUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	if (   0 == strlen(pPostServerString) 
		|| 0 == strlen(pCmd)
		|| 0 == strlen(pUTCTString) 
		|| 0 == SizeOfRETString 
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
		
	//// -------------------------- Get PostServer DID -------------------------	
    // Get Number From PostServerString
    unsigned short NumberOfPostServer = 0;
	unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pPostServerString, &NumberOfPostServer, &SizeOfDID) || 0 == NumberOfPostServer)
	{
		return WiPN_ERROR_GetNumberFromPostServerStringFailed;
	}
	SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
	
	// Allocate memory space according to the number of PostServerDID
    CHAR *pPostServerDID = (CHAR *)malloc(SizeOfDID*NumberOfPostServer);
    if (!pPostServerDID)
	{
		dzlog_error("WiPN_Post - Malloc PostServerDID Buf failed!!");
		return WiPN_ERROR_MallocFailed;
	}   
    memset(pPostServerDID, '\0', SizeOfDID*NumberOfPostServer);
    
    // Get DID From PostServerString 
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfPostServer; i++)
    {
        pDID = pharse_DID(pPostServerString, i);
        if (!pDID)
		{
			free((void *)pPostServerDID);
			return WiPN_ERROR_GetDIDFromPostServerStringFailed;
		}   
        memcpy(&pPostServerDID[SizeOfDID*i], pDID, strlen(pDID));    
        //dzlog_info("PostServerDID[%d]=%s", i, &pPostServerDID[SizeOfDID*i]);
		free((void*)pDID);
		pDID = NULL;
    }
	//// -----------------------------------------------------------------------
	
	// Calculate the space required for PostCmd
	UINT32 Length_PostCmd = strlen("UTCT=0x&")+strlen(pUTCTString)+strlen(pCmd);
	
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
	int MaxSizeOfCmd = 630;
	if (MaxSizeOfCmd < Length_PostCmd) 
	{
		dzlog_error("WiPN_Post - Length Of PostCmd is Exceed %d bytes!!", MaxSizeOfCmd);
		free((void *)pPostServerDID);
		return WiPN_ERROR_ExceedMaxSize;
	}
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOf_CR_Buffer = (Length_PostCmd/4+1)*4;
	char *CR_Buffer = (char *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_Post - Malloc PostCmd Buf failed!!n");
		free((void *)pPostServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_Post - Malloc Buffer failed!!");
		free((void *)pPostServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}  
	
	int ret = 0;
    int PostServerHandle = -1;
    short retryCount_RecvFrom = 0;
	unsigned short PrintfFlag = 0;
	
	srand((UINT32)time(NULL));
	short index = 0;
	unsigned short j = abs(rand() % NumberOfPostServer);
    while (grunning)
    {
        if (0 > PostServerHandle)
        {
            for (i = 0; i < NumberOfPostServer; i++)
            {             
				j = (j + 1) % NumberOfPostServer;
				index = SizeOfDID * j;
				
				// Calculate UTCT time
				UINT32 UTCT_Post = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
				
				// Format PostCmd, Save in CR_Buffer
				memset(CR_Buffer, '\0', SizeOf_CR_Buffer);
				SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "UTCT=0x%X&%s", (UINT32)UTCT_Post, pCmd);
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					//dzlog_info("PostCmd= %s PostCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
					
				// encryption PostCmd, Save in Buffer 
				if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
				{
					dzlog_error("WiPN_Post - iPN_StringEnc failed!");
					free((void *)pPostServerDID);
					free((void *)CR_Buffer);
					free((void *)Buffer);
					return WiPN_ERROR_iPNStringEncFailed;
				}
				
				UINT32 SizeOfPostCmd = strlen(Buffer);
				//dzlog_info("send cmd to PostServer, PostServerDID[%d]= %s. SizeOfPostCmd= %d byte (Encrypted Size). sending...", 
				//	j, &pPostServerDID[index], SizeOfPostCmd);

				//unsigned int tick = MyGetTickCount();	
				
				// Send Cmd to PostServer
				ret = NDT_PPCS_SendTo(	&pPostServerDID[index], 
										Buffer, 
										SizeOfPostCmd, 
										g_SendToMode);
				//dzlog_info("NDT_PPCS_SendTo done! TimeUsed: %ld ms", MyGetTickCount() - tick);
				
				if (0 > ret)
                {
                    dzlog_error("send cmd to PostServer failed!! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
					continue;
                }
                else
                {
					PostServerHandle = ret;
                    dzlog_info("send cmd to PostServer success!! ");
                    break;
                }
            }
            if (0 > PostServerHandle)
            {
                dzlog_error("WiPN_Post - Get PostServerHandle failed! PostServerDID[%d]= %s. ret= %d [%s]", j, &pPostServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            //dzlog_info("Waiting for PostServer response, NDT_PPCS_RecvFrom ...");      
			UINT16 SizeToRead = SizeOfBuffer;
			memset(Buffer, 0, SizeOfBuffer); 	
			
			ret = NDT_PPCS_RecvFrom(PostServerHandle, Buffer, &SizeToRead, 3000);
			
			// Record RecvFrom return time
			time_t Time_ServerRet = time(NULL); 
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);
            if (0 > ret)
            {
				dzlog_info("WiPN_Post - NDT_PPCS_RecvFrom: PostServerDID[%d]= %s. ret= %d. [%s]", j, &pPostServerDID[index], ret, getErrorCodeInfo(ret));
                if (ptm)
				{
					//dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}  
        				             				
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_Post - PostServer already call CloseHandle(), PostServerDID[%d]= %s.", j, &pPostServerDID[index]);
				}  
                break;
            }
            else
            {
				// Decrypt received data                         
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_Post - NDT_PPCS_RecvFrom - iPN_StringDnc: RecvFrom Data Dec failed! PostServerDID[%d]: %s", j, &pPostServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                } 
				
				//dzlog_info("From PostServer(Handle:%d, DID[%d]=%s): ", PostServerHandle, j, &pPostServerDID[index]);
				//dzlog_info("Data: %s", CR_Buffer); 
				//dzlog_info("Size: %u byte", (UINT32)strlen(CR_Buffer)); 
				if (ptm)
				{
					//dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}				
 			
				// Get RET 
                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_Post - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
				// Get UTCT 
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_Post - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
				else // g_Time_ServerRet Must be synchronized with the UTCTString time update!!!
				{
					g_Time_ServerRet = Time_ServerRet;
				}
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    if (0 <= PostServerHandle)
	{		
		NDT_PPCS_CloseHandle(PostServerHandle);	
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", PostServerHandle);
	}
	if (pPostServerDID)
		free((void *)pPostServerDID);
	if (CR_Buffer)
		free((void *)CR_Buffer);
    if (Buffer)
		free((void *)Buffer);	
	
    return ret;
}

//// WiPN_PostByServer 
INT32 WiPN_PostByServer(const CHAR *pServerString,
						const CHAR *pAES128Key,
						const CHAR *pPostServerString, 
						const CHAR *pCmd, 
						CHAR *pRETString, 
						UINT32 SizeOfRETString, 
						CHAR *pUTCTString, 
						UINT32 SizeOfUTCTString)
{
    if (   !pServerString 
		|| !pAES128Key 
		|| !pPostServerString 
		|| !pCmd 
		|| !pRETString 
		|| !pUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	if (   0 == strlen(pServerString)
		|| 0 == strlen(pAES128Key)
		|| 0 == strlen(pPostServerString) 
		|| 0 == strlen(pCmd)
		|| 0 == strlen(pUTCTString) 
		|| 0 == SizeOfRETString 
		|| 0 == SizeOfUTCTString)
	{
		return WiPN_ERROR_InvalidParameter;
	}
		
	//// -------------------------- Get PostServer DID -------------------------	
    // Get Number From PostServerString
    unsigned short NumberOfPostServer = 0;
	unsigned short SizeOfDID = 0;
    if (0 > pharse_number(pPostServerString, &NumberOfPostServer, &SizeOfDID) || 0 == NumberOfPostServer)
	{
		return WiPN_ERROR_GetNumberFromPostServerStringFailed;
	}
	SizeOfDID = (SizeOfDID/4+1)*4; // Keep enough distance between DID
	
	// Allocate memory space according to the number of PostServerDID
    CHAR *pPostServerDID = (CHAR *)malloc(SizeOfDID*NumberOfPostServer);
    if (!pPostServerDID)
	{
		dzlog_error("WiPN_PostByServer - Malloc PostServerDID Buf failed!!");
		return WiPN_ERROR_MallocFailed;
	}   
    memset(pPostServerDID, '\0', SizeOfDID*NumberOfPostServer);
    
    // Get DID From PostServerString 
    const CHAR *pDID = NULL;
    int i = 0;
    for ( ; i < NumberOfPostServer; i++)
    {
        pDID = pharse_DID(pPostServerString, i);
        if (!pDID)
		{
			free((void *)pPostServerDID);
			return WiPN_ERROR_GetDIDFromPostServerStringFailed;
		}   
        memcpy(&pPostServerDID[SizeOfDID*i], pDID, strlen(pDID));    
        //dzlog_info("PostServerDID[%d]=%s", i, &pPostServerDID[SizeOfDID*i]);
		free((void*)pDID);
		pDID = NULL;
    }
	//// -----------------------------------------------------------------------

	// Calculate the space required for PostCmd
	UINT32 Length_PostCmd = strlen("UTCT=0x&")
							+strlen(pUTCTString)
							+strlen(pCmd);
	
	// NDT can only send a maximum of 1280 bytes of data, according to the encryption algorithm, encryption data can not be more than 630 bytes
	int MaxSizeOfCmd = 630;
	if (MaxSizeOfCmd < Length_PostCmd) 
	{
		dzlog_info("WiPN_PostByServer - Length Of PostCmd is Exceed %d bytes!!", MaxSizeOfCmd);
		free((void *)pPostServerDID);
		return WiPN_ERROR_ExceedMaxSize;
	}
	
	// Save: 1.Cmd (Encryption before)
	//		2.Response: Server response data (After decryption)
	UINT32 SizeOf_CR_Buffer = (Length_PostCmd/4+1)*4;
	CHAR *CR_Buffer = (CHAR *)malloc(SizeOf_CR_Buffer);
	if (!CR_Buffer)
	{
		dzlog_error("WiPN_PostByServer - Malloc PostCmd Buf failed!!");
		free((void *)pPostServerDID);
		return WiPN_ERROR_MallocFailed;
	}   
		
	
	// Save: 1.Cmd (After encryption)
	//		2.Response: Server response data (After decryption)
	unsigned short SizeOfBuffer = SizeOf_CR_Buffer*2;
	char *Buffer = (char *)malloc(SizeOfBuffer);
	if (!Buffer)
	{
		dzlog_error("WiPN_PostByServer - Malloc Buffer failed!!");
		free((void *)pPostServerDID);
		free((void *)CR_Buffer);
		return WiPN_ERROR_MallocFailed;
	}
	
	int ret = 0;
    int PostServerHandle = -1;
    short retryCount_RecvFrom = 0;
	unsigned short PrintfFlag = 0;	
	
	srand((UINT32)time(NULL));
	short index = 0;
	unsigned short j = abs(rand() % NumberOfPostServer);
    while (grunning)
    {
        if (0 > PostServerHandle)
        {
            for (i = 0; i < NumberOfPostServer; i++)
            {             
				j = (j + 1) % NumberOfPostServer;
				index = SizeOfDID * j;
				// Calculate UTCT time
				UINT32 UTCT_Post = time(NULL) - g_Time_ServerRet + strtol(pUTCTString, NULL, 16);
				
				// Format PostCmd, Save in CR_Buffer
				memset(CR_Buffer, '\0', SizeOf_CR_Buffer);
				SNPRINTF(CR_Buffer, SizeOf_CR_Buffer, "UTCT=0x%X&%s", (UINT32)UTCT_Post, pCmd);
				
				if (0 == PrintfFlag)
				{
					PrintfFlag = 1;
					dzlog_info("PostCmd= %s PostCmdSize= %u byte (Not Encrypted Size)", CR_Buffer, (UINT32)strlen(CR_Buffer));
				}
					
				// encryption PostCmd, Save in Buffer				
				if (0 > iPN_StringEnc(STRING_ENC_DEC_KEY, CR_Buffer, Buffer, SizeOfBuffer))
				{
					dzlog_error("WiPN_PostByServer - iPN_StringEnc: PostCmd Enc failed!");
					free((void *)pPostServerDID);
					free((void *)CR_Buffer);
					free((void *)Buffer);
					return WiPN_ERROR_iPNStringEncFailed;
				}
				
				UINT32 SizeOfPostCmd = strlen(Buffer);
				dzlog_info("send cmd to PostServer, PostServerDID[%d]= %s. SizeOfPostCmd= %d byte (Encrypted Size). sending...", 
						j, &pPostServerDID[index], SizeOfPostCmd);

				//unsigned int tick = MyGetTickCount();		
				
				// Send Cmd to PostServer
				ret = NDT_PPCS_SendToByServer(	&pPostServerDID[index], 
												Buffer, 
												SizeOfPostCmd, 
												g_SendToMode, 
												pServerString, 
												pAES128Key);
				//dzlog_info("NDT_PPCS_SendToByServer done! TimeUsed: %U ms", MyGetTickCount() - tick);
				
				if (0 > ret)
                {
                    dzlog_error("send cmd to PostServer failed!! ret= %d [%s]", ret, getErrorCodeInfo(ret));
                    dzlog_info("retry to send ...");
					continue;
                }
                else
                {
					PostServerHandle = ret;
                    dzlog_info("send cmd to PostServer success!! ");
                    break;
                }
            } // for
            if (0 > PostServerHandle)
            {
                dzlog_error("WiPN_PostByServer - Get PostServerHandle failed! PostServerDID[%d]= %s. ret= %d [%s]", 
						j, &pPostServerDID[index], ret, getErrorCodeInfo(ret));
                break;
            }
        }
        else
        {
            dzlog_info("Waiting for PostServer response, NDT_PPCS_RecvFrom ...");      
			memset(Buffer, 0, SizeOfBuffer); 
			UINT16 SizeToRead = SizeOfBuffer;		
			
			ret = NDT_PPCS_RecvFrom(PostServerHandle, Buffer, &SizeToRead, 3000);
		
			// Record RecvFrom return time
			time_t Time_ServerRet = time(NULL); 
			struct tm *ptm = localtime((const time_t *)&Time_ServerRet);			
            if (0 > ret)
            {
				dzlog_info("WiPN_PostByServer - NDT_PPCS_RecvFrom: PostServerDID[%d]= %s. ret= %d. [%s]", j, &pPostServerDID[index], ret, getErrorCodeInfo(ret));
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}	
				
                // -26 -27 -3
                if ((NDT_ERROR_NoAckFromPushServer == ret || NDT_ERROR_NoAckFromDevice == ret || NDT_ERROR_TimeOut == ret) && 3 > retryCount_RecvFrom)
                {
                    retryCount_RecvFrom++;
                    continue;
                }
                else if (NDT_ERROR_RemoteHandleClosed == ret) // -36
				{
					dzlog_error("WiPN_PostByServer - PostServer already call CloseHandle().");
				}  
                break;
            }
            else
            {
				// Decrypt received data, Save in CR_Buffer                         
                if (0 > iPN_StringDnc(STRING_ENC_DEC_KEY, Buffer, CR_Buffer, SizeOf_CR_Buffer))
                {
                    dzlog_error("WiPN_PostByServer - NDT_PPCS_RecvFrom - iPN_StringDnc:  RecvFromData Dec failed! PostServerDID[%d]: %s", j, &pPostServerDID[index]);
                    ret = WiPN_ERROR_iPNStringDncFailed;
                    break ;
                }
				
				dzlog_info("From PostServer(Handle:%d, DID[%d]=%s): ", PostServerHandle, j, &pPostServerDID[index]);
				dzlog_info("Data: %s", CR_Buffer); 
				dzlog_info("Size: %u byte\n", (UINT32)strlen(CR_Buffer)); 
				if (ptm)
				{
					dzlog_info("LocalTime: %d-%d-%d %d:%d:%d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
				}
				
				// Get RET
                if (0 > GetStringItem(CR_Buffer, "RET", '&', pRETString, SizeOfRETString))
                {
                    dzlog_error("WiPN_PostByServer - Get RETString failed!");
                    ret = WiPN_ERROR_GetRETStringItemFailed;
                    break;
                }
				// Get UTCT 
                if (0 > GetStringItem(CR_Buffer, "UTCT", '&', pUTCTString, SizeOfUTCTString))
                {
                    dzlog_error("WiPN_PostByServer - Get UTCTString failed!");
                    ret =  WiPN_ERROR_GetUTCTStringItemFailed;
                    break;
                }
				else // g_Time_ServerRet Must be synchronized with the UTCTString time update!!!
				{
					g_Time_ServerRet = Time_ServerRet;
				}
                break;
            } // ret > 0
        } // Handle > 0
    } // while (1)
    if (0 <= PostServerHandle)
	{			
		NDT_PPCS_CloseHandle(PostServerHandle);
		dzlog_info("NDT_PPCS_CloseHandle(%d) done!", PostServerHandle);
	}
	if (pPostServerDID)
		free((void *)pPostServerDID);
    if (CR_Buffer)
		free((void *)CR_Buffer);
	if (Buffer)
		free((void *)Buffer);
	
    return ret;
}
#endif // #if POST_FLAG
