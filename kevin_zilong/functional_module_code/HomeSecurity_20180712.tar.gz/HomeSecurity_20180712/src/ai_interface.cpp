/*============================================================================
 Name        : ai_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-12-05
 Description :
 ============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <openssl/md5.h>

#include "ai_interface.h"
#include "sys_interface.h"
#include "local_storage_interface.h"
#include "PPCS/PPCS_Error.h"

#define TCP_SERVER_ADDR "192.168.32.3"

#if RUN_AI_MODULE

static rspacket m_packet;
static int m_clientfd = -1;

static int algo_id = MODE_MAX;
static int algo_result = 0;     // 数据帧的人脸总数

int send_frame_No = 1;
int recv_frame_No = 1;
int gAI_pipe[2] = {-1};

extern int grunning;
extern int ai_face_track_channel;

int InitTcpClient(const char *addr)
{
    int ret;
    int yes = 1;
    
    m_clientfd = socket(AF_INET, SOCK_STREAM, 0);
    if (m_clientfd < 0)
    {
        dzlog_error("AI socket err:%s", strerror(errno));
        return -1;  // AI模块没有准备好
    }

    ret = setsockopt(m_clientfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (ret < 0)
    {
        dzlog_error("setsockopt: %s", strerror(errno));
        goto exit_close;
    }

    int nSendBuf = sizeof(rspacket);
    if(setsockopt(m_clientfd, SOL_SOCKET, SO_SNDBUF,  (const char*)&nSendBuf, sizeof(int)) < 0) 
    {
        dzlog_error("setsockopt error");
        goto exit_close;
    }
    int nRecvBuf = sizeof(rspacket);
    if(setsockopt( m_clientfd, SOL_SOCKET, SO_RCVBUF, (const char*)&nRecvBuf, sizeof(int)) < 0 )
    {
        dzlog_error("setsockopt error");
        goto exit_close;
    }

    struct timeval timeout;  
    timeout.tv_sec = 0;  
    timeout.tv_usec = 60*1000;        
    socklen_t len = sizeof(timeout);
    if (setsockopt(m_clientfd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) < 0)
    {
        dzlog_error("setsockopt error");
        goto exit_close;
    }

    struct sockaddr_in svr_addr;
    svr_addr.sin_family      = AF_INET;
    svr_addr.sin_port        = htons(TCP_SERVER_PORT);
    svr_addr.sin_addr.s_addr = inet_addr(addr);
    memset(svr_addr.sin_zero, 0, sizeof(svr_addr.sin_zero));

    ret = connect(m_clientfd, (struct sockaddr *)&svr_addr, sizeof(svr_addr));
    if (ret == -1)
    {
        dzlog_error("connect AI(%s:%d) fail，err: %s\n", addr, TCP_SERVER_PORT, strerror(errno));
        if (errno == EINPROGRESS)
        {
            zx_do_system("%s", "gpio dirout 15");
            zx_do_system("%s", "gpio set 15");
            usleep(50*1000);
            zx_do_system("%s", "gpio clear 15");
        }
    }
    else
    {
        dzlog_info("Init Client, AI server(%s:%d)", addr, TCP_SERVER_PORT);
        return 0;
    }

exit_close:
    close(m_clientfd);
exit:
    m_clientfd = -1;
    return -1;
}

void UninitTcpClient(void)
{
    if (-1 != m_clientfd)
    {
        dzlog_info("close m_clientfd...\n");
        close(m_clientfd);
        m_clientfd = -1;
    }
    ai_face_track_channel = -1;
}

int zx_wait_AI_res(int command_id, int channel)
{
    packet_head comm_pack;
    fd_set rfds;
    struct timeval tv; 
    dzlog_info("wait_AI_res: cmdtype=0x%x, channel=%d", command_id, channel);
    tv.tv_sec = 1;
    tv.tv_usec = 0;    

    FD_ZERO(&rfds);
    FD_SET(gAI_pipe[0], &rfds);
    memset((char *)&comm_pack, 0, HEADSIZE);
    switch(select(gAI_pipe[0] + 1, &rfds, NULL, NULL, &tv))
    {
        case -1:
            break;

        case 0:
        {
            return ERROR_WAIT_TIMEOUT;
        }

        default: 
        {
            if(FD_ISSET(gAI_pipe[0], &rfds)) 
            {
                FD_CLR(gAI_pipe[0], &rfds);
                if (read(gAI_pipe[0], &comm_pack, HEADSIZE) <=0)
                {
                    dzlog_error("pipe read fail");
                    break;
                }
                dzlog_info("get AI_res: cmdtype=0x%x, channel=%d", comm_pack.cmdtype, comm_pack.id);
                if (command_id == comm_pack.cmdtype && channel == comm_pack.id)
                {
                    return 0;
                }                
            }
        }
        break;
    }

    return ERROR_WAIT_TIMEOUT;
}

int zx_set_ai_workmode(char mode, char channel)
{
    int ret = send_packet_to_ai(AI_CMD_SET_WORKMODE, channel, &mode);
    if (ret <= 0)
    {
        dzlog_error("AI_CMD_SET_WORKMODE fail\n");        
    }
    else
    {
        algo_id = mode;
    }
    return ret;
}

void * ai_recv_response_thread(void *argv)
{
    int ret,i;
    struct timeval tv;
    fd_set rfds;
    int recvbytes;
    unsigned int actualRevBytes = 0;    //有中断的情况下recv可能会被打断
    unsigned int needRcvBytes;

    dzlog_info("ai_recv_response_thread, PID %d", getpid());
    while (grunning)
    {
ai_recv_magic_again:
        if (m_clientfd == -1)
        {
            break;
        }
        tv.tv_sec  = 60;
        tv.tv_usec = 0;
        
        FD_ZERO(&rfds);
        FD_SET(m_clientfd, &rfds);

        ret = select(m_clientfd + 1, &rfds, NULL, NULL, &tv);
        if (ret < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            dzlog_error("select error!");
            goto ai_recv_response_exit;
        }
        else if (ret == 0)
        {
            dzlog_info("ai_recv_response_thread timeout!");
        }
        else if (ret > 0)
        {
            /*check rfds fd*/
            if (FD_ISSET(m_clientfd, &rfds))
            {
                actualRevBytes = 0;
                memset(m_packet.head.magic, 0, MAGIC_SIZE);
                while (actualRevBytes < MAGIC_SIZE)
                {
                    needRcvBytes = MAGIC_SIZE - actualRevBytes;
                    recvbytes = recv(m_clientfd, &m_packet.head.magic[actualRevBytes], needRcvBytes, 0);
                    if (recvbytes <= 0)
                    {
                        if (errno == EINTR || errno == EAGAIN)
                        {
                            if (actualRevBytes)
                            {
                                continue;
                            }
                            else
                            {
                                goto ai_recv_magic_again;
                            }
                        }
                        dzlog_info("read magic failed: %s\n", strerror(errno));
                        goto ai_recv_response_exit;
                    }
                    else
                    {
                        actualRevBytes += recvbytes;
                    }
                }
                if (0 != memcmp(m_packet.head.magic, HEAD_MAGIC, MAGIC_SIZE))
                {
                    dzlog_error("invalid head!\n");
                    goto ai_recv_magic_again;
                }

                actualRevBytes = 0;
                while (actualRevBytes < HEADSIZE-MAGIC_SIZE)
                {
                    needRcvBytes = HEADSIZE - MAGIC_SIZE - actualRevBytes;
                    recvbytes = recv(m_clientfd, &m_packet.head.version + actualRevBytes, needRcvBytes, 0);
                    if (recvbytes <= 0)
                    {
                        dzlog_info("read bodysize failed: %s\n", strerror(errno));
                        if (errno == EINTR || errno == EAGAIN)
                        {
                            continue;
                        }
                        goto ai_recv_response_exit;
                    }
                    else
                    {
                        actualRevBytes += recvbytes;
                    }
                }

                m_packet.head.bodysize = ntohl(m_packet.head.bodysize);
                if (m_packet.head.bodysize > AI_BUFSIZE)
                {
                    dzlog_error("recv AI cmdtype: 0x%x, bodysize=%d \n", m_packet.head.cmdtype, m_packet.head.bodysize);
                    goto ai_recv_magic_again;
                }

                actualRevBytes = 0;
                dzlog_info("recv AI cmdtype: 0x%x, bodysize:%d", m_packet.head.cmdtype, m_packet.head.bodysize);
                while (actualRevBytes < m_packet.head.bodysize)
                {
                    needRcvBytes = m_packet.head.bodysize - actualRevBytes;
                    recvbytes = recv(m_clientfd, &m_packet.param_body.face_data[actualRevBytes], needRcvBytes, 0);
                    if (recvbytes <= 0)
                    {
                        dzlog_info("read data failed:%s\n", strerror(errno));
                        if (errno == EINTR || errno == EAGAIN)
                        {
                            continue;
                        }
                        goto ai_recv_response_exit;
                    }
                    else
                    {
                        actualRevBytes += recvbytes;
                    }
                }

                switch(m_packet.head.cmdtype)
                {
                    case AI_REPLY_PING:
                    {
                        dzlog_info("ping: %s",m_packet.param_body.ai_ping.ping_status);
                    }
                    break;

                    case AI_REPLY_VERSION:
                    {
                        dzlog_info("AI version: %s-%s-%s", m_packet.param_body.ai_module_version.algorversion,
                                    m_packet.param_body.ai_module_version.kernelversion,
                                    m_packet.param_body.ai_module_version.rootfsversion);
                        write(gAI_pipe[1], &m_packet.head, HEADSIZE);
                    }
                    break;

                    case AI_REPLY_MODE:
                    {
                        if (algo_id == MODE_FACE_TRACK)
                        {
                            ai_face_track_channel = m_packet.head.id;
                        }
                        else if (algo_id == MODE_FACE_BODY_RECOGNITION)
                        {
                            ai_face_track_channel = -1;
                        }
                        dzlog_info("camera_id %d, algor id: %d ------->", m_packet.head.id, algo_id);                        
                    }
                    break;

                    case AI_REPLY_START:
                    {
                        dzlog_info("AI start ok");
                        recv_frame_No = 1;
                        write(gAI_pipe[1], &m_packet.head, HEADSIZE);
                    }
                    break;

                    case AI_REPLY_H264FRAME:
                    {
                        dzlog_info("recv h264 frame No: %d", m_packet.param_body.h264_result.frame_num);
                        //recv_frame_No = m_packet.param_body.h264_result.frame_num;
                    }
                    break;

                    case AI_REPLY_FACE:
                    {
                        RS_REP_ALGO_RESULT *rep = (RS_REP_ALGO_RESULT *)m_packet.param_body.face_data;
                        RS_FACE_RECOGNITION_RESULT *face = (RS_FACE_RECOGNITION_RESULT *)rep->data;

                        dzlog_info("AI FACE: camera_id: %d, frame No: %d, faces count: %d", m_packet.head.id, rep->index, rep->cnt);
                        recv_frame_No = rep->index;
                        algo_result = rep->cnt;
                        for (i = 0; i < rep->cnt; i++)
                        {
                            dzlog_info("Face %d position is: [%d, %d, %d, %d]", i,
                                       face->left, face->top, face->right, face->bottom);
                            face += 1;
                        }
                        if (algo_result > 0)
                        {
                            update_storage_status_by_channel(m_packet.head.id, STORAGE_OPEN_FILE);
                        }
                    }
                    break;

                    case AI_REPLY_BODY:
                    {
                        RS_REP_ALGO_RESULT *rep = (RS_REP_ALGO_RESULT *)m_packet.param_body.face_data;
                        RS_BODY_DETECTION_RESULT *body = (RS_BODY_DETECTION_RESULT *)rep->data;

                        dzlog_info("AI BODY: camera_id: %d, frame No: %d, bodys count: %d", m_packet.head.id, rep->index, rep->cnt);
                        algo_result = rep->cnt;
                        recv_frame_No = rep->index;
                        for (i = 0; i < rep->cnt; i++)
                        {
                            dzlog_info("Body %d position is: [%d, %d, %d, %d]", i,
                                   body->left, body->top, body->right, body->bottom);
                            body += 1;
                        }
                    }
                    break;

                    case AI_REPLY_FACETRACK:
                    {
                        RS_REP_ALGO_RESULT *rep = (RS_REP_ALGO_RESULT *)m_packet.param_body.face_data;
                        RS_FACE_TRACKING_RESULT *ft = (RS_FACE_TRACKING_RESULT *)rep->data;

                        dzlog_info("AI FACETRACK: camera_id: %d, frame No: %d, faces count: %d", m_packet.head.id, rep->index, rep->cnt);
                        algo_result = rep->cnt;
                        recv_frame_No = rep->index;
                        for (i = 0; i < rep->cnt; i++)
                        {
                            dzlog_info("Face %d position is: [%d, %d, %d, %d]",
                                       ft->index, ft->left, ft->top, ft->right, ft->bottom);
                            if (ft->fr_available_flag)
                            {
                                dzlog_info("fr_available_flag: %d", ft->index);
                            }
                            ft += 1;
                        }

                        if (algo_result == 0 && algo_id != MODE_FACE_BODY_RECOGNITION)
                        {
                            zx_set_ai_workmode(MODE_FACE_BODY_RECOGNITION, m_packet.head.id);
                            //update_storage_status_by_channel(m_packet.head.id, MODE_FACE_BODY_RECOGNITION);
                        }
                    }
                    break;

                    case AI_REPLY_AUDIO_OPEN:
                    {
                        dzlog_info("return AI_REPLY_AUDIO_OPEN %0x", m_packet.param_body.ai_para_ok.get_value);
                    }
                    break;

                    case AI_REPLY_AUDIO_DATA:
                    {
                        dzlog_info("AI_REPLY_AUDIO_DATA %d", m_packet.param_body.ai_data_ok.get_value);
                    }
                    break;

                    case AI_REPLY_AUDIO_CLOSE:
                    {
                        dzlog_info("return AI_REPLY_AUDIO_CLOSE %0x", m_packet.param_body.ai_over_ok.get_value);
                    }
                    break;

                    case AI_REPLY_REBOOT:
                    {
                        dzlog_info("reboot AI module\n");
                    }
                    break;

                    case AI_REPLY_SET_SN:
                    {
                        dzlog_info("AI_REPLY_SET_SN ACK %d", m_packet.param_body.ai_sn_result.get_value);
                    }
                    break;

                    case AI_REPLY_GET_SN:
                    {
                        dzlog_info("return AI_REPLY_GET_SN %s", m_packet.param_body.ai_get_sn.sn_num);
                    }
                    break;

                    case AI_REPLY_FW_PREPARE:
                    {
                        dzlog_info("AI_REPLY_FW_PREPARE %d", m_packet.param_body.ai_updata_result.get_value);
                    }
                    break;

                    case AI_REPLY_FW_DATA:
                    {
                        dzlog_info("AI_REPLY_FW_DATA:pack_num %d, value %d", m_packet.param_body.ai_updata_data_result.pack_num,
                                    m_packet.param_body.ai_updata_data_result.get_value);
                    }
                    break;

                    case AI_REPLY_FW_UPDATE:
                    {
                        dzlog_info("return AI_REPLY_FW_UPDATE %0x %0x", m_packet.param_body.ai_md5_result.get_value);
                    }
                    break;

                    default:
                    {
                        dzlog_error("recv no cmdtype = 0x%x\n", m_packet.head.cmdtype);
                    }
                    break;
                }
           }
       }
    }

ai_recv_response_exit:
    UninitTcpClient();
    zx_clear_thread_info_by_type(AI_RECV);
    dzlog_info("ai_recv_response_thread exit......");
    pthread_exit(0);
}



// 阻塞式，直到接收到应答
int send_packet_to_ai(unsigned char cmdtype, char channel, void *pdata)
{
    int ret = -1;
    if (m_clientfd == -1)
    {
        return -1;
    }
    memcpy(m_packet.head.magic, HEAD_MAGIC, MAGIC_SIZE);
    m_packet.head.version = 0;
    m_packet.head.id = channel;     // camera id
    m_packet.head.cmdtype = cmdtype;

    switch(cmdtype)
    {
        case AI_CMD_PING:
        case AI_CMD_GET_VISION:
        case AI_CMD_START:
        case AI_CMD_PLAYER_PCM_STOP:
        case AI_CMD_GET_SN:
        {
            m_packet.head.bodysize = 0;
            dzlog_info("send AI cmd = 0x%x", cmdtype);
        }
        break;

        case AI_CMD_REBOOOT:
        {
            dzlog_info("send AI_CMD_REBOOOT");
        }
        break;

        case AI_CMD_SET_WORKMODE:
        {
            m_packet.head.bodysize = htonl(sizeof(AI_ALGORITHM_CONTROL));
            m_packet.param_body.ai_algor_ctrl.algor_id = *(char *)pdata;
            dzlog_info("AI_CMD_SET_WORKMODE, algor_id = %d", *(char *)pdata);
        }
        break;

        case AI_CMD_PLAYER_PCM_PARA:
        {
            m_packet.head.bodysize = htonl(sizeof(AI_PCM_PARA));
            m_packet.param_body.ai_para.rate = 44100;
            m_packet.param_body.ai_para.bits = 16;
            m_packet.param_body.ai_para.channels = 2;
            m_packet.param_body.ai_para.volume = *(unsigned char*)pdata;
            dzlog_info("AI_CMD_PLAYER_PCM_PARA,volume = %d", *(unsigned char*)pdata);
        }
        break;

        case AI_CMD_UPDATA_FIRMWARE_OTA:
        {
            m_packet.head.bodysize = htonl(sizeof(AI_UPDATE_TYPE));
            m_packet.param_body.ai_updata_type.type = *(unsigned char*)pdata;
            dzlog_info("AI_CMD_UPDATA_FIRMWARE_OTA, ai_updata_type = %d", *(unsigned char*)pdata);
        }
        break;

        case AI_CMD_SET_SN:
        {
            m_packet.head.bodysize = htonl(sizeof(AI_SET_MODULE_SN));
            memcpy(m_packet.param_body.ai_set_sn.sn_num, pdata, sizeof(AI_SET_MODULE_SN));
        }
        break;

        case AI_CMD_PLAYER_PCM_TRAN:
        {
            //m_packet.head.bodysize = htonl(0);
            //memcpy(m_packet.param_body.ai_data.buffer, pdata, 0);
        }
        break;

        case AI_CMD_TRANSFORH264:
        {
            AI_FRAME_ST *pH264 = (AI_FRAME_ST *)pdata;
            if (pH264->len > AI_DATA_SIZE)
            {
                return -1;
            }
            dzlog_info("AI_CMD_SENDH264: S_frame_No=%d, R_frame_No=%d, size = %d", send_frame_No/*pH264->frame_No*/, recv_frame_No, pH264->len);
            m_packet.head.bodysize = htonl(pH264->len + 4);
            m_packet.param_body.h264_pkt.frame_count = send_frame_No;//pH264->frame_No;
            memcpy(m_packet.param_body.h264_pkt.buffer, pH264->buf, pH264->len);
            recv_frame_No = 0;
            send_frame_No +=1;
        }
        break;

        default:
            return -1;
    }
    ret = send(m_clientfd, (char *)&m_packet, HEADSIZE + ntohl(m_packet.head.bodysize), 0); // MSG_DONTWAIT
    if (ret <= 0)
    {
        dzlog_info("send failed:errno=%d, %s\n", errno, strerror(errno));
        if (errno != EINTR && errno != EAGAIN)
        {
             UninitTcpClient();
        }
    }

    return ret;
}


int zx_init_ai_model(void)
{
    int ret = 0;
    if (m_clientfd == -1)
    {
        ret = InitTcpClient(TCP_SERVER_ADDR);
        if ( ret == 0)
        {
            if (pipe(gAI_pipe) != 0)
            {
                dzlog_error("create gAI_pipe fail...");
                ret = -1;
            }
            else
            {
                zx_create_thread(LOW_PRIORITY, ai_recv_response_thread, NULL, -1, AI_RECV, -1);
            }
        }                
    }
    return ret;
}

int zx_deinit_ai_model(void)
{
    UninitTcpClient();
    if (gAI_pipe[0] >= 0)
    {
        close(gAI_pipe[0]);
    }
    if (gAI_pipe[1] >= 0)
    {
        close(gAI_pipe[1]);
    }
    return 0;
}

#endif

