/*============================================================================
 Name        : security_main
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-11-21 
 Description :
 ============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/select.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <dirent.h>  

//#include "Xm_lib.h"
#include "comm_protocol_define.h"
#include "as_interface.h"
#include "ppcs_interface.h"
#include "enc_decrypt_interface.h"
#include "sub1g_interface.h"
#include "broadcast_interface.h"
//#include "media_interface.h"
#include "push_interface.h"
#include "circular_buffer.h"
#include "hisi_interface.h"
#include "sys_interface.h"
#include "local_storage_interface.h"
#include "zlog.h"
#include "cloud_storage_interface.h"
#include "ota_interface.h"
#include "push_stream.h"
#include "hal_interface.h"
#include "hisi_interface.h"
#include "hal_video.h"
#include "floodlight_interface.h"
#include "cjson.h"
#include "ntpclient.h"

unsigned char gsystem_init = 0;
unsigned char grunning = 1; 
HUB_BASE_PARAM *base_param = NULL;
unsigned char gbopen_p2p = 1;
unsigned int tfcard_free_mb = 0; // T卡可用空间，如果无卡，为0
unsigned int tfcard_format_flg = 0; // T卡格式化标记, 0: 不需要，1:正在格式化, 2:格式化失败
extern int ai_play_wav_flg;


#define CMD_ARRAY_MAX   (50)
#define CMD_ITEM_MAX    (32)
#define CMD_LINE_MAX    (CMD_ARRAY_MAX * CMD_ITEM_MAX)

//static sem_t g_semCmdLoop; 
static char cmd_array[CMD_ARRAY_MAX][CMD_ITEM_MAX];
//static int  cmd_num = 0;

//HISI_CAMERA_PRA_INFO *hisi_cam_info = NULL;
//HISI_WIFI_INFO *hisi_wifi_info = NULL;


extern HISI_CAMERA_INFO_DATA * hisi_cam_data;
extern HISI_WIFI_LIST_DATA *hisi_wifi_list;
extern HISI_CAMERA_WIFI_DATA *hisi_cam_wifi;
extern int hisi_bind_dev_grunning;
extern FILE *hisi_audio;


int g_argc = 0;
char **g_argv = NULL;

short wifi_connect_status = 0;
short p2p_status = 0;


#if SQLITE3

#include "sqlite3.h"

int callback(void *p,int n,char **f_value,char **f_name)//n代表了表中的列数 f_value
{
    int i;
    if(*(int *)p == 1)
    {
        for(i = 0;i < n;i ++)
        {
            printf("%s\t",f_name[i]);
        }
        printf("\n");
        *(int *)p = 0;
    }
    for(i = 0;i < n;i ++)
    {
        printf("%s\t",f_value[i]);
    }
    printf("\n");
    return 0;
}

int test_sqlite3()
{
    sqlite3 *db;
    char *errmsg;
    if(sqlite3_open("./my.db",&db) != SQLITE_OK)
    {
        puts(sqlite3_errmsg(db));
        exit(1);
    }

    char sqlopt[64];
    sprintf(sqlopt,"create table stu(name,id);");
    if(sqlite3_exec(db,sqlopt,NULL,NULL,&errmsg) != SQLITE_OK)
    {
        puts(errmsg);
        exit(1);
    }
#if 0
    sprintf(sqlopt,"insert into stu values('lxs',1000);");
    if(sqlite3_exec(db,sqlopt,NULL,NULL,&errmsg) != SQLITE_OK)
    {
        puts(errmsg);
        exit(1);
    }
#endif 

    char name[15];
    int id;
    int i;

    for(i = 0;i < 2;i ++)
    {
        printf("请输入数据:");
        scanf("%s%d",name,&id);

        sprintf(sqlopt,"insert into stu values('%s',%d);",name,id);
        sqlite3_exec(db,sqlopt,NULL,NULL,&errmsg);

    }

    int a = 1;
    sprintf(sqlopt,"select * from stu;");
    if(sqlite3_exec(db,sqlopt,callback,&a,&errmsg) != SQLITE_OK)
    {
        puts(errmsg);
        exit(1);
    }

    char **val;// char *val[];
    int r;
    int c;
    sprintf(sqlopt,"select * from stu;");
    if(sqlite3_get_table(db,sqlopt,&val,&r,&c,&errmsg) != SQLITE_OK)
        //r代表数据的行数，c代表列数
    {
        puts(errmsg);
        exit(1);
    }

    for(i = 0;i < c;i ++)
    {
        printf("%s\t",val[i]);
    }
    printf("\n");
    int count = 0;
    for(i = c;i < (r + 1) * c;i ++)
    {
        printf("%s\t",val[i]);
        count ++;
        if(count % c == 0)
            printf("\n");
    }
    return 0;
}
#endif

void * set_hisi_time(void *data)
{
	int ret = -1;
	
	dzlog_info("set_hisi_time, PID = %d......", getpid());

#if 0
		dzlog_info("【------hisi time set start.------】");

		zx_ota_system("/bin/ntpclient -c 1 -h time.nist.gov -s");				//设置时间和时区

		dzlog_info("【------hisi time set is OK.------】");

		//zx_set_timetone("GMT-8");  //设置时区

		dzlog_info("set timeone is ok");
#endif

	ret = zx_hisi_time_calibration();

	if(ret != 0)
	{
		dzlog_error("hisi time claibration error");
		
	}

	pthread_exit(0);
	return;
		
}

static void * net_detection(void *argv)
{
    //int eth_status = 0;
	int wifi_status = 0;
    int net_status = 1; //开机后,主线保证网络ok
    zx_Error err;
	int ret = -1;

#if 0
    int old_status = zx_internet_detection(GOOGLEDNS);//zx_eth_state_get();
    dzlog_info("net_detection,curr_eth_status = %d ,PID=%d", old_status, getpid());
#endif

    struct timeval tv;
    while(grunning)
    {
        tv.tv_sec = TIMER_ETH_DETCTION;
        tv.tv_usec = 0;

        switch(select(0, NULL, NULL, NULL, &tv))
        {
            case -1:
            dzlog_info("select Error!");
            break;

            case 0:
            {
#if RUN_P2P_SERVER

				wifi_status = zx_hisi_wifi_state_get(hisi_cam_wifi->wifi_ssid);

				if ( wifi_status == 2 )
                {

					wifi_connect_status = WIFI_CONNECTED;

					gsystem_init = 1;

				#if 0
                    if (net_status == 0)
                    {
                        err = zx_active_curl_for_thread();
                        if (err.code == AS_HTTP_200)
                        {
                            dzlog_info("net connected......");
							
						#if 0
                            zx_hub_sub1g_led_control(RED_LED, 0);
                            zx_hub_sub1g_led_control(WHITE_LED, 1);
						#endif
						
                            PPCS_Listen_Break();
                            net_status = 1;
                        }
                    }
				#endif

#if 0
                    if (wifi_status) // 断网重联,查看是否有本地存储文件要重传
                    {
                        zx_resend_hub_history_record();
                    }
	#endif
                }
				else{
					
					wifi_connect_status = WIFI_NO_CONNECT;
					
					dzlog_info("net disconnected......");
					
				}

			#if 0
                if (eth_status == 0 && old_status == 1)
                {
                    dzlog_info("net disconnected......");
					
				#if 0
                    zx_hub_sub1g_led_control(RED_LED, 1);
                    zx_hub_sub1g_led_control(WHITE_LED, 0);
				#endif
				
                    net_status = 0;
                }
                old_status = eth_status;
			#endif
#endif
            }
            break;

            default:
                break;
        }  
    }  
    dzlog_info("exit...... ");
    return 0;
} 


int zx_system_update()
{
	int ret = -1;

	zx_get_system_soft_version(base_param->hub_info.hub_software_main_ver);			//获取基站版本号

 	zx_get_system_soft_version(base_param->dev_param[0].dev_software_main_ver);		//获取设备版本号
		
 	dzlog_info("【system version = %s】", base_param->hub_info.hub_software_main_ver);
	
	VERSION_UPGRADE *home_security_version = zx_get_all_upgrade_version_info(base_param->hub_info.hub_software_main_ver, 
												OTA_PAKAGE, 0, base_param->hub_info.hub_sn);  //总是取最新的版本，写了个0
	if (home_security_version)
	{
		dzlog_info("【get all upgrade version info ok.】");
		
		VERSION_UPGRADE *hub_main_sys_ver = get_device_type_info(home_security_version, FLOODLIGHT_SYSTEM);

		if (hub_main_sys_ver)
		{
			ret = zx_hub_ota_process((void *)hub_main_sys_ver, hub_main_sys_ver->rom_version_name, base_param->hub_info.hub_software_main_ver);
			
		}else{
			
			dzlog_warn("【get FLOODLIGHT SYSTEM version info is NULL，system not upgrade. ret = %d】",ret);
		}
	
		zx_upgrade_free(home_security_version);						
	}
	return ret;
}


static void * zx_ota_server(void *argv)  
{  
	int ret = -1;
	dzlog_info("zx_ota_server, PID=%d......", getpid());
	struct timeval tv; 

	ret = zx_hisi_time_calibration();				//校时一次

	if(ret != 0)
	{
		dzlog_error("hisi time claibration error");
		
	}
	
    while(grunning)  
    {  
		tv.tv_sec = TIMER_OTA_EVERY_DAY;    
        tv.tv_usec = 0; 

        switch(select(0, NULL, NULL, NULL, &tv))   
        {  
        	case -1:  
            	dzlog_info("select Error!");  
            	break;  
        	case 0:  
				{

					ret = zx_hisi_time_calibration();			//每天校时一次

					if(ret != 0)
					{
						dzlog_error("hisi time claibration error");
						
					}

#if ZX_UPGRADE_EN

#if 0
					zx_upload_dev_info();				//更新设备信息
#endif

					if (zx_system_update() == 0)
					{
						grunning = 0;	
					}
					//ota 				
#endif
				} 
            	break;  
        	default:  
            	break;  
        }  
    }  
 	dzlog_info("exit...... ");
	return 0;		
}


static void * zx_watch_dog(void *argv)  
{  
	dzlog_info("zx_watch_dog, PID=%d-----------", getpid());
	struct timeval tv; 

    while(grunning)  
    {  
		tv.tv_sec = TIMER_WATCH_DOG;    
        tv.tv_usec = 0;    
          
        switch(select(0, NULL, NULL, NULL, &tv))   
        {  
        	case -1:  
            	dzlog_info("select Error!");  
            	break;  
        	case 0:  
				{
				#if 0
					appclient_SendWatchdogTickReq(); 
				#endif
				} 
            	break;  
        	default:  
            	break;  
        }  
    }  
 	dzlog_info("exit...... ");
	return 0;		
}  

void sig_quit(int arg)
{
	//dzlog_info("sig_handler, arg = %d", arg);
	//printf("program exit\n");
	
	grunning = 0;
	hisi_bind_dev_grunning = 0;
	gbopen_p2p = 0;
	
	//exit(0);
}

int zx_check_tfcard_device(void)
{
    char sd_req = '0';
    FILE *fd = fopen("/var/run/sd_req", "r");   //判断TFcard是否挂载
    if (fd)
    {
        fread(&sd_req, 1, 1, fd);
        fclose(fd);
        dzlog_info("TFcard status: %c", sd_req);
        if (sd_req == '1')
        {
            zx_push_tfcard_message("home_security", "TF card info", TFCARD_NON_ORIGINAL);
            return 0;
        }
    } 

    if(tfcard_free_mb == 0) // 推送服务起来后才能发
    {
        zx_push_tfcard_message("home_security", "TF card info", TFCARD_MOUNT_FAIL);
    }

    return 0;
}

void sig_key_proces(int arg)
{
	dzlog_info("arg = %d", arg);	
}

void sig_tf_status_proces(int arg)
{
    dzlog_info("arg = %d", arg);
    switch(arg)
    {
        case TF_INSERT:
        {
        }
        break;

        case TF_REMOVE:
        {
            tfcard_free_mb = 0; // 拨出T card
            dzlog_warn("T card pull out\n");
            free_all_link_node();
            if (tfcard_format_flg == 0) // 不在格式化状态
            {
                zx_push_tfcard_message("home_security", "TF card info", TFCARD_REMOVE);
            }
        }
        break;

        case TF_INSERT_MOUNT:
        {
            //zlog_fini(); // 这个function会阻塞系统
            int rc = dzlog_init(LOG_CONF, "");
            if (rc)
            {
                printf("------>> init failed\n");
            }

            if (zx_create_dir("/media/mmcblk0p1/video/") == 0)
            {// 文件系统可写
                tfcard_free_mb = get_system_tf_free(NULL);
                if (tfcard_free_mb > 0)
                {
                    dzlog_warn("T card insert, freeDisk=%dMB", tfcard_free_mb);
                    get_all_link_from_flash();
                }
                if (tfcard_format_flg)
                {
                    zx_push_tfcard_message("home_security", "TF card info", TFCARD_NORMAL);
                    tfcard_format_flg = 0;
                }
            }
            else
            {
                tfcard_free_mb = 0;
                zx_push_tfcard_message("home_security", "TF card info", TFCARD_MOUNT_FAIL);
            }
        }
        break;

        case TF_REMOVE_UMOUNT:
        {
            //zlog_fini(); // 这个function会阻塞系统
        }
        break;

        case TF_INSERT_FORMAT: // 非标配卡要format
        {
            zx_push_tfcard_message("home_security", "TF card info", TFCARD_NON_ORIGINAL); //格式化失败
        }
        break;

        case TF_FORMAT_FAIL: // TF卡挂载失败或格式化失败
        {
            // 发送TF卡失败通知
            if (tfcard_format_flg == 0)
            {
                zx_push_tfcard_message("home_security", "TF card info", TFCARD_MOUNT_FAIL); //文件系统挂载失败
            }
            else
            {
                zx_push_tfcard_message("home_security", "TF card info", TFCARD_FORMAT_FAIL); //格式化失败
                tfcard_format_flg = 0;
            }
        }
        break;

        case TF_FORMAT_BUSY:
        {
            if (tfcard_format_flg != 0)
            {
                zx_push_tfcard_message("home_security", "TF card info", TFCARD_BUSY); //设备忙
                tfcard_format_flg = 0;
            }
        }
        break;

        default:
            break;
    }
}


static void show_cmd_prompt(void)
{
    printf("$ ");
} 


static void get_cmd_line(char *pCmd)
{
    int  nIndex = 0;
    char ch = 0;
    
    do
    {
        ch = getchar();
        if ('\r' == ch || '\n' == ch)
        {
            break;
        }
        
        if (0 == nIndex)
        {
            if (' ' == ch)
            {
                continue;
            }
        }
        else if ((nIndex + 1) >= CMD_LINE_MAX)
        {
            continue;
        }
        
        //if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')
        //    || (ch >= '0' && ch <= '9'))
        {
            pCmd[nIndex] = ch;
            nIndex++;
        }
        
    } while (grunning);
    
    pCmd[nIndex] = '\0';
    
    while ((' ' == pCmd[nIndex - 1]) && grunning)
    {
        pCmd[nIndex - 1] = '\0';
        nIndex--;
		if (grunning == 0)
			break;
    }
}


static int parse_cmd_line(char *pCmd)
{
    int item  = 0;
    int index = 0;
    int skip  = 0;
    int i = 0;
    
    do
    {
        if ('\0' == pCmd[i])
        {
            cmd_array[item][index] = '\0';
            //printf("cmd_array %d %s\n", item, cmd_array[item]);
            
            item++;
            //index = 0;
            break;
        }
        else if ('\"' == pCmd[i])
        {
            skip = !skip;
        }
        else if (!skip && ' ' == pCmd[i])
        {
            if ((i + 1 < CMD_LINE_MAX) && (' ' == pCmd[i + 1]))
            {
                i++;
                continue;
            }
            
            if (0 == item && 0 == index)
            {
                i++;
                continue;
            }
            
            cmd_array[item][index] = '\0';
            //printf("cmd_array %d %s\n", item, cmd_array[item]);
            
            item++;
            index = 0;
        }
        else
        {
            cmd_array[item][index] = pCmd[i];
            index++;
        }
        
        i++;
        
    } while(grunning);
    
    //cmd_num = item;
    
    return 0;
}

static void show_usage(void)
{
    printf("Usage:\n");
    printf("help: show usage\n");
    printf("exit: test app exit\n");
    printf("0 - 9, a - z: test interface\n");
    printf("\n");
}

extern int gdev_bind_type;
static void test_case(void)
{
	int i = 0;
    printf("cmd: %c %c %s\n", cmd_array[0][0], cmd_array[1][0], cmd_array[2]);	

    switch (cmd_array[0][0])
    {
    case '0':
        {
			int ret = 0;
			char wifi_ssid[128] = {0};
			char wifi_paword[128] = {0};

			dzlog_info("【please input WIFI SSID : 】");

			scanf("%s",wifi_ssid);

			dzlog_info("wifi ssid OK.");

			dzlog_info("【please input WIFI paword : 】");

			scanf("%s",wifi_paword);

			dzlog_info("wifi paword OK.");

			ret = zx_hisi_camera_connect_network(wifi_ssid,wifi_paword);

			if(ret != 0)
			{
				dzlog_error("hisi camera connect network error");
				return;
			}

			dzlog_info("wifi config OK.");

			ret = zx_hisi_set_flash_ssid_and_password(wifi_ssid,wifi_paword);

			if(ret != 0)
			{
				dzlog_error("hisi set flash ssid and password error");
				return;
			}

			dzlog_info("hisi set flash ssid and password OK.");
			
        }
        break;
    case '1':
        {
			int ret = -1;
       		dzlog_info("white led on ");
			
			ret = zx_hisi_set_white_led_on();
			
			if(ret != 0)
			{
				dzlog_error("set white led on error");
				return;
			}
			dzlog_info("set white led open OK");
			
        }
        break;
    case '2':
        {
			int ret = -1;
			dzlog_info("white led off ");
			
			ret = zx_hisi_set_white_led_off();
			
			if(ret != 0)
			{
				dzlog_error("set white led on error");
				return;
			}
			dzlog_info("set white led close OK");
			
			hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_OFF;
        }
        break;
    case '3':
        {
			int ret = -1;
			dzlog_info("set red led open .");
        	zx_hisi_set_red_led_on();
			
			if(ret != 0)
			{
				dzlog_error("set red led on error");
				return;
			}
			dzlog_info("set red led open OK.");

			hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_OFF;
        }
        break;
    case '4':
        {
			int ret = 0;
			dzlog_info("set red led close .");
			ret = zx_hisi_set_red_led_off();

			if(ret != 0)
			{
				dzlog_error("set red led off error");
				return;
			}
			dzlog_info("set red led close OK.");

			hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_ON;

        }
        break;
    case '5':
        {

			int ret = -1;

			int floodlight_value = 0;

			dzlog_info("【please input floodlight value : 】");

			scanf("%d",&floodlight_value);
			
			ret = hal_set_floodlight_bright(floodlight_value);

			if(ret != 0)
			{
				dzlog_error("hal set flood light bright error ret : %d",ret);
				return -1;
			}

			if(floodlight_value)
			{
				hisi_cam_data->floodlight_state = ON_STATE;
				hisi_cam_data->floodlight_last_tigger = MANUAL_CONDITION;
				dzlog_info("hisi flood light open ok");
				
			}
			else
			{
				hisi_cam_data->floodlight_state = OFF_STATE;
				hisi_cam_data->floodlight_last_tigger = INIT_CONDITION;
				dzlog_info("hisi flood light close ok");
			}
			
			hisi_cam_data->floodlight_value = floodlight_value;

			
			
	
        }
        break;
    case '6':
        {
			unsigned int volue = 0;
			int ret = -1;
			dzlog_info("please output volume:");
			
			scanf("%d",&volue);
			
        	ret = hal_audio_set_vout(volue);

			if(ret != 0)
			{
				dzlog_error("set speaker volme error");
				return;
			}
			hisi_cam_data->speaker_volume = volue;
			dzlog_info("set speaker volume ok.");
			
        }
        break;
    case '7':
        {
			unsigned int volue = 0;
			int ret = -1;
			dzlog_info("please input volume:");
			scanf("%d",&volue);
			
        	ret = hal_audio_set_vin(volue);

			if(ret != 0)
			{
				dzlog_error("set audio volme error");
				return;
			}
			hisi_cam_data->mic_volume = volue;
			dzlog_info("set mic volume ok.");
      		
        }
        break;
    case '8':
        {	
			//dzlog_info("get current tem value: %d°",hisi_cam_data->tem_sensor_value);
			//dzlog_info("get current tem adc value: 0x%x",hisi_cam_data->tem_sensor_adc_value);
			dzlog_info("get current photo adc value: 0x%x",hisi_cam_data->photo_sensor_value);
        }
        break;
    case '9':
        {
			int ret = -1;
			dzlog_info("set ircut open ");
			ret = zx_hisi_set_ircut_on();

			if(ret != 0)
			{
				dzlog_error("set hisi ircut open error");
				return;
			}
			dzlog_info("set ircut open OK.");
        }
        break;
    case 'a':
        {
			int ret = -1;
			dzlog_info("set ircut close ");
			
			ret = zx_hisi_set_ircut_off();
			
			if(ret != 0)
			{
				dzlog_error("set hisi ircut close error");
				return;
			}
			dzlog_info("set ircut close OK.");
           
        }
        break;
    case 'b':
        {
			int ret = -1;
			int enble[3] = {0};
			
			dzlog_info("please input PIR enable value:");
			
			scanf("%d,%d,%d",&enble[0],&enble[1],&enble[2]);

			dzlog_info("left enble : %d",enble[0]);
			dzlog_info("middle enble : %d",enble[1]);
			dzlog_info("right enble : %d",enble[2]);
				
			ret = hal_pir_enable(enble);

			if(ret != 0)
			{
				dzlog_error("hal pir enable error");
				return;
			}
			
			if(enble[0])
			{
				dzlog_info("set pir left enable ok");
			}
			else
			{
				dzlog_info("set pir left disable ok");
			}
			
			if(enble[1])
			{
				dzlog_info("set pir middle enable ok");
			}
			else
			{
				dzlog_info("set pir middle disable ok");
			}
			
			if(enble[2])
			{
				dzlog_info("set pir right enable ok");
			}
			else
			{
				dzlog_info("set pir right disable ok");
			}

			
        }
        break;
    case 'c':
        {
			dzlog_info("【save g711 audio start...】");
			if(hisi_audio == NULL)
			{
				hisi_audio = fopen(HISI_AUDIO_FILE,"wb");

				if(hisi_audio == NULL)
				{
					dzlog_error("open file %s failed error", HISI_AUDIO_FILE);
				}
			}
        }
        break;
    case 'd':
        {
			
			dzlog_info("【save g711 audio end...】");
			if(hisi_audio)
			{
				fclose(hisi_audio);
				hisi_audio = NULL;
			}
			
		
        }
        break;
    case 'e':
        {
			int ret = zx_set_sta_wifi_and_connect();
			if(ret != 2)
			{
				dzlog_error("set sta wifi and connect error ret : %d",ret);
				return;
				
			}else{
				dzlog_info("set sta wifi and connect is ok ");
			}
			
	
        }
        break;
    case 'f':
        {
			int ret = zx_set_sta_wifi_and_connect_one();
			if(ret != 2)
			{
				dzlog_error("set sta wifi and connect one error ret : %d",ret);
				return;
			}
			else{
				dzlog_info("set sta wifi and connect one is ok ");
			}
			
	
        }
        break;
    case 'g':
        {
			int ret = zx_set_sta_wifi_and_connect_zhuoyi();
			if(ret != 2)
			{
				dzlog_error("set sta wifi and connect error ret : %d",ret);
				return;
				
			}else{
				dzlog_info("set sta wifi and connect is ok ");
			}
        }
        break;
    case 'h':
        {
			dzlog_info("set hisi pir open");
			zx_hisi_set_pir_on();
        }
        break;
    case 'i':
        {
			dzlog_info("set hisi pir close");
			zx_hisi_set_pir_off();
        }
        break;
    case 'j':
        {	
			int ret = -1;
			dzlog_info("【G711 audio PLAY...】");
			
			ret = hal_audio_play_file(HISI_AUDIO_FILE);
			if(ret != 0)
			{
				dzlog_error("audio play file error.");
				return;
			}
			dzlog_info("G711 audio play ok.");
		
        }
        break;
    case 'k':
        {
			int ret = -1;
			char data[1024] = {0};
			char en_data[1024] = {0};
			int en_len = 0;
			
			FILE *fp = fopen("/mnt/sdcard/add_cam_success.pcm","r");
			FILE *fp2 = fopen("/mnt/sdcard/add_cam_success.wav","w");

			while(1)
			{
				ret = fread(data, 1,1024,fp); 
			
		        if (-1 == ret)  
		        {  
		            dzlog_error(" read error "); 
		            return ret;  
		        } 

				dzlog_info("ret = %d",ret);

				if(0 == ret )
				{
					dzlog_info("read end.");
					break;
				}
				
	   			en_len = g711a_encode(data,en_data,ret);

				if(en_len <= 0)
				{
					dzlog_error("g711a encode error");
					return;
				}
				
				if((fwrite(en_data,1,en_len,fp2)) != en_len)
			    {
			    	dzlog_error("【fwrite error errno:%d===>[%s]】",errno,strerror(errno));
					return 0;
			    }

			
			}

			fclose(fp);
			fclose(fp2);
        }
        break;
    case 'l':
        {
			
        }
        break;
    case 'm':
        {
			dzlog_info("hisi time calibration start.");
			
   			zx_hisi_time_calibration();

			dzlog_info("hisi set time calibration OK.");

			zx_set_timetone("GMT-8");  //设置时区

			dzlog_info("set timetone OK.");
			
        }
        break;
    case 'n':
        {
		
        }
        break;
    case 'o':
        {

        }
        break;
    case 'p':
        {
			dzlog_info("pir triger handle start.");
 			zx_motion_and_pir_triger_local_storage(HISI_CH0);
			dzlog_info("pir triger handle end.");
        }
        break;
    case 'q':
        {
       		int ret = hisi_ota_test();

			if(ret != 0)
			{
				dzlog_error("hisi ota test error ret : %d",ret);
				return;
			}else{
				dzlog_info("hisi ota test is ok ");
			}
        }
        break;
	case 'r':
        {
       		int ret = -1;
			char flash_data[1024*1024] = {0};
			//char *flash_read_data = NULL;
			int flash_read_len = 1024;
			int flash_data_len = 0;
			
        	ret = hal_read_param_partition(flash_data,0,1024*1024);

			if(ret < 0)
			{
				dzlog_error("read param partition is error : %d",ret);
				return;
			}

			dzlog_info("read param partition data : %s *** %d",flash_data,ret);

			ret = hal_get_param_partition_datasize(&flash_data_len);

			if(ret < 0)
			{
				dzlog_error("read param partition is error : %d",ret);
				return;
			}

			dzlog_info("read flash data len : %d",flash_data_len);
			
        }
        break;
    case 's':
        {
		
			
        }
        break;
    case 't':
        {
			dzlog_info("set cur time start.");
			zx_hisi_set_cur_time();
			dzlog_info("set cur time end.");

        }
        break;
    case 'u':
        {
			char pir_soft_versoft[1024]= {0};
			dzlog_info("get pir softversion start");
        	int ret = hal_get_pir_softversions(pir_soft_versoft,sizeof(pir_soft_versoft));
			if(ret != 0)
			{
				dzlog_error("get pir soft verdion error :%d",ret);
				return;
			}
			dzlog_info("pir_soft_versoft : %s",pir_soft_versoft);
        }
        break;
    case 'v':
        {
       		char version[20]= {0};
			
			int ret  =hal_get_version(version);
			if(ret != 0)
			{
				dzlog_error("get version error ret : %d",ret);
			}else{
				
				dzlog_info("get version is ok  version: %s",version);
			}
        }
        break;
	case 'w':
        {
			

		
        }
        break;
	case 'x':
        {

			
      
        }
        break;
    case 'y':
        {
			int wifi_count = 0;
			wifi_count = zx_hisi_wifi_list_upgrade_insert(hisi_wifi_list);
			
			zx_hisi_wifi_list_all_printf(hisi_wifi_list);

			dzlog_info("=================================== wifi_count = %d",wifi_count);
			dzlog_info("===================================");

			//zx_hisi_get_camera_wifi_data(hisi_cam_data);

			//zx_hisi_camera_wifi_info_printf(hisi_cam_data);
			
        }
        break;
    case 'z':
        {
			//hal_clear_param_partition();
        	//clean_base_param();
        	
			grunning = 0;
			
			dzlog_info("【system reboot start】");
   			zx_do_system("%s", "reboot");
			//zx_ota_system("reboot");
        }
        break;
	case 'A':
		{

		
		}
		break;
	case 'B':
		{
			char local_ip[64] = {0};
			char local_mac[64] = {0};
			zx_hisi_get_wifi_localip(local_ip);
			zx_hisi_get_wifi_mac(local_mac);
			dzlog_info("local ip = %s",local_ip);
			dzlog_info("local mac = %s",local_mac);

			zx_ota_system("date");
		}
		break;
	case 'C':
		{
			
			
		}
		break;
    case 'D':
        {
		
			char url[4][128] = {"rtsp://127.0.0.1/live",
								"rtmp://192.168.1.181/live/test",
								"rtsp://192.168.1.155/live.sdp",
								"test.mp4"};
			int stream_index = 0;
			stream_index = cmd_array[2][0] - 0x30;
			if(cmd_array[2][0] - 0x30 > 3)stream_index = 3;
			if(cmd_array[2][0] - 0x30 < 0)stream_index = 0;
			
			zx_start_stream(HISI_CH0,url[0]);

			//zx_hisi_video_push_stream();
			//zx_hisi_audio_push_stream();

			
        }
        break;
    case 'E':
        {
			STREAM_CONNECT_INFO *stream_info = NULL;
			stream_info = zx_get_stream(HISI_CH0);

			if(!stream_info)
			{
				dzlog_error("get stream error");
				return;
			}
			
			stream_info->iControlThreadRun = 0;
			 
        }
        break;
    case 'F':
    {
        
    }
	case 'G':
	{

		
	}
    break;    
    default:
        {
            
        }
        break;
   }
}


static void *command_thread(void *param)
{
    char szCmd[CMD_LINE_MAX];
    int  nCmdLen = 0;
     
    //printf("command thread begin...\n");
    do
    {
        // prompt
        show_cmd_prompt();
        get_cmd_line(szCmd);
        
        // check cmd length
        nCmdLen = strlen(szCmd);
        if (0 == nCmdLen)
        {
            continue;
        }
        
        // parse cmd string
        memset((char *)&cmd_array, 0, CMD_LINE_MAX);
        parse_cmd_line(szCmd);
        nCmdLen = strlen(cmd_array[0]);
        
        if (1 == nCmdLen)
        {
            if ((cmd_array[0][0] >= '0' && cmd_array[0][0] <= '9')
                || (cmd_array[0][0] >= 'a' && cmd_array[0][0] <= 'z')
				|| (cmd_array[0][0] >= 'A' && cmd_array[0][0] <= 'Z'))
            {
                test_case();
            }
            else
            {
                printf("%c: 1 not found\n", cmd_array[0][0]);
            }
        }
        else // other...
        {
			if (2 == nCmdLen) 
			{
				if (cmd_array[0][0] == '^' && (cmd_array[0][1] == 'c' || cmd_array[0][1] == 'C'))
				{
					printf("program exit\n");
					grunning = 0;
					//continue;
					break;
				}
			}
            if (0 == strcmp(cmd_array[0], "help"))
            {
                show_usage();
            }
            else if (0 == strcmp(cmd_array[0], "exit"))
            {
                printf("command thread quit.\n");
				grunning = 0;
                break;
            }
			else if (0 == strcmp(cmd_array[0], "reboot"))
			{
				printf("reboot system......\n");
				zx_do_system("%s", "reboot");
			}
            else
            {
                printf("%s: 2 not found\n", szCmd);
            }
        }
        //usleep(5000);
    } while(grunning);
    
    //sem_post(&g_semCmdLoop);
    //printf(" exit.\n");
    return NULL;
}


/*
测试用sn

T800116161616166
T800112345678913
T800113113131333
*/

int main(int argc, char *argv[])
{
	unsigned char sn[DEVICE_SN_LEN + 1] = "T8001G0217530001";		//获取sn号
	//unsigned char sn[DEVICE_SN_LEN + 1] = "T8001G0317480032";		//获取sn号
	//unsigned char sn[DEVICE_SN_LEN + 1] = "T8001G0217530010";		//获取sn号
	//unsigned char sn[DEVICE_SN_LEN + 1] = {0};		//获取sn号
	char lan_ipaddr[SMALL_STR_LEN + 1] = {0};
	zx_Error err;
	char *buf_wifi_data = NULL;
	int ap_count = -1;
	int num = 0;
	short bopen_hisi_log = 0;
	short bopen_command = 0;
	THREAD_INFO thread_info[MAX_THREAD_COUNT] ;		//线程信息 32个
	P2P_BASE_INFO p2p_info;		//p2p信息
	
	dzlog_info("home_security is start");

	gsystem_init = 0;

	zx_do_system("%s", "echo 1 >/proc/sys/vm/drop_caches"); 		//清理缓存
	zx_do_system("%s", "echo 0 >/proc/sys/vm/drop_caches");			//清理缓存
	
    int rc = dzlog_init(LOG_CONF, "");   //初始化log信息 "/etc/zx_log.conf"
    
    if (rc)
    {
        dzlog_error("------>> init failed\n");
    }

	dzlog_info("dzlog init is ok ");

	if (argc >= 3) 
	{
		dzlog_info("hisi_log=%s command=%s" , argv[1], argv[2]);	
		if (strcmp(argv[1], "1") == 0)
			bopen_hisi_log = 1;
		if (strcmp(argv[2], "1") == 0)
			bopen_command = 1;		
	}
	if (argc == 4) 
	{
		dzlog_info("open_p2p=%s" , argv[3]);	
		if (strcmp(argv[3], "0") == 0)
			gbopen_p2p = 0;	
	}
	
	signal(SIGQUIT, sig_quit);
	signal(SIGINT, sig_quit);
	signal(SIGKILL, sig_quit);

	signal(TF_INSERT, sig_tf_status_proces);      //SD卡插入
	signal(TF_REMOVE, sig_tf_status_proces);      //SD卡拔出
	signal(TF_INSERT_MOUNT, sig_tf_status_proces);
    signal(TF_REMOVE_UMOUNT, sig_tf_status_proces);

	dzlog_info(" signal is ok.");

	zx_hisi_set_hal_log_print(bopen_hisi_log);		//设置回调log打印	

	if((zx_hisi_hal_all_init()) != 0)				//初始化海思接口
	{
		dzlog_error("hisi hal all init error");
		exit(EXIT_FAILURE);
	}

	dzlog_info("hisi hal all init ok");

#if 0
	hal_clear_param_partition();					//清除flash信息
	dzlog_info("hal clear param partition ok");
#endif
	
    zx_create_dir(CONF_PATH);   //创建目录      	"/mnt/DataDisk/"  	//固定值(参数保存区)
    
	dzlog_info("create dir is ok.");
	
	P2P_CONNECT_INFO p2p_con_list[MAX_CONNECT_NUM];		//p2p连接信息链 最大8个
	
	base_param = (HUB_BASE_PARAM *)malloc(sizeof(HUB_BASE_PARAM));  //基站信息分配空间
	
	if (!base_param)
	{
		dzlog_error("malloc base_param fail.");
		exit(EXIT_FAILURE);	
	}

	memset(&p2p_con_list, 0, sizeof(P2P_CONNECT_INFO)*MAX_CONNECT_NUM);		//p2p连接信息清零
	memset(base_param, 0, sizeof(HUB_BASE_PARAM));							//基站信息清零
	memset(&p2p_info, 0, sizeof(P2P_BASE_INFO));							//p2p信息清零
	memset(&thread_info, 0, sizeof(THREAD_INFO)*MAX_THREAD_COUNT);			//线程信息清零

	dzlog_info("memset is ok.");

	if((zx_hisi_floodlight_init()) != 0)			
	{
		dzlog_error("hisi flood light init error");
		goto exit_hisi;
	}

	dzlog_info("hisi floodlight init ok");

#if 1
	if (read_base_param(base_param) < 0)  //读flash内信息
	{
		dzlog_warn("【read_base_param is NULL】");
		//exit(EXIT_FAILURE);
	} 	
#endif

#if 1
	if((zx_hisi_set_camera_parameter()) != 0)			//设置设备信息
	{
		dzlog_error("set hisi camera parameter error");
		goto exit_hisi;
	}else{
		
		dzlog_info("set hisi camera parameter ok");

		if((zx_hisi_get_camera_info_data(hisi_cam_data)) != 0)		//获取设备信息
		{
			dzlog_error("get hisi camera info data error");
			goto exit_hisi;
			
		}else{
			
			zx_hisi_camera_dev_info_printf(hisi_cam_data);
		}
	}
#endif

#if RUN_LOCAL_STORGE
    zx_local_storage_ini(); //在要sub1g之前初始化，创建pir线程，初始化本地存储
	dzlog_info(" local storage ini is ok.");
#endif

	zx_hisi_camera_key_event();				//注册回调函数
	zx_hisi_cam_pir_detect_event();
	zx_hisi_cam_motion_event();			//注册移动侦测
	dzlog_info("call back function ok");

	if((hal_get_sn(sn)) != 0)			//获取SN
	{
		dzlog_error("【hal get hisi dev sn fail.】");	
	}

	if(strlen(sn) <= 0)
	{
		dzlog_warn("hisi get dev sn len is zero.");
		memcpy(sn,FLOODLIGHT_DEV_SN,DEVICE_SN_LEN);
		memcpy(base_param->hub_info.hub_sn, sn, strlen(sn));
	}

	dzlog_info("*** sn = %s ***" , sn);
	
	zx_init_sys_interface(&thread_info, base_param);  //创建flash 写数据线程

	dzlog_info(" init sys interface is ok.");
	
	zx_write_pid_file();    //将主线程pid写入文件
	
	dzlog_info(" write pid file is ok.");

	zx_init_as_interface(); 			//初始化curl库
	
	dzlog_info(" init as interface is ok.");

WIFI_LIST_AGAIN:
	if((ap_count = zx_hisi_wifi_list_upgrade_insert(hisi_wifi_list)) <= 0)			//获取一次wifi列表，准备绑定使用
	{
		++num;
		dzlog_error("【first get hisi upgrade info list insert error,try again %d times】",num);

		zx_mgw_setTimer(3,0);

		if(num <= 6)
		{
			goto WIFI_LIST_AGAIN;
		}
		
		goto exit_hisi;
	}
	
	num = 0;
	
	dzlog_info("【---get wifi list ap_count = %d ---】",ap_count);
	

#if 1
	if((zx_hisi_set_device_sn(sn,DEVICE_SN_LEN)) <= 0)
	{
		dzlog_error("set device sn fail.");
		goto exit_hisi;
	}else{
		dzlog_info("sn=%s" , sn);
	}
		
	if((zx_hisi_get_device_sn(sn, DEVICE_SN_LEN)) <= 0) // || sn[0] == 0xFF  //获取设备sn，
	{
		dzlog_error("get device sn fail.");
		goto exit_hisi;
	}else{
		dzlog_info("sn=%s" , sn);
	}
#endif

#if 0
	if(zx_hisi_get_flash_account_id(base_param->hub_info.account_id,sizeof(base_param->hub_info.account_id)) <= 0)
	{
		dzlog_warn("hisi get account id error");
		
	}else{
		
		dzlog_info("hisi get account id ok account_idd = %s",base_param->hub_info.account_id);
	}
#endif

	if((zx_hisi_camera_connect_network(hisi_cam_wifi->wifi_ssid,hisi_cam_wifi->wifi_password)) != 0)
	{
		dzlog_info("hisi camera connect network fail");
		dzlog_info("【please press key input ap mode and matching network.】");
		
	}else{
		
		dzlog_info("hisi camera connect network ok");
	}
		
	
	zx_create_thread(LOW_PRIORITY, log_upload_thread, NULL, -1, LOG_UPLOAD, -1);		//创建log上传线程

	if (bopen_command)
		zx_create_thread(LOW_PRIORITY, command_thread, NULL, -1, TEST_CASE, -1);  //创建命令测试线程


BIND_TIMEOUT_AGAIN:

	if (gbopen_p2p)
	{
		while (grunning)
		{	

			if(HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode  && WIFI_NO_CONNECT == wifi_connect_status )
			{
				if(hisi_cam_data->red_led_state != FLASH_STATE)
				{
					if(zx_hisi_set_red_led_flash() != 0)		//红灯闪烁
					{
						dzlog_error("red led set flash error");
						goto exit_local_sto;
							
					}
					dzlog_info("【please press key input ap mode and matching network.】");
				}
			}
			
			if((zx_hisi_wifi_state_get(hisi_cam_wifi->wifi_ssid)) == 2)		//检查wifi状态
			{
				dzlog_info("hisi wifi state get is ok");
				
				zx_hisi_set_white_led_on();				//白灯常亮
				
				if (strlen(base_param->hub_info.account_id) > 0)
				{
					err = zx_get_hub_bind_status(base_param->hub_info.account_id, sn);	//获取绑定状态
					if (err.code == AS_HTTP_HUB_NO_BIND)
					{
						clean_base_param();					//清除信息
					
						dzlog_info("############### hub no bind ###############");
					
						break;					
					}
					else if (err.code == AS_HTTP_HUB_BIND_OTHER || err.code == AS_HTTP_OPER_SUCESS)	
					{
						dzlog_info("############### hub bind ok ###############");
						break;	
					}
					dzlog_info("base_param->hub_info.account_id = %s",base_param->hub_info.account_id);
									
				}					
				else
				{
					dzlog_info("hisi wifi state get base_param->hub_info.account_id : %s",base_param->hub_info.account_id);
					
					err = zx_active_curl_for_thread();		//检查网络的线程
					
					if (err.code == AS_HTTP_200)
					{
						zx_hisi_set_white_led_on();
						break;
					}
					
				}
			}
			else
			{
				
				if(HISI_WIFI_STA_MODE == hisi_cam_wifi->wifi_mode  && WIFI_NO_CONNECT == wifi_connect_status)
				{
					
		LIST_TRY_AGAIN:
					if((ap_count = zx_hisi_wifi_list_upgrade_insert(hisi_wifi_list)) <= 0)
					{

						++num;
						dzlog_error("【get hisi wifi upgrade info list insert error,try again %d times】",num);

						zx_mgw_setTimer(3,0);

						if(num <= 6)
						{
							goto LIST_TRY_AGAIN;
						}
		
						goto exit_local_sto;
					}

					zx_hisi_wifi_list_printf_ssid(hisi_wifi_list);
				}
			}
			zx_mgw_setTimer(5,0);
			
		}
	}



	if(zx_hisi_wifi_state_get(hisi_cam_wifi->wifi_ssid) == 2)
	{
		dzlog_info("【wifi network is ok...】");
		wifi_connect_status = WIFI_CONNECTED;
		zx_hisi_set_white_led_on();					//白灯常亮
		
	}else{
		
		wifi_connect_status = WIFI_NO_CONNECT;
		zx_mgw_setTimer(1,0);
		dzlog_warn("【wifi network disconnect】");
	}

#if 1
	if((zx_hisi_wifi_update_data()) != 0)
	{
		dzlog_error("hisi wifi update data error");
		goto exit_local_sto;
		
	}else{
		
		dzlog_info("【hisi wifi update data ok.】");
	}
#endif


	dzlog_info(" base_param->hub_info.version : %d",base_param->hub_info.version);
	
	unsigned int version = base_param->hub_info.version;
	
	if (version != PARAM_VER)		//判断版本
	{
		dzlog_info(" 【version compare same ok*********************】");
		
		memset(base_param, 0, sizeof(HUB_BASE_PARAM));		
		
		err = zx_hub_get_p2p_params(sn, &base_param->p2p_info);		//获取p2p信息
		
		if (err.code == 0)
		{
			
			dzlog_info(" hub get p2p params is ok.");
			base_param->hub_info.version = PARAM_VER;
			memcpy(base_param->hub_info.hub_sn, sn, strlen(sn));
		#if 1	
			if (write_config_param(SET_HUB_PARAM) < 0)			//写基站配置参数信息
			{
				dzlog_error("write_base_param error"); 	
				goto exit_local_sto;
			}
		#endif	
			dzlog_info(" write_config_param is ok.");
		}
	}
	
	dzlog_info("channel info = %d  hub info wifi channel = %d",hisi_cam_wifi->wifi_channel,base_param->hub_info.wifi_channel);
	
	if (hisi_cam_wifi->wifi_channel != base_param->hub_info.wifi_channel)
	{
		base_param->hub_info.wifi_channel = hisi_cam_wifi->wifi_channel;		//赋值新的wifi信道
	}

	dzlog_info("hub info record time = %d",base_param->hub_info.record_time_out);

	if (base_param->hub_info.record_time_out <= 1000)
	{
		base_param->hub_info.record_time_out = 30000; // 默认记录30s
	}
	dzlog_info(" ####################.");

	dzlog_info("p2p_uid=%s version=%d [%d.%d.%d.%d] size=%d account=%s", base_param->p2p_info.p2p_uid,  
			version, (version & 0xFF000000) >> 24, (version & 0x00FF0000) >> 16, (version & 0x0000FF00) >> 8,  
			(version & 0x000000FF) >> 0, sizeof(HUB_BASE_PARAM), base_param->hub_info.account_id);	

	base_param->hub_info.update_status = 0;
	
	
	if (gbopen_p2p)
	{
#if RUN_P2P_SERVER
		dzlog_info(" RUN_P2P_SERVER is start.");

		if (zx_init_p2p_server(&p2p_con_list, base_param, 1, lan_ipaddr) == ERROR_PPCS_SUCCESSFUL)  //初始化p2p服务
		{
			dzlog_info("init p2p server is ok......");
		
		}else{

			dzlog_error("p2p server init error.");
			goto exit;
		}
		
	#if 0
		zx_init_push_server(base_param);  //初始化push服务,内存不够，push功能无法实现
	#endif
	
#endif
	}
	

#if 1
	if(zx_hisi_init_camera_sdk(bopen_hisi_log, &p2p_con_list) != 0)		
	{
		dzlog_error("hisi init camera sdk error");
		goto exit;
		
	}else{
		
		dzlog_info("hisi init camera sdk ok");
		
	}
#endif

	//zx_set_timetone("GMT-8");  //设置时区

	if (zx_system_update() == 0)  //系统 OTA 升级
	{
		grunning = 0;	
		goto exit;
	}

	zx_create_thread(LOW_PRIORITY, net_detection, NULL, -1, NET_DET, -1);  //创建检测网络线程

	//zx_create_thread(LOW_PRIORITY, set_hisi_time, NULL, -1, THREAD_TEST, -1);  //创建检测网络线程

	zx_create_thread(LOW_PRIORITY, zx_ota_server, NULL, -1, OTA_SERVER, -1); //创建 OTA 系统升级,检测是否更新升级的 一天查一次
	
#if 0
	if (bopen_command)
		zx_create_thread(LOW_PRIORITY, command_thread, NULL, -1, TEST_CASE, -1);  //创建命令测试线程
#endif

	gsystem_init = 1;		//系统初始化完成

	int old_net_status = 1, net_status = 1;
	struct timeval tv; 
	
    while(grunning)  
    {  
		//tv.tv_sec = TIMER_ETH_DETCTION; 
		tv.tv_sec = 1;
        tv.tv_usec = 0;    
			
        //dzlog_info("tv_sec : %d",tv.tv_sec);
        switch(select(0, NULL, NULL, NULL, &tv))   
        {  
        	case -1:  
            	//dzlog_error("【select error errno:%d===>[%s]】",errno,strerror(errno));  
            	break;  
        	case 0:  
				{
					
#if 0

					net_status = hal_wifi_check_link(hisi_cam_wifi->wifi_ssid);

					dzlog_info("net_status =%d......", net_status);
					
					if (old_net_status == 0 && net_status == 2)
					{
						dzlog_info("net reconnected......");
						PPCS_Listen_Break();											
					}
					old_net_status = net_status;

					if(hisi_cam_wifi->wifi_mode == HISI_WIFI_STA_MODE && WIFI_NO_CONNECT == wifi_connect_status )
					{
						dzlog_info("restart configure wifi network.");
						goto BIND_TIMEOUT_AGAIN;
					}
#endif
				} 
            	break;  
        	default:  
            	break;  
        } 

		if(hisi_cam_wifi->wifi_mode == HISI_WIFI_STA_MODE && WIFI_NO_CONNECT == wifi_connect_status )
		{
			dzlog_info("restart configure wifi network.");
			goto BIND_TIMEOUT_AGAIN;
		}

		//zx_ota_system("echo 3 > /proc/sys/vm/drop_caches");				//清除缓存

    }  
	

	zx_stop_broadcase();
	zx_hisi_stop_tcp_server();
	

exit:
#if 1
  	zx_hisi_deinit_camera_sdk();
  	zx_deinit_as_interface();
#endif

	if (gbopen_p2p)
	{
#if RUN_P2P_SERVER
		zx_deinit_p2p_server();
	#if 0
		zx_deinit_push_server();
	#endif
#endif
    }
exit_local_sto:
#if RUN_LOCAL_STORGE
    zx_deinit_local_storage();
#endif

exit_hisi:
	zx_hisi_hal_all_deinit();
	
	zx_deinit_as_interface();

	if((zx_hisi_floodlight_deinit()) != 0)
	{
		dzlog_error("hisi flood light deinit error");
	}
	
	if(base_param)
	{
		free(base_param);
		base_param = NULL;
	}
   	
	dzlog_info("exit......");
	zlog_fini();
	_exit(EXIT_SUCCESS);
}


