/*============================================================================
 Name        : ppcs_interface.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-10-30 
 Description :
 ============================================================================*/

#include <unistd.h> 
#include <fcntl.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/time.h> 
#include <signal.h> 
#include <netinet/in.h>
#include <netdb.h> 
#include <net/if.h>
#include <string.h>
#include <sched.h>
#include <dirent.h>
#include <arpa/inet.h>  

#include "ppcs_interface.h"
#include "comm_protocol_define.h"
#include "sub1g_interface.h"
#include "circular_buffer.h"
#include "as_interface.h"
#include "broadcast_interface.h"
//#include "Xm_lib.h"
#include "local_storage_interface.h"
#include "ai_interface.h"
#include "ota_interface.h"
#include "enc_decrypt_interface.h"
#include "hisi_interface.h"
#include "floodlight_interface.h"
P2P_CONNECT_INFO *gp2p_con_list = NULL;
HUB_BASE_PARAM *gppcs_base_param = NULL;
//char gcur_wlan_ip[SHORT_STR_LEN] = {0};
char log_key_prefix[NORMAL_STR_LEN] = {0}; // 保存APP提前hub的log时，APP对应的log url;
int gdev_bind_type = 0;                    // 设备绑定类型

extern unsigned char grunning;
extern int h264_download;
extern unsigned int tfcard_format_flg;
extern unsigned int tfcard_free_mb;
extern HISI_CAMERA_INFO_DATA * hisi_cam_data;


char *get_p2p_err_info(int err)
{
    if (0 < err)
        return "NoError";
    switch (err)
    {
        case ERROR_PPCS_SUCCESSFUL:     
			return "ERROR_P2P_SUCCESSFUL";
        case ERROR_PPCS_NOT_INITIALIZED:     
			return "ERROR_P2P_NOT_INITIALIZED";
        case ERROR_PPCS_ALREADY_INITIALIZED: 
			return "ERROR_P2P_ALREADY_INITIALIZED";
        case ERROR_PPCS_TIME_OUT: 
			return "ERROR_P2P_TIME_OUT";
        case ERROR_PPCS_INVALID_ID: 
			return "ERROR_P2P_INVALID_ID";
        case ERROR_PPCS_INVALID_PARAMETER: 
			return "ERROR_PPCS_INVALID_PARAMETER";
        case ERROR_PPCS_DEVICE_NOT_ONLINE: 
			return "ERROR_P2P_DEVICE_NOT_ONLINE";
        case ERROR_PPCS_FAIL_TO_RESOLVE_NAME: 
			return "ERROR_P2P_FAIL_TO_RESOLVE_NAME";
        case ERROR_PPCS_INVALID_PREFIX: 
			return "ERROR_P2P_INVALID_PREFIX";
        case ERROR_PPCS_ID_OUT_OF_DATE: 
			return "ERROR_P2P_ID_OUT_OF_DATE";
        case ERROR_PPCS_NO_RELAY_SERVER_AVAILABLE: 
			return "ERROR_P2P_NO_RELAY_SERVER_AVAILABLE";
        case ERROR_PPCS_INVALID_SESSION_HANDLE: 
			return "ERROR_P2P_INVALID_SESSION_HANDLE";
        case ERROR_PPCS_SESSION_CLOSED_REMOTE: 
			return "ERROR_P2P_SESSION_CLOSED_REMOTE";
        case ERROR_PPCS_SESSION_CLOSED_TIMEOUT: 
			return "ERROR_P2P_SESSION_CLOSED_TIMEOUT";
        case ERROR_PPCS_SESSION_CLOSED_CALLED: 
			return "ERROR_P2P_SESSION_CLOSED_CALLED";
        case ERROR_PPCS_REMOTE_SITE_BUFFER_FULL: 
			return "ERROR_P2P_REMOTE_SITE_BUFFER_FULL";
        case ERROR_PPCS_USER_LISTEN_BREAK: 
			return "ERROR_P2P_USER_LISTEN_BREAK";
        case ERROR_PPCS_MAX_SESSION: 
			return "ERROR_P2P_MAX_SESSION";
        case ERROR_PPCS_UDP_PORT_BIND_FAILED: 
			return "ERROR_P2P_UDP_PORT_BIND_FAILED";
        case ERROR_PPCS_USER_CONNECT_BREAK: 
			return "ERROR_P2P_USER_CONNECT_BREAK";
        case ERROR_PPCS_SESSION_CLOSED_INSUFFICIENT_MEMORY: 
			return "ERROR_P2P_SESSION_CLOSED_INSUFFICIENT_MEMORY";
        case ERROR_PPCS_INVALID_APILICENSE: 
			return "ERROR_P2P_INVALID_APILICENSE";
        case ERROR_PPCS_FAIL_TO_CREATE_THREAD: 
			return "ERROR_P2P_FAIL_TO_CREATE_THREAD";

        case ERROR_NULL_POINT:
            return "NULL_POINT";
        case ERROR_HAVE_CONNECT:
            return "HAVE_CONNECT";
        case ERROR_MAX_HUB_CONNECT_NUM:
            return "MAX_HUB_CONNECT_NUM";
        case ERROR_INVALID_COMMAND:
            return "INVALID_COMMAND";
        case ERROR_INVALID_ACCOUNT:
            return "INVALID_ACCOUNT";
        case ERROR_WRITE_FLASH:
            return "WRITE_FLASH";
        case ERROR_NOT_FIND_DEV:
            return "NOT_FIND_DEV";
        case ERROR_INVALID_PARAM_LEN:
            return "NVALID_PARAM_LEN";
        case ERROR_WAIT_TIMEOUT:
            return "WAIT_TIMEOUT";
        case ERROR_DEV_OFFLINE:
            return "DEV_OFFLINE";
        case ERROR_INVALID_PARAM:
            return "INVALID_PARAM";
        case ERROR_OPEN_FILE_FAIL:
            return "OPEN_FILE_FAIL";
        case ERROR_HUB_UPDATEING:
            return "HUB_UPDATEING";
        case ERROR_DEV_UPDATEING:
            return "DEV_UPDATEING";
        case ERROR_DEV_BUSY:
            return "DEV_BUSY";
        case ERROR_NOT_FACE:
            return "NOT_FACE";
        case ERROR_PARAM_NO_CHANGE:
            return "PARAM_NO_CHANGE";

        default:
            return "Unknow, something is wrong!";
    }
}


int zx_set_p2p_connect_info(st_PPCS_Session *session_info, int session_handle) //, int msg_id
{
	unsigned char i = 0;
	int result = -1;
	if (session_info == NULL || session_handle < 0)
	{
		dzlog_error("session_info is NULL, session_id= %d......", session_handle);
		return ERROR_NULL_POINT;
	}
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == -1)
		{
			gp2p_con_list[i].session_handle = session_handle; 
			gp2p_con_list[i].channel = -1;
            gp2p_con_list[i].rsa_pubkey = NULL;
			memcpy(&gp2p_con_list[i].session_info, session_info, sizeof(st_PPCS_Session));	
			
			if (gp2p_con_list[i].video_queue == NULL)
			{
				gp2p_con_list[i].video_queue = (void *)create_queue(MAXVIDEOQUEUE, COMM_HEARD_LEN + sizeof(VIDEO_FRAME));
				gp2p_con_list[i].audio_queue = (void *)create_queue(MAXAUDIOQUEUE, COMM_HEARD_LEN + sizeof(AUDIO_FRAME));
				//dzlog_info("WriteSize=%d......", WriteSize);
			}
			else
			{
				clear_queue(gp2p_con_list[i].video_queue, MAXVIDEOQUEUE);
				clear_queue(gp2p_con_list[i].audio_queue, MAXAUDIOQUEUE);
			}
			result = pipe(gp2p_con_list[i].audio_pipe);
			if (result != 0) 
			{
				dzlog_error("audio_pipe create fail... error=%d", errno);
			}
			result = pipe(gp2p_con_list[i].video_pipe);
			if (result != 0) 
			{
				dzlog_error("video_pipe create fail... error=%d", errno);
			}
			dzlog_info("session_id: %d, audio_pipe[0]=%d vido_pipe[0]=%d",
                        session_handle, gp2p_con_list[i].audio_pipe[0], gp2p_con_list[i].video_pipe[0]);
			break;
		}
	}

    result = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        if (gp2p_con_list[i].session_handle >= 0)
        {
            result += 1;
        }
    }
    dzlog_info("cur p2p connect number: %d---->\n", result);

    return session_handle;
}

P2P_CONNECT_INFO* zx_get_p2p_connect_info()
{
	return gp2p_con_list;
}


QUEUE * zx_get_p2p_queue_by_session(int session_id, int type)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			if (type == MEDIA_VIDEO)
				return (QUEUE *)gp2p_con_list[i].video_queue;
			else if  (type == MEDIA_AUDIO)
				return (QUEUE *)gp2p_con_list[i].audio_queue;
		}
	}
	return NULL;;
}

int * zx_get_p2p_pipe_by_session(int session_id, int type)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			if (type == AUDIO_PIPE)
				return gp2p_con_list[i].audio_pipe;
			else if (type == VIDEO_PIPE)
				return gp2p_con_list[i].video_pipe; 
		}
	}
	return NULL;
}


// channel 和 session 是一对多关系,只可取其中一个
int zx_get_p2p_session_by_channel(int channel)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].channel == channel)
		{
			return gp2p_con_list[i].session_handle;
		}
	}
	return -1;
}

RSA* zx_get_p2p_pubkey_by_session(int session_id)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			return gp2p_con_list[i].rsa_pubkey;
		}
	}
	return NULL;
}


int zx_update_p2p_channel_by_session(int session_id, int channel)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			gp2p_con_list[i].channel = channel;
			if (channel == -1)
			{
				clear_queue(gp2p_con_list[i].video_queue, MAXVIDEOQUEUE);
				clear_queue(gp2p_con_list[i].audio_queue, MAXAUDIOQUEUE);
			}
            break;
		}
	}
	return 0;
}

int zx_update_p2p_rsakey_by_session(int session_id, RSA* key)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
            if (gp2p_con_list[i].rsa_pubkey != NULL)
            {
                RSA_free(gp2p_con_list[i].rsa_pubkey);
            }
            gp2p_con_list[i].rsa_pubkey = key;
			dzlog_info("update_p2p_rsakey");
			break;
		}
	}
	return 0;
}

int zx_check_p2p_channel_status(int session_id, short channel)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].channel == channel && gp2p_con_list[i].session_handle != session_id)
		{
			return -1; // 设备被占用
		}
	}
	return 0;
}

int zx_get_p2p_channel_by_session(int session_id)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			return gp2p_con_list[i].channel;
		}
	}
	return -1;
}

int zx_set_dev_name_by_channel(int channel, char *value)
{
	unsigned char i = 0;

	if (value == NULL)
		return ERROR_NULL_POINT;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			memset(gppcs_base_param->dev_param[i].dev_name, 0, sizeof(gppcs_base_param->dev_param[i].dev_name));
			memcpy(gppcs_base_param->dev_param[i].dev_name, value, strlen(value));
			dzlog_info("enter channel=%d value=%s", channel, gppcs_base_param->dev_param[i].dev_name);
			return 0;
		}
	}

	return ERROR_NOT_FIND_DEV;
}

int zx_get_power_level_by_channle(int channel)
{
	unsigned char i = 0;
	
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			dzlog_info("enter channel=%d power_level=%d", channel, gppcs_base_param->dev_param[i].dev_electric_quantity);
			return gppcs_base_param->dev_param[i].dev_electric_quantity;
		}
	}

	return 0;
}

int zx_set_power_level_by_channle(int channel, unsigned char power_level)
{
	unsigned char i = 0;

	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			dzlog_info("enter channel=%d power_level=%d", channel, power_level);
			gppcs_base_param->dev_param[i].dev_electric_quantity = power_level;
			return power_level;
		}
	}	

	return 0;
}

int zx_set_dev_status_by_channel_type(int channel, int type, int value)
{
	unsigned char i = 0;
	//dzlog_info("enter channel=%d type=%d value=%d", channel, type, value);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			switch (type)
			{
				case APP_CMD_PIR_SWITCH:
					gppcs_base_param->dev_param[i].dev_pir_status = value;
					break;

				case APP_CMD_IRCUT_SWITCH:
					gppcs_base_param->dev_param[i].dev_ir_cut_status = value;
					break;

				case APP_CMD_EAS_SWITCH:
					gppcs_base_param->dev_param[i].dev_gsession_status = value;
					break;
				
				case APP_CMD_DEVS_UNBIND:
					{
						dzlog_info("APP_CMD_DEVS_UNBIND channel=%d", channel);
						//gppcs_base_param->dev_param[i].sub1g_info.shortaddress = 0;
						//gppcs_base_param->dev_param[i].sub1g_info.panid = 0;
						//gppcs_base_param->dev_param[i].channle_id = -1;
					}
					break;
				case APP_CMD_AUDDEC_SWITCH:
					gppcs_base_param->dev_param[i].dev_voice_det_status = value;
					break;
				
				case APP_CMD_DEV_LED_SWITCH:
					gppcs_base_param->dev_param[i].dev_led_status = value;
					break;

				case APP_CMD_SET_MIRRORMODE:
					gppcs_base_param->dev_param[i].dev_video_mirr_mode = value;
					break;
                case APP_CMD_SET_DEV_MIC_VOLUME:
                {
                    if (gppcs_base_param->dev_param[i].dev_mic_volume == value)
                    {
                        return ERROR_PARAM_NO_CHANGE;
                    }
                    gppcs_base_param->dev_param[i].dev_mic_volume = value;
                }
                break;
                case APP_CMD_SET_DEV_SPEAKER_VOLUME:
                {
                    if (gppcs_base_param->dev_param[i].dev_speaker_volume == value)
                    {
                        return ERROR_PARAM_NO_CHANGE;
                    }
                    gppcs_base_param->dev_param[i].dev_speaker_volume = value;
                }
                break;                
				default:
					break;
			}
				
			return 0;	
		}
	}
	return ERROR_NOT_FIND_DEV;
}


int zx_set_dev_schedule_by_channel(int channel, char *schedule, int size)
{
    unsigned char i,j;
    struct tm *ptm = NULL;
    time_t curtime,schtime;
    DEV_SCHEDULE *pschedule = NULL;
    ONCE_SCHEDULE *ponce_schedule;
    DEV_SCHEDULE *bs_schedule;
    BS_ONCE_SCHEDULE *bs_once_schedule;

    //printf_hex(schedule, 16);
    if (schedule)
    {
        for (i = 0; i < MAX_SUB1G_CONNECT; i++)
        {
            if (gppcs_base_param->dev_param[i].channle_id == channel)
            {
                pschedule = (DEV_SCHEDULE *)schedule;
                bs_schedule = (DEV_SCHEDULE *)gppcs_base_param->dev_param[i].dev_schedule;

                bs_schedule->loop_sch_count = pschedule->loop_sch_count;
                bs_schedule->once_sch_count = pschedule->once_sch_count;
                bs_schedule->defult_action  = pschedule->defult_action;

                // 周期调度按APP数据格式保存
                memcpy(bs_schedule->loop_sch, pschedule->loop_sch, sizeof(bs_schedule->loop_sch));

                // 单次调度把APP时间先转换为time_t后再保存(省2个字节和使用时转换时间)
                curtime = time(NULL);
                ptm = localtime(&curtime);
                for (j=0; j<pschedule->once_sch_count; j++ )
                {
                    ponce_schedule = &pschedule->once_sch[j];
                    bs_once_schedule = (BS_ONCE_SCHEDULE *)&bs_schedule->once_sch[j];

                    ptm->tm_min = ponce_schedule->start_m;
                    ptm->tm_hour = ponce_schedule->start_h;
                    ptm->tm_mday = ponce_schedule->start_dd;
                    ptm->tm_mon = ponce_schedule->start_mm - 1;    // 从一月算起，范围从0-11
                    ptm->tm_year = ponce_schedule->start_yy + 100; // 从1900年算起至今的年数(2000-1900)
                    schtime = mktime(ptm);
                    bs_once_schedule->start_time = schtime;
                    
                    ptm->tm_min = ponce_schedule->end_m;
                    ptm->tm_hour = ponce_schedule->end_h;
                    ptm->tm_mday = ponce_schedule->end_dd;
                    ptm->tm_mon = ponce_schedule->end_mm - 1;      // 从一月算起，范围从0-11
                    ptm->tm_year = ponce_schedule->end_yy + 100;   // 从1900年算起至今的年数(2000-1900)
                    schtime = mktime(ptm);
                    bs_once_schedule->end_time = schtime;

                    bs_once_schedule->action = ponce_schedule->action;
                }

                return 0;
            }
        }
    }
    return ERROR_NOT_FIND_DEV;
}

int zx_clear_dev_schedule_by_channel(int channel)
{
    unsigned char i = 0;    
    dzlog_info("enter channel=%d ", channel);

    for (i = 0; i < MAX_SUB1G_CONNECT; i++)
    {
        if (gppcs_base_param->dev_param[i].channle_id == channel)
        {
            memset(&gppcs_base_param->dev_param[i].dev_schedule, 0, SCHEDULE_SIZE);
            return 0;
        }
    }
    return ERROR_NOT_FIND_DEV;
}

int zx_set_dev_storagetype_by_channel(int channel, char type, time_t time)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			gppcs_base_param->dev_param[i].dev_storage_type = type;
			gppcs_base_param->dev_param[i].storage_cycle = time;
			return 0;
		}
	}
	return ERROR_NOT_FIND_DEV;
}

int zx_set_dev_pri_action_by_channel(int channel, int action)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)   // 离线设备不能设置
		{
            action = (gppcs_base_param->dev_param[i].pri_action&0xfc)|action;
            gppcs_base_param->dev_param[i].pri_action = action;
            dzlog_info("AI action=%d", action);
            zx_update_dev_pri_action_by_channel(channel, action);
            return 0;
		}
	}
	return ERROR_NOT_FIND_DEV;
}

int zx_set_dev_ai_by_channel(int channel, int action)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)   // 离线设备不能设置
		{
            unsigned char ai_action = gppcs_base_param->dev_param[i].pri_action&(~PRI_AI);
            if (action)
            {
                ai_action |= PRI_AI;
            }           
            gppcs_base_param->dev_param[i].pri_action = ai_action;
            zx_update_dev_pri_action_by_channel(channel, ai_action);
            return 0;
		}
	}
	return ERROR_NOT_FIND_DEV;
}


DEV_BASE_PARAM* zx_get_dev_by_channel(int channel)
{
	unsigned char i = 0;
	dzlog_info("enter channel=%d", channel);
	if (gppcs_base_param == NULL)
	{
		return ERROR_NULL_POINT;
	}
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
                 return &(gppcs_base_param->dev_param[i]);	
		}
	}
	return NULL;
}

int zx_get_dev_sn_by_channel(int channel, char *value)
{
	unsigned char i = 0;
	//dzlog_info("enter channel=%d", channel);
	if (value == NULL || gppcs_base_param == NULL)
	{
		return ERROR_NULL_POINT;
	}
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			strncpy(value, gppcs_base_param->dev_param[i].dev_sn, DEVICE_SN_LEN);
			return 0;	
		}
	}
	return ERROR_NOT_FIND_DEV;
}

/********************************************************
    funcname:     zx_get_dev_name_by_channel
    Description:
    intput:       channel
                  *valu
    output:       *value
********************************************************/
int zx_get_dev_name_by_channel(int channel, char *value)
{
	unsigned char i = 0;

	if (value == NULL || gppcs_base_param == NULL)
	{
		return ERROR_NULL_POINT;
	}
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			memcpy(value, gppcs_base_param->dev_param[i].dev_name, strlen(gppcs_base_param->dev_param[i].dev_name));
			return 0;	
		}
	}
	return ERROR_NOT_FIND_DEV;
}


int zx_get_dev_saddr_by_channel(int channel)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{

			return HISI_CH0;
		#if 0
			return gppcs_base_param->dev_param[i].sub1g_info.shortaddress;	
		#endif
		
		}
	}
	return -1;
}

/********************************************************
    funcname:     zx_get_p2p_session_handle
    Description:
    intput:       session_id
    output:       &session_handle
********************************************************/
int * zx_get_p2p_session_handle(int session_id)
{
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].session_handle == session_id)
		{
			return &gp2p_con_list[i].session_handle;
		}
	}
	return NULL;
}

/********************************************************
    funcname:     zx_get_dev_storagetype_by_channel
    Description:
    intput:       channel
    output:       1 支持
********************************************************/
int zx_check_dev_storagetype_by_channel(int channel)
{
	unsigned char i = 0;
	if (gppcs_base_param == NULL)
	{
		return ERROR_NULL_POINT;
	}
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gppcs_base_param->dev_param[i].channle_id == channel)
		{
			if (gppcs_base_param->dev_param[i].dev_storage_type == CLOUD_STORGE)
			{
				// 生命周期
				time_t cur_time = time(NULL);
				if (cur_time < gppcs_base_param->dev_param[i].storage_cycle)
				{
					return CLOUD_STORGE;
				}
			}
			return 0;
		}
	}
	return ERROR_NOT_FIND_DEV;
}


int zx_notify_thread_exit(int session_id)
{
	ZX_COMMUNICATION_PACKET comm_data;
	memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));

	comm_data.msg_head.head_tag = PAG_HEARD_TAG;
	comm_data.msg_head.command_id = APP_CMD_GET_P2P_CONN_STATUS;
	comm_data.msg_head.param_len = 0;
	comm_data.msg_head.version = COMM_VERSION;
	comm_data.msg_head.sign_code = NO_SEC_KEY;
	comm_data.msg_head.channel_id = 0;
	comm_data.msg_head.dev_type = 0x01;
	zx_write_notify(0, (uint8_t *)&comm_data, COMM_HEARD_LEN, session_id);
	dzlog_info("session_id:%d, exit......", session_id);
	return 0;
}


int zx_clear_p2p_connect_info(int session_handle)
{
    unsigned char i = 0;
    int ret=0;    
    for (i = 0; i < MAX_CONNECT_NUM; i++)
    {
        if (gp2p_con_list[i].session_handle == session_handle)
        {
            int channel_id = zx_get_p2p_channel_by_session(session_handle);

            gp2p_con_list[i].session_handle = -1;
            gp2p_con_list[i].channel = -1;
            if (gp2p_con_list[i].rsa_pubkey)
            {
                RSA_free(gp2p_con_list[i].rsa_pubkey);
                gp2p_con_list[i].rsa_pubkey = NULL;
            }
            memset(&gp2p_con_list[i].session_info, 0, sizeof(st_PPCS_Session));
            close(gp2p_con_list[i].video_pipe[0]);
            close(gp2p_con_list[i].video_pipe[1]);
            close(gp2p_con_list[i].audio_pipe[0]);
            close(gp2p_con_list[i].audio_pipe[1]);

            zx_notify_thread_exit(session_handle);  // for zx_p2p_notify_write() msgrcv exit

            ret = PPCS_ForceClose(session_handle);
            
            if ( channel_id >= 0)
            {

		#if 0
                zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel_id, CLIENT_P2P, 0);
		#endif
		
            }            
            dzlog_info("session_id: %d, exit(%d)......", session_handle, ret);

            int connect_num = 0;
            for (i = 0; i < MAX_CONNECT_NUM; i++)
            {
                if (gp2p_con_list[i].session_handle != -1)
                {
                    connect_num += 1;
                }
            }
            dzlog_info("cur p2p remain connect number: %d\n", connect_num);
            break;
        }
    }
    
    return session_handle;
}

#if 0
int zx_p2p_get_exec_result(int session_id, int command_id)
{
	ZX_COMM_HEAD comm_head;
	int data_len = COMM_HEARD_LEN;
    memset((CHAR*)&comm_head, 0, COMM_HEARD_LEN);
	int ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&comm_head, &data_len, READ_TIME_OUT);
	switch (ret)
	{
        case ERROR_PPCS_TIME_OUT:
            break;
        case ERROR_PPCS_SESSION_CLOSED_REMOTE: 
			PPCS_Close(session_id);
			dzlog_info("******** PPCS_Close result=%d %s", ret, get_p2p_err_info(ret));
			return ret;
		default:
			break;
	}
	dzlog_info("PPCS_Read result=%d %s", ret, get_p2p_err_info(ret));
	if (command_id == comm_head.command_id)
	{
		return comm_head.param_len;
	}
	return -1;
}
#endif

int zx_p2p_send_data(int session_id, void *data, int data_len)
{
	UINT32 WriteSize = 0;
	int ret = -1;
	if (data == NULL)
	{
		dzlog_info("data = NULL......");
		return -1;
	}
	while(grunning)
	{
		ret = PPCS_Check_Buffer(session_id, P2P_COMMAND_CHANNEL, &WriteSize, NULL);  //检查buffer 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			//dzlog_info("WriteSize=%d......", WriteSize);
			if (WriteSize <= MAX_P2P_BUF_SIZE)   //只有要写入的数据比 buf可存储的存储数据小，才让其写入
			{
				break;
			}
			usleep(50*1000);
		}
		else
		{
			goto exit;
		}
	}
	ret = PPCS_Write(session_id, P2P_COMMAND_CHANNEL, (CHAR*)data, data_len);
exit:
    if (ret < ERROR_PPCS_SUCCESSFUL)
    {
        dzlog_info("end ret=%d,[%s]......", ret, get_p2p_err_info(ret));
    }
    return ret;
}

int zx_p2p_send_command(char * hub_sn, int channel, int command_type, void *value, void *value2)
{
	dzlog_info("start[%d] [%d]......", channel, command_type);
	if (value == NULL || value2 == NULL)
		return ERROR_NULL_POINT;	
	
	if (channel > MAX_DEV_CONNECT)
		return ERROR_MAX_HUB_CONNECT_NUM;
	
	if (command_type > APP_CMD_SET_DEVS_NAME || command_type < APP_CMD_BIND_SYNC_ACCOUNT_INFO)
		return ERROR_INVALID_COMMAND;

	ZX_COMMUNICATION_PACKET comm_data;
	memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
	comm_data.msg_head.head_tag = PAG_HEARD_TAG;
	comm_data.msg_head.command_id = command_type;
	comm_data.msg_head.version = COMM_VERSION;
	comm_data.msg_head.sign_code = NO_SEC_KEY;

	//int session_id = -1;//zx_get_p2p_session_by_sn(hub_sn);
	//dzlog_info("end......");
	return ERROR_PPCS_SUCCESSFUL;
}



const char *get_command_str_info(int command_type)
{
    switch (command_type)
    {
        case APP_CMD_START_REC_BROADCASE:   //开始接收基站广播
			return "APP_CMD_START_REC_BROADCASE";
		case APP_CMD_STOP_REC_BROADCASE:          //停止接收基站广播
			return "APP_CMD_STOP_REC_BROADCASE";
		case APP_CMD_BIND_BROADCAST:       //1000基站配对广播	
			return "APP_CMD_BIND_BROADCAST";
		case APP_CMD_BIND_SYNC_ACCOUNT_INFO:      //1001 APP同步账户信息
			return "APP_CMD_BIND_SYNC_ACCOUNT_INFO";
		case APP_CMD_UNBIND_ACCOUNT:              //1002 APP解除账户绑定信息
			return "APP_CMD_UNBIND_ACCOUNT";
		case APP_CMD_START_REALTIME_MEDIA:   	 //1003 APP 查看实时视频
			return "APP_CMD_START_REALTIME_MEDIA";
		case APP_CMD_STOP_REALTIME_MEDIA: 		 //1004 APP 停止查看实时视频
			return "APP_CMD_STOP_REALTIME_MEDIA";
		case APP_CMD_START_TALKBACK:				 //1005 APP开始对讲
			return "APP_CMD_START_TALKBACK";
		case APP_CMD_STOP_TALKBACK:				 //1006停止对讲
			return "APP_CMD_STOP_TALKBACK";
		case APP_CMD_START_VOICECALL:			 //1007开始语音通话
			return "APP_CMD_START_VOICECALL";
		case APP_CMD_STOP_VOICECALL:				 //1008停止语音通话
			return "APP_CMD_STOP_VOICECALL";
		case APP_CMD_START_RECORD:                //1009开始录像
			return "APP_CMD_START_RECORD";
		case APP_CMD_STOP_RECORD:                 //1010停止录像
			return "APP_CMD_STOP_RECORD";
		case APP_CMD_PIR_SWITCH:                    //1011打开红外告警
			return "APP_CMD_PIR_SWITCH";
		case APP_CMD_CLOSE_PIR:                   //1012关闭红外告警
			return "APP_CMD_CLOSE_PIR";
		case APP_CMD_IRCUT_SWITCH:                  //1013打开夜视
			return "APP_CMD_IRCUT_SWITCH";
		case APP_CMD_CLOSE_IRCUT:                 //1014关闭夜视
			return "APP_CMD_CLOSE_IRCUT";
		case APP_CMD_EAS_SWITCH:                    //1015打开防盗
			return "APP_CMD_EAS_SWITCH";
		case APP_CMD_CLOSE_EAS:                   //1016关闭防盗
			return "APP_CMD_CLOSE_EAS";
		case APP_CMD_AUDDEC_SWITCH:                 //1017打开音频侦测
			return "APP_CMD_AUDDEC_SWITCH";
		case APP_CMD_CLOSE_AUDDEC:                //1018关闭音频侦测
			return "APP_CMD_CLOSE_AUDDEC";
		case APP_CMD_DEVS_LOCK_SWITCH:                   //1019设备锁定
			return "APP_CMD_DEVS_LOCK_SWITCH";
		case APP_CMD_DEVS_UNLOCK:                 //1020设备解锁
			return "APP_CMD_DEVS_UNLOCK";
		case APP_CMD_RECORD_IMG:				     //1021获取录像缩略图 
			return "APP_CMD_RECORD_IMG";
		case APP_CMD_RECORD_IMG_STOP:			 //1022停止获取缩略图
			return "APP_CMD_RECORD_IMG_STOP";
		case APP_CMD_STOP_SHARE:                  //1023视频共享
			return "APP_CMD_STOP_SHARE";
		case APP_CMD_DOWNLOAD_VIDEO:              //1024视频下载
			return "APP_CMD_DOWNLOAD_VIDEO";
		case APP_CMD_RECORD_VIEW:                 //1025录像回放
			return "APP_CMD_RECORD_VIEW";
		case APP_CMD_RECORD_PLAY_CTRL:			 //1026回放控制
			return "APP_CMD_RECORD_PLAY_CTRL";
		case APP_CMD_DELLETE_RECORD:              //1027录像删除
			return "APP_CMD_DELLETE_RECORD";
		case APP_CMD_SNAPSHOT:				     //1028抓图
			return "APP_CMD_SNAPSHOT";
		case APP_CMD_FORMAT_SD:                   //1029格式化基站SD卡
			return "APP_CMD_FORMAT_SD";
		case APP_CMD_CHANGE_PWD:                  //1030修改管理员密码
			return "APP_CMD_CHANGE_PWD";
		case APP_CMD_CHANGE_WIFI_PWD:             //1031修改wifi密码
			return "APP_CMD_CHANGE_WIFI_PWD";
		case APP_CMD_WIFI_CONFIG:				 //1032切换上级路由器
			return "APP_CMD_WIFI_CONFIG";
		case APP_CMD_TIME_SYCN:					 //1033时间同步
			return "APP_CMD_TIME_SYCN";
		case APP_CMD_HUB_REBOOT:			         //1034重启基站
			return "APP_CMD_HUB_REBOOT";
		case APP_CMD_DEVS_REBOOT:			     //1035重启设备
			return "APP_CMD_DEVS_REBOOT";
		case APP_CMD_HUB_TO_FACTORY:		         //1036基站恢复出厂
			return "APP_CMD_HUB_TO_FACTORY";
		case APP_CMD_DEVS_TO_FACTORY:             //1037设备恢复出厂设置
			return "APP_CMD_DEVS_TO_FACTORY";
		case APP_CMD_DEVS_BIND_BROADCASE:		 //1038设备绑定广播
			return "APP_CMD_DEVS_BIND_BROADCASE";
		case APP_CMD_DEVS_BIND_NOTIFY:            //1039设备绑定通知
			return "APP_CMD_DEVS_BIND_NOTIFY";
		case APP_CMD_DEVS_UNBIND:                 //1040设备解除绑定
			return "APP_CMD_DEVS_UNBIND";
		case APP_CMD_RECORDDATE_SEARCH: 		     //1041搜索存在录像的日期
			return "APP_CMD_RECORDDATE_SEARCH";
		case APP_CMD_RECORDLIST_SEARCH:			 //1042搜索指定日期的录像 
			return "APP_CMD_RECORDLIST_SEARCH";
		case APP_CMD_UPDATE:                      //1043版本更新
			return "APP_CMD_UPDATE";
		case APP_CMD_P2P_DISCONNECT:              //1044断开P2P连接
			return "APP_CMD_P2P_DISCONNECT";
		case APP_CMD_DEV_LED_SWITCH:                //1045打开设备指示灯	
			return "APP_CMD_DEV_LED_SWITCH";
		case APP_CMD_CLOSE_DEV_LED:               //1046关闭设备指示灯
			return "APP_CMD_CLOSE_DEV_LED";
        case APP_CMD_COLLECT_RECORD:              //1047记录收藏操作
            return "APP_CMD_COLLECT_RECORD";
        case APP_CMD_DECOLLECT_RECORD:            //1048取消记录收藏
            return "APP_CMD_DECOLLECT_RECORD";
        case APP_CMD_BATCH_RECORD:                //1049批量删除记录
            return "APP_CMD_BATCH_RECORD";
        case APP_CMD_STRESS_TEST_OPER:            //1050压力测试
			return "APP_CMD_STRESS_TEST_OPER";
        case APP_CMD_DOWNLOAD_CANCEL:
            return "APP_CMD_DOWNLOAD_CANCEL";

		case APP_CMD_GATEWAYINFO:			 //1100获取基站信息
			return "APP_CMD_GATEWAYINFO";
		case APP_CMD_GET_BATTERY:				 //1101获取电池电量
			return "APP_CMD_GET_BATTERY";
		case APP_CMD_SDINFO:                     //1102获取SD卡信息
			return "APP_CMD_SDINFO";
		case APP_CMD_CAMERA_INFO:				 //1103获取摄像机信息
			return "APP_CMD_CAMERA_INFO";
		case APP_CMD_GET_RECORD_TIME:			 //1104获取录像时长
			return "APP_CMD_GET_RECORD_TIME";
		case APP_CMD_GET_MDETECT_PARAM:		     //1105获取移动侦测参数
			return "APP_CMD_GET_MDETECT_PARAM";			
		case APP_CMD_MDETECTINFO:				 //1106获取移动侦测状态
			return "APP_CMD_MDETECTINFO";
		case APP_CMD_GET_ARMING_INFO:			 //1107获取布防撤防配置信息
			return "APP_CMD_GET_ARMING_INFO";
		case APP_CMD_GET_ARMING_STATUS:			 //1108获取设备布防撤防状态
			return "APP_CMD_GET_ARMING_STATUS";
		case APP_CMD_GET_AUDDEC_INFO:             //1109获取音频侦测参数
			return "APP_CMD_GET_AUDDEC_INFO";
		case APP_CMD_GET_AUDDEC_SENSITIVITY:      //1110获取音频侦测灵敏度
			return "APP_CMD_GET_AUDDEC_SENSITIVITY";
		case APP_CMD_GET_AUDDE_CSTATUS:           //1111获取音频侦测状态
			return "APP_CMD_GET_AUDDE_CSTATUS";
		case APP_CMD_GET_MIRRORMODE:			     //1112获取视频翻转状态
			return "APP_CMD_GET_MIRRORMODE";
		case APP_CMD_GET_IRMODE:				     //1113获取夜视模式
			return "APP_CMD_GET_IRMODE";
		case APP_CMD_GET_IRCUTSENSITIVITY:        //1114获取IRCUT光感门限
			return "APP_CMD_GET_IRCUTSENSITIVITY";
		case APP_CMD_GET_PIRINFO:                 //1115获取PIR配置参数
			return "APP_CMD_GET_PIRINFO";
		case APP_CMD_GET_PIRCTRL:				 //1116获取PIR状态
			return "APP_CMD_GET_PIRCTRL";
		case APP_CMD_GET_PIRSENSITIVITY:			 //1117获取PIR灵敏度
			return "APP_CMD_GET_PIRSENSITIVITY";
		case APP_CMD_GET_EAS_STATUS:              //1118获取防盗状态
			return "APP_CMD_GET_EAS_STATUS";
		case APP_CMD_GET_CAMERA_LOCK:			 //1119获取摄像机锁定状态
			return "APP_CMD_GET_CAMERA_LOCK";
		case APP_CMD_GET_GATEWAY_LOCK:			 //1120获取网关锁定状态
			return "APP_CMD_GET_GATEWAY_LOCK";
		case APP_CMD_GET_UPDATE_STATUS:			 //1121获取升级状态
			return "APP_CMD_GET_UPDATE_STATUS";
		case APP_CMD_GET_ADMIN_PWD:               //1122获取管理员密码
			return "APP_CMD_GET_ADMIN_PWD";
		case APP_CMD_GET_WIFI_PWD:                //1123获取wifi密码
			return "APP_CMD_GET_WIFI_PWD";
		case APP_CMD_GET_EXCEPTION_LOG:           //1124获取异常日志
			return "APP_CMD_GET_EXCEPTION_LOG";
		case APP_CMD_GET_NEWVESION:			     //1125获取新版本
			return "APP_CMD_GET_NEWVESION";
		case APP_CMD_GET_HUB_TONE_INFO:           //1126获取基站提示音配置
			return "APP_CMD_GET_HUB_TONE_INFO";
		case APP_CMD_GET_DEV_TONE_INFO:           //1127获取设备提示音配置
			return "APP_CMD_GET_DEV_TONE_INFO";
		case APP_CMD_GET_HUB_NAME:                //1128获取基站名称
			return "APP_CMD_GET_HUB_NAME";
		case APP_CMD_GET_DEVS_NAME:               //1129获取设备名称
			return "APP_CMD_GET_DEVS_NAME";
		case APP_CMD_GET_P2P_CONN_STATUS:         //1130获取P2P连接状态
			return "APP_CMD_GET_P2P_CONN_STATUS";
        case APP_CMD_GET_DEV_STATUS:
            return "APP_CMD_GET_DEV_STATUS";
        case APP_CMD_GET_HUB_LOG:                 //1132 提取hub log
            return "APP_CMD_GET_HUB_LOG";

		case APP_CMD_SET_LANGUAGE:			 //1200设置语言
			return "APP_CMD_SET_LANGUAGE";
		case APP_CMD_SET_TONE_FILE:               //1201设置基站提示音
			return "APP_CMD_SET_TONE_FILE";
		case APP_CMD_SET_DEVS_TONE_FILE:          //1202设置设备提示音
			return "APP_CMD_SET_DEVS_TONE_FILE";
		case APP_CMD_SET_RECORDTIME:			     //1203设置录像时长(全局)
			return "APP_CMD_SET_RECORDTIME";
		case APP_CMD_SET_MDETECTPARAM:			 //1204设置移动侦测配置
			return "APP_CMD_SET_MDETECTPARAM";
		case APP_CMD_SET_RESOLUTION:			     //1205设置视频分辨率
			return "APP_CMD_SET_RESOLUTION";
		case APP_CMD_SET_BITRATE:				 //1206设置码率
			return "APP_CMD_SET_BITRATE";
		case APP_CMD_SET_MIRRORMODE:			     //1207设置视频翻转
			return "APP_CMD_SET_MIRRORMODE";
		case APP_CMD_SET_IRMODE:				     //1208设置夜视模式
			return "APP_CMD_SET_IRMODE";
		case APP_CMD_SET_PIR_INFO:                //1209设置PIR配置
			return "APP_CMD_SET_PIR_INFO";
		case APP_CMD_SET_PIRSENSITIVITY:			 //1210设置PIR灵敏度  0-255
			return "APP_CMD_SET_PIRSENSITIVITY";
		case APP_CMD_SET_ARMING_SCHEDULE:	     //1211设置布防撤防配置
			return "APP_CMD_SET_ARMING_SCHEDULE";
		case APP_CMD_SET_AUDDEC_INFO:			 //1212设置音频侦测配置
			return "APP_CMD_SET_AUDDEC_INFO";
		case APP_CMD_SET_AUDDEC_SENSITIVITY:      //1213设置音频侦测门限
			return "APP_CMD_SET_AUDDEC_SENSITIVITY";
		case APP_CMD_SET_DEVS_OSD:                //1214设置设备OSD
			return "APP_CMD_SET_DEVS_OSD";
		case APP_CMD_SET_TIMEZONE:                //1215设置基站时区
			return "APP_CMD_SET_TIMEZONE";
		case APP_CMD_SET_HUB_NAME:                //1216设置基站名称
			return "APP_CMD_SET_HUB_NAME";
		case APP_CMD_SET_DEVS_NAME:               //1217设置设备名称
			return "APP_CMD_SET_DEVS_NAME";
		case APP_CMD_SET_HUB_PIR_STATUS:          //1218设置基站PIR总状态
			return "APP_CMD_SET_HUB_PIR_STATUS";
		case APP_CMD_SET_HUB_IRCUT_STATUS:        //1219设置基站IRCUT总开关
			return "APP_CMD_SET_HUB_IRCUT_STATUS";
		case APP_CMD_SET_HUB_GS_STATUS:           //1220设置基站防盗总开关
			return "APP_CMD_SET_HUB_GS_STATUS";
		case APP_CMD_SET_HUB_MVDEC_STATUS:        //1221设置基站运动侦测总开关
			return "APP_CMD_SET_HUB_MVDEC_STATUS";
		case APP_CMD_SET_HUB_AUDEC_STATUS:        //1222设置基站音频侦测总开关
			return "APP_CMD_SET_HUB_AUDEC_STATUS";
		case APP_CMD_SET_STORGE_TYPE:             //1223设置存储类型	
			return "APP_CMD_SET_STORGE_TYPE";
		case APP_CMD_SET_ARMING:                  //1224摄像头布防	
			return "APP_CMD_SET_ARMING";
		case APP_CMD_SET_DISARMING:               //1225摄像头撤防	
			return "APP_CMD_SET_DISARMING";
		case APP_CMD_SET_GSSENSITIVITY:			 //1226设置GS灵敏度	 0-127
			return "APP_CMD_SET_GSSENSITIVITY";
		case APP_CMD_SET_AUDIOSENSITIVITY:	     //1227设置音频侦测灵敏度
			return "APP_CMD_SET_AUDIOSENSITIVITY";
		case APP_CMD_SET_DEV_MIC_VOLUME:          //1229设置设备的麦克增益
			return "APP_CMD_SET_DEV_MIC_VOLUME";
		case APP_CMD_SET_DEV_SPEAKER_VOLUME:      //1230设置设备的喇叭音量
			return "APP_CMD_SET_DEV_SPEAKER_VOLUME";
        case APP_CMD_SET_AI_PHOTO:                //1231设置AI识别的头像
            return "APP_CMD_SET_AI_PHOTO";
        case APP_CMD_DEL_USER_PHOTO:                //1232删除AI用户的头像
            return "APP_CMD_DEL_USER_PHOTO";
        case APP_CMD_SET_PRI_ACTION:              //1233 PRI触发后的行为
            return "APP_CMD_SET_PRI_ACTION";
        case APP_CMD_DEL_FACE_PHOTO:              //1234删除AI用户的头像
            return "APP_CMD_DEL_FACE_PHOTO";
        case APP_CMD_SET_HUB_SPK_VOLUME:          //1235设置HUB的喇叭音量
            return "APP_CMD_SET_HUB_SPK_VOLUME";
        case APP_CMD_SET_AI_SWITCH:
            return "APP_CMD_SET_AI_SWITCH";
 
		case APP_CMD_VIDEO_FRAME:
			return "APP_CMD_VIDEO_FRAME";
		case APP_CMD_AUDIO_FRAME:
			return "APP_CMD_AUDIO_FRAME";
		case APP_CMD_STREAM_MSG:
			return "APP_CMD_STREAM_MSG";
		case APP_CMD_CONVERT_MP4_OK:
			return "APP_CMD_CONVERT_MP4_OK";
		case APP_CMD_DOENLOAD_FINISH:
			return "APP_CMD_DOENLOAD_FINISH";
		case APP_CMD_SET_DEV_STORAGE_TYPE:
			return "APP_CMD_SET_DEV_STORAGE_TYPE";

             /*added by dennis for door sensor*/
             case APP_CMD_DOOR_SENSOR_INFO_REPORT:
			 return "APP_CMD_DOOR_SENSOR_INFO_REPORT";
             case APP_CMD_DOOR_SENSOR_GET_INFO:
			 return "APP_CMD_DOOR_SENSOR_GET_INFO";
		case APP_CMD_DOOR_SENSOR_GET_DOOR_STATE:
			 return "APP_CMD_DOOR_SENSOR_GET_DOOR_STATE";
		case APP_CMD_DOOR_SENSOR_DOOR_EVT:
			 return "APP_CMD_DOOR_SENSOR_DOOR_EVT";
              case APP_CMD_DOOR_SENSOR_LOW_POWER_REPORT:
			 return "APP_CMD_DOOR_SENSOR_LOW_POWER_REPORT";
              /*added by dennis for door sensor end*/

        default:
            return "Unknow command!";
    }
}

unsigned char run_stress_test_mode = 0;

void * zx_process_stress_test(void *argv)
{
	unsigned char i = 0;
	unsigned char irled_mode = 0;
	unsigned int channel = *(int *)argv; 
	unsigned char open_camera = 0, open_pir = 0, open_ir_led = 0, close_camera = 0, close_pir = 0, close_ir_led = 0;
	unsigned int test_count = 0;
	while (run_stress_test_mode)
	{
		open_camera = zx_hisi_open_camera(channel, CLIENT_CMD);
	#if 0
		sleep(10);
		open_pir = zx_sub1g_send_command(SUB1G_CMD_OPEN_PIR, channel, 0, 0);
		sleep(5);
		irled_mode = 2;
		open_ir_led = zx_send_command(COMMON_TYPE_SET_IRLEDMODE, (char *)&irled_mode, channel);
		sleep(10);
		irled_mode = 0;
		close_ir_led = zx_send_command(COMMON_TYPE_SET_IRLEDMODE, (char *)&irled_mode, channel);
		close_pir = zx_sub1g_send_command(SUB1G_CMD_CLOSE_PIR, channel, 0, 0);
		sleep(10);
		close_camera = zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel, CLIENT_CMD, 0);	
		test_count++;
	#endif
		dzlog_info(">>>>>>[TEST COUNT:%d] channel = %d,  open_camera =%d open_pir=%d open_ir_led=%d close_ir_led=%d close_pir=%d close_camera=%d<<<<<<", test_count, channel, open_camera, open_pir, open_ir_led, close_ir_led, close_pir, close_camera);
		if (open_camera != 0)
			zx_push_message("home_security", "warning", channel);
	}
	return 0;
}


static void zx_p2p_process_door_sensor_msg(ZX_COMM_HEAD* comm_head,int session_id)
{
    ZX_COMMUNICATION_PACKET send_data;
    ZX_COMM_HEAD *send_head = &send_data.msg_head;
    int param_len = comm_head->param_len;
    int ret = 0;
    int channel_id = 0;

    dzlog_info("zx_p2p_process_door_sensor_msg enter, command_id = %d,param_len = %d",
                     comm_head->command_id,param_len);
    memcpy(send_head,comm_head,sizeof(ZX_COMM_HEAD));
    send_head->is_response = 1;
    //send_head->random = random();
    send_head->sign_code = NO_SEC_KEY;
    switch (comm_head->command_id)
    {
        case APP_CMD_DOOR_SENSOR_GET_INFO:
        {
            PARAM_ONE_INT_SET one_int_param;// = &comm_data.param_body.one_int_param; 
            DOOR_SENSOR_DEVICE_INFO *pGetInfoRspMsg = &(send_data.param_body.device_info_report);
            param_len = sizeof(PARAM_ONE_INT_SET);
            ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
            channel_id = one_int_param.value;
            dzlog_info("get door sensor info req,channel_id = %d",channel_id);
            DEV_BASE_PARAM *devParam = zx_get_dev_by_channel(channel_id);
	     if (devParam == NULL)
	     {
	         dzlog_error("no such device find");
                return;
	     }
            memset(pGetInfoRspMsg,0,sizeof(DOOR_SENSOR_DEVICE_INFO));
	     pGetInfoRspMsg->doorState = devParam->dev_door_sensor_state;
            pGetInfoRspMsg->isBatteryLow = devParam->dev_door_sensor_is_battery_low;
            pGetInfoRspMsg->led_switch = devParam->dev_door_sensor_led_switch;
            memcpy(&(pGetInfoRspMsg->dev_hardware_main_ver),&(devParam->dev_hardware_main_ver),SHORT_STR_LEN);
            memcpy(&(pGetInfoRspMsg->dev_software_main_ver),&(devParam->dev_software_main_ver),SHORT_STR_LEN);
            memcpy(&(pGetInfoRspMsg->dev_sn),&(devParam->dev_sn),SHORT_STR_LEN);

            send_head->param_len = sizeof(DOOR_SENSOR_DEVICE_INFO);
            dzlog_info("DOOR_SENSOR_DEVICE_INFO send,msg len = %d",send_head->param_len);
            zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	
        }
        break;
        case APP_CMD_DOOR_SENSOR_GET_DOOR_STATE:
        {
            PARAM_ONE_INT_SET one_int_param;// = &comm_data.param_body.one_int_param; 
            MSG_SUB1G_DOOR_SENSOR_GET_DOOR_STATE_RESP *pGetDoorStateRspMsg = &(send_data.param_body.device_info_report);
            param_len = sizeof(PARAM_ONE_INT_SET);
            ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
            channel_id = one_int_param.value;
            dzlog_info("get door state req,channel_id = %d",channel_id);
            DEV_BASE_PARAM *devParam = zx_get_dev_by_channel(channel_id);
	     if (devParam == NULL)
	     {
	         dzlog_error("no such device find");
                return;
	     }
            pGetDoorStateRspMsg->state = devParam->dev_door_sensor_state;
        }
        break;
	 case APP_CMD_DOOR_SENSOR_ALARM_ENABLE:
	 {
            PARAM_TWO_INT_SET two_int_param;
            param_len = sizeof(PARAM_TWO_INT_SET);
            ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
            channel_id = two_int_param.value;
            dzlog_info("get alarm enable req,channel_id = %d,enable = %d",channel_id,two_int_param.value1);
            DEV_BASE_PARAM *devParam = zx_get_dev_by_channel(channel_id);
	     if (devParam == NULL)
	     {
	         dzlog_error("no such device found");
                return;
	     }
		 
            if (two_int_param.value1 != devParam->dev_door_sensor_alarm_enable)
            {
                dzlog_info("change door_sensor_alarm_enable.");
                devParam->dev_door_sensor_alarm_enable = two_int_param.value1;
                write_config_param(SET_DEV_PARAM);//write alarm enable info to db
                char value_str[2] = {0};
		   sprintf(value_str,"%d",devParam->dev_door_sensor_alarm_enable);
                zx_Error err = zx_upload_devs_params(gppcs_base_param->hub_info.account_id, gppcs_base_param->hub_info.hub_sn, devParam->dev_sn, APP_CMD_DOOR_SENSOR_ALARM_ENABLE, value_str);
                ret = err.code;
            }
	     else
            {
                ret = ERROR_PARAM_NO_CHANGE;
            }
			
	     send_head->param_len = sizeof(EXEC_RESULT);
            send_data.param_body.result_info.error_code = ret;
            zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	
	 }
	 break;
	 default:
	     dzlog_info("unknow door sensor msg %d received",comm_head->command_id);
	 break;
    }
}

void * zx_p2p_command_read(void *argv)
{
	int session_id = *(int *)argv; 
	int ret = -1;
	int channel_id = 0;
	ZX_COMMUNICATION_PACKET send_data;
	ZX_COMM_HEAD comm_head; 
	ZX_COMM_HEAD *send_head = &send_data.msg_head;
	int head_len = 0;
	int param_len = 0;
    int find_head_tag = 0;

    dzlog_info("session = %d, PID =%d......", session_id, getpid());
    if (session_id < 0)
    {
        dzlog_error("exit p2p_command_read!");
        return NULL;
    }
    while (grunning)
    {
        memset((char *)&comm_head, 0 , COMM_HEARD_LEN);
        head_len = 4;   // 找头
        if (find_head_tag)
        {
            ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&comm_head.head_tag, &head_len, 1000); // ms
        }
        else
        {
            ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&comm_head.head_tag, &head_len, 0xFFFFFFFF);
        }
        switch (ret)
        {
            case ERROR_PPCS_TIME_OUT:
                dzlog_info("time_out.....");
                find_head_tag = 0;
                continue;
            case ERROR_PPCS_INVALID_PARAMETER:
            case ERROR_PPCS_INVALID_SESSION_HANDLE:
            case ERROR_PPCS_SESSION_CLOSED_REMOTE:
            case ERROR_PPCS_SESSION_CLOSED_TIMEOUT:
            case ERROR_PPCS_SESSION_CLOSED_CALLED:
                goto exit;
            default:
                if (ret < ERROR_PPCS_SUCCESSFUL)
                {
                    dzlog_warn("PPCS_Read ret: %d", ret);
                }
                break;
        }

        if (comm_head.head_tag != PAG_HEARD_TAG )
        {
            if (find_head_tag == 0)
            {
                dzlog_warn("[%s] bad msg, head_tag=0x%x..... ", get_p2p_err_info(ret), comm_head.head_tag);
                find_head_tag = 1;
            }
            continue;
        }

        find_head_tag = 0;
        head_len = COMM_HEARD_LEN - 4;
        PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&comm_head.command_id, &head_len, READ_TIME_OUT);

        //printf_hex((char *)&comm_head, COMM_HEARD_LEN);
        memcpy(send_head, (char *)&comm_head, COMM_HEARD_LEN);
        send_head->is_response = 0x01;

		ret = -1;
		param_len = comm_head.param_len; 
		
		if (gppcs_base_param->hub_info.update_status == 1)
		{
			//ppcs读信息
			ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&send_data, &param_len, READ_TIME_OUT);  //ppcs读信息
			send_head->param_len = sizeof(EXEC_RESULT);
			send_data.param_body.result_info.error_code = ERROR_HUB_UPDATEING;
			//发送数据
			zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	  //发送数据
			
			dzlog_warn("******hub updateing..... ");		
			return 0;
		}
		
		switch (comm_head.command_id)
		{
			case APP_CMD_BIND_SYNC_ACCOUNT_INFO:      //1001 APP同步账户信息
			{
				param_len = sizeof(PARAM_APP_BIND_ACCOUNT);
				
				if (comm_head.param_len == param_len)
				{
					PARAM_APP_BIND_ACCOUNT bind_account;//= &comm_data.param_body.bind_account;	
					//读信息
					ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&bind_account, &param_len, READ_TIME_OUT);  //读信息
					
					printf_hex((char *)&bind_account, param_len);
					
					dzlog_info("%s sn[%s] account[%s]......", get_command_str_info(comm_head.command_id), bind_account.sn,  bind_account.account);
					//char 1310_version[SMALL_STR_LEN] = {0};
					
				#if 0
					zx_get_colector_version(&gppcs_base_param->hub_info.hub_software_sec_ver);  //获取基站1310版本号
				
					dzlog_info("sub1g version=%s", gppcs_base_param->hub_info.hub_software_sec_ver);
					//char main_version[SMALL_STR_LEN] = {0};					
				#endif

					//获取系统版本号
					zx_get_system_soft_version(gppcs_base_param->hub_info.hub_software_main_ver);  //获取系统版本号
					
					dzlog_info("system version=V%s", gppcs_base_param->hub_info.hub_software_main_ver);	

					//app绑定基站
					zx_Error err = zx_app_bind_hub(bind_account.sn, bind_account.account, "", "");  //绑定基站
					ret = err.code;
					
					if (ret == 0)
					{
						dzlog_info("hub_sn = %s , dev_sn = %s",bind_account.sn,bind_account.sn);
						
						//app设备绑定
						err = zx_hub_bind_devs(bind_account.sn, bind_account.sn, "", HISI_CH0, 
                                               FLOODLIGHT , bind_account.account);
						ret = err.code;

						if(ret == 0)
						{
							
							err = zx_upload_devs_params(bind_account.account, bind_account.sn, bind_account.sn, APP_CMD_GET_DEV_STATUS, "1");		//更新app在线为在线状态
							
	                        #if RUN_AI_MODULE
	                        ai_play_wav(0, "/etc_ro/add_HB_success.wav");		//绑定成功播放声音
	                        #endif
					#if HISI_AUDIO_PLAY
							if(hal_audio_play_file("/etc/en/add_cam_success.wav") != 0)   //绑定成功播放声音
							{
								dzlog_error("hisi audio play file error");
							}
							dzlog_info("【---audio play add_cam_success.wav ok---】");
					#endif
							
							memset(gppcs_base_param->hub_info.account_id, 0, sizeof(gppcs_base_param->hub_info.account_id));
							//memset(gppcs_base_param->hub_info.hub_name, 0, sizeof(gppcs_base_param->hub_info.hub_name));
							//memset(gppcs_base_param->hub_info.time_tone, 0, sizeof(gppcs_base_param->hub_info.time_tone));
							memcpy(gppcs_base_param->hub_info.account_id, bind_account.account, strlen(bind_account.account));

							memcpy(gppcs_base_param->dev_param[0].dev_sn, bind_account.sn, strlen(bind_account.sn));

							memcpy(hisi_cam_data->account_id,bind_account.account,strlen(bind_account.account));		//brady add

							dzlog_info("【hisi_cam_data->account_id = %s】",hisi_cam_data->account_id);

				#if 0
							//设置ID到flash里面
							if(zx_hisi_set_flash_account_id(hisi_cam_data->account_id,sizeof(hisi_cam_data->account_id)) <= 0)
							{
								
								dzlog_error("hisi set account id error");
								break;
							}
				#endif
							dzlog_info("gppcs_base_param->hub_info.account_id = %s",gppcs_base_param->hub_info.account_id);
							
							//memcpy(gppcs_base_param->hub_info.hub_name, bind_account.hub_name, strlen(bind_account.hub_name));
							//memcpy(gppcs_base_param->hub_info.time_tone, bind_account.time_tone, strlen(bind_account.time_tone));
							gppcs_base_param->hub_info.have_bind_app	= 0x01;

							//更新软件版本信息
							err = zx_hub_update_version(bind_account.sn, bind_account.account, gppcs_base_param->hub_info.hub_software_main_ver, gppcs_base_param->hub_info.hub_software_sec_ver);
	                        gppcs_base_param->hub_info.rsa_pub_id = 0;
	                        zx_check_local_rsa_pubkey();
	                        write_config_param(HAVE_BIND_ACCOUNT);

						}
                    }
                    else
                    {
                        #if RUN_AI_MODULE
                        ai_play_wav(0, "/etc_ro/add_HB_fail.wav");		//绑定失败播放声音
                        #endif
			#if HISI_AUDIO_PLAY
						if(hal_audio_play_file("/etc/en/add_cam_fail.wav") != 0)   //绑定失败播放声音
						{
							dzlog_error("hisi audio play file error");
						}
						dzlog_info("【---audio play add_cam_fail.wav ok---】");
			#endif
                    }
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;

				//p2p发送数据
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	//往p2p发送数据

				break;
			}

			case APP_CMD_UNBIND_ACCOUNT:   //app解除账号绑定信息
			{
				PARAM_APP_BIND_ACCOUNT bind_account;
				param_len = sizeof(PARAM_APP_BIND_ACCOUNT);
				
				//读信息
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&bind_account, &param_len, READ_TIME_OUT);
				
				printf_hex((char *)&bind_account, param_len);
				
				dzlog_info("%s sn[%s] account[%s]......", get_command_str_info(comm_head.command_id), bind_account.sn,  bind_account.account);

				//app解除绑定
				zx_Error err = zx_app_unbind_hub(bind_account.sn, bind_account.account);
				ret = err.code;
				
				if (ret == 0)
				{
					//解除绑定设备
					err = zx_hub_unbind_devs(bind_account.sn, bind_account.sn,bind_account.account);
					ret = err.code;

					if(ret == 0)
					{
						//解除绑定后将信息都清零
						memset(gppcs_base_param->hub_info.account_id, 0, sizeof(gppcs_base_param->hub_info.account_id));	
						memset(gppcs_base_param->hub_info.hub_name, 0, sizeof(gppcs_base_param->hub_info.hub_name));	
						memset(gppcs_base_param->hub_info.time_tone, 0, sizeof(gppcs_base_param->hub_info.time_tone));	
						gppcs_base_param->hub_info.have_bind_app	= 0x00;	

						//写解除账号配置
						write_config_param(UNBIND_ACCOUNT);

						//发送数据
						zx_send_boradcast(BROADCAST_PORT, gppcs_base_param->hub_info.hub_sn, " ");
						
	                    #if RUN_AI_MODULE
	                    ai_play_wav(0, "/etc_ro/add_HB_ready.wav");			//解绑账号播放声音
	                    #endif

						
					}
                }
                else
                {
                    #if RUN_AI_MODULE
                    ai_play_wav(0, "/etc_ro/add_HB_fail.wav");		//解绑失败播放声音
                    #endif
                }

				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				
				//p2p发送给服务端，解除app绑定
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	
				break;
			}

			case APP_CMD_START_REALTIME_MEDIA:   	 //1003 APP 查看实时视频 默认单向语音
			{
                RSA_PUB_INFO rsakey; 
                param_len = comm_head.param_len;
                if (param_len > sizeof(RSA_PUB_INFO))
                {
                    PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&send_data.param_body, &param_len, READ_TIME_OUT);
                    ret = ERROR_INVALID_PARAM;
                }
                else
                {
                    memset((char *)&rsakey, 0, sizeof(RSA_PUB_INFO));
                    ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&rsakey, &param_len, READ_TIME_OUT);
                    
                    channel_id = rsakey.channel;
					unsigned char power_level = zx_get_power_level_by_channle(channel_id);
                    dzlog_info("%s channel_id=%d power_level=%d", get_command_str_info(comm_head.command_id), channel_id, power_level);
					if (power_level < 10 && power_level != 0)
					{
						ret = ERROR_POWER_LOW;
						goto STOP_;
					}
					//更新p2p通道
                    zx_update_p2p_channel_by_session(session_id, channel_id);

                    //ret = zx_open_camera(channel_id,CLIENT_P2P);
                 #if 0
					ret = zx_hisi_open_camera(channel_id,CLIENT_P2P);
                    if (ret == ERROR_WAIT_TIMEOUT)
                    {
                        ret = 0;
                    }
				#endif
				
                    if (param_len == sizeof(RSA_PUB_INFO))
                    {
                        #if 0 // test only
                        char hexTable[] = "0123456789ABCDEF";
                        int i;
                        for (i=0; i<NORMAL_PARAM_LEN; i++)
                        {
                            rsakey.nkey[i] = hexTable[i&0xf];
                        }
                        #endif                    
                        rsakey.nkey[NORMAL_PARAM_LEN] = 0;
					#if 1
                        RSA* pubkey = rsa_get_pubKey(rsakey.nkey);
                        if (pubkey != NULL)
                        {
                            zx_update_p2p_rsakey_by_session(session_id, pubkey);
                        }
                        else
                        {
                            dzlog_info("pubkey is NULL!");
                        }
					#endif
                    }
                }
STOP_:
				send_head->param_len = sizeof(EXEC_RESULT);
			#if 0
				send_data.param_body.result_info.error_code = ret;
			#endif

				//p2p发送数据
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
			
			case APP_CMD_STOP_REALTIME_MEDIA: 		 //1004 APP 停止查看实时视频
			{
				PARAM_ONE_INT one_int_param; 
				param_len = sizeof(PARAM_ONE_INT);

				//读信息
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				
				dzlog_info("%s channel_id=%d......", get_command_str_info(comm_head.command_id), channel_id);
				
				send_head->param_len = sizeof(EXEC_RESULT);
				
				if (zx_check_p2p_channel_status(session_id, channel_id) == 0) // 没有其它session占用时才关闭
				{
				#if 0
					ret = zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel_id, CLIENT_P2P, 0);
				#endif
				}
				else
				{
					ret = 0;
				}
				zx_update_p2p_channel_by_session(session_id, -1);

				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
			
			case APP_CMD_START_TALKBACK:		     //1005 APP开始对讲  
			case APP_CMD_STOP_TALKBACK:				 //1006停止对讲
			case APP_CMD_START_VOICECALL:			 //1007开始语音通话
			case APP_CMD_STOP_VOICECALL:			 //1008停止语音通话
				break;

			case APP_CMD_START_RECORD:               //1009对于主动发起的远程查看开始录像 录制到基站
			case APP_CMD_STOP_RECORD:                //1010停止录像
				break;

			case APP_CMD_PIR_SWITCH:                   //1011红外告警开关
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				dzlog_info("%s channel_id[%d] account[%s] switch=%d......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
				{
					dzlog_error("【camera account id error. gppcs_base_param->hub_info.account_id = %s】",gppcs_base_param->hub_info.account_id);
					ret = ERROR_INVALID_ACCOUNT;
				}
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					if (param_int == SWITCH_OPEN)
					{
						ret = zx_hisi_set_pir_on();
						dzlog_info("pir open ok.");
					}
						
					else if (param_int == SWITCH_CLOSE)
					{
						ret = zx_hisi_set_pir_off();
						dzlog_info("pir close ok.");
					}
						
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, comm_head.command_id, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
							
							char param_str[4] = {0};
							sprintf(param_str, "%d", param_int);
							
							if (ret == 0)
							{
								dzlog_info("dev_sn  = %s",dev_sn);
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_PIR_SWITCH, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
					else
					{
						dzlog_error("zx_sub1g_send_command, error = %d", ret);
					}
				}
    			send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}	
/*			case APP_CMD_CLOSE_PIR:                  //1012关闭红外告警
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);

				dzlog_info("APP_CMD_CLOSE_PIR channel_id[%d] account[%s]......", channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = zx_sub1g_send_command(SUB1G_CMD_CLOSE_PIR, channel_id, 0, 0);
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, comm_head.command_id, 0);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
							if (ret == 0)
							{
								zx_Error err = zx_upload_devs_params(one_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_OPEN_PIR, "0");
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
*/
			case APP_CMD_IRCUT_SWITCH:                 //1013夜视模式
			{
				PARAM_TWO_INT two_int_param; 
				param_len = sizeof(PARAM_TWO_INT);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				unsigned int irled_mode = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				dzlog_info("%s channel_id[%d] IRCUT mode=%d......", get_command_str_info(comm_head.command_id), channel_id,  irled_mode);
				
				if (irled_mode < HISI_IRLEDMODE_OFF || irled_mode > HISI_IRLEDMODE_ON)
					ret = ERROR_INVALID_PARAM;
				else
				{
					#if 0
					//ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, channel_id, 1, 0);
					ret = zx_sub1g_send_command(SUB1G_CMD_OPER_IRCUT, channel_id, irled_mode, 0); 
					#endif
					
					if(irled_mode == HISI_IRLEDMODE_OFF)
					{
						ret = zx_hisi_set_ircut_off();			//关闭IRCUT
						hisi_cam_data->ircut_set_mode = HISI_IRLEDMODE_OFF;
						dzlog_info("hisi set ircut close.");
					}
					else if(irled_mode == HISI_IRLEDMODE_ON)
					{
						ret = zx_hisi_set_ircut_on();			//打开IRCUT
						hisi_cam_data->ircut_set_mode = HISI_IRLEDMODE_ON;
						dzlog_info("hisi set ircut open.");
					}
					else if(irled_mode == HISI_IRLEDMODE_AUTO)
					{
						ret = 0;
						hisi_cam_data->ircut_set_mode = HISI_IRLEDMODE_AUTO;
						dzlog_info("hisi set ircut auto.");
					}
					
					if (ret == 0)
					{
						//ret = zx_send_command(COMMON_TYPE_SET_IRLEDMODE, (char *)&irled_mode, channel_id);
						//if (ret == 0)
						{
							ret = zx_set_dev_status_by_channel_type(channel_id, comm_head.command_id, irled_mode);
							if (ret == 0)
							{
								char dev_sn[SHORT_STR_LEN] = {0};

								ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

								//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
								
								if (ret == 0)
								{
									char param[4] = {0};
									sprintf(param, "%d", irled_mode);
									dzlog_info("dev_sn  = %s",dev_sn);
									
									zx_Error err = zx_upload_devs_params(gppcs_base_param->hub_info.account_id, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_IRCUT_SWITCH, param);
									ret = err.code;
									if (ret == 0)
										write_config_param(SET_DEV_PARAM);
								}
							}
						}
					}
						
				}
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	
				break;
			}
/*
			case APP_CMD_CLOSE_IRCUT:                //1014关闭夜视
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);
				unsigned int irled_mode = XM_IRLEDMODE_OFF;				

				dzlog_info("APP_CMD_CLOSE_IRCUT channel_id[%d] account[%s]......", channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, channel_id, 1, 0);
					if (ret == 0)
					{
						ret = zx_send_command(COMMON_TYPE_SET_IRLEDMODE, (char *)&irled_mode, channel_id);
						if (ret == 0)
						{
							ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_OPEN_IRCUT, irled_mode);
							if (ret == 0)
							{
								char dev_sn[SHORT_STR_LEN] = {0};
								ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
								if (ret == 0)
								{
									char param[4] = {0};
									sprintf(param, "%d", irled_mode);
									zx_Error err = zx_upload_devs_params(one_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_OPEN_IRCUT, param);
									ret = err.code;
									if (ret == 0)
										write_config_param(SET_DEV_PARAM);
								}
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);	
			}
				break;
*/

			case APP_CMD_EAS_SWITCH:                   //1015防盗 GSENSOR开关
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
				#if 0
					if (param_int == SWITCH_OPEN)
						ret = zx_sub1g_send_command(SUB1G_CMD_OPEN_GSENSOR, channel_id, 0, 0);
					else if (param_int == SWITCH_CLOSE)
						ret = zx_sub1g_send_command(SUB1G_CMD_CLOSE_GSENSOR, channel_id, 0, 0);
				#endif
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_EAS_SWITCH, 1);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};

							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
							
							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
							
							if (ret == 0)
							{
								char param_str[4] = {0};
								sprintf(param_str, "%d", param_int);
								dzlog_info("dev_sn  = %s",dev_sn);
								
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_EAS_SWITCH, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}

/*			case APP_CMD_CLOSE_EAS:                  //1016关闭防盗 GSENSOR
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);

				dzlog_info("APP_CMD_CLOSE_EAS channel_id[%d] account[%s]......", channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = zx_sub1g_send_command(SUB1G_CMD_CLOSE_GSENSOR, channel_id, 0, 0);
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_OPEN_EAS, 0);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
							if (ret == 0)
							{
								zx_Error err = zx_upload_devs_params(one_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_EAS_SWITCH, "0");
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
*/
			case APP_CMD_AUDDEC_SWITCH:                //1017音频侦测开关
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d ......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					
					if (param_int == SWITCH_OPEN)
					{
						ret = hal_audio_vin_enable(param_int);
						dzlog_info("audio mic open...");
						
					}
					else if (param_int == SWITCH_CLOSE)
					{
						ret = hal_audio_vin_enable(param_int);
						dzlog_info("audio mic close...");
					}

				
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_AUDDEC_SWITCH, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
						
							if (ret == 0)
							//if (ret > 0)
							{
								char param_str[4] = {0};
								sprintf(param_str, "%d", param_int);
								
								dzlog_info("dev_sn  = %s",dev_sn);
								
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_AUDDEC_SWITCH, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
/*
			case APP_CMD_CLOSE_AUDDEC:               //1018关闭音频侦测
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);

				dzlog_info("APP_CMD_CLOSE_AUDDEC channel_id[%d] account[%s]......", channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = zx_sub1g_send_command(SUB1G_CMD_CLOSE_AUDIO_DEC, channel_id, 0, 0);
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_OPEN_AUDDEC, 0);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
							if (ret == 0)
							{
								zx_Error err = zx_upload_devs_params(one_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_OPEN_AUDDEC, "0");
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}
*/

			case APP_CMD_DEV_LED_SWITCH:                //1045设备指示灯开关
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d ......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					
					if (param_int == SWITCH_OPEN)
					{

						ret = zx_hisi_set_white_led_on();		//打开白色指示灯

						dzlog_info("set white led on OK.");
					
					}
					else if (param_int == SWITCH_CLOSE)
					{

						ret = zx_hisi_set_white_led_off();		//打开白色指示灯

						hisi_cam_data->white_led_tigger = HISI_IRLEDMODE_OFF;		//手动关闭

						dzlog_info("set white led manual off OK.");
					
					}					
					
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_DEV_LED_SWITCH, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);	//获取sn
							
							if (ret == 0)
							//if (ret > 0)
							{
								char param_str[4] = {0};
								sprintf(param_str, "%d", param_int);

								dzlog_info("dev_sn  = %s",dev_sn);
							
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_DEV_LED_SWITCH, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}			

			case APP_CMD_DEVS_LOCK_SWITCH:           //1019设备锁定
			case APP_CMD_DEVS_UNLOCK:                //1020设备解锁	 
				break;

			case APP_CMD_DEVS_UNBIND:                //1040设备解除绑定
			{
				PARAM_ONE_INT_SET one_int_param;// = &comm_data.param_body.one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;

				dzlog_info("%s channel_id[%d] account[%s]......", get_command_str_info(comm_head.command_id), channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					
				#if 0
                    if (channel_id <  DOOR_SENSOR_CHANNEL_ID_START)
                    {
                        ret = zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel_id, CLIENT_P2P, 0);
                    }
                    ret = zx_sub1g_send_command(SUB1G_CMD_DISASSOC_DEV, channel_id, 0, 0); // 解绑SUB1G
                    //if (ret == 0 || ret == ERROR_DEV_OFFLINE || ret == ERROR_NOT_FIND_DEV)
				#endif
				
                    if ((channel_id >=  DOOR_SENSOR_CHANNEL_ID_START) &&
                       (channel_id <  (DOOR_SENSOR_CHANNEL_ID_START+DOOR_SENSOR_MAX_NUM)))
                    {
                         dzlog_info("clear door sensor info.");
                         int shortAddr= zx_get_dev_saddr_by_channel(channel_id);
						 
                         if (shortAddr > 0)
                         {
                             char dev_sn[SHORT_STR_LEN] = {0};
							 
                             ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

							// ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
							 
                             if (ret == 0)
							 //if (ret > 0)
                             {
                                 dzlog_info("clear door sensor info in bg server");
								 
								 dzlog_info("dev_sn  = %s",dev_sn);
								 
                                 zx_Error err = zx_hub_unbind_devs(gppcs_base_param->hub_info.hub_sn, dev_sn, one_int_param.account);
                                 ret = err.code;
                                 if (ret == 0)
                                 {
                                     dzlog_info("clear door sensor info in local db");
									 
									#if 0
                                     zx_clean_dev_linkinfo_by_shortaddr(shortAddr);
									#endif
									
                                 }
                             }
                         }
                    }
				
                    else
					{
						
					#if 0
						ret = XMHAL_ClearCameraMatchInfo(RELEASE_SINGLE_CHANNEL, channel_id);
						dzlog_info("XMHAL_ClearCameraMatchInfo channel[%d] res=%d......", channel_id, ret);
					#endif
					
						char dev_sn[SHORT_STR_LEN] = {0};
					
						ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

						//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
						
						if (ret == 0)
						//if (ret > 0)
						{
							dzlog_info("dev_sn  = %s",dev_sn);
							
							zx_Error err = zx_hub_unbind_devs(gppcs_base_param->hub_info.hub_sn, dev_sn, one_int_param.account);
							ret = err.code;
							if (ret == 0)
							{
								//ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_DEVS_UNBIND, 0);
								
							#if 0
								zx_clean_dev_linkinfo_by_channel(channel_id);
							#endif
							
								//appclient_SendGetDeviceArrayReq();
								write_config_param(UNBIND_ACCOUNT);
							}
						}
					}
					
				#if 0
					zx_get_dev_count();
				#endif
				
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}		
		
			case APP_CMD_DEVS_REBOOT:			     //1035重启设备	
			{
				PARAM_ONE_INT_SET one_int_param;// = &comm_data.param_body.one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
			
				dzlog_info("%s channel_id[%d] account[%s]......", get_command_str_info(comm_head.command_id), channel_id,  one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					dzlog_error("【reboot start......】");
					zx_ota_system("reboot");					//重启设备
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = 0x01;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_DOWNLOAD_VIDEO:             //1024视频下载  视频下载从P2P通道3
			{
				PARAM_SET_PARAM dev_param;
				param_len = sizeof(PARAM_SET_PARAM);
				memset(&dev_param, 0, param_len);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&dev_param, &param_len, READ_TIME_OUT);

				dzlog_info("%s filepath[%s] account[%s]......", get_command_str_info(comm_head.command_id), dev_param.value,  dev_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, dev_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					if( access(dev_param.value, F_OK) == 0 )
					{
						if (h264_download == 0)
						{
						//启动一个线程,把文件转为mp4格式后通过socket上传到媒体服务器
						PARAM_SESSION_FILE sessiion_info;
						memset(&sessiion_info, 0, sizeof(PARAM_SESSION_FILE));
						strcpy(sessiion_info.filename, dev_param.value);
						sessiion_info.session_id = session_id;
						zx_create_thread(LOW_PRIORITY, zx_h264tomp4_thread, &sessiion_info, -1, RECORD_TO_MP4, -1);
						ret = 0;
						}
						else
						{
							ret = ERROR_DEV_BUSY;
						}
					}
					else
					{
						ret = ERROR_OPEN_FILE_FAIL;
						dzlog_error("%s error, ret =%d", get_command_str_info(comm_head.command_id), ret);
					}
				}
				
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_RECORD_VIEW:                //1025录像回放 视频回放用P2P 1通道  camera00(摄像头名称)+channel(摄像头通道)+时间（月日时分秒0000000000）
			{
				PARAM_SET_PARAM dev_param;
				param_len = sizeof(PARAM_SET_PARAM);
				memset(&dev_param, 0, param_len);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&dev_param, &param_len, READ_TIME_OUT);

				dzlog_info("%s filepath[%s] ......", get_command_str_info(comm_head.command_id), dev_param.value);
				if (strcmp(gppcs_base_param->hub_info.account_id, dev_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;    // 本地录像不再分享
				else
				{
					if( access(dev_param.value, F_OK) == 0 )
					{
						//启动一个线程,读取文件把数据通过P2P上传
						PARAM_SESSION_FILE sessiion_info;
						memset(&sessiion_info, 0, sizeof(PARAM_SESSION_FILE));
						strcpy(sessiion_info.filename, dev_param.value);
						sessiion_info.session_id = session_id;
						zx_create_thread(LOW_PRIORITY, zx_tfcard_h264_playback_thread, &sessiion_info, -1, RECORD_SEND, -1);
						ret = 0;
					}
					else
					{
						ret = ERROR_OPEN_FILE_FAIL;
						dzlog_error("%s error, ret =%d",get_command_str_info(comm_head.command_id), ret);
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_DELLETE_RECORD:              //1026录像删除  参数为路径
			{
				PARAM_SET_PARAM_EX dev_param;
				param_len = sizeof(PARAM_SET_PARAM_EX);
				memset(&dev_param, 0, param_len);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&dev_param, &param_len, READ_TIME_OUT);

				dzlog_info("%s filepath[%s] account[%s]......", get_command_str_info(comm_head.command_id), dev_param.value,  dev_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, dev_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
                {
                    zx_Error err = zx_delete_hub_history_record(gppcs_base_param->hub_info.account_id,
                                                                gppcs_base_param->hub_info.hub_sn,
                                                                dev_param.ivalue);
                    if (err.code == 0)
                    {
                        file_list_del((char *)&dev_param.value);
                        ret = 0;  // 文件不存在，认为删了
                    }
                    else
                    {
                         ret = err.code;
                    }
                }
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_RECORD_PLAY_CTRL:			 //1026回放控制
			{
				PARAM_TWO_INT two_int_param; 
				param_len = sizeof(PARAM_TWO_INT);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&two_int_param, &param_len, READ_TIME_OUT);
			
				PLAYBACK_CONTROL_PARAM playback;
				playback.control_type = two_int_param.value;
				playback.fram_num = two_int_param.value1;
				zx_set_playclt_by_session(session_id, playback);

				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = 0x00;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

            case APP_CMD_FORMAT_SD:                  //1029格式化基站SD卡 TF卡异常时通知用户确认格式化
            {
                PARAM_ONE_INT_SET one_int_param;
                param_len = sizeof(PARAM_ONE_INT_SET);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);

                dzlog_info("%s ......", get_command_str_info(comm_head.command_id));
                if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else
                {
                    if(access("/sys/block/mmcblk0/size", W_OK) == 0)
                    {
                        ret = 0;
                    }
                    else
                    {
                        ret = ERROR_NOT_TFCARD;
                    }
                }
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                if (ret == 0)
                {
                    tfcard_format_flg = 1;

                     ret = system("/sbin/format_tf.sh");  // 执行时间比较长
                    if (ret == -1 || ret==127)
                    {
                        dzlog_error("format TF card err:%d", errno);
                    }
                }
            }
            break;

			case APP_CMD_HUB_TO_FACTORY:		     //1036基站恢复出厂 谨慎使用
				break;

			case APP_CMD_DEVS_TO_FACTORY:             //1037设备恢复出厂设置
				break;

			case APP_CMD_DEVS_BIND_BROADCASE:		 //1038设备绑定广播
			{
				PARAM_TWO_INT_SET two_int_param;
                param_len = comm_head.param_len;
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);

                int bind_timeout;
                int bind_type;
                char* p_account;
                if (param_len == sizeof(PARAM_ONE_INT_SET)) // 老接口
                {
                    PARAM_ONE_INT_SET *parmp = (PARAM_ONE_INT_SET *)&two_int_param;
                    bind_timeout = parmp->value;
                    bind_type = FLOODLIGHT;
                    p_account = parmp->account;
                }
                else
                {
                    bind_timeout = two_int_param.value;
                    bind_type    = two_int_param.value1;
                    p_account    = two_int_param.account;
                }

				dzlog_info("%s bind_timeout=%d, bind_type=%d", get_command_str_info(comm_head.command_id), bind_timeout,bind_type);
				if (strcmp(gppcs_base_param->hub_info.account_id, p_account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else
				{
				#if 0
                    ret = zx_set_bind_status(session_id, bind_timeout*1000);
                    dzlog_info("dev bind ret= %d", ret);
				#endif
				
                    if (bind_timeout)
                    {
                        switch(bind_type)
                        {
                            case FLOODLIGHT:
                            {
                                gdev_bind_type = FLOODLIGHT;
                            }
                            break;
                            case DOOR_SENSOR:
                            {
                                gdev_bind_type = DOOR_SENSOR;
                            }
                            break;
                            default:
                                gdev_bind_type = XM_CAMERA;
                                break;
                        }
                    }
                    else
                    {
                        gdev_bind_type = 0; // 停止提示音
                    }
                }
                send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_STRESS_TEST_OPER:            //1050压力测试
			{
				PARAM_ONE_INT one_int_param; 
				param_len = sizeof(PARAM_ONE_INT);
				
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				unsigned char set_value = one_int_param.value;
				unsigned int oper_channel = 0;
				dzlog_info("%s set_value=%d......", get_command_str_info(comm_head.command_id), set_value);
				send_head->param_len = sizeof(EXEC_RESULT);
				
				if (set_value == 1)
				{
					run_stress_test_mode = 1;
					unsigned char dev_num = 0;
					for (dev_num = 0; dev_num < MAX_SUB1G_CONNECT; dev_num++)
					{
						if (gppcs_base_param->dev_param[dev_num].channle_id >= 0)
						{
							oper_channel = gppcs_base_param->dev_param[dev_num].channle_id;
							zx_create_thread(HIGH_PRIORITY, zx_process_stress_test, &oper_channel, -1, STRESS_TEST, 0);
						}
					}
				}
				else if (set_value == 0)
				{
					run_stress_test_mode = 0;
				}

				send_data.param_body.result_info.error_code = 0;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

				
			case APP_CMD_HUB_REBOOT:			     //1033重启基站
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				channel_id = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);

				dzlog_info("%s account[%s]......", get_command_str_info(comm_head.command_id), one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = 0;
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;	
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				if (ret == 0)
				{
					dzlog_info("******APP_CMD_HUB_REBOOT reboot......");
					//zx_do_system("%s", "reboot");
					zx_ota_system("reboot");
				}
				break;
			};

			case APP_CMD_SET_STORGE_TYPE:            //1222设置存储类型:                 
			case APP_CMD_SET_HUB_PIR_STATUS:          //1218设置基站PIR总状态
			case APP_CMD_SET_HUB_IRCUT_STATUS:        //1219设置基站IRCUT总开关
			case APP_CMD_SET_HUB_GS_STATUS:           //1220设置基站防盗总开关
			case APP_CMD_SET_HUB_MVDEC_STATUS:        //1221设置基站运动侦测总开关
			case APP_CMD_SET_HUB_AUDEC_STATUS:        //1221设置基站音频侦测总开关
			case APP_CMD_SET_RECORDTIME:			 //1203设置录像时长(全局)
			case APP_CMD_SET_HUB_SPK_VOLUME:        //1235设置HUB的喇叭音量
			{
				PARAM_ONE_INT_SET one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				int set_value = one_int_param.value;
				send_head->param_len = sizeof(EXEC_RESULT);

				char svalue[2] = {0};
				sprintf(svalue, "%d", set_value);

				dzlog_info("%s Set_type[%d] value=%d account[%s]......", get_command_str_info(comm_head.command_id), comm_head.command_id, 
								set_value, one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					zx_Error err = zx_upload_hub_params(one_int_param.account, gppcs_base_param->hub_info.hub_sn, comm_head.command_id, svalue);
					ret = err.code;
					if (ret == 0)
					{
						switch (comm_head.command_id)
						{
							case APP_CMD_SET_STORGE_TYPE:
								gppcs_base_param->hub_info.storage_type	= set_value;
								break;
							case APP_CMD_SET_HUB_PIR_STATUS:
								gppcs_base_param->hub_info.pir_status = set_value;
								break;
							case APP_CMD_SET_HUB_IRCUT_STATUS:
								gppcs_base_param->hub_info.ir_cut_status = set_value;
								break;
							case APP_CMD_SET_HUB_GS_STATUS:
								gppcs_base_param->hub_info.gsession_status = set_value;
								break;
							case APP_CMD_SET_HUB_MVDEC_STATUS:
								gppcs_base_param->hub_info.move_det_status = set_value;
								break;
							case APP_CMD_SET_HUB_AUDEC_STATUS:
								gppcs_base_param->hub_info.voice_det_status	= set_value;
								break;
							case APP_CMD_SET_RECORDTIME:
								gppcs_base_param->hub_info.record_time_out = set_value * 1000; // ms
								break;
                            case APP_CMD_SET_HUB_SPK_VOLUME:
                            {
                                gppcs_base_param->hub_info.spk_volume = set_value;

								ret = hal_audio_set_vout(set_value);

								hisi_cam_data->speaker_volume = set_value;

								dzlog_info("set vout %d , ret = %d",set_value,ret);
								
                                break;
                            }
						}
						write_config_param(SET_HUB_PARAM);
						ret = 0;
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;	
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			};

			
		
			case APP_CMD_GET_MDETECT_PARAM:		     //1105获取移动侦测参数
			case APP_CMD_MDETECTINFO:				 //1106获取移动侦测状态
			case APP_CMD_GET_ARMING_STATUS:			 //1108获取设备布防撤防状态
			case APP_CMD_GET_AUDDEC_SENSITIVITY:      //1110获取音频侦测灵敏度
			case APP_CMD_GET_AUDDE_CSTATUS:           //1111获取音频侦测状态
			case APP_CMD_GET_MIRRORMODE:			  //1112获取视频翻转状态
			case APP_CMD_GET_IRMODE:				  //1113获取夜视模式
			case APP_CMD_GET_IRCUTSENSITIVITY:        //1114获取IRCUT光感门限
			case APP_CMD_GET_PIRCTRL:				  //1116获取PIR状态
			case APP_CMD_GET_PIRSENSITIVITY:		  //1117获取PIR灵敏度
			case APP_CMD_GET_EAS_STATUS:              //1118获取防盗状态
			case APP_CMD_GET_CAMERA_LOCK:			  //1119获取摄像机锁定状态
			case APP_CMD_GET_UPDATE_STATUS:			  //1121获取设备升级状态
				break;

			case APP_CMD_GET_BATTERY:				  //1101获取设备电池电量
			{
				//PARAM_ONE_INT *one_int_param = &comm_data.param_body.one_int_param; 
				//one_int_param->value = channel;
				//zx_p2p_send_data(session_id, (void*)&comm_data, sizeof(ZX_COMM_HEAD) + sizeof(PARAM_ONE_INT));	
				//comm_read_data = zx_p2p_get_exec_result(session_id, command_type);
				//return comm_read_data->param_body.result_info.error_code;
				break;
			}

		
			case APP_CMD_GET_GATEWAY_LOCK:			 //1120获取网关锁定状态
			{
				//zx_p2p_send_data(session_id, (void*)&comm_data, sizeof(ZX_COMM_HEAD));	
				//comm_read_data = zx_p2p_get_exec_result(session_id, command_type);
				//return comm_read_data->param_body.one_int_param.value;
				break;
			};	
		
/*			case APP_CMD_SET_RECORDTIME:			 //1203设置录像时长(全局)
			{
				PARAM_ONE_INT_SET one_int_param;// = &comm_data.param_body.one_int_param; 
				param_len = sizeof(PARAM_ONE_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);
				send_head->param_len = sizeof(EXEC_RESULT);

				dzlog_info("%s account[%s]......", get_command_str_info(comm_head.command_id), one_int_param.account);
				if (strcmp(gppcs_base_param->hub_info.account_id, one_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					gppcs_base_param->hub_info.record_time_out = one_int_param.value;
					write_config_param(SET_HUB_PARAM);
					ret = 0;
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;	
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}
*/
			case APP_CMD_SET_RESOLUTION:			 //1205设置视频质量
			{
				PARAM_TWO_INT two_int_param; 
				param_len = sizeof(PARAM_TWO_INT);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int video_quality = two_int_param.value1;
				unsigned int video_bitrate = VIDEO_2M;
				unsigned int frame_rate = FRAME_RATE;
				unsigned int gop_interval = H264_GOP_INTERVAL;
				dzlog_info("%s video_quality=%d......", get_command_str_info(comm_head.command_id), video_quality);
                if (channel_id<0 || channel_id>=MAX_CAMERA_NUM || ret<ERROR_PPCS_SUCCESSFUL)
                {
                    ret = ERROR_INVALID_PARAM;
                }
                else
                {
					dzlog_info("【set video quality...】");
					
                    if (video_quality == VIDEO_HIGH_QUALITY)
                    {

						dzlog_info("【set video reslution 1080p】");
						ret = hal_video_set_resolution(HISI_CH0,RES_1080P);

						if(ret != 0)
						{
							dzlog_error("set video resolution error");
							ret = ERROR_INVALID_ACCOUNT;
						}
						video_quality = RES_1080P;
						frame_rate = FRAME_RATE;

						hal_video_set_bitrate(HISI_CH0,HISI_CAMERA_1080P_BITRATE,MODE_VBR);		//设置码率
						
					#if 0
                        if (strcmp(gppcs_base_param->dev_param[channel_id].dev_hardware_main_ver, XM_CAM_720P_HWMODEL) == 0)
                        {
                            video_quality = RES_720P;
                        }
                        else
                        {
                            video_quality = RES_1080P;
                        }
                        video_bitrate = VIDEO_2M;
					#endif

						
					
                    }
                    else if (video_quality == VIDEO_MID_QUALITY)
                    {

						dzlog_info("【set video reslution 720p】");
						ret = hal_video_set_resolution(HISI_CH0,RES_720P);

						if(ret != 0)
						{
							dzlog_error("set video resolution error");
							ret = ERROR_INVALID_ACCOUNT;
						}

						//hal_video_set_fps(HISI_CH0,FRAME_RATE);
						//video_quality = RES_720P;
						frame_rate = FRAME_RATE;

						hal_video_set_bitrate(HISI_CH0,HISI_CAMERA_720P_BITRATE,MODE_VBR);		//设置码率

					#if 0
                        video_quality = RES_720P;
                        video_bitrate = VIDEO_1_5M;
                        frame_rate = FRAME_RATE;
					#endif
					
                    }
                    else if (video_quality == VIDEO_LOW_QUALITY)
                    {

						dzlog_info("【set video reslution 360p】");
						ret = hal_video_set_resolution(HISI_CH0,RES_VGA);

						if(ret != 0)
						{
							dzlog_error("set video resolution error");
							ret = ERROR_INVALID_ACCOUNT;
						}
						
						//video_quality = RES_VGA;
						frame_rate = FRAME_RATE;

						hal_video_set_bitrate(HISI_CH0,HISI_CAMERA_360P_BITRATE,MODE_VBR);		//设置码率

						
					#if 0
                        video_quality = RES_720P;
                        video_bitrate = VIDEO_600k;
                        frame_rate = FRAME_RATE;
					#endif
					
                    }
                    else
                    {

						dzlog_info("【set video reslution 1080p】");
						ret = hal_video_set_resolution(HISI_CH0,RES_1080P);

						if(ret != 0)
						{
							dzlog_error("set video resolution error");
							ret = ERROR_INVALID_ACCOUNT;
						}
						video_quality = RES_1080P;
						frame_rate = FRAME_RATE;

						hal_video_set_bitrate(HISI_CH0,HISI_CAMERA_1080P_BITRATE,MODE_VBR);		//设置码率
						
					#if 0
                        video_quality = RES_1080P;
					#endif
					
                    }

				#if 0
                    ret = zx_send_command(COMMON_TYPE_SET_RESOLUTION, (char *)&video_quality, channel_id);
                    usleep(50*1000);
                    ret = zx_send_command(COMMON_TYPE_SET_BITRATE, (char *)&video_bitrate, channel_id);
                    usleep(50*1000);
                    ret = zx_send_command(COMMON_TYPE_SET_H264GOP, (char *)&gop_interval, channel_id);
                    usleep(50*1000);
                    ret = zx_send_command(COMMON_TYPE_SET_FRAMERATE, (char *)&frame_rate, channel_id);
                    usleep(50*1000);
				#endif
				
                    char dev_sn[SHORT_STR_LEN] = {0};
				
                    ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

					//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
					
                    if (ret == 0)
					//if (ret > 0)
                    {
						dzlog_info("【***dev_sn = %s***】",dev_sn);
						
						dzlog_info("【***account_id = %s***】",gppcs_base_param->hub_info.account_id);
                        char param_str[4] = {0};
                        sprintf(param_str, "%d", two_int_param.value1);
                        zx_Error err = zx_upload_devs_params(gppcs_base_param->hub_info.account_id,
                                                             gppcs_base_param->hub_info.hub_sn,
                                                             dev_sn, APP_CMD_SET_RESOLUTION, param_str);
                        ret = err.code;

						dzlog_info("【send app code = %d】",ret);
						
                    }
                }
                send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_SET_BITRATE:				 //1206设置码率
			{
				
				break;
			}

			case APP_CMD_SET_MIRRORMODE:			 //1207设置视频翻转
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int video_mirror = two_int_param.value1;
				dzlog_info("%s video_mirror=%d......", get_command_str_info(comm_head.command_id), video_mirror);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
				#if 0
					ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, channel_id, WAKEUP_WITH_WIFI, 0);
					if (ret == 0)
					{
						ret = zx_wait_channel_ready(channel_id, 15, 1);
						if (ret == 0)
						{
							ret = zx_send_command(COMMON_TYPE_SET_MIRROR, (char *)&video_mirror, channel_id);
							dzlog_info("%s COMMON_TYPE_SET_MIRROR=%d......", get_command_str_info(comm_head.command_id), ret);
							if (ret == 0)
							{
								ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_SET_MIRRORMODE, video_mirror);
								char dev_sn[SHORT_STR_LEN] = {0};
								ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
								if (ret == 0)
								{
									char param_str[4] = {0};
									sprintf(param_str, "%d", video_mirror);
									zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_SET_MIRRORMODE, param_str);
									ret = err.code;
									if (ret == 0)
										write_config_param(SET_DEV_PARAM);
								}
							}
						}
					}
					zx_sub1g_send_command(SUB1G_CMD_SLEEP, channel_id, CLIENT_P2P, 0);
				#endif
					dzlog_info("【set video torate... : %d】",video_mirror);
				
					ret = hal_video_set_torate(video_mirror);		//视频翻转
				
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_SET_MIRRORMODE, video_mirror);
						char dev_sn[SHORT_STR_LEN] = {0};
						
						ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);
						
						//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
						
						if (ret == 0)
						//if (ret > 0)
						{
							char param_str[4] = {0};
							sprintf(param_str, "%d", video_mirror);

							dzlog_info("dev_sn  = %s",dev_sn);
							
							dzlog_info("【***account_id = %s***】",two_int_param.account);
							
							zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_SET_MIRRORMODE, param_str);
							ret = err.code;
							if (ret == 0)
								write_config_param(SET_DEV_PARAM);
							
						}
					}
					
				}
				send_head->param_len = sizeof(EXEC_RESULT);				
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_SET_IRMODE:				 //1208设置夜视模式
				break;

			case APP_CMD_SET_DEV_MIC_VOLUME:          //1229设置设备的麦克增益
			{
				PARAM_TWO_INT_SET two_int_param;
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int mic_volume = two_int_param.value1;
				dzlog_info("%s channle=%d, MIC volume:%d", get_command_str_info(comm_head.command_id), channel_id, mic_volume);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else
				{

				#if 1
					//ret = zx_send_command(COMMON_TYPE_SET_MICGAIN, (char *)&mic_volume, channel_id);
                    //dzlog_info("%s COMMON_TYPE_SET_MICGAIN,ret=%d......", get_command_str_info(comm_head.command_id), ret);

					ret = hal_audio_set_vin(mic_volume);		//设置mic音量
				
                    if (ret == 0)
                    {
                        ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_SET_DEV_MIC_VOLUME, mic_volume);                        
                        if (ret == 0)
                        {
                            char dev_sn[SHORT_STR_LEN] = {0};
                            char param_str[4] = {0};
                            sprintf(param_str, "%d", mic_volume);
							
                            ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);
							
							dzlog_info("dev_sn  = %s",dev_sn);
							
                            zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn,
                                                                 dev_sn, APP_CMD_SET_DEV_MIC_VOLUME, param_str);
                            ret = err.code;
                            if (ret == 0)
                            {
                                write_config_param(SET_DEV_PARAM);
                            }
                        }
                        else if (ret == ERROR_PARAM_NO_CHANGE)
                        {
                            ret = 0;
                        }
                    }
				#endif
				
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}
			case APP_CMD_SET_DEV_SPEAKER_VOLUME:      //1230设置设备的喇叭音量
			{
				PARAM_TWO_INT_SET two_int_param;
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int spk_volume = two_int_param.value1;
				dzlog_info("%s channle=%d, speaker volume:%d", get_command_str_info(comm_head.command_id), channel_id, spk_volume);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else
				{
					
				#if 0
					ret = zx_send_command(COMMON_TYPE_SET_SPKGAIN, (char *)&spk_volume, channel_id);
                    //dzlog_info("%s COMMON_TYPE_SET_SPKGAIN,ret=%d......", get_command_str_info(comm_head.command_id), ret);
				#endif
				
					dzlog_info("【set speaker volume... : %d】",spk_volume);
				
					ret = hal_audio_set_vout(spk_volume);		//设置speaker音量
					
                    if (ret == 0)
                    {
                        ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_SET_DEV_SPEAKER_VOLUME, spk_volume);
                        if (ret == 0)
                        {
                            char dev_sn[SHORT_STR_LEN] = {0};
                            char param_str[4] = {0};
                            sprintf(param_str, "%d", spk_volume);
							
                            ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);
                            
							//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);

							dzlog_info("【***dev_sn = %s ,account_id = %s***】",dev_sn ,two_int_param.account);
							
                            zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn,
                                                                 dev_sn, APP_CMD_SET_DEV_SPEAKER_VOLUME, param_str);
                            ret = err.code;
                            if (ret == 0)
                            {
                                //write_config_param(SET_DEV_PARAM);
                            }
                        }
                        else if (ret == ERROR_PARAM_NO_CHANGE)
                        {
                            ret = 0;
                        }
                    }
				
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_SET_PIRSENSITIVITY:	     //1210设置PIR灵敏度
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
                int set_value = two_int_param.value1;
				dzlog_info("%s pir_sensitivity=%d......", get_command_str_info(comm_head.command_id), set_value);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else
				{
                    char dev_sn[SHORT_STR_LEN] = {0};
                    char param_str[8] = {0};

					dzlog_info("【set pir sensivity... : %d】",set_value);
					
					if( set_value >= PIR_ONE_LEVEL && set_value <PIR_SEVEN_LEVEL )
						ret = zx_hisi_set_pir_sensivity_value(set_value,set_value,set_value);		//设置pir的灵敏度,后期或者改成单独设置
					else
						dzlog_error("pie sensivity : %d",set_value);
					
                    sprintf(param_str, "%d", set_value);
					
                    ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);
					
					//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
					
					dzlog_info("dev_sn  = %s",dev_sn);
					
					
                    zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn,
                                                         dev_sn, APP_CMD_SET_PIRSENSITIVITY, param_str);
                    ret = err.code;
                    if (ret == 0)
                    {
						
					#if 0
                        ret = zx_sub1g_send_command(SUB1G_CMD_SET_PIR_SENSITIVITY, channel_id, set_value, 0);
					#endif
					
						
					
                    }
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				
				break;
			}

			case APP_CMD_SET_AUDDEC_SENSITIVITY:     //1213设置音频侦测门限
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
                int set_value = two_int_param.value1;
				dzlog_info("%s audio_sensitivity=%d......", get_command_str_info(comm_head.command_id), set_value);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = 0;//zx_sub1g_send_command(SUB1G_CMD_SET_PIR_SENSITIVITY, channel_id, set_value, 0);//无定义
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				
				break;
			}

			case APP_CMD_SET_GSSENSITIVITY:		//设置GS灵敏度
			{
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
                int set_value = two_int_param.value1;
				dzlog_info("%s gs_sensitivity=%d......", get_command_str_info(comm_head.command_id), set_value);
				//zx_update_p2p_channel_by_session(session_id, channel_id);
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
                    char dev_sn[SHORT_STR_LEN] = {0};
                    char param_str[4] = {0};
                    sprintf(param_str, "%d", set_value);
                    ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);
                    zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn,
                                                         dev_sn, APP_CMD_SET_GSSENSITIVITY, param_str);
                    ret = err.code;
                    if (ret == 0)
                    {
						
					#if 0
                        ret = zx_sub1g_send_command(SUB1G_CMD_SET_GSENSOR_SENSITIVITY, channel_id, set_value, 0);
					#endif
					
                    }
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				
				break;
			}

			case APP_CMD_SET_DEVS_OSD:               //1214设置设备OSD
				break;

			case APP_CMD_SET_LANGUAGE:			     //1200设置语言  =1200:
			{
				PARAM_TWO_INT_SET one_two_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_two_param, &param_len, READ_TIME_OUT);
				channel_id = one_two_param.value;
                //int set_value = one_two_param.value1;

				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = 0x01;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				
				break;
			}

			case APP_CMD_SET_ARMING:				 //1224布防撤防
				break;

			case APP_CMD_SET_MDETECTPARAM:			 //1204设置移动侦测配置
			case APP_CMD_SET_PIR_INFO:               //1209设置PIR配置
			case APP_CMD_SET_AUDDEC_INFO:			 //1212设置音频侦测配置
				break;
			case APP_CMD_SET_ARMING_SCHEDULE:	     //1211设置布防撤防配置
			{
				PARAM_SCHEDULED scheduled;
				param_len = sizeof(PARAM_SCHEDULED);
				memset(&scheduled, 0, param_len);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&scheduled, &param_len, READ_TIME_OUT);
				channel_id = scheduled.channel;
				dzlog_info("%s account=%s loop_count=%d once_cout=%d......", get_command_str_info(comm_head.command_id), scheduled.account, scheduled.schedule.loop_sch_count, scheduled.schedule.once_sch_count);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, scheduled.account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else if (scheduled.schedule.loop_sch_count > LOOP_SCH_COUNT || scheduled.schedule.once_sch_count > ONCE_SCH_COUNT)
				{
					ret = ERROR_INVALID_PARAM_LEN;
				}
				else
				{
					char dev_sn[SHORT_STR_LEN] = {0};
					
					//ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

					ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);		//add 
					
					//if (ret == 0)
						
					if (ret > 0)
					{						
						zx_Error err = zx_hub_edit_devs_strinfo_by_paramname(dev_sn, gppcs_base_param->hub_info.hub_sn, scheduled.account,
																			"schedule", scheduled.app_schedule);
                        //设置布防撤防配置(自动)与 APP_CMD_SET_PRI_ACTION(手动)互斥
                        char param_str[4] = {0};
                        sprintf(param_str, "%d", PRI_IDLE);
                        err = zx_upload_devs_params(scheduled.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_SET_PRI_ACTION, param_str);
                        ret = err.code;
						if (ret == 0)
						{
                            ret = zx_set_dev_pri_action_by_channel(channel_id, PRI_IDLE);
							ret = zx_set_dev_schedule_by_channel(channel_id, (char *)&scheduled.schedule, sizeof(DEV_SCHEDULE));
							if (ret == 0)
							{
							    write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_BATCH_RECORD:    //1049批量删除记录
			{
				REC_BATCH_DEL batch_del;
				param_len = comm_head.param_len;
				memset(&batch_del, 0, param_len);

				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&batch_del, &param_len, READ_TIME_OUT);
				dzlog_info("%s record_count=%d", get_command_str_info(comm_head.command_id), batch_del.record_count);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, batch_del.account) != 0)
				{
					ret = ERROR_INVALID_ACCOUNT;
				}
				else if (batch_del.record_count > MAX_BATCH_DEL_NUM)
				{
					ret = ERROR_INVALID_PARAM_LEN;
				}
				else
				{
                    zx_Error err = zx_delete_hub_history_records(gppcs_base_param->hub_info.account_id,
                                                                 gppcs_base_param->hub_info.hub_sn,
                                                                 batch_del.record_count, 
                                                                 batch_del.record_list);
                    if (err.code == 0)
                    {
                        batch_del_files(&batch_del);
                        ret = 0;    // 删除文件，默认是成功
                    }
                    else
                    {
                        ret = err.code;
                    }
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}


			case APP_CMD_SET_TIMEZONE:                //1215设置基站时区
			{
				PARAM_SET_PARAM set_param;
				param_len = sizeof(PARAM_SET_PARAM);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
				channel_id = set_param.channel;
				dzlog_info("%s value[%s] account[%s]......", get_command_str_info(comm_head.command_id), set_param.value,  set_param.account);
				if (strlen(set_param.value) <= 0 || strlen(set_param.value) > SMALL_STR_LEN)
					ret = ERROR_INVALID_PARAM_LEN;
				else if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					memset(gppcs_base_param->hub_info.time_tone, 0, sizeof(gppcs_base_param->hub_info.time_tone));
					memcpy(gppcs_base_param->hub_info.time_tone, set_param.value, strlen(set_param.value));
					
					ret = zx_set_timetone(set_param.value);
					
					if (ret == 0)
					{
						zx_Error err = zx_hub_update_info_by_infoname(gppcs_base_param->hub_info.hub_sn, set_param.account, "time_zone", set_param.value);
						ret = err.code;
						if (ret == 0)
						{
							write_config_param(SET_HUB_TIMETONE); // 由操作系统保存当前时区
						}
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}
			case APP_CMD_SET_HUB_NAME:                //1216设置基站名称
			{
				PARAM_SET_PARAM set_param;
				param_len = sizeof(PARAM_SET_PARAM);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
				channel_id = set_param.channel;
				dzlog_info("%s value[%s] ......", get_command_str_info(comm_head.command_id), set_param.value);
				dzlog_info("account_id[%s] account[%s]......", gppcs_base_param->hub_info.account_id,  set_param.account);
				
				if (strlen(set_param.value) <= 0 || strlen(set_param.value) > SHORT_STR_LEN)
					ret = ERROR_INVALID_PARAM_LEN;
				else if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					dzlog_info("value[%s] account[%s]......", set_param.value,  set_param.account);

					memset(gppcs_base_param->hub_info.hub_name, 0, sizeof(gppcs_base_param->hub_info.hub_name));
					memset(gppcs_base_param->dev_param[0].dev_name, 0, sizeof(gppcs_base_param->dev_param[0].dev_name));
					
					memcpy(gppcs_base_param->hub_info.hub_name, set_param.value, strlen(set_param.value));

					memcpy(gppcs_base_param->dev_param[0].dev_name, set_param.value, strlen(set_param.value));

					//ret = zx_hisi_get_flash_account_id(set_param.account,sizeof(set_param.account));
					
					zx_Error err = zx_hub_update_info_by_infoname(gppcs_base_param->hub_info.hub_sn, set_param.account, "station_name", set_param.value);
					//zx_upload_hub_params(set_param.account, gppcs_base_param->hub_info.hub_sn, comm_head.command_id, set_param.value);

					err = zx_hub_edit_devs_strinfo_by_paramname(gppcs_base_param->hub_info.hub_sn, gppcs_base_param->hub_info.hub_sn, set_param.account, 
                     															"device_name", set_param.value);
					ret = err.code;
					if (ret == 0)
					{
						dzlog_info("hub update info by infoname ok");
						write_config_param(SET_HUB_NAME);
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}
							
			case APP_CMD_STOP_SHARE:                 //1022视频共享  返回云存储路径 MP4文件格式
			case APP_CMD_GET_HUB_NAME:                //1128获取基站名称
			{
				//zx_p2p_send_data(session_id, (void*)&comm_data, sizeof(ZX_COMM_HEAD));	
				//comm_read_data = zx_p2p_get_exec_result(session_id, command_type);
				//memcpy((char *)value2, comm_read_data->param_body.one_string_param.value, strlen(comm_read_data->param_body.one_string_param.value));
				break;
			}

			case APP_CMD_COLLECT_RECORD:                   //1047记录收藏操作
			case APP_CMD_DECOLLECT_RECORD:                 //1048取消记录收藏
			{
				PARAM_SET_PARAM_EX set_param;
				param_len = sizeof(PARAM_SET_PARAM_EX);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
				channel_id = set_param.channel;
				dzlog_info("%s file_path[%s]......", get_command_str_info(comm_head.command_id), set_param.value);
				if (strlen(set_param.value) <= 0 || strlen(set_param.value) > NORMAL_STR_LEN)
					ret = ERROR_INVALID_PARAM_LEN;
				else if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					if( access(set_param.value, F_OK) == 0 )
					{
						int mode = 0;
						if (comm_head.command_id == APP_CMD_COLLECT_RECORD)
						{
							mode = 1;  //收藏
						}
						else if (comm_head.command_id == APP_CMD_DECOLLECT_RECORD)
						{
							mode = 0;  //取消收藏
						}

                        dzlog_info("monitor_id: %d", set_param.ivalue);
                        zx_Error err = zx_update_favorite_history_record(gppcs_base_param->hub_info.account_id, 
                                                    gppcs_base_param->hub_info.hub_sn, set_param.ivalue, mode);
                        if (err.code == 0)
                        {
                            ret = update_file_favorite(set_param.value, mode);
                        }
                        else
                        {
                            ret = err.code;
                        }
					}
					else
					{
						ret = ERROR_OPEN_FILE_FAIL;
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

#if RUN_AI_MODULE
            case APP_CMD_SET_AI_PHOTO:                //1231设置AI识别的头像
            {
                AI_IMAGE_INFO *image_param =NULL;
                AI_INFO * ai_info;
                param_len = sizeof(AI_IMAGE_INFO);
                image_param = malloc(param_len);
                if (image_param == NULL)
                {
                    ret = ERROR_NULL_POINT;
                    goto send_ai_exec_result;
                }

                memset((char *)image_param, 0, param_len);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)image_param, &param_len, READ_TIME_OUT);
                if (ret < ERROR_PPCS_SUCCESSFUL)
                {
                    dzlog_error("PPCS_Read len:%d, error: %d", param_len, ret);
                    goto send_ai_exec_result;
                }
                ai_info = &image_param->ai_info;
                dzlog_info("%s userid[%d], nick_name:%s, image_size %d, face_point[0] =%f", get_command_str_info(comm_head.command_id),
                           ai_info->user_id, ai_info->nick_name, ai_info->image_size, ai_info->face_point[0]);

                if (strcmp(gppcs_base_param->hub_info.account_id, image_param->account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else if (ai_info->image_size > JPG_BUF_SIZE || ai_info->image_size == 0)
                {
                    ret = ERROR_INVALID_PARAM_LEN;
                }

			#if 0
                else
                {
                    AI_FACE_FEATURE *pface = zx_get_face_feature(ai_info->image_buf, ai_info->image_size, (char *)ai_info->face_point);
                    if (pface != NULL)
                    {
                        // upload AI face freture, get id
                        char* pfacebase64 = NULL;
                        char* pimagebase64 = NULL;
                        zx_Error err;
                        pfacebase64 = zx_Memory_Encode(pface->feature, sizeof(float)*FACE_FEATURE_SAMPLE);
                        pimagebase64 = zx_Memory_Encode(ai_info->image_buf, ai_info->image_size);
                        pface->group_id = ai_info->group_id;
                        pface->notify = ai_info->notify;
                        pface->user_id = ai_info->user_id;
                        memset(pface->nick_name, 0, sizeof(pface->nick_name));
                        memcpy(pface->nick_name, ai_info->nick_name, strlen(ai_info->nick_name));
					#if 0
                        if (ai_info->face_id == 0) // 新用户
                        {
                            err = zx_hub_add_face_features(gppcs_base_param->hub_info.account_id,
                                                           gppcs_base_param->hub_info.hub_sn,
                                                           pfacebase64, pimagebase64, pface);
                        }
                        else
                        {
                            err = zx_hub_update_face_features(gppcs_base_param->hub_info.account_id,
                                                              gppcs_base_param->hub_info.hub_sn,
                                                              pfacebase64, pimagebase64, pface);
                        }
					#endif
                        //dzlog_info("pfacebase64: %s", pfacebase64);
                        if(pfacebase64)
                        {
							free(pfacebase64);
							pfacebase64 = NULL;
                        }

						if(pimagebase64)
						{
							free(pimagebase64);
							pimagebase64 = NULL;
						}
                        
					#if 0
                        if (err.code == 0 && pface->face_id > 0)
                        {
                            dzlog_info("get faceID: %d", pface->face_id);
                            save_face_feature_to_file();
                        }
                        else
                        {
                            ret = err.code;
                        }
					#endif
					
                    } 
                    else
                    {
                        ret = ERROR_NOT_FACE;
                    }
                }
			#endif

                send_ai_exec_result:
                if (image_param)
                {
                    free(image_param);
					image_param = NULL;
                }
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }

			case APP_CMD_DEL_USER_PHOTO:               //1232按USER_ID删除AI用户的头像
			case APP_CMD_DEL_FACE_PHOTO:             //1234按FACE_ID删除AI用户的头像
            {
                PARAM_ONE_INT_SET set_param;
                param_len = sizeof(PARAM_ONE_INT_SET);
                memset(&set_param, 0, param_len);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&set_param, &param_len, READ_TIME_OUT);

                dzlog_info("%s , del user_id:%d", get_command_str_info(comm_head.command_id), set_param.value);
                if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else
                {
                    zx_Error err = zx_hub_delete_faces_features(gppcs_base_param->hub_info.account_id,
                                                                gppcs_base_param->hub_info.hub_sn, set_param.value);
                    if (err.code == 0)
                    {
                        del_face_feature_by_userid(set_param.value);
                    }
                    else
                    {
                        ret = err.code;
                    }
                }

                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }
#endif
            case APP_CMD_SET_PRI_ACTION:              //1233 PRI触发后的行为
            {
                PARAM_TWO_INT_SET set_param;
                param_len = sizeof(PARAM_TWO_INT_SET);
                memset(&set_param, 0, param_len);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&set_param, &param_len, READ_TIME_OUT);

                dzlog_info("%s channel[%d], PRI action:%d ", get_command_str_info(comm_head.command_id), set_param.value, set_param.value1);
                channel_id = set_param.value;
                if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else
                {
                    char dev_sn[SHORT_STR_LEN] = {0};
					
                    ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

					//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
					
                    if (ret == 0)
					//if (ret > 0)
                    {
                        char param_str[4] = {0};
                        sprintf(param_str, "%d", set_param.value1);

						dzlog_info("dev_sn = %s",dev_sn);
						
                        zx_Error err = zx_upload_devs_params(set_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_SET_PRI_ACTION, param_str);
                        //设置PRI触发后的行为(手动)与 APP_CMD_SET_ARMING_SCHEDULE(自动)互斥
                        err = zx_hub_edit_devs_strinfo_by_paramname(dev_sn, gppcs_base_param->hub_info.hub_sn, set_param.account, "schedule", "");
                        ret = err.code;
                        if (ret == 0)
                        {
                            zx_clear_dev_schedule_by_channel(channel_id);
                            ret = zx_set_dev_pri_action_by_channel(channel_id, set_param.value1);
                            write_config_param(SET_DEV_PARAM);
                        }
                    }                    
                }
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }

		#if 0
            case APP_CMD_SET_AI_SWITCH:              //1236设置是否打开AI检测
            {
                PARAM_TWO_INT_SET set_param;
                param_len = sizeof(PARAM_TWO_INT_SET);
                memset(&set_param, 0, param_len);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (char *)&set_param, &param_len, READ_TIME_OUT);

                dzlog_info("%s channel[%d], AI status:%d ", get_command_str_info(comm_head.command_id), set_param.value, set_param.value1);
                channel_id = set_param.value;
                if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else
                {
                    zx_Error err;
                    char param_str[4] = {0};
                    sprintf(param_str, "%d", set_param.value1);
                    if (channel_id < MAX_CAMERA_NUM)
                    {
                        char dev_sn[SHORT_STR_LEN] = {0};
						
                       // ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);

						ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
					   
                        //if (ret == 0)
						if (ret > 0)
                        {
                            err = zx_upload_devs_params(set_param.account, gppcs_base_param->hub_info.hub_sn,
                                                        dev_sn, APP_CMD_SET_AI_SWITCH, param_str);
                            ret = err.code;
                            if (ret == 0)
                            {
                                ret = zx_set_dev_ai_by_channel(channel_id, set_param.value1);
                            }
                        }
                    }
                    else
                    {
                        int i;
                        err = zx_upload_hub_params(set_param.account, gppcs_base_param->hub_info.hub_sn, APP_CMD_SET_AI_SWITCH, param_str);
                        ret = err.code;
                        if (ret == 0)
                        {
                            for (i=0; i< MAX_CAMERA_NUM; i++)
                            {
                                zx_set_dev_ai_by_channel(i, set_param.value1);
                            }
                        }
                    }
                }
                if (ret == 0)
                {
                    write_config_param(SET_DEV_PARAM);
                }
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }
		#endif

			case APP_CMD_SET_DEVS_NAME:               //1217设置设备名称
			{
				PARAM_SET_PARAM set_param;
				param_len = sizeof(PARAM_SET_PARAM);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
				channel_id = set_param.channel;
				dzlog_info("%s dev_name[%s] ", get_command_str_info(comm_head.command_id), set_param.value);
				if (strlen(set_param.value) <= 0 || strlen(set_param.value) > SHORT_STR_LEN)
					ret = ERROR_INVALID_PARAM_LEN;
				else if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else
				{
					ret = zx_set_dev_name_by_channel(channel_id, set_param.value);
					if (ret == 0)
					{
						char dev_sn[DEVICE_SN_LEN+1] = {0};
						ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);
						
						//ret = zx_hisi_get_device_sn(dev_sn,HISI_DEV_SN_LEN);
						
						if (ret == 0)
						//if (ret > 0)
						{
							dzlog_info("hub_sn[%s] dev_sn[%s]......", gppcs_base_param->hub_info.hub_sn,  dev_sn);
							//zx_Error err = zx_hub_edit_devs_name(dev_sn, gppcs_base_param->hub_info.hub_sn, set_param.value, set_param.account);

							memset(gppcs_base_param->hub_info.hub_name, 0, sizeof(gppcs_base_param->hub_info.hub_name));
							memset(gppcs_base_param->dev_param[0].dev_name, 0, sizeof(gppcs_base_param->dev_param[0].dev_name));
							
							memcpy(gppcs_base_param->dev_param[0].dev_name,set_param.value,strlen(set_param.value));
							memcpy(gppcs_base_param->hub_info.hub_name,set_param.value,strlen(set_param.value));
							
							zx_Error err = zx_hub_edit_devs_strinfo_by_paramname(dev_sn, gppcs_base_param->hub_info.hub_sn, set_param.account, 
                     															"device_name", set_param.value);
							err = zx_hub_update_info_by_infoname(gppcs_base_param->hub_info.hub_sn, set_param.account, "station_name", set_param.value);
							
							ret = err.code;
							if (ret == 0)
								write_config_param(SET_DEV_NAME);
						}
					}
				}
				send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}	

			case APP_CMD_SET_DEV_STORAGE_TYPE:         //1228设置单个设备的存储类型
			{
				PARAM_SET_PARAM set_param;
				param_len = sizeof(PARAM_SET_PARAM);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
				channel_id = set_param.channel;
				int storage_type = set_param.ivalue;

				dzlog_info("%s channel_id[%d] storage=%d......", get_command_str_info(comm_head.command_id), channel_id, storage_type);
				if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (storage_type > LOACL_AND_CLOUD)
					ret = ERROR_INVALID_PARAM;
				else
				{
					time_t cur_time, set_time;
					struct tm *ptm = NULL;

					cur_time = time(NULL);
					ptm = localtime(&cur_time);
					if (set_param.value[0] < 18)
					{
						ret = ERROR_INVALID_PARAM;
					}
					ptm->tm_year = set_param.value[0] + (2000 - 1900);// 从1900年算起至今的年数
					if (set_param.value[1] > 12 || set_param.value[1] < 1)
					{
						ret = ERROR_INVALID_PARAM;
					}
					ptm->tm_mon = set_param.value[1] - 1; // 从一月算起，范围从0-11
					if (set_param.value[2] > 31 || set_param.value[2] < 1)
					{
						ret = ERROR_INVALID_PARAM;
					}
					ptm->tm_mday = set_param.value[2];

					ptm->tm_hour = 23;
					ptm->tm_min = 59;
					ptm->tm_sec = 59;
                    if (ret == 0)
                    {
	                    set_time = mktime(ptm);
						if (set_time <= cur_time)
						{
							ret = ERROR_INVALID_PARAM;
						}

						if (ret == 0)
						{
							ret = zx_set_dev_storagetype_by_channel(channel_id, storage_type, set_time);
						}
                    }
					if (ret == 0)
					{
						char dev_sn[SHORT_STR_LEN] = {0};
						ret = zx_get_dev_sn_by_channel(channel_id, dev_sn);
						if (ret == 0)
						{
							char param_str[4] = {0};
							sprintf(param_str, "%d", storage_type);
							zx_Error err = zx_upload_devs_params(set_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_DEV_LED_SWITCH, param_str);
							ret = err.code;
							if (ret == 0)
							{
								write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}
                send_head->param_len = sizeof(EXEC_RESULT);
				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
				break;
			}

			case APP_CMD_GET_DEVS_NAME:               //1129获取设备名称
			{
				//PARAM_ONE_INT *one_int_param = &comm_data.param_body.one_int_param; 
				//one_int_param->value = channel;
				//zx_p2p_send_data(session_id, (void*)&comm_data, sizeof(ZX_COMM_HEAD) + sizeof(PARAM_ONE_INT));	
				//comm_read_data = zx_p2p_get_exec_result(session_id, command_type);
				//memcpy((char *)value2, comm_read_data->param_body.dev_name.value, strlen(comm_read_data->param_body.dev_name.value));
				break;
			}

            case APP_CMD_SDINFO:                   //1102获取SD卡信息
            {
                send_head->param_len = sizeof(PARAM_TWO_INT);
                send_data.param_body.two_int_param.value1 = get_system_tf_free(&send_data.param_body.two_int_param.value);
                dzlog_info("T card info: total %dMB, free: %dMB",send_data.param_body.two_int_param.value, send_data.param_body.two_int_param.value1);
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }
            case APP_CMD_GET_HUB_LOG:
            {
                PARAM_SET_PARAM set_param;
                param_len = sizeof(PARAM_SET_PARAM);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);
                channel_id = set_param.channel;
                dzlog_info("%s key_prefix:%s ", get_command_str_info(comm_head.command_id), set_param.value);
                if (strcmp(gppcs_base_param->hub_info.account_id, set_param.account) != 0)
                {
                    ret = ERROR_INVALID_ACCOUNT;
                }
                else
                {
                    memcpy(log_key_prefix, set_param.value, NORMAL_STR_LEN-1);
                    switch(set_param.ivalue) // 错误码
                    {
                        case 1:
                        {
                            #if RUN_AI_MODULE
                            ai_play_wav(0, "/etc_ro/add_HB_fail.wav");
                            #endif
                        }
                        break;

                        default:
                            break;
                    }
					dzlog_info("APP_upload");
                    upload_log_param(LOG_NORMAL, FLOODLIGHT, gppcs_base_param->hub_info.hub_sn, "Error", "Camera", log_key_prefix, "APP_upload");
                    ret = 0;
                }

                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
                break;
            }
            
			case APP_CMD_GET_EXCEPTION_LOG:           //1124获取异常日志  主动上报消息
			case APP_CMD_UPDATE:                      //1042版本更新   主动上报给APP P2P通道4
				break;

			//case APP_CMD_DEVS_BIND_NOTIFY:         //1039设备绑定通知  P2P通道4用于基站消息上报
			//case APP_CMD_CHANGE_PWD:               //1029修改管理员密码
			//case APP_CMD_CHANGE_WIFI_PWD:          //1030修改wifi密码
			//case APP_CMD_WIFI_CONFIG:				 //1031切换上级路由器
			//case APP_CMD_RECORDDATE_SEARCH: 		 //1040搜索存在录像的日期 从后台获取
			//case APP_CMD_RECORDLIST_SEARCH:		 //1041搜索指定日期的录像 
			//case APP_CMD_GATEWAYINFO:			     //1100获取基站信息  =1100  从后台获取
			//case APP_CMD_CAMERA_INFO:				 //1103获取摄像机信息 从后台获取
			//case APP_CMD_GET_RECORD_TIME:			 //1104获取录像时长 不再使用，在打开回放的文件时返回文件相关信息
			//case APP_CMD_GET_ADMIN_PWD:            //1122获取管理员密码
			//case APP_CMD_GET_WIFI_PWD:             //1123获取wifi密码
			//case APP_CMD_SNAPSHOT:				 //1027抓图  在APP端实现  
			//case APP_CMD_RECORD_IMG:				 //1120获取录像缩略图 不适用 录像历史记录中存储首帧H264视频，从后台获取
			//case APP_CMD_RECORD_IMG_STOP:			 //1121停止获取缩略图
			//case APP_CMD_GET_ARMING_INFO:			 //1107获取布防撤防配置信息  从后台获取
			//case APP_CMD_GET_AUDDEC_INFO:          //1109获取音频侦测参数 从后台获取
			//case APP_CMD_GET_PIRINFO:              //1115获取PIR配置参数 从后台获取
			//case APP_CMD_GET_NEWVESION:			 //1125获取新版本
			//case APP_CMD_TIME_SYCN:			     //1032时间同步
			//case APP_CMD_GET_HUB_TONE_INFO:        //1126获取基站提示音配置
			//case APP_CMD_GET_DEV_TONE_INFO:        //1127获取设备提示音配置
            case APP_CMD_SET_TONE_FILE:              //1201设置基站提示音
            {
                PARAM_TWO_INT set_param;
                param_len = sizeof(PARAM_TWO_INT);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);                
                dzlog_info("%s tone type=%d, volume=%d", get_command_str_info(comm_head.command_id), set_param.value, set_param.value1);
                #if RUN_AI_MODULE
                switch(set_param.value)
                {
                    case 1:
                    {
                        ai_play_wav(set_param.value1, "/etc_ro/alarmtone1.wav");
                    }
                    break;

                    default:
                    {
                        ai_play_wav(set_param.value1, "/etc_ro/alarmtone1.wav");
                    }
                    break;
                }
                #endif
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
            }
            break;

            case APP_CMD_SET_DEVS_TONE_FILE:       //1202设置设备提示音
            {
                PARAM_TWO_INT set_param;
                param_len = sizeof(PARAM_TWO_INT);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&set_param, &param_len, READ_TIME_OUT);                
                dzlog_info("%s ,chanel=%d, tone type=%d", get_command_str_info(comm_head.command_id), set_param.value, set_param.value1);
#if 0
                zx_send_command(COMMON_TYPE_PLAY_ALARMSOUND, (char *)&set_param.value1, set_param.value);            
#endif
                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ret;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len); 
            }
            break;
            case APP_CMD_DOWNLOAD_CANCEL:
            {
                PARAM_ONE_INT one_int_param;
                param_len = sizeof(PARAM_ONE_INT);
                ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&one_int_param, &param_len, READ_TIME_OUT);

                h264_download = 0; // 取消,退出下载线程

                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = 0;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
            }
            break;

			case APP_CMD_SET_FLOODLIGHT_LED_SWTICH:					//打开或者关闭floodlight灯
			{
				dzlog_info("set floodlight led switch...");
				
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d ......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					
					if (param_int == SWITCH_OPEN)
					{

						ret = zx_hisi_flood_light_on();		//打开floodlight灯

						hisi_cam_data->floodlight_last_tigger = MANUAL_CONDITION;		//手动触发

						dzlog_info("set floodlight on OK.");
					
					}
					else if (param_int == SWITCH_CLOSE)
					{

						ret = zx_hisi_flood_light_off();		//关闭floodlight灯

						hisi_cam_data->floodlight_last_tigger = INIT_CONDITION;		//恢复初始状态

						dzlog_info("set floodlight off OK.");
					
					}					
					
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_SET_FLOODLIGHT_LED_SWTICH, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);	//获取sn
							
							if (ret == 0)
							//if (ret > 0)
							{
								char param_str[4] = {0};
								
								sprintf(param_str, "%d", param_int);

								dzlog_info("dev_sn = %s",dev_sn);
								
							#if 0
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_DEV_LED_SWITCH, param_str);
							#endif
							
								zx_Error err = zx_upload_devs_params(two_int_param.account, dev_sn, dev_sn, APP_CMD_SET_FLOODLIGHT_LED_SWTICH, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);				
				break;
			}

			case APP_CMD_GET_FLOODLIGHT_WIFI_LIST:					//获取floodlight的wifi列表
			{
				dzlog_info("get floodlight wifi list data...");
				
				PARAM_TWO_INT_SET two_int_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_int_param, &param_len, READ_TIME_OUT);
				channel_id = two_int_param.value;
				int param_int = two_int_param.value1;
				send_head->param_len = sizeof(EXEC_RESULT);
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d ......", get_command_str_info(comm_head.command_id), channel_id,  two_int_param.account, param_int);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_int_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					
					if(param_int > 0)
					{
						dzlog_info("get wifi send app data...");
						ret = zx_hisi_wifi_list_send_app_data(send_data.param_body.floodlight_wifi_list.wifi_data,send_data.param_body.floodlight_wifi_list.data_len);
					}
					
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_GET_FLOODLIGHT_WIFI_LIST, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);	//获取sn
							
							if (ret == 0)
							//if (ret > 0)
							{
								char param_str[4] = {0};
								sprintf(param_str, "%d", param_int);
								
								dzlog_info("dev_sn = %s",dev_sn);
							#if 0
								zx_Error err = zx_upload_devs_params(two_int_param.account, gppcs_base_param->hub_info.hub_sn, dev_sn, APP_CMD_DEV_LED_SWITCH, param_str);
							#endif
							
								zx_Error err = zx_upload_devs_params(two_int_param.account, dev_sn, dev_sn, APP_CMD_GET_FLOODLIGHT_WIFI_LIST, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				dzlog_info("send app data ==== 【%s】",send_data.param_body.floodlight_wifi_list.wifi_data);
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);		//发送wifi列表		
				break;
			}

			case APP_CMD_SET_FLOODLIGHT_wifi_INFO:
			{
				dzlog_info("set floodlight wifi list data...");
				
				PARAM_SET_PARAM two_param; 
				param_len = sizeof(PARAM_TWO_INT_SET);
				ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&two_param, &param_len, READ_TIME_OUT);

				dzlog_info("recv data : %s",two_param.value);		//打印接收到的数据
				
				send_head->param_len = sizeof(EXEC_RESULT);

				int param_int = two_param.ivalue;
				
				dzlog_info("%s channel_id[%d] account[%s] switch=%d ......", get_command_str_info(comm_head.command_id), channel_id,  two_param.account, param_int);
				
				if (strcmp(gppcs_base_param->hub_info.account_id, two_param.account) != 0)
					ret = ERROR_INVALID_ACCOUNT;
				else if (param_int != SWITCH_OPEN && param_int != SWITCH_CLOSE)
					ret = ERROR_INVALID_PARAM;
				else
				{
					
					if(param_int > 0)
					{
						dzlog_info("get wifi  data...【%s】",two_param.value);
						ret = zx_hisi_parsing_data_connect_network(two_param.value);

						if(ret != 0)
						{
							ret = zx_hisi_get_flash_wifi_data_connect_network();
						}
					}
					
					if (ret == 0)
					{
						ret = zx_set_dev_status_by_channel_type(channel_id, APP_CMD_GET_FLOODLIGHT_WIFI_LIST, param_int);
						if (ret == 0)
						{
							char dev_sn[SHORT_STR_LEN] = {0};
							ret = zx_get_dev_sn_by_channel(channel_id, &dev_sn);

							//ret = zx_hisi_get_device_sn(dev_sn,DEVICE_SN_LEN);	//获取sn
							
							if (ret == 0)
							//if (ret > 0)
							{
								char param_str[4] = {0};
								sprintf(param_str, "%d", param_int);
								dzlog_info("dev_sn = %s",dev_sn);
							
								zx_Error err = zx_upload_devs_params(two_param.account, dev_sn, dev_sn, APP_CMD_GET_FLOODLIGHT_WIFI_LIST, param_str);
								ret = err.code;
								if (ret == 0)
									write_config_param(SET_DEV_PARAM);
							}
						}
					}
				}

				send_data.param_body.result_info.error_code = ret;
				zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);		//发送wifi列表		
				break;
			}

            default:
            {
                param_len = comm_head.param_len;
                while (param_len)
                {
                    if (param_len < sizeof(PARAM_SCHEDULED))
                    {
                        ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&send_data.param_body.scheduled, &param_len, READ_TIME_OUT);
                    }
                    else
                    {
                        ret = PPCS_Read(session_id, P2P_COMMAND_CHANNEL, (CHAR*)&send_data.param_body.scheduled, sizeof(PARAM_SCHEDULED), READ_TIME_OUT);
                        param_len -= sizeof(PARAM_SCHEDULED);
                    }
                }

                send_head->param_len = sizeof(EXEC_RESULT);
                send_data.param_body.result_info.error_code = ERROR_INVALID_COMMAND;
                zx_p2p_send_data(session_id, (void*)&send_data, COMM_HEARD_LEN + send_head->param_len);
            }
            break;
        }
    }

exit:
	//PPCS_Close(session_id);
	//dzlog_info("PPCS_Close result=%d %s", ret, get_p2p_err_info(ret));
	zx_clear_thread_info_by_sessionid(session_id); 
	zx_clear_p2p_connect_info(session_id);
	dzlog_info("********session_id:%d, exit, %s.....", session_id, get_p2p_err_info(ret));
	return 0;
}

#define SAVE_APP_AUDIO_DATA 0
#define SAVE_QUEUE_DATA     0

#if SAVE_APP_AUDIO_DATA		
FILE *fp_audio_app = NULL;
#define AUDIO_APP_FILE_NAME "/mnt/sdcard/appsend.pcm"
#endif

#if SAVE_QUEUE_DATA		
FILE *fp_video_queue = NULL;
#define VIDEO_QUEUE_FILE_NAME "/mnt/sdcard/queue_out.h264"
#endif


void * zx_p2p_media_read(void *argv)
{
	int session_id = *(int *)argv; 
	ZX_COMM_HEAD comm_head;
	int ret = -1;
	int head_len = COMM_HEARD_LEN;
	int param_len = 0;
    int find_head_tag = 0;
	dzlog_info("start session_id = %d, PID=%d......", session_id, getpid());
    if (session_id < 0)
    {
        return NULL;
    }
#if SAVE_APP_AUDIO_DATA		
	if(fp_audio_app == NULL) 
	{
		fp_audio_app = fopen(AUDIO_APP_FILE_NAME, "wb");
		if(fp_audio_app == NULL)
		{
			dzlog_error("open file %s failed", AUDIO_APP_FILE_NAME);
		}	
	}				
#endif	
	memset(&comm_head, 0 , COMM_HEARD_LEN);
	//int iframe = 0;
	//int iframe_size = 0;
	AUDIO_FRAME audio_frame;
    while(grunning)  
    {  
        memset((char *)&comm_head, 0 , COMM_HEARD_LEN);
        head_len = 4;
        if (find_head_tag)
        {
            ret = PPCS_Read(session_id, P2P_MEDIA_CHANNEL, (CHAR*)&comm_head.head_tag, &head_len, 1000);
        }
        else
        {
            ret = PPCS_Read(session_id, P2P_MEDIA_CHANNEL, (CHAR*)&comm_head.head_tag, &head_len, 0xFFFFFFFF);
        }
        switch (ret)
        {
            case ERROR_PPCS_TIME_OUT:
                dzlog_info("time_out.....");
                find_head_tag = 0;
                continue;
            case ERROR_PPCS_INVALID_PARAMETER:
            case ERROR_PPCS_INVALID_SESSION_HANDLE:
            case ERROR_PPCS_SESSION_CLOSED_TIMEOUT:
            case ERROR_PPCS_SESSION_CLOSED_REMOTE:
            case ERROR_PPCS_SESSION_CLOSED_CALLED:
                goto exit;
            default:
                break;
        }

		if (comm_head.head_tag == PAG_HEARD_TAG)		//如果包头不对，就要找包头的
		{
            find_head_tag = 0;
            head_len = COMM_HEARD_LEN - 4;
            PPCS_Read(session_id, P2P_MEDIA_CHANNEL, (CHAR*)&comm_head.command_id, &head_len, READ_TIME_OUT);
			param_len = comm_head.param_len;
			//iframe_size = param_len;
			//dzlog_info("audio size=%d ......", param_len);
			if (comm_head.command_id == APP_CMD_AUDIO_FRAME && param_len < sizeof(AUDIO_FRAME))
			{
				//读信息
				ret = PPCS_Read(session_id, P2P_MEDIA_CHANNEL, (CHAR*)&audio_frame, &param_len, READ_TIME_OUT);
				//dzlog_info("frame_size=%d......", audio_frame.frame_size);

#if SAVE_APP_AUDIO_DATA		
				if(fp_audio_app) 
				{
					fwrite(audio_frame.buf, 1, audio_frame.frame_size, fp_audio_app);	
				}	
#endif	 

				ret = hal_audio_out(audio_frame.buf,audio_frame.frame_size);		//播放声音

				if(ret != 0)
				{
					dzlog_error("【hisi audio out error : %d】",ret);
					break;
				}

			}
		}
        else if (find_head_tag == 0)
        {
            dzlog_warn("media_read, head_tag=0x%x......", comm_head.head_tag);
            find_head_tag = 1;  // 开始找head_tag
        }
    } 
exit:
	//PPCS_Close(session_id);
	zx_clear_thread_info_by_sessionid(session_id); 
	zx_clear_p2p_connect_info(session_id);
#if SAVE_APP_AUDIO_DATA		
	if(fp_audio_app) 
	{
		fclose(fp_audio_app);
		fp_audio_app = NULL;	
	}				
#endif	
	dzlog_info("******** end......");
	return 0;
}


int zx_maxint(int a, int b)
{
	return (a>b) ? a : b;
}


void * zx_p2p_media_write(void *argv)
{
	int session_id = *(int *)argv;
	int write_size = 0;
	int re_write_count = 0;
	int ret = -1;	 
	QUEUE * queue = NULL;
	QUEUE * audio_queue = NULL;
  
#if SAVE_QUEUE_DATA		
	if(fp_video_queue == NULL) 
	{
		fp_video_queue = fopen(VIDEO_QUEUE_FILE_NAME, "wb");
		if(fp_video_queue == NULL)
		{
			dzlog_error("open file %s failed", VIDEO_QUEUE_FILE_NAME);
		}	
	}	

#endif
	
#if 0
	//获取p2p视频队列
	queue = (QUEUE *)zx_get_p2p_queue_by_session(session_id, MEDIA_VIDEO);

	//获取p2p音频队列
	audio_queue = (QUEUE *)zx_get_p2p_queue_by_session(session_id, MEDIA_AUDIO);
	
	dzlog_info("start[%d] queue=0x%X audio_queue=0x%X......", session_id,  queue, audio_queue);	
	
    while (grunning)  
    {  
//TRY_AGAIN
		//检查buffer数据大小
		ret = PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &write_size, NULL); 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			if (write_size > MAX_P2P_BUF_SIZE)	//判断写入数据大小和队列的数据大小
			{
				usleep(20000);				
				//goto TRY_AGAIN;					
			}
		}
		else
		{
			dzlog_info("PPCS_Check_Buffer=%d %s", ret, get_p2p_err_info(ret));	
			break;
		}

		if (queue)	
		{
			if (query_queue(queue->pNextQueue, &queue, ADDTOQUEUE, MAXVIDEOQUEUE)) 
			{
#if SAVE_QUEUE_DATA		
				if(fp_video_queue) 
				{
					fwrite(queue->pFrameBuf, 1, queue->frame_size, fp_video_queue);	
				}				
#endif			//写数据
				ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, queue->pFrameBuf, queue->frame_size);				
				queue->frame_size = 0;
				if (ret < ERROR_PPCS_SUCCESSFUL)
				{
					dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
					break;
				}
				queue->nUseFlag = NOTUSE;
			}
		}
#if 1
		if (audio_queue)	
		{
			while (query_queue(audio_queue->pNextQueue, &audio_queue, ADDTOQUEUE, MAXAUDIOQUEUE)) 
			{
				//写数据
				ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, audio_queue->pFrameBuf, audio_queue->frame_size);
				//dzlog_info("[%s]sendvideo: size = %d ", queue->frame_size);
				
				audio_queue->frame_size = 0;
				if (ret < ERROR_PPCS_SUCCESSFUL)
				{
					dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
					break;
				}
				audio_queue->nUseFlag = NOTUSE;
			}
		}	
#endif	
		usleep(20000);	
	} 
#else
	fd_set rfds;
	int *ivideo_fdp = NULL, *iaudio_fdp = NULL;
    int imax_fdp = -1;
    int send_frame_sum = 0;
	time_t now_time, run_time;
	struct timeval tv; 
	int frame_rate = 0;

	iaudio_fdp = zx_get_p2p_pipe_by_session(session_id, AUDIO_PIPE);
	ivideo_fdp = zx_get_p2p_pipe_by_session(session_id, VIDEO_PIPE);
    if (iaudio_fdp == NULL || ivideo_fdp == NULL)
    {
        goto exit; //清除线程信息
    }
	imax_fdp = zx_maxint(iaudio_fdp[0], ivideo_fdp[0]);
	run_time = time(NULL);
	while (grunning)
	{
		FD_ZERO(&rfds);
		FD_SET(iaudio_fdp[0], &rfds);
		FD_SET(ivideo_fdp[0], &rfds);

		tv.tv_sec = 0;
		tv.tv_usec = 100*1000;  // 检测p2P断线退出

		ret = PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &write_size, NULL); 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			if (write_size)
			{
				now_time = time(NULL);
				if (now_time > run_time+1)
				{

					dzlog_info("【send_frame_sum = %d , write_size = %d frame_rate = %d】",send_frame_sum,write_size,frame_rate);

				#if 0
					dzlog_info("P2P upload speed: %dKB/s, buffer: %dKB, frame_rate: %dF/s",
							    (send_frame_sum - write_size)/2048, write_size/2048, frame_rate/2);
				#endif

					dzlog_info("【frame_rate: %dF/s, buffer: %dKB, upload speed: %dKB/s】",
				            					frame_rate/2, write_size/1024, (send_frame_sum - write_size)/2048);
					
					send_frame_sum = write_size;
					run_time = now_time;
					frame_rate = 0;

					if (write_size > MAX_P2P_BUF_SIZE)
					{
						dzlog_info("P2P Buffer > 512KB");
						//usleep(20*000);	// 在这里调camera, 1080p > 720P
					}
				}
			}
		}
		else
		{
			dzlog_info("PPCS_Check_Buffer=%d %s", ret, get_p2p_err_info(ret));
			goto exit;
		}
		//dzlog_info("imax_fdp=%d iaudio_fdp[0]=%d ivideo_fdp[0]=%d......", imax_fdp, iaudio_fdp[0], ivideo_fdp[0]);
		switch(select(imax_fdp + 1, &rfds, NULL, NULL, &tv))
		{
			case -1:
				goto exit;

            case 0:
				//dzlog_info("time out");
				break;
 
            default: 
            {
				if(FD_ISSET(ivideo_fdp[0], &rfds)) 
				{
					FD_CLR(ivideo_fdp[0], &rfds);
					if (read(ivideo_fdp[0], &queue, sizeof(queue)) <= 0)
					{
						dzlog_info("pipe read fail ... ");	
						goto exit;
					}
					ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, queue->pFrameBuf, queue->frame_size);
					if (ret < ERROR_PPCS_SUCCESSFUL)
					{
						dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));
						goto exit; 
					}
					send_frame_sum += ret;
					frame_rate += 1;

					//dzlog_info("【***video_queue=0x%X frame_size=%d send len = %d***】", queue, queue->frame_size,ret);
#if SAVE_QUEUE_DATA
					if(fp_video_queue) 
					{
						fwrite(queue->pFrameBuf, 1, queue->frame_size, fp_video_queue);
					}
#endif
					//dzlog_info("queue=0x%X frame_size=%d......", queue, queue->frame_size);	
					queue->frame_size = 0;
					queue->nUseFlag = NOTUSE;
				}
				else if(FD_ISSET(iaudio_fdp[0], &rfds))
				{
					FD_CLR(iaudio_fdp[0], &rfds);
					if (read(iaudio_fdp[0], &audio_queue, sizeof(audio_queue)) <= 0)
					{
						dzlog_info("pipe read fail ... ");	
						goto exit;
					}
					ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, audio_queue->pFrameBuf, audio_queue->frame_size);
					//dzlog_info("[%s]send audio: size = %d ", queue->frame_size);
					if (ret < ERROR_PPCS_SUCCESSFUL)
					{
						dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
						goto exit; 
					}
					
                    send_frame_sum += ret;

					//dzlog_info("【audio_queue=0x%X frame_size=%d send len = %d......】", audio_queue, audio_queue->frame_size,ret);	
					audio_queue->frame_size = 0;
					audio_queue->nUseFlag = NOTUSE;
				}
				break;
			}
		}  
	}
	
	
#endif

exit:
	//PPCS_Close(session_id);
	zx_clear_thread_info_by_sessionid(session_id); 
	zx_clear_p2p_connect_info(session_id);
#if SAVE_QUEUE_DATA		
	if(fp_video_queue) 
	{
		fclose(fp_video_queue);
		fp_video_queue = NULL;	
	}				
#endif
	dzlog_info("******** end......");
	return 0;	
}



#if 0
void * zx_p2p_media_write(void *argv)
{
	int session_id = *(int *)argv;
	UINT32 write_size = 0;
	//int re_write_count = 0;
	int ret = -1;	 
	QUEUE * queue = NULL;
	QUEUE * audio_queue = NULL;
    if (session_id < 0)
    {
        return NULL;
    }  
#if SAVE_QUEUE_DATA		
	if(fp_video_queue == NULL) 
	{
		fp_video_queue = fopen(VIDEO_QUEUE_FILE_NAME, "wb");
		if(fp_video_queue == NULL)
		{
			dzlog_error("open file %s failed", VIDEO_QUEUE_FILE_NAME);
		}	
	}				
#endif
	
#if 0
	//获取p2p视频队列
	queue = (QUEUE *)zx_get_p2p_queue_by_session(session_id, MEDIA_VIDEO);

	//获取p2p音频队列
	audio_queue = (QUEUE *)zx_get_p2p_queue_by_session(session_id, MEDIA_AUDIO);
	
	dzlog_info("start[%d] queue=0x%X audio_queue=0x%X......", session_id,  queue, audio_queue);	
	
    while (grunning)  
    {  
//TRY_AGAIN
		//检查buffer数据大小
		ret = PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &write_size, NULL); 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			if (write_size > MAX_P2P_BUF_SIZE)	//判断写入数据大小和队列的数据大小
			{
				usleep(20000);				
				//goto TRY_AGAIN;					
			}
		}
		else
		{
			dzlog_info("PPCS_Check_Buffer=%d %s", ret, get_p2p_err_info(ret));	
			break;
		}

		if (queue)	
		{
			if (query_queue(queue->pNextQueue, &queue, ADDTOQUEUE, MAXVIDEOQUEUE)) 
			{
#if SAVE_QUEUE_DATA		
				if(fp_video_queue) 
				{
					fwrite(queue->pFrameBuf, 1, queue->frame_size, fp_video_queue);	
				}				
#endif			//写数据
				ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, queue->pFrameBuf, queue->frame_size);				
				queue->frame_size = 0;
				if (ret < ERROR_PPCS_SUCCESSFUL)
				{
					dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
					break;
				}
				queue->nUseFlag = NOTUSE;
			}
		}
#if 1
		if (audio_queue)	
		{
			while (query_queue(audio_queue->pNextQueue, &audio_queue, ADDTOQUEUE, MAXAUDIOQUEUE)) 
			{
				//写数据
				ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, audio_queue->pFrameBuf, audio_queue->frame_size);
				//dzlog_info("[%s]sendvideo: size = %d ", queue->frame_size);
				
				audio_queue->frame_size = 0;
				if (ret < ERROR_PPCS_SUCCESSFUL)
				{
					dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
					break;
				}
				audio_queue->nUseFlag = NOTUSE;
			}
		}	
#endif	
		usleep(20000);	
	} 
#else
	fd_set rfds;
	int *ivideo_fdp = NULL, *iaudio_fdp = NULL;
    int imax_fdp = -1;
    int send_frame_sum = 0;
	time_t now_time, run_time;
	struct timeval tv; 
	int frame_rate = 0;
	ZX_COMM_HEAD *comm_head = NULL;
    VIDEO_FRAME *video = NULL;
    short ichannel_id = -1;
    unsigned int video_bitrate = VIDEO_2M;
    unsigned int bitrate_updae = 0;
    unsigned int upload_speed = 0;
    unsigned int video_second = 0;
    int i = 0;

    RSA* rsa_pubkey = NULL;
    RSA* last_rsa_pubkey = NULL;
    AES_KEY aes_kye;

    char aes_key_Plaintext[AES_BLOCK_SIZE+1];
    char aes_key_encrypt[NORMAL_STR_LEN+1];
    VIDEO_ENCRYPT *encrypt_video = malloc(sizeof(VIDEO_ENCRYPT));
    
	iaudio_fdp = zx_get_p2p_pipe_by_session(session_id, AUDIO_PIPE);
	ivideo_fdp = zx_get_p2p_pipe_by_session(session_id, VIDEO_PIPE);
    if (iaudio_fdp == NULL || ivideo_fdp == NULL || encrypt_video == NULL)
    {
        goto exit; //清除线程信息
    }
    dzlog_info("p2p_media_write thread run, session_id =%d, PID=%d", session_id, getpid());
	imax_fdp = zx_maxint(iaudio_fdp[0], ivideo_fdp[0]);
	run_time = time(NULL);
	while (grunning)
	{
		ret = PPCS_Check_Buffer(session_id, P2P_MEDIA_CHANNEL, &write_size, NULL); 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			now_time = time(NULL);
			if (now_time > (run_time+1) && write_size)  // 2s
			{
                if (send_frame_sum > write_size)
                {
                    upload_speed = (send_frame_sum - write_size)/2; // Byte
                }
                else
                {
                    upload_speed = 0;
                }
                
				dzlog_info("frame_rate: %dF/s, buffer: %dKB, upload speed: %dKB/s",
				            frame_rate/2, write_size/1024, upload_speed/1024);
				send_frame_sum = write_size;
				run_time = now_time;
				frame_rate = 0;
				if (ichannel_id >= 0)
				{
                    if (write_size)
                    {
                        //dzlog_info("P2P Buffer : %d", write_size);
                      #if 0
                        zx_send_command(COMMON_TYPE_GET_WIFISIGNAL, " ", ichannel_id);
					  #endif
					  
                    }
                    if (write_size > MAX_P2P_BUF_256K )
                    {
                        if (upload_speed)
                        {
                            video_second = write_size/upload_speed;
                            if (video_second < 4)
                            {
                                video_bitrate = 640;    //kbps = 80KB/S
                            }
                            else if (video_second < 7)
                            {
                                video_bitrate = 480;    //kbps = 60KB/S
                            }
                            else if (video_second < 10)
                            {
                                video_bitrate = 320;    //kbps = 40KB/S
                            }
                        }
                        else
                        {
                            video_bitrate = 320;    //kbps = 40KB/S
                        }
                        if (bitrate_updae != video_bitrate)
                        {
                            dzlog_info("P2P Buffer secson: %d, bitrate: %dkbps", video_second, video_bitrate);
						#if 0
                            zx_send_command(COMMON_TYPE_SET_BITRATE, (char *)&video_bitrate, ichannel_id);
						#endif

			#if 0
							ret = hal_video_set_bitrate(HISI_CH0,video_bitrate,MODE_VBR);

							if(ret != 0)
							{
								dzlog_error("【set video bitrate error...】");
								break;
							}
			#endif
                            bitrate_updae = video_bitrate;
                        }
                    }
                    else if (write_size < 100*1024) //约2秒数据
                    {
                        video_bitrate = VIDEO_2M;
                        if (upload_speed)
                        {
                            video_second = write_size/upload_speed;
                            if (video_second > 2)
                            {
                                video_bitrate = VIDEO_1_5M;
                            }
                        }
                        if (bitrate_updae != video_bitrate)
                        {
                            dzlog_info("P2P Buffer secson: %d, bitrate: %dkbps", video_second, video_bitrate);
							
						#if 0
                            zx_send_command(COMMON_TYPE_SET_BITRATE, (char *)&video_bitrate, ichannel_id);
						#endif

				#if 0
							ret = hal_video_set_bitrate(HISI_CH0,video_bitrate,MODE_VBR);

							if(ret != 0)
							{
								dzlog_error("【set video bitrate error...】");
								break;
							}
				#endif
                            bitrate_updae = video_bitrate;
                        }
                    }
				}
			}
		}
		else
		{
			dzlog_info("PPCS_Check_Buffer=%d %s", ret, get_p2p_err_info(ret));
			goto exit;
		}

		FD_ZERO(&rfds);
		FD_SET(iaudio_fdp[0], &rfds);
		FD_SET(ivideo_fdp[0], &rfds);

		tv.tv_sec = 0;
		tv.tv_usec = 100*1000;  // 检测p2P断线退出

		//dzlog_info("imax_fdp=%d iaudio_fdp[0]=%d ivideo_fdp[0]=%d......", imax_fdp, iaudio_fdp[0], ivideo_fdp[0]);
		switch(select(imax_fdp + 1, &rfds, NULL, NULL, &tv))
		{
			case -1:
				goto exit;

            case 0:
				//dzlog_info("time out");
				break;
 
            default: 
            {
				if(FD_ISSET(ivideo_fdp[0], &rfds)) 
				{
					FD_CLR(ivideo_fdp[0], &rfds);
					if (read(ivideo_fdp[0], &queue, sizeof(queue)) != 4)
					{
						dzlog_error("pipe read fail ... \n");
						goto exit;
					}
                    if (queue == NULL)
                    {
                        dzlog_error("pipe read fail ... \n");
                        goto exit;
                    }
                    comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
                    ichannel_id = comm_head->channel_id;

                    #if ZX_RSA_EN // 加密I帧
                    video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
                 
                    rsa_pubkey = zx_get_p2p_pubkey_by_session(session_id);
                    if (rsa_pubkey && (last_rsa_pubkey != rsa_pubkey))
                    {
                        // 生成key字符串
                        rand_str(aes_key_Plaintext, AES_BLOCK_SIZE);

                        last_rsa_pubkey = rsa_pubkey;
                        if (rsa_encrypt(rsa_pubkey, aes_key_Plaintext, aes_key_encrypt) == -1)
                        {
                            aes_key_Plaintext[0] = 0;
                            aes_key_encrypt[0] = 0;
                            rsa_pubkey = NULL;
                        }
                        else if (int_aes_encryptkey(aes_key_Plaintext, &aes_kye) == -1)
                        {
                            aes_key_Plaintext[0] = 0;
                            aes_key_encrypt[0] = 0;
                            rsa_pubkey = NULL; 
                        }
                    }

                    if (rsa_pubkey && video->frame_type == FRAME_TYPE_I && comm_head->sign_code == 0)
                    {
                        //一个原始的H.264 NALU 单元常由[StartCode]+[NALU Header]+[NALU Payload] 三部分组成
                        memcpy((char *)encrypt_video, (char*)video, VIDEO_HEAD_SIZE);   // 加密前的视频头部
                        memcpy(encrypt_video->buf, video->buf, video->frame_size);      // 加密前的视频
                        ret = aes_encrypt(&aes_kye, video->buf, 128, encrypt_video->buf);
                        if (ret == 128)
                        {
                            memcpy(encrypt_video->aes_key, aes_key_encrypt, NORMAL_STR_LEN); // 插入aes_key
                            encrypt_video->aes_key[NORMAL_STR_LEN] = 0;

                            #if 1
                            comm_head->sign_code = SEC_RSAKEY;
                            comm_head->param_len = (sizeof(VIDEO_ENCRYPT) - VIDEO_ENCRYPT_SIZE) + encrypt_video->frame_size;
                            //dzlog_info("AES_encrypt out param_len【%d】", comm_head->param_len);

                            PPCS_Write(session_id, P2P_MEDIA_CHANNEL, queue->pFrameBuf, COMM_HEARD_LEN);
                            PPCS_Write(session_id, P2P_MEDIA_CHANNEL, (char*)encrypt_video, comm_head->param_len);
                            #endif
                        }
                    }                    
                    #endif

                    if (comm_head->sign_code == NO_SEC_KEY)
                    {
                        if (write_size < MAX_P2P_BUF_2M ) // buf大于2M时丢P帧
                        {
                            ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, queue->pFrameBuf, queue->frame_size);
                        }
                        else
                        {
                            ret = ERROR_PPCS_SUCCESSFUL;
                        }
                        if (ret < ERROR_PPCS_SUCCESSFUL)
                        {
                            dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));
                            goto exit; 
                        }
                    }

					send_frame_sum += ret;
					frame_rate += 1;
#if SAVE_QUEUE_DATA
					if(fp_video_queue) 
					{
						fwrite(queue->pFrameBuf, 1, queue->frame_size, fp_video_queue);
					}
#endif
					//dzlog_info("queue=0x%X frame_size=%d......", queue, queue->frame_size);	
					queue->frame_size = 0;
					queue->nUseFlag = NOTUSE;
				}
				else if(FD_ISSET(iaudio_fdp[0], &rfds))
				{
					FD_CLR(iaudio_fdp[0], &rfds);
					if (read(iaudio_fdp[0], &audio_queue, sizeof(audio_queue)) != 4)
					{
						dzlog_error("pipe read fail ... \n");
						goto exit;
					}
                    if (audio_queue == NULL)
                    {
                        dzlog_error("pipe read fail ... \n");
                        goto exit;
                    }
                    if (write_size < MAX_P2P_BUF_1M ) // buf大于1M时丢声音
                    {
                        ret = PPCS_Write(session_id, P2P_MEDIA_CHANNEL, audio_queue->pFrameBuf, audio_queue->frame_size);
                    }
                    else
                    {
                        ret = ERROR_PPCS_SUCCESSFUL;
                    }
					//dzlog_info("[%s]send audio: size = %d ", queue->frame_size);
					if (ret < ERROR_PPCS_SUCCESSFUL)
					{
						dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));	
						goto exit; 
					}
                    send_frame_sum += ret;
					//dzlog_info("audio_queue=0x%X frame_size=%d......", audio_queue, audio_queue->frame_size);	
					audio_queue->frame_size = 0;
					audio_queue->nUseFlag = NOTUSE;
				}
				break;
			}
		}  
	}
	
	
#endif

exit:
    if (encrypt_video)
    {
        free(encrypt_video);
        encrypt_video = NULL;
    }
	//PPCS_Close(session_id);
	zx_clear_thread_info_by_sessionid(session_id); 
	zx_clear_p2p_connect_info(session_id);
#if SAVE_QUEUE_DATA		
	if(fp_video_queue) 
	{
		fclose(fp_video_queue);
		fp_video_queue = NULL;	
	}				
#endif
	dzlog_info("********session_id:%d, end......", session_id);
	return 0;	
}
#endif


int zx_write_notify(int channel, uint8_t *data, int data_len, int session_id)
{
	int ret = -1;
	//dzlog_info("enter session_id=%d channel=%d", session_id, channel); 
	if (session_id >= 0)
	{
		int msg_id = zx_get_msgid_by_session_type(session_id, P2P_NOTIFY_WRITE);
		//dzlog_info("enter session_id=%d msg_id=%d channel=%d", session_id, msg_id, channel);
		if (msg_id >= 0 && data)
		{
			ZX_MAG_DATA send_data; 
			memset(&send_data, 0, sizeof(ZX_MAG_DATA));
			send_data.msg_type = P2P_NOTIFY_WRITE;
			memcpy(&send_data.comm_data, data, data_len);
			if(msgsnd(msg_id, (void*)&send_data, data_len , 0) == -1)  
        	{  
         		dzlog_info("msgsnd failed");  
       		} 
			else
				ret = 0;
		}
	}
	//dzlog_info("exit......");  
	return ret;	
}


//通知线程
//static void * zx_p2p_notify_write(void *argv)		
void * zx_p2p_notify_write(void *argv)	
{
	int session_id = *(int *)argv;	
	ZX_MAG_DATA notify_data; 
	UINT32 write_size = 0;
	int ret = -1;

    if (session_id < 0)
    {
        dzlog_error("enter session_id = %d ", session_id);
        goto exit; // 清除线程信息
    }

    int msg_id = zx_get_msgid_by_session_type(session_id, P2P_NOTIFY_WRITE);    
    if (msg_id == -1)
    {
        return 0;
    }
    dzlog_info("p2p_notify thread run, session_id=%d, PID=%d", session_id, getpid());

    ZX_COMMUNICATION_PACKET *comm_data = &notify_data.comm_data;
    while (grunning)
    {
        memset(&notify_data, 0, sizeof(ZX_MAG_DATA));
        if(msgrcv(msg_id, (void*)&notify_data, sizeof(ZX_MAG_DATA), 0, 0) == -1)
        {
            dzlog_error("msgrcv failed with errno: %d", errno);
            goto exit;
        }

		ret = PPCS_Check_Buffer(session_id, P2P_NOTIFY_CHANNEL, &write_size, NULL); 
		if (ret == ERROR_PPCS_SUCCESSFUL)
		{
			if (write_size > MAX_P2P_BUF_SIZE)
			{
				usleep(20*1000);	
			}
			
			if (comm_data->msg_head.command_id == APP_CMD_DEVS_BIND_NOTIFY)	
			{
#if RUN_P2P_SERVER
                NOTIFY_DEV_INFO *dev_info = &comm_data->param_body.dev_base_info;
                dzlog_info("dev_sn=%s", dev_info->dev_sn);
				
                zx_Error err = zx_hub_bind_devs(gppcs_base_param->hub_info.hub_sn, gppcs_base_param->hub_info.hub_sn, gppcs_base_param->hub_info.hub_name, dev_info->channle_id, 
                                                FLOODLIGHT, gppcs_base_param->hub_info.account_id);
                //printf_hex((char *)notify_data, 5*COMM_HEARD_LEN);
                if (err.code == 0)
                {
                    // 通知APP
                    ret = PPCS_Write(session_id, P2P_NOTIFY_CHANNEL, (CHAR *)comm_data, comm_data->msg_head.param_len + COMM_HEARD_LEN);

                    if (dev_info->channle_id <= MAX_CAMERA_CHANNEL_ID)
                    {
						
                      #if 0
                        ai_play_wav(0, "/etc_ro/add_cam_success.wav");
                    

                        unsigned char dev_power_level = zx_sub1g_send_command(SUB1G_CMD_GET_VOLTAGE, dev_info->channle_id, 0, 0); //获取电量
                        if (dev_power_level > 0)
                        {
                            char str_value[4] = {0};
                            sprintf(str_value, "%d", dev_power_level);
                            zx_set_power_level_by_channle(dev_info->channle_id, dev_power_level);
                            err = zx_upload_devs_params(gppcs_base_param->hub_info.account_id, gppcs_base_param->hub_info.hub_sn, dev_info->dev_sn, APP_CMD_GET_BATTERY, str_value);
                        }
				
                        zx_sub1g_send_command(SUB1G_CMD_SLEEP, dev_info->channle_id, CLIENT_P2P, 0);
					#endif
					
                    }
                    else
                    {
                      #if 0
                        ai_play_wav(0, "/etc_ro/add_SS_success.wav");
                      #endif
                    }
                    err = zx_upload_devs_params(gppcs_base_param->hub_info.account_id, gppcs_base_param->hub_info.hub_sn, gppcs_base_param->hub_info.hub_sn, APP_CMD_GET_DEV_STATUS, "1");
                    
                }
                else // 绑定失败时,清除sub1G关联
                {
                    if (dev_info->channle_id <= MAX_CAMERA_CHANNEL_ID)
                    {
                      #if 0
                        dzlog_warn("DEV bind Fail");
                        ai_play_wav(0, "/etc_ro/add_cam_fail.wav");
                     
                        zx_sub1g_send_command(SUB1G_CMD_SLEEP, dev_info->channle_id, CLIENT_P2P, 0); // close camera

					 #endif
					 
                    }
                    else
                    {
                      #if 0
                        ai_play_wav(0, "/etc_ro/add_SS_fail.wav");
                      #endif
                    }

			#if 0
                    zx_sub1g_send_command(SUB1G_CMD_DISASSOC_DEV, dev_info->channle_id, 0, 0);
                    XMHAL_ClearCameraMatchInfo(RELEASE_SINGLE_CHANNEL, dev_info->channle_id);
                    dzlog_info("XMHAL_ClearCameraMatchInfo channel[%d]", dev_info->channle_id);
		
                    zx_clean_dev_linkinfo_by_channel(dev_info->channle_id);
                    upload_log_param(LOG_NORMAL, XM_CAMERA, gppcs_base_param->hub_info.hub_sn, "Error", "Camera", "", "DEV bind Fail");
			#endif
			
                }                
                write_config_param(HUB_BIND_DEV);   //更新

				//dzlog_info("sendvideo: size = %d ", queue->frame_size);
				//zx_sub1g_send_command(SUB1G_CMD_WAKEUP, dev_info->channle_id, WAKEUP_WITH_WIFI, 0);
				//ret = XMHAL_TimeSync(dev_info->channle_id);
				//dzlog_info("XMHAL_TimeSync ret = %d ", ret);
				//ret = XMHAL_GetDSPVersion(dev_info->channle_id);
				//dzlog_info("XMHAL_GetDSPVersion ret = %d ", ret);
#endif
			}	
			else
			{
				//dzlog_info("send notify command_id[%d]: %s", comm_data->msg_head.command_id, get_command_str_info(comm_data->msg_head.command_id));
				
				//写信息
				PPCS_Write(session_id, P2P_NOTIFY_CHANNEL, (CHAR *)comm_data, comm_data->msg_head.param_len + COMM_HEARD_LEN);
			}
		}
		else
		{
			dzlog_info("PPCS_Check_Buffer=%d %s", ret, get_p2p_err_info(ret));	
			break;
		}
	}
exit:
	if(msgctl(msg_id, IPC_RMID, 0) == -1)  
    {  
        dzlog_error("msgctl(IPC_RMID) failed");  
    } 
	//PPCS_Close(session_id);
	zx_clear_thread_info_by_sessionid(session_id); 
	zx_clear_p2p_connect_info(session_id);
	dzlog_info("********session_id:%d, end......",session_id);
	return 0;
}


int zx_download_data_send(char *data, UINT32 data_len, int session_id)
{
	int ret = PPCS_Write(session_id, P2P_DOWNLOAD_CHANNEL, data, data_len);
	if (ret < ERROR_PPCS_SUCCESSFUL)
	{
	   dzlog_info("PPCS_Write fail ... [%d] %s", ret, get_p2p_err_info(ret));
	}
	return ret;
}

//static void * zx_p2p_listen(void *argv)
void * zx_p2p_listen(void *argv)
{
	int result = -1;
	INT32 session_handle;
	P2P_BASE_INFO *p2p_info = argv;
	char * p2p_uid = p2p_info->p2p_uid;
	char * p2p_license = p2p_info->p2p_license;
	char * license = zx_String_Concat2(p2p_license, ":ZXCAMAA");
    dzlog_info("zx_p2p_listen, PID %d", getpid());
	while (grunning)
	{
		dzlog_info("PPCS_Listen(%s, 3600, 0, 1, %s)...", p2p_uid, license);
		session_handle = PPCS_Listen(p2p_uid, 3600, 0, 1, license);
		if (session_handle >= 0)
		{
			dzlog_info("New P2P Connected!! session_handle= %d.", session_handle);
			st_PPCS_Session Sinfo;
            result = PPCS_Check(session_handle, &Sinfo);
			if (result == ERROR_PPCS_SUCCESSFUL)
			{
				dzlog_info("Session Ready: %s", (Sinfo.bMode ==0)? "P2P":"RLY");
				//dzlog_info("Socket : %d", Sinfo.Skt);
				//dzlog_info("Remote Addr : %s:%d", inet_ntoa(Sinfo.RemoteAddr.sin_addr),ntohs(Sinfo.RemoteAddr.sin_port));
				dzlog_info("My Lan Addr : %s:%d", inet_ntoa(Sinfo.MyLocalAddr.sin_addr),ntohs(Sinfo.MyLocalAddr.sin_port));
				dzlog_info("My Wan Addr : %s:%d", inet_ntoa(Sinfo.MyWanAddr.sin_addr),ntohs(Sinfo.MyWanAddr.sin_port));
				dzlog_info("Connection time : %d second before", Sinfo.ConnectTime);
				//dzlog_info("DID : %s", Sinfo.DID);
				//dzlog_info("I am %s", (Sinfo.bCorD ==0)? "Client":"Device");
				dzlog_info("Connection mode: %s", (Sinfo.bMode ==0)? "P2P":"RLY");
				dzlog_info("End of Session info");

                zx_set_p2p_connect_info(&Sinfo, session_handle);		//创建P2P的音视频队列，后面传输音视频信息
				
                zx_create_thread(HIGH_PRIORITY, zx_p2p_command_read, &session_handle, -1, P2P_COMMAND_READ, session_handle);
                zx_create_thread(HIGH_PRIORITY, zx_p2p_media_read, &session_handle, -1, P2P_MEDIA_READ, session_handle);
                zx_create_thread(LOW_PRIORITY, zx_p2p_media_write, &session_handle, -1, P2P_MEDIA_WRITE, session_handle);
                zx_create_thread(HIGH_PRIORITY, zx_p2p_notify_write, &session_handle, -1, P2P_NOTIFY_WRITE, session_handle);
            }
            else
            {
                dzlog_error("PPCS_Check, result=%d", result);
            }
		}
		else
		{
			switch (session_handle)
			{
				case ERROR_PPCS_MAX_SESSION:
					{
						unsigned char i = 0;
                        dzlog_error("PPCS_Listen() ret= %d. [%s]", session_handle, get_p2p_err_info(session_handle));
						for (i = 0; i < MAX_CONNECT_NUM; i++)
						{
							if (gp2p_con_list[i].session_handle >= 0)
							{
                                dzlog_warn("PPCS_ForceClose(%d)", gp2p_con_list[i].session_handle);
                                result = PPCS_ForceClose(gp2p_con_list[i].session_handle);
                                dzlog_info("PPCS_ForceClose, result=%d --------->", result);
								gp2p_con_list[i].session_handle = -1; 
								gp2p_con_list[i].channel = -1;
								memset(&gp2p_con_list[i].session_info, 0, sizeof(st_PPCS_Session));	
							}
						}
					}
					break;
                case ERROR_PPCS_TIME_OUT:
                    break;
				case ERROR_PPCS_USER_LISTEN_BREAK:	
					dzlog_error("PPCS_Listen() ret= %d. [%s]", session_handle, get_p2p_err_info(session_handle));
					break;

				case ERROR_PPCS_NOT_INITIALIZED:
				case ERROR_PPCS_INVALID_PARAMETER:
				case ERROR_PPCS_INVALID_ID:
				case ERROR_PPCS_INVALID_PREFIX:
				case ERROR_PPCS_ID_OUT_OF_DATE:
				case ERROR_PPCS_UDP_PORT_BIND_FAILED:
				case ERROR_PPCS_INVALID_APILICENSE:
					_exit(EXIT_SUCCESS);
					break;
				
				default:
                    dzlog_error("PPCS_Listen() ret= %d. [%s]", session_handle, get_p2p_err_info(session_handle));
					break;
			}
		}
	}
	if (license)
	{
		free(license); 
		license = NULL;
	}
	//dzlog_info("errcode=%d info=%s", result, get_p2p_err_info(result));
	return 0;
}

int zx_init_p2p_server(P2P_CONNECT_INFO *list, HUB_BASE_PARAM *base_param, int shared, char *lan_ipaddr)
{
	int result = zx_False;	
	unsigned char i = 0;
	int ret = 0;
	//short tryCount = 0;
	
	if (list && base_param && lan_ipaddr) //判断参数
	{
		gp2p_con_list = list;
		gppcs_base_param = base_param;
		
		P2P_BASE_INFO *p2p_info = &base_param->p2p_info;
		
		for (i = 0; i < MAX_CONNECT_NUM; i++)  	//全部初始化，清零和置-1
		{
			gp2p_con_list[i].session_handle = -1; 
			gp2p_con_list[i].channel = -1;
			memset(&gp2p_con_list[i].session_info, 0, sizeof(st_PPCS_Session));	
		}				

#if 0
		ret = zx_hisi_get_flash_account_id(gppcs_base_param->hub_info.account_id,sizeof(gppcs_base_param->hub_info.account_id));

		if(ret <= 0)
		{
			dzlog_error("get flash account id error");
			goto exit;	
		}

		ret = zx_hisi_get_device_sn(gppcs_base_param->hub_info.hub_sn,DEVICE_SN_LEN);

		if(ret <= 0)
		{
			dzlog_error("get flash account id error");
			goto exit;	
		}

		dzlog_info("get flash accuont id = %s",gppcs_base_param->hub_info.account_id);
#endif

		UINT32 APIVersion = PPCS_GetAPIVersion();  //获取版本号
		
		dzlog_info("PPCS_API Version: %d.%d.%d.%d", 
				(APIVersion & 0xFF000000)>>24, (APIVersion & 0x00FF0000)>>16, 
				(APIVersion & 0x0000FF00)>>8,  (APIVersion & 0x000000FF) >> 0 );
#if 1
		result = PPCS_Initialize(p2p_info->p2p_initstr);  //ppcs初始化
		
		if (result != ERROR_PPCS_SUCCESSFUL)
		{			
			goto exit;	
		}
		
		st_PPCS_NetInfo NetInfo;
		while (grunning)
		{
			//dzlog_info("%s init_str=%s, uid=%s license=%s", "PPCS_NetworkDetect......", p2p_info.p2p_initstr, p2p_info.p2p_uid, p2p_info.p2p_license);
			result = PPCS_NetworkDetect(&NetInfo, 10000);
			if (result != ERROR_PPCS_SUCCESSFUL)
			{
				goto exit1;
			}
			//dzlog_info("%s", "-------------- NetInfo: -------------------");
			//dzlog_info("Internet Reachable     : %s", (NetInfo.bFlagInternet == 1) ? "YES":"NO");
			//dzlog_info("P2P Server IP resolved : %s", (NetInfo.bFlagHostResolved == 1) ? "YES":"NO");
			//dzlog_info("P2P Server Hello Ack   : %s", (NetInfo.bFlagServerHello == 1) ? "YES":"NO");
			switch (NetInfo.NAT_Type)
			{
				case 0:
					dzlog_info("Local NAT Type : Unknow");
					break;
				case 1:
					dzlog_info("Local NAT Type : IP-Restricted Cone");
					break;
				case 2:
					dzlog_info("Local NAT Type : Port-Restricted Cone");
					break;
				case 3:
					dzlog_info("Local NAT Type : Symmetric");
					break;
			}
			
			if (0 == NetInfo.bFlagServerHello) // && 2 > tryCount++
			{
				dzlog_info("can't connect to p2p server......");
				usleep(5000*1000);
			}
			else 
			{
				dzlog_info("My Wan IP : %s", NetInfo.MyWanIP);
				memcpy(gppcs_base_param->hub_info.hub_wlan_ip_addr, NetInfo.MyWanIP, strlen(NetInfo.MyWanIP));  //IP地址赋值
				dzlog_info("My Lan IP : %s", NetInfo.MyLanIP);
				memcpy(lan_ipaddr, NetInfo.MyLanIP, strlen(NetInfo.MyLanIP));  //IP地址赋值
				
				//更新基站信息
				zx_hub_update_info_by_infoname(gppcs_base_param->hub_info.hub_sn, gppcs_base_param->hub_info.account_id, "ip_addr", NetInfo.MyWanIP);  //更新基站信息
				break;
			}
		}
		
		dzlog_info("%s", "PPCS_Share_Bandwidth(1)");
		
		PPCS_Share_Bandwidth(shared);   //分享p2p带宽，允许中继服务器接入

		//创建监听线程
		zx_create_thread(LOW_PRIORITY, zx_p2p_listen, p2p_info, -1, P2P_LISTEN, -1); //创建监听线程
#endif		
		goto exit;
	}

exit1:
	PPCS_DeInitialize();		//去初始化

exit:
	if (result != ERROR_PPCS_SUCCESSFUL)
	{
		dzlog_error("errcode=%d info=%s", result, get_p2p_err_info(result));
	}
	else
	{
		dzlog_info("errcode=%d info=%s", result, get_p2p_err_info(result));
	}
	return result;
}


int zx_deinit_p2p_server(void)
{
	PPCS_Listen_Break();
	unsigned char i = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gp2p_con_list[i].video_queue)
		{
			if(gp2p_con_list[i].video_queue)
			{
				destroy_queue(gp2p_con_list[i].video_queue);
				gp2p_con_list[i].video_queue = NULL;
			}
			if(gp2p_con_list[i].audio_queue)
			{
				destroy_queue(gp2p_con_list[i].audio_queue);
				gp2p_con_list[i].audio_queue = NULL;
			}
			//dzlog_info("WriteSize=%d......", WriteSize);
		}
	}
	dzlog_info("【deinit P2P server end...】");
	return 0;
}


