/*============================================================================
 Name        : xm_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 Date        : 2017-11-21
 Description :
 ============================================================================*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include "Xm_lib.h"
#include "xm_interface.h"
#include "comm_protocol_define.h"
#include "ppcs_interface.h"
#include "circular_buffer.h"
#include "g711_codec.h"
#include "local_storage_interface.h"
#include "push_stream.h"
#include "sub1g_interface.h"
#include "sys_interface.h"

P2P_CONNECT_INFO *gxm_con_list = NULL;
int gready_pipe[2] = {-1};
int gcommand_pipe[2] = {-1};
int gupdate_pipe[2] = {-1};

#if GET_WIFI_SIGNAL
int gwifi_signal = -120;
#endif

//视频回调
//buff                 视频BUFF
//size                 视频数据长度
//stream_type          视频流类型
//frame_type           视频帧类型 1-I帧 0-P帧
//frame_rate           帧率
//width height         分辨率
//ntimestamp           时间戳
//channel              通道号

//QUEUE snapshot_queue;           // 因为缩略图比较大，这个定义一个queue.(1.2.9已经支持320*240)
QUEUE* psnapshot_queue = NULL;

QUEUE* xm_video_queue = NULL;     // 所有打开的camera共用一个queue, 当前约占用6.5M内存
QUEUE* xm_audio_queue = NULL;

int gcount = 0;
int gaudio_count = 0;
extern unsigned char grunning;
extern HUB_BASE_PARAM *base_param;

char gcheck_ready = 0;

#define SAVE_VIDEO_DATA  0
#define SAVE_AUDIO_DATA  0

#if SAVE_VIDEO_DATA
FILE *fp_video = NULL;
#define VIDEO_FILE_NAME "/media/mmcblk0p1/rec_video.h264"
#endif

#if SAVE_AUDIO_DATA
FILE *fp_audio = NULL;
#define AUDIO_FILE_NAME "/media/mmcblk0p1/rec_audio.pcm"
FILE *fp_dec_audio = NULL;
#define AUDIO_DEC_FILE_NAME "/media/mmcblk0p1/dec_audio.pcm"
#endif

char gdec_buf[AUDIO_FRAME_SIZE] = {0};
char genc_buf[AUDIO_FRAME_SIZE] = {0};

XM_CAMERA_INFO gCamera_info[MAX_CAMERA_NUM];

// ==============================================================================


int connect_video_server(void)
{
	int sockfd;
	struct sockaddr_in dest_addr;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
	{
		dzlog_error("create socket error");
		return -1;
	}

    //阻塞式发送
	int nSendBuf = COMM_HEARD_LEN+sizeof(VIDEO_FRAME);
	if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const char*)&nSendBuf, sizeof(int)) < 0)
	{
		dzlog_error("setsockopt error");
		close(sockfd);
		return -1;
	}

	bzero(&dest_addr,sizeof(dest_addr));
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(9000);
	inet_pton(AF_INET,IP_ADDR_REMOTE, &dest_addr.sin_addr);
	if (connect(sockfd, (struct sockaddr*)&dest_addr, sizeof(dest_addr)) != 0)
	{
		dzlog_error("connect error");
		close(sockfd);
		return -1;
	}

	dzlog_info("connect the server=%s success",IP_ADDR_REMOTE);
	return sockfd;

}

#if GET_WIFI_SIGNAL
int zx_get_wifi_signal()
{
	return gwifi_signal;
}
#endif


//int zx_video_callback(char *buff, int size, int stream_type, int frame_type, int frame_rate,
//	                  int width, int height, long long ntimestamp, int channel, long reserve)
int zx_video_callback(char *buff, int size, int stream_type, int frame_type, int frame_rate,int IR_mode,
	                  int width, int height, long long ntimestamp, int channel, long reserve)
{
#if 0
	if (gcount == 0)
	{
		dzlog_info("enter! channel = %d, size = %d, %d x %d, isIframe = %d ,frame_rate =%d",
                    channel, size, width, height, frame_type, frame_rate);
	}
#endif
	QUEUE * queue = NULL;
	//QUEUE * vqueue = NULL;
	int i = 0;
	int session_handle = -1;
	//int msg_id = -1;
	int result = -1;
	int temp_size = 0;
	int multiple = 0;
	LOCAL_FP_INFO* file_info = NULL;
	STREAM_CONNECT_INFO *stream_info = NULL;
#if 0
    if (size > VIDEO_FRAME_SIZE || frame_type == FRAME_TYPE_I)
    {
        dzlog_info("Video: channel = %d, size = %d, %d x %d, isIframe = %d, IR_mode: %d",
                    channel, size, width, height, frame_type, IR_mode);
    }
#endif

	if (buff)
	{
#if SAVE_VIDEO_DATA
		if(fp_video )
		{
			fwrite(buff, 1, size, fp_video);
		}
#endif
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			temp_size = size;
			multiple = 0;
			session_handle = gxm_con_list[i].session_handle;
			if (session_handle >= 0 ) // P2P or playback
			{
				if (gxm_con_list[i].channel == channel || reserve == TFCARD_RD_FLAG)
				{ // 回放时，channel = -1，PIR打开的数据不会从当前 session 发出去
trans_next:
					queue = (QUEUE *)gxm_con_list[i].video_queue;
					if (queue)
					{
						//dzlog_info("queue in %d......", size);
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXVIDEOQUEUE))
			            {
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
							VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_VIDEO_FRAME;

							comm_head->version = COMM_VERSION;
							comm_head->channel_id = channel;
							comm_head->sign_code = NO_SEC_KEY;
							comm_head->dev_type = XM_CAMERA;

							video->frame_rate = frame_rate;
							video->width = width;
							video->height = height;
							video->frame_type = frame_type;
							video->ntimestamp = ntimestamp;

							if (temp_size > VIDEO_FRAME_SIZE)
							{
								comm_head->param_len = sizeof(VIDEO_FRAME);
								temp_size = temp_size - VIDEO_FRAME_SIZE;
								video->frame_size = VIDEO_FRAME_SIZE;
								memcpy(video->buf, &buff[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
								multiple++;
								queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
								queue->nUseFlag = ADDTOQUEUE;
								result = write(gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
								goto trans_next;
							}
							else
							{
								video->frame_size = temp_size;
								comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
								memcpy(video->buf, &buff[VIDEO_FRAME_SIZE*multiple], temp_size);
								temp_size = 0;
							}

							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
							queue->nUseFlag = ADDTOQUEUE;
							result = write(gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
							//if (gcount == 0)
							//	dzlog_info("queue=0x%X video_size=%d ......", queue, size);

						}
						else
						{
							dzlog_error("QUEUE FULL......");
							//dzlog_info("queue out......");
						}
					}
				}
			}
		}

#if RUN_LOCAL_STORGE
		if (reserve != TFCARD_RD_FLAG)
		{
			file_info = get_local_filerecord_by_channel(channel);
			if (file_info != NULL && file_info->record_flag) // 这个channel有PIR触发
			{
				if (file_info->frame_num > 0 || frame_type == FRAME_TYPE_I)
				{// 第一帧录像要为I帧
					temp_size = size;
					multiple = 0;
                    ntimestamp = zx_LocalTime_ms(); // 相同的frame，时间不变
local_trans_next:
					if (query_queue(xm_video_queue, &queue, NOTUSE, XM_VIDEO_MAX_QUEUE))
					{
						ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
						VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
						memset(comm_head, 0, COMM_HEARD_LEN);

						comm_head->head_tag = PAG_HEARD_TAG;
						comm_head->command_id = APP_CMD_VIDEO_FRAME;
						comm_head->version = COMM_VERSION;
                        comm_head->ir_mode = IR_mode;
						comm_head->channel_id = channel;
						comm_head->sign_code = NO_SEC_KEY;
                        comm_head->dev_type = XM_CAMERA;
                        if (frame_rate) // 生成mp4文件时需要frame_rate计算时间
                        {
                            video->frame_rate = frame_rate;
                        }
                        else
                        {
                            video->frame_rate = FRAME_RATE;
                        }
						video->width = width;
						video->height = height;
						video->frame_type = frame_type;
						video->ntimestamp = ntimestamp;

						if (temp_size >= VIDEO_FRAME_SIZE)
						{
							comm_head->param_len = sizeof(VIDEO_FRAME);
							video->frame_size = VIDEO_FRAME_SIZE;
							memcpy(video->buf, &buff[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
							temp_size = temp_size - VIDEO_FRAME_SIZE;
							multiple++;

							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
							queue->nUseFlag = ADDTOQUEUE;
							result = write(file_info->storage_pipe[1], &queue, sizeof(queue));
							goto local_trans_next;
						}
						else
						{
							comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
							video->frame_size = temp_size;
							memcpy(video->buf, &buff[VIDEO_FRAME_SIZE*multiple], temp_size);
							temp_size = 0;
						}

						queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
						queue->nUseFlag = ADDTOQUEUE;
						write(file_info->storage_pipe[1], &queue, sizeof(queue));
					}
					else
					{
						dzlog_error("video QUEUE FULL......");
                        file_info->end_time = ntimestamp; //提前结束
					}
				}
			}
		}
#endif

#if RUN_PUSH_STREAM
		stream_info 		       = zx_get_stream(channel);
		if (reserve != TFCARD_RD_FLAG && stream_info)
		{
			memset(&stream_info->videoInfo,0,sizeof(VIDEO_INFO));
			stream_info->videoInfo.frame_rate   = frame_rate;
			stream_info->videoInfo.width	    = width;
			stream_info->videoInfo.height	    = height;
			stream_info->videoInfo.frame_type   = frame_type;
			stream_info->videoInfo.ntimestamp   = zx_LocalTime_ms();

			if( size > VIDEO_FRAME_SIZE )
			{
				int sendCnt 			 = size/VIDEO_FRAME_SIZE;

				for(i = 0; i < sendCnt; i ++)
				{
					stream_info->videoInfo.frame_size = VIDEO_FRAME_SIZE;
					zx_stream_send_video_frame(channel,buff + VIDEO_FRAME_SIZE*i);
				}

				stream_info->videoInfo.frame_size 	 = size - VIDEO_FRAME_SIZE*sendCnt;
				zx_stream_send_video_frame(channel, buff + VIDEO_FRAME_SIZE*sendCnt);
			}
			else
			{
				stream_info->videoInfo.frame_size 	 = size;
				zx_stream_send_video_frame(channel,buff);
			}

		}

#endif

	}

	gcount++;
	if (gcount == 100)
		gcount = 0;	
#if GET_WIFI_SIGNAL
	if (gcount == 10)
	{
		zx_send_command(COMMON_TYPE_GET_WIFISIGNAL, " ", channel);
		gcount = 0;	
	}
#endif
	return XM_SUCCESS;
}

//音频回调
//编码格式			   G711A
//buff                 音频BUFF
//size                 音频数据长度
//ntimestamp           时间戳
//channel              通道号


int zx_audio_callback(char *buff, int size, long long ntimestamp, int channel, long reserve)
{
	QUEUE * queue = NULL;
	int i = 0;
	int session_handle = -1;
	//int msg_id = -1;
	int result = -1;
	LOCAL_FP_INFO* file_info = NULL;

#if SAVE_AUDIO_DATA
	g711a_decode((unsigned char*)buff, &gdec_buf, size);
	g711a_encode(gdec_buf, (unsigned char*)&genc_buf, size*2);
	if(fp_audio)
	{
		fwrite(genc_buf, 1, size, fp_audio);
	}
	if(fp_dec_audio)
	{
		fwrite(gdec_buf, 1, size*2, fp_dec_audio);
	}
#endif
#if 0
	if (gaudio_count == 0)
		dzlog_info("Audio: channel = %d, size = %d", channel, size);
#endif
	gaudio_count++;
	if (gaudio_count == 100)
		gaudio_count = 0;

	if(buff)
	{
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			session_handle = gxm_con_list[i].session_handle;
			if (session_handle >= 0 )
			{
				if (gxm_con_list[i].channel == channel || reserve == TFCARD_RD_FLAG)
				{
					queue = (QUEUE *)gxm_con_list[i].audio_queue;
					if (queue)
					{
						//dzlog_info("queue in %d......", size);
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXAUDIOQUEUE))
			            {
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_AUDIO_FRAME;
							comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + size;
							comm_head->version = COMM_VERSION;
							comm_head->channel_id = channel;
							comm_head->sign_code = NO_SEC_KEY;
                            comm_head->dev_type = XM_CAMERA;

							AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size = size;
							audio->channel = channel;
							audio->ntimestamp = ntimestamp;
							memcpy(audio->buf, buff, size);

							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
							queue->nUseFlag = ADDTOQUEUE;
							result = write(gxm_con_list[i].audio_pipe[1], &queue, sizeof(queue));
#if 0
							XMHAL_AudioPlay(buff, size, channel);
#endif
							//dzlog_info("audio_size=%d write=%d audio_pipe=%d......", size, result, gxm_con_list[i].audio_pipe[1]);
						}
						else
						{
							dzlog_error("QUEUE FULL......");
						///dzlog_info("queue out......");
						}
					}
				}
			}
		}

#if RUN_LOCAL_STORGE
		if (reserve != TFCARD_RD_FLAG)
		{
			file_info = get_local_filerecord_by_channel(channel);
			if (file_info != NULL && file_info->record_flag && file_info->frame_num) // 这个channel有PIR触发
			{
				ntimestamp = zx_LocalTime_ms();
				if (query_queue(xm_audio_queue, &queue, NOTUSE, XM_AUDIO_MAX_QUEUE))
				{
					ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
					memset(comm_head, 0, COMM_HEARD_LEN);
					if ( size > AUDIO_FRAME_SIZE)
					{
						size = AUDIO_FRAME_SIZE;
					}
					comm_head->head_tag = PAG_HEARD_TAG;
					comm_head->command_id = APP_CMD_AUDIO_FRAME;
					comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + size;
					comm_head->version = COMM_VERSION;
					comm_head->channel_id = channel;
					comm_head->sign_code = NO_SEC_KEY;
                    comm_head->dev_type = XM_CAMERA;

					AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
					audio->frame_size = size;
					audio->channel = channel;
					audio->ntimestamp = ntimestamp;
					memcpy(audio->buf, buff, size);
					queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
					queue->nUseFlag = ADDTOQUEUE;

					write(file_info->storage_pipe[1], &queue, sizeof(queue));
				}
				else
				{
					dzlog_error("audio QUEUE FULL......");
					file_info->end_time = ntimestamp;
				}
			}
		}
#endif


#if RUN_PUSH_STREAM
		if (reserve != TFCARD_RD_FLAG)
		{
			//static int audioFrameCnt  = 0;
			STREAM_CONNECT_INFO *info = zx_get_stream(channel);
			if(info)
			{
				if(info->iControlThreadRun)
				{
					info->iAudioCallBackRunState = 1;
					QUEUE *aqueue = (QUEUE *)info->audio_queue;
					if (aqueue)
					{
						if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE)){
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf;
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag 	= PAG_HEARD_TAG;
							comm_head->command_id   = APP_CMD_AUDIO_FRAME;
							comm_head->param_len 	= sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + size;
							comm_head->version 		= COMM_VERSION;
							comm_head->channel_id 	= channel;
							comm_head->sign_code 	= NO_SEC_KEY;
                            comm_head->dev_type = XM_CAMERA;

							AUDIO_FRAME *audio 		= (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size 		= size;
							audio->channel 			= channel;
							audio->ntimestamp 		= ntimestamp;
							//audio->ntimestamp 		= audioFrameCnt*1000*1024/8000;
							audio->ntimestamp 		= zx_LocalTime_ms();

							//audioFrameCnt ++;
							memcpy(audio->buf, buff, size);

							aqueue->frame_size 		= COMM_HEARD_LEN + comm_head->param_len;
							aqueue->nUseFlag 		= ADDTOQUEUE;
							result 					= write(info->audio_pipe[1], &aqueue, sizeof(aqueue));
							//dzlog_info("audio_size=%d write=%d audio_pipe=%d......", size, result, gxm_con_list[i].audio_pipe[1]);
						}
						else
							dzlog_error("QUEUE FULL......");
					}
				}
				info->iAudioCallBackRunState = 0;
			}

		}
#endif
	}

	return XM_SUCCESS;
}

//在此函数处理消息
//msgtype              消息类型
//msgdata              消息数据
//channel              通道号
int zx_msg_callback(int msgtype, char *msgdata, int channel, long reserve)
{
	int status;							//布防撤防状态
	int doorbell_signal;               	//门铃信号强度
	XM_RECORD_INFO recordinfo;     		//快速录像

	//dzlog_info("new message, msgtype = %d", msgtype);

	switch(msgtype)
	{
		case COMMON_TYPE_KEY_DOWN:   //摄像机呼叫消息
			//播放响铃声
			//XMHAL_AudioFilePlay(AUDIO_CONFIG_SAMPLE, AUDIO_CONFIG_CHANNEL,
			//	                AUDIO_FILETYPE_OPUS, "/usr/share/sound/doorbell.opus");

#if 1
			//是否保持摄像机唤醒状态
			//1. 当前已有用户在观看视频
			//2. 需要录像或录像中
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 1;
			recordinfo.audio = 1;
			recordinfo.video = 1;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
#else
			//不需要摄像机保持唤醒状态
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 0;
			recordinfo.audio = 0;
			recordinfo.video = 0;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
			XMHAL_UserOnline(channel, 1);
#endif

			return XM_SUCCESS;
		case COMMON_TYPE_WIFI_INFO_ACK:
			return XM_SUCCESS;
		case COMMON_TYPE_TAMPER:  //防拆报警消息
#if 1
			//是否保持摄像机唤醒状态
			//1. 当前已有用户在观看视频
			//2. 需要录像或录像中
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 1;
			recordinfo.audio = 1;
			recordinfo.video = 1;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
#else
			//不需要摄像机保持唤醒状态
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 0;
			recordinfo.audio = 0;
			recordinfo.video = 0;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
			XMHAL_UserOnline(channel, 1);
#endif
			return XM_SUCCESS;
		case COMMON_TYPE_BATTERY_LEVEL:
			//电池电量消息
			{
				int battery = msgdata[0];
				dzlog_info("battery:%d",battery);
			}
			return XM_SUCCESS;
		case COMMON_TYPE_LOW_POWER:
			//低电量报警
			return XM_SUCCESS;
		case COMMON_TYPE_EXTERNAL_POWER:
			//外部电源接入
			return XM_SUCCESS;
		case COMMON_TYPE_PIR_TRIGGER:
			//红外报警
#if 1
			//是否保持摄像机唤醒状态
			//1. 当前已有用户在观看视频
			//2. 需要录像或录像中
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 1;
			recordinfo.audio = 1;
			recordinfo.video = 1;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
#else
			//不需要摄像机保持唤醒状态
			memset(&recordinfo, 0, sizeof(struct _recordinfo));
			recordinfo.type = 0;
			recordinfo.audio = 0;
			recordinfo.video = 0;
			memcpy(msgdata, &recordinfo, sizeof(struct _recordinfo));
			XMHAL_UserOnline(channel, 1);
#endif
			return XM_SUCCESS;
		case COMMON_TYPE_GET_SIGNO_ACK:
			//摄像机与网关信号强度
			memcpy(&doorbell_signal, msgdata, sizeof(int));
			dzlog_info("signal data:%d", doorbell_signal);
			break;
		case COMMON_TYPE_ARM_STATUS:
			memcpy(&status, msgdata, sizeof(int));
			dzlog_info("arming status = %d", status);
			break;
		case COMMON_TYPE_GET_UART_ACK:
			{
				XM_DSP_REPORT dsp_report;			//DSP配置命令结果回复
				memcpy(&dsp_report, msgdata, sizeof(XM_DSP_REPORT));
				//dzlog_info("type = %d, result = %d", dsp_report.type, dsp_report.result);
				if (dsp_report.type == COMMON_TYPE_GET_WIFISIGNAL_ACK)
				{
                    XM_WIFI_Info wifi_info;
                    ZX_COMMUNICATION_PACKET comm_data;
                    int i;

					//dzlog_info("channel = %d rssi=%d TxSpeed=%dMbps/s", channel, wifi_info.signal, wifi_info.TxSpeed/10);
					memcpy(&wifi_info, &msgdata[sizeof(XM_DSP_REPORT)], sizeof(XM_WIFI_Info));
					memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
					PARAM_TWO_INT *wifi_rssi_info = (PARAM_TWO_INT *)&comm_data.param_body.two_int_param;
#if GET_WIFI_SIGNAL
					gwifi_signal = wifi_info.signal;
#endif
					comm_data.msg_head.head_tag = PAG_HEARD_TAG;
					comm_data.msg_head.command_id = APP_CMD_WIFI_CONFIG;
					comm_data.msg_head.param_len = sizeof(PARAM_TWO_INT);
					comm_data.msg_head.version = COMM_VERSION;
					comm_data.msg_head.sign_code = NO_SEC_KEY;
					comm_data.msg_head.channel_id = channel;
					comm_data.msg_head.dev_type = 0x01;
					wifi_rssi_info->value = wifi_info.signal;
					wifi_rssi_info->value1 = wifi_info.TxSpeed;
                    for (i = 0; i < MAX_CONNECT_NUM; i++)
                    {
                        if (gxm_con_list[i].channel == channel && gxm_con_list[i].session_handle >= 0)
                        {
                            zx_write_notify(channel, (uint8_t *)&comm_data, COMM_HEARD_LEN + sizeof(PARAM_TWO_INT), gxm_con_list[i].session_handle);
                        }
                    }
				}
			}
			break;
		case COMMON_TYPE_WAKEUP_RESP:
			break;

		case COMMON_TYPE_SET_MIRROR:
			dzlog_info("set COMMON_TYPE_SET_MIRROR ok");
			break;

		case COMMON_TYPE_GET_VERSION_ACK:
			{
				XM_CAMERA_VERSION dsp_version;
				memcpy(&dsp_version, msgdata, sizeof(XM_CAMERA_VERSION));
				dzlog_info("channel = %d dsphver=%s dspsver=%s", channel, dsp_version.dsphardversion, dsp_version.dspsoftversion);
				if (gcommand_pipe[1] >= 0)
				{
					write(gcommand_pipe[1],  &dsp_version, sizeof(XM_CAMERA_VERSION));	//
				}

			}
			break;

		case COMMON_TYPE_GET_WIFISIGNAL_ACK:
			{

			}
			break;

		default:
			break;
	}

	return XM_SUCCESS;
}


int zx_img_callback(char *buff, int size, int channel,long long ntimestamp,long reserve)
{
    LOCAL_FP_INFO* file_info = NULL;
    QUEUE * queue = NULL;

#if 0
    FILE *fp = fopen("/media/mmcblk0p1/snapshot.jpg", "wb");
    if(fp == NULL)
    {
        dzlog_error("open file snapshot.jpg failed");
    }
    else
    {
        fwrite(buff, 1, size, fp);
        fclose(fp);
    }
#endif

    dzlog_info("get channel[%d] img finish, size=%d ", channel, size);
    if (size > VIDEO_FRAME_SIZE)
    {
        return -1;
    }

    file_info = get_local_filerecord_by_channel(channel);
    if (file_info != NULL && file_info->record_flag && buff)
    {
        if (query_queue(xm_video_queue, &queue, NOTUSE, XM_VIDEO_MAX_QUEUE))
        {
            ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
            VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
            memset(comm_head, 0, COMM_HEARD_LEN);

            comm_head->head_tag = PAG_HEARD_TAG;
            comm_head->command_id = XM_SNAPSHOT_FRAME;
            comm_head->version = COMM_VERSION;
            comm_head->channel_id = channel;
            comm_head->sign_code = NO_SEC_KEY;
            comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + size;;

            video->frame_size = size;
            video->frame_rate = 1;
            video->width = 360;
            video->height = 240;
            video->frame_type = 1;
            video->ntimestamp = ntimestamp;
            memcpy(video->buf, buff, size);

            queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
            queue->nUseFlag = ADDTOQUEUE;
            write(file_info->storage_pipe[1], &queue, sizeof(queue));
        }
    }
    return XM_SUCCESS;
}


int zx_xmsdk_ready(int channel, long reserve)
{
	//dzlog_info("channel[%d] have ready!", channel);
	int ret = XMHAL_TimeSync(channel);
	dzlog_info("channel[%d] have ready! XMHAL_TimeSync[%d]", channel, ret);
#if 1
	//char ready[2] = "1";
	int channel_id = channel;
	if (gcheck_ready == 1 && gready_pipe[1] >= 0)
	{
		write(gready_pipe[1],  &channel_id, sizeof(int));	//
		gcheck_ready = 0;
	}
#endif
	return 0;
}


int zx_log_callback(char *plogstr, int size, XM_LOG_MODULE_TYPE logtype, XM_LOG_LV_TYPE lvtype, long reserve)
{
	if (plogstr)
	{
		if (size > 1)
			plogstr[size-1] = 0x00;
		if (lvtype == INFO_LEVEL_LOG)					//普通打印信息
			dzlog_info("LOG_TYPE[%d]:%s", logtype, plogstr);
		else if (lvtype == WARRING_LEVEL_LOG)				//警告打印信息
			dzlog_warn("LOG_TYPE[%d]:%s", logtype, plogstr);
		else if (lvtype == ERROR_LEVEL_LOG)					//错误打印信息
			dzlog_error("LOG_TYPE[%d]:%s", logtype, plogstr);
	}
	return 0;
}


int zx_send_command(int command_type, char *command_data, int channel)
{
    //dzlog_info("zx_send_command: %d, chn=%d", command_type, channel);
    return XMHAL_SendCmd(command_type, command_data, channel);
}

int get_camera_clientmark(unsigned short channel)
{
    if (channel < MAX_CAMERA_NUM)
    {
        return gCamera_info[channel].clientmark;
    }
    else
    {
        return 0;
    }
}


int set_camera_clientmark(unsigned short channel, short clientmark)
{

    if (channel < MAX_CAMERA_NUM)
    {
        gCamera_info[channel].clientmark |= clientmark;
        //dzlog_info("open camera channel = %d ,clientmark =%d", channel, gCamera_info[channel].clientmark);
        return 0;
    }
    else
    {
        return -1;
    }
}

int clear_camera_clientmark(unsigned short channel, short clientmark)
{
    int i;
    int ret = 0;

    if (channel < MAX_CAMERA_NUM)
    {
        gCamera_info[channel].clientmark &= (~clientmark);
        if ((gCamera_info[channel].clientmark&0x07) != 0)
        {
            dzlog_info("clear_camera = %d, remain clientmark =0x%x(b2:PUSH,b1:PIR,b0:APP)",
                        channel, gCamera_info[channel].clientmark);
            ret = -1; // 不可以待机
        }
    }
    //--------------------------------------------------------------
    for (i = 0; i < MAX_CAMERA_NUM; i++)
    {
        if ((gCamera_info[i].clientmark & CLIENT_PIR) == CLIENT_PIR)
        {
            break;
        }
    }
    if (i >= MAX_CAMERA_NUM)    // 如果 CLIENT_PIR都关闭了，重置
    {
        if (xm_video_queue)
        {
            clear_queue(xm_video_queue, XM_VIDEO_MAX_QUEUE);
        }
        if (xm_audio_queue)
        {
            clear_queue(xm_audio_queue, XM_AUDIO_MAX_QUEUE);
        }
    }
    //---------------------------------------------------------------
    return ret;
}

void clear_camera_status(unsigned short channel)
{
	unsigned char camera_is_working = 0;
	unsigned char i = 0;
    if (channel < MAX_CAMERA_NUM)
    {
        gCamera_info[channel].channel = -1;
        gCamera_info[channel].clientmark = 0;
    }
//当所有摄像头没有启动的时候打开快充
	for (i=0; i < MAX_CAMERA_NUM; i++)
	{
		if (gCamera_info[i].clientmark != 0)
		{
			camera_is_working = 1;	
			break;
		}
	}
	if (camera_is_working == 0)
	{
		zx_hub_sub1g_quick_charge_control( 0 ); // enable fast charge. by yuxw.
	}
//end
}

int zx_init_camera_sdk(int print_type, void *list)
{
	int ret = -1;
	int i = 0;
	dzlog_info("enter......"); //获取SD库版本号
#if 0
	ret = XMHAL_RegistLogProc(zx_log_callback, 0);
	if(ret != XM_SUCCESS)
	{
		dzlog_error("XMHAL_RegistLogProc fail");
		goto exit;
	}
#endif
	XMHAL_Print(print_type);				//开启打印信息 XM_PRINT_OPEN
	//XMHAL_Print_avinfo(print_type);		   //开启音视频流打印信息 XM_PRINT_OPEN
	//XMHAL_LanguageSet(XM_LANGUAGE_CHINESE);	//设置语言为中文
	dzlog_info("XMLIB VERSION: %s", XMHAL_getlibversion()); //获取SD库版本号
	ret = XMHAL_Init(WIFI_DEVICE, 1, 1, CONF_PATH); //初始化库

	if(ret != XM_SUCCESS)
	{
		dzlog_error("XMHAL_Init sdk fail");
		return ret;
	}

	gxm_con_list = (P2P_CONNECT_INFO *)list;

	memset(gCamera_info, 0, sizeof(XM_CAMERA_INFO)*MAX_CAMERA_NUM);
	for (i = 0; i < MAX_CAMERA_NUM; i++)
	{
		gCamera_info[i].channel = -1;
		gCamera_info[i].clientmark = 0;
	}

    //所有camera的queue分配一次，不动动态释放;
    xm_video_queue = create_queue(XM_VIDEO_MAX_QUEUE, COMM_HEARD_LEN + sizeof(VIDEO_FRAME));
    xm_audio_queue = create_queue(XM_AUDIO_MAX_QUEUE, COMM_HEARD_LEN + sizeof(AUDIO_FRAME));

	if (pipe(gready_pipe) != 0)
		dzlog_error("create gready_pipe fail...");

	if (pipe(gcommand_pipe) != 0)
		dzlog_error("create gcommand_pipe fail...");

	if (pipe(gupdate_pipe) != 0)
		dzlog_error("create gupdate_pipe fail...");


	for (i = 0; i < MAX_CAMERA_NUM; i++)
	{
		ret = XMHAL_RegistTransparentCmdReady(zx_xmsdk_ready, i);
		if(ret != XM_SUCCESS)
		{
			dzlog_error("XMHAL_RegistTransparentCmdReady [%d] fail result=%d", i, ret);
			goto exit;
		}
		ret = XMHAL_RegistMsg(zx_msg_callback, i, 0);
		if(ret != XM_SUCCESS)
		{
			dzlog_error("XMHAL_RegistMsg [%d] fail result=%d", i, ret);
			goto exit;
		}
#if 1
		//注册视频回调
		ret = XMHAL_RegistVideo(zx_video_callback, i, STREAM_VIDEO_TYPE_MAIN, 0);
		if(ret != XM_SUCCESS)
		{
			dzlog_error("XMHAL_RegistVideo [%d] fail result=%d", i, ret);
			goto exit;
		}
		//注册音频回调
		ret = XMHAL_RegistAudio(zx_audio_callback, i, 0);
		if(ret != XM_SUCCESS)
		{
			dzlog_error("XMHAL_RegistAudio [%d] fail result=%d", i, ret);
			goto exit;
		}
		ret = XMHAL_RegistImgage(zx_img_callback, i, 0);
		if(ret != XM_SUCCESS)
		{
			dzlog_error("XMHAL_RegistImgage [%d] fail result=%d", i, ret);
			goto exit;
		}
#endif

	}


#if 0
	fd_set rfds;
	struct timeval tv;
	FD_ZERO(&rfds);
	if (gsdk_pipe[0] >= 0)
	{
		FD_SET(gsdk_pipe[0], &rfds);

		tv.tv_sec = 10;
		tv.tv_usec = 0;
		switch(select(gsdk_pipe[0] + 1, &rfds, NULL, NULL, &tv))
		{
			case -1:
			case 0:
				break;

			default:
			{
				char ready[2] = {0};
				if(FD_ISSET(gsdk_pipe[0], &rfds))
				{
					FD_CLR(gsdk_pipe[0], &rfds);
					read(gsdk_pipe[0], &ready, 2);
				}
				break;
			}
		}
	}
#endif
	return ret;
#if 0
	while(g_running)
	{
		XMHAL_AudioFilePlay(16000, 1, AUDIO_FILETYPE_OPUS, "/tmp/llw/Alarm.opus");

		sleep(10);
	}

	return 0;
#endif
exit:
	XMHAL_Deinit();
	return ret;
}


int zx_deinit_camera_sdk(void)
{
	//XMHAL_UserOnline(0, g_channel); //休眠摄像机
	XMHAL_Deinit();
	dzlog_info("enter...");
	if (gready_pipe[0] >= 0)
	{
		close(gready_pipe[0]);
		close(gready_pipe[1]);
	}

	if (gcommand_pipe[0] >= 0)
	{
		close(gcommand_pipe[0]);
		close(gcommand_pipe[1]);
	}

	if (gupdate_pipe[0] >= 0)
	{
		close(gupdate_pipe[0]);
		close(gupdate_pipe[1]);
	}

    if (xm_video_queue != NULL)
    {
        destroy_queue(xm_video_queue);
        xm_video_queue = NULL;
    }
    if (xm_audio_queue != NULL)
    {
        destroy_queue(xm_audio_queue);
        xm_audio_queue = NULL;
    }

    return 0;
}


int zx_open_camera(int channel, short clientmark)
{
    //int i;
    if (channel >= MAX_CAMERA_NUM)
    {
        return ERROR_NOT_FIND_DEV;
    }
    
#if GET_WIFI_SIGNAL
	gwifi_signal = -120;
#endif
	int ret;
#if SAVE_VIDEO_DATA
	if(fp_video == NULL)
	{
		fp_video = fopen(VIDEO_FILE_NAME, "wb");
		if(fp_video == NULL)
		{
			dzlog_error("open file %s failed", VIDEO_FILE_NAME);
		}
	}
#endif

#if SAVE_AUDIO_DATA
	if(fp_audio == NULL)
	{
		fp_audio = fopen(AUDIO_FILE_NAME, "wb");
		if(fp_audio == NULL)
		{
			dzlog_error("open file %s failed", AUDIO_FILE_NAME);
		}
	}
	if(fp_dec_audio == NULL)
	{
		fp_dec_audio = fopen(AUDIO_DEC_FILE_NAME, "wb");
		if(fp_dec_audio == NULL)
		{
			dzlog_error("open file %s failed", AUDIO_DEC_FILE_NAME);
		}
	}
#endif
#if 0
	//注册视频回调
	ret = XMHAL_RegistVideo(zx_video_callback, channel, STREAM_VIDEO_TYPE_MAIN, 0);
	if(ret != XM_SUCCESS)
	{
		dzlog_error("XMHAL_RegistVideo [%d] fail result=%d", channel, ret);
		goto exit;
	}
	//注册音频回调
	ret = XMHAL_RegistAudio(zx_audio_callback, channel, 0);
	if(ret != XM_SUCCESS)
	{
		dzlog_error("XMHAL_RegistAudio [%d] fail result=%d", channel, ret);
		goto exit;
	}
	ret = XMHAL_RegistImgage(zx_img_callback, channel, 0);
	if(ret != XM_SUCCESS)
	{
		dzlog_error("XMHAL_RegistImgage [%d] fail result=%d", channel, ret);
		goto exit;
	}
#endif
    if (get_camera_clientmark(channel) != 0)
    {
        dzlog_warn("reopen camera %d", channel);
        ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, channel, WAKEUP_WITH_VIDEO, 0);
        zx_send_command(COMMON_TYPE_INSERT_IFRAME, (char *)&ret, channel);
    }
    else
    {
        ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, channel, WAKEUP_WITH_VIDEO, 0);
    }
	if (ret)
	{
        dzlog_error("open_camera(%d) error=%d", channel, ret);
		
	#if 0
        upload_log_param(LOG_NORMAL, XM_CAMERA, base_param->hub_info.hub_sn, "Warn", "Camera", "", get_p2p_err_info(ret));
	#endif

		dzlog_info("open camera");
		upload_log_param(LOG_NORMAL, FLOODLIGHT, base_param->hub_info.hub_sn, "Warn", "Camera", "", get_p2p_err_info(ret));
	}
	else
	{
		set_camera_clientmark(channel, clientmark);
		dzlog_info("open_camera(%d) ok, waiting data stream...", channel);
	}
//exit:
	return ret;
}


int zx_match_dev(int ip_addr,char* pMacAddr,int MacLen)
{
	dzlog_info("enter pMacAddr=%s...", pMacAddr);

	int channel = XMHAL_MatchDev(ip_addr, pMacAddr, MacLen);
	if (channel >= 0)
	{
        dzlog_info("Bind XM assign channel number=%d...", channel);
		XMHAL_RegistTransparentCmdReady(zx_xmsdk_ready, channel);
	}
	return channel;
}


int zx_close_camera(int channel)
{
	int ret = -1;

	//dzlog_info("enter channel=%d...", channel);
	gcount = 0;
	gaudio_count = 0;

    if (channel < MAX_CAMERA_NUM)
    {
        ret = XMHAL_ReleaseChannle(channel);//XMHAL_UserOnline(0, channel);
        clear_camera_status(channel);
    }

#if SAVE_AUDIO_DATA
	if(fp_audio)
	{
		fclose(fp_audio);
		fp_audio = NULL;
	}
	if(fp_dec_audio)
	{
		fclose(fp_dec_audio);
		fp_dec_audio = NULL;
	}
#endif

#if SAVE_VIDEO_DATA
	if(fp_video)
	{
		fclose(fp_video);
		fp_video = NULL;
	}
#endif

	dzlog_info("ret = %d exit...", ret);

	return ret;
}

int zx_set_log_print_type(int print_type)
{
	XMHAL_Print(print_type);				//开启打印信息 XM_PRINT_OPEN
	return XMHAL_Print_avinfo(print_type);		   //开启音视频流打印信息 XM_PRINT_OPEN
}


int zx_update_dsp_callback(unsigned int State,unsigned int ErrCode,long reserve)
{
	dzlog_info("State = %d ErrCode=%d firmwaretype=%d...", State, ErrCode, reserve);
	if ( (State == UPGRADE_OK) || ((State == UPGRADE_SEND_COMPELETE) && reserve == UPDATE_TYPE_SUB1G))
	{
		int channel_id = reserve;
		write(gupdate_pipe[1],  &channel_id, sizeof(int));
	}
	return 0;
}


int zx_update_xmdsp(int channel, char* pfilePath, int firmwaretype)
{
	int ret = XMHAL_UpdateDSPMoudule(channel, pfilePath, firmwaretype, zx_update_dsp_callback, 0);
	dzlog_info("channel = %d pfilePath=%s firmwaretype=%d ret=%d...", channel, pfilePath, firmwaretype, ret);
	if (ret == 1)
	{
		dzlog_info("wait update end......");
		if (firmwaretype == UPDATE_TYPE_SUB1G)
			ret = zx_wait_channel_ready(channel, 60, 0);
		else if (firmwaretype == UPDATE_TYPE_SYS)
			ret = zx_wait_channel_ready(channel, 600, 0);
		else if (firmwaretype == UPDATE_TYPE_APP)
			ret = zx_wait_channel_ready(channel, 120, 0);
	}
	return ret;
}


int zx_wait_channel_ready(int channel, int timeout, int type)
{
	fd_set rfds;
	struct timeval tv;
	int pipe0 = -1;

	if (type == 1)
	{
		gcheck_ready = 1;
		pipe0 = gready_pipe[0];
	}
	else if (type == 0)
		pipe0 = gupdate_pipe[0];
	FD_ZERO(&rfds);
	if (pipe0 >= 0)
		FD_SET(pipe0, &rfds);
	else
		return ERROR_NULL_POINT;
	tv.tv_sec = timeout;
	tv.tv_usec = 0;
	switch(select(pipe0 + 1, &rfds, NULL, NULL, &tv))
	{
		case -1:
		case 0:
			break;

		default:
		{
			int channel_id = 0;
			if(FD_ISSET(pipe0, &rfds))
			{
				FD_CLR(pipe0, &rfds);
				read(pipe0, &channel_id, sizeof(int));
				dzlog_info("firmwaretype [%d] ready!", channel_id);
				return 0;
			}
			break;
		}
	}
	return ERROR_WAIT_TIMEOUT;
}

int zx_get_dev_version(int channel, char* sw_ver, char *hw_ver)
{
	if (sw_ver && hw_ver && channel >= 0)
	{
		fd_set rfds;
		struct timeval tv;
		usleep(1000*1000);
		int ret = XMHAL_GetDSPVersion(channel);
		dzlog_info("XMHAL_GetDSPVersion ret[%d] ", ret);
		if (ret == 0)
		{
			FD_ZERO(&rfds);
			if (gcommand_pipe[0] >= 0)
				FD_SET(gcommand_pipe[0], &rfds);
			else
				return ERROR_NULL_POINT;
			tv.tv_sec = 5;
			tv.tv_usec = 0;
			switch(select(gcommand_pipe[0] + 1, &rfds, NULL, NULL, &tv))
			{
				case -1:
				case 0:
					break;

				default:
				{
					XM_CAMERA_VERSION ver_info;
					if(FD_ISSET(gcommand_pipe[0], &rfds))
					{
						FD_CLR(gcommand_pipe[0], &rfds);
						read(gcommand_pipe[0], &ver_info, sizeof(XM_CAMERA_VERSION));
						dzlog_info("get sw_ver[%s] hw_ver[%s]", ver_info.dspsoftversion, ver_info.dsphardversion);
						memcpy(sw_ver, ver_info.dspsoftversion, strlen(ver_info.dspsoftversion));
						memcpy(hw_ver, ver_info.dsphardversion, strlen(ver_info.dsphardversion));
						return 0;
					}
					break;
				}
			}
		}
	}
	return ERROR_NULL_POINT;
}


int zx_get__snapshot_img(int channel, int width, int height)
{
	dzlog_info("get_snapshot: channel=%d, %d*%dP...", channel, width, height);
	struct _snapshot snapparam;
	memset(&snapparam, 0, sizeof(struct _snapshot));
	snapparam.eventtype = 0;        // 0:APP触发
	snapparam.number = 1;
	snapparam.quality = 0;          // 0:默认
	snapparam.intervalTime = 1000;
	snapparam.width = width;
	snapparam.height = height;
	return XMHAL_SendCmd(COMMON_TYPE_SNAPSHORT, (char *)&snapparam, channel);
}




