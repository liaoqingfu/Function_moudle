/*
 ============================================================================
 Name        : sub1g_interface.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-28 
 Description :
 ============================================================================
 */

#include "compiler.h"
#include "ini_file.h"       /* This reads our ini file */
#include "log.h"            /* Our logging scheme */
#include "timer.h"
#include "fatal.h"
#include "stream.h"
#include "stream_socket.h"  /* We use a socket in our app */
#include "appsrv.pb-c.h"
#include "threads.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "sub1g_interface.h"
#include "comm_protocol_define.h"
#include "xm_interface.h"
#include "push_interface.h"
#include "PPCS/PPCS_Error.h"
#include "sys_interface.h"
#include "ppcs_interface.h"
#include "as_interface.h"
#include "ota_interface.h"
#include "Xm_lib.h"

//DEV_BASE_PARAM *gdev_base_param = NULL;
P2P_CONNECT_INFO *gsub1g_con_list = NULL;
HUB_BASE_PARAM *gdev_base_param = NULL;
unsigned int gsub1g_msgid = -1;
int gsession_id = -1;
int gsub1g_pipe[2] = {-1};
extern int grunning;
extern short gbopen_p2p;

int zx_alloc_wifi_addr(char *addr, char *dev_mac)
{
	int i = 0, addr_index = WIFI_ADDR_START_INDEX;
	if (addr && dev_mac)
	{
		for (i = 0; i < MAX_SUB1G_CONNECT; i++)
		{
			if (strcmp(dev_mac, gdev_base_param->dev_param[i].dev_mac) == 0)
			{
				memcpy(addr, gdev_base_param->dev_param[i].dev_ipaddr, strlen(gdev_base_param->dev_param[i].dev_ipaddr));	
				return 0;
			}
		}
GET_AGAIN:
		sprintf(addr, "%s%d", WIFI_ADDR_BASE, addr_index);
		//dzlog_info("dev ip_addr=%s", addr);
		for (i = 0; i < MAX_SUB1G_CONNECT; i++)
		{
			if (gdev_base_param->dev_param[i].dev_ipaddr[0] != 0) // dev_ipaddr长度 > 0
			{
				if (strcmp(addr, gdev_base_param->dev_param[i].dev_ipaddr) == 0)
				{
					addr_index++;
					if (addr_index > WIFI_ADDR_END_INDEX)
					{
						*addr = 0;
						return -1;
					}
					goto GET_AGAIN;
				}
				dzlog_info("dev[%d]_ipaddr=%s", i, gdev_base_param->dev_param[i].dev_ipaddr);
			}
		}
		return 0;	// 分配的addr没有重复
	}
	*addr = 0;
	return -1;
}

#if 1
AppclientDeviceDescriptor * zx_get_dev_descriptor_by_addr(unsigned int addr_code)
{
	int i = 0;
	dzlog_info("enter addr_code=%d", addr_code);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == addr_code)
		{
			return &gdev_base_param->dev_param[i].sub1g_info;	
		}
	}
	return NULL;
}


AppclientDeviceDescriptor * zx_get_dev_descriptor_by_channel(unsigned int channel)
{
	int i = 0;
	//dzlog_info("enter addr_code=%d",  channel);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].channle_id == channel)
		{		
			//dzlog_info("short_addr=%d channel=%d",  gdev_base_param->dev_param[i].sub1g_info.shortaddress, gdev_base_param->dev_param[i].channle_id);	
			return &gdev_base_param->dev_param[i].sub1g_info;	
		}
	}
	return NULL;
}
#endif
int zx_get_dev_channel_by_shortaddr(unsigned int shortadd)
{
	#if 1
	int i = 0;
	//dzlog_info("enter addr_code=%d",  shortadd);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == shortadd)
		{		
			//dzlog_info("short_addr=%d channel=%d",  gdev_base_param->dev_param[i].sub1g_info.shortaddress, gdev_base_param->dev_param[i].channle_id);	
			return gdev_base_param->dev_param[i].channle_id;	
		}
	}
	return ERROR_DEV_OFFLINE;
	#endif
}


char * zx_get_dev_sn_by_shortaddr(unsigned int shortadd)
{
	#if 1
	int i = 0;
	//dzlog_info("enter addr_code=%d",  shortadd);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == shortadd)
		{		
			//dzlog_info("short_addr=%d channel=%d",  gdev_base_param->dev_param[i].sub1g_info.shortaddress, gdev_base_param->dev_param[i].channle_id);	
			return gdev_base_param->dev_param[i].dev_sn;	
		}
	}
	return NULL;
	#endif
}

int zx_update_dev_rssi_by_shortaddr(unsigned int shortadd, unsigned int rssi)
{
	#if 1
	int i = 0;
	//dzlog_info("enter addr_code=%d",  shortadd);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == shortadd)
		{		
			//dzlog_info("short_addr=%d channel=%d",  gdev_base_param->dev_param[i].sub1g_info.shortaddress, gdev_base_param->dev_param[i].channle_id);	
			gdev_base_param->dev_param[i].dev_sub1g_rssi = rssi;
			return 0;
		}
	}
	return ERROR_DEV_OFFLINE;
	#endif
}

DEV_BASE_PARAM * zx_get_dev_info_by_addr(unsigned int addr_code)
{
	#if 1
	int i = 0;
	//dzlog_info("enter addr_code=%d", addr_code);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == addr_code)
		{
			//dzlog_info("exit [%d]", i);
			return &gdev_base_param->dev_param[i];	
		}
	}
	return NULL;
#endif
}

int * zx_get_p2p_pipe_by_channel(int channel, int type)
{
	#if 1
	int i = 0;
	int have_p2p_pipe = 0;
	for (i = 0; i < MAX_CONNECT_NUM; i++)
	{
		if (gsub1g_con_list[i].channel == channel && type == SUB1G_PIPE)
		{
			have_p2p_pipe = 1;
			return &gsub1g_con_list[i].sub1g_pipe;
		}
	}
	if (have_p2p_pipe == 0)
	{
		dzlog_error("not find p2p pipe channel=%d type=%d", channel, type);
		return &gsub1g_pipe;
	}

	return NULL;
	#endif
}


int *zx_write_pipe_by_shortaddr(unsigned int shortadd)
{
	int channel = zx_get_dev_channel_by_shortaddr(shortadd);
	if (channel >= 0)
	{
		return zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);
	}
	else
	{
		dzlog_error("addr_code % <-> channel %d", shortadd, channel);		
	}
	return NULL;
}


int zx_update_dev_wifi_info_by_addr(unsigned int addr_code, char *ip_addr, char *sn, char *mac)
{
	#if 1
	int i = 0;
	dzlog_info("enter addr_code =%d ip_addr=%s sn=%s %d", addr_code, ip_addr, sn, strlen(sn));
	if (ip_addr && sn && mac)
	{
		for (i = 0; i < MAX_SUB1G_CONNECT; i++)
		{
			if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == addr_code)
			{
				memset(&gdev_base_param->dev_param[i].dev_mac, 0, sizeof(gdev_base_param->dev_param[i].dev_mac));
				memset(&gdev_base_param->dev_param[i].dev_ipaddr, 0, sizeof(gdev_base_param->dev_param[i].dev_ipaddr));
				memset(&gdev_base_param->dev_param[i].dev_sn, 0, sizeof(gdev_base_param->dev_param[i].dev_sn));
				short ilen = strlen(sn);
				memcpy(&gdev_base_param->dev_param[i].dev_mac, mac, MAC_BYTE_LEN);	
				memcpy(&gdev_base_param->dev_param[i].dev_ipaddr, ip_addr, strlen(ip_addr));
				memcpy(&gdev_base_param->dev_param[i].dev_sn, sn, ilen>DEVICE_SN_LEN?DEVICE_SN_LEN:ilen);
				
				printf_hex((char *)&gdev_base_param->dev_param[i].dev_mac, MAC_BYTE_LEN);
				//dzlog_info("exit [%d]", i);
				return 0;
			}
		}
	}
	
	return -1;
	#endif
}


int zx_update_channel_by_addr(unsigned int addr_code, int channel, int dev_type)
{
	#if 1
	int i = 0;
	dzlog_info("enter addr_code=%d channel=%d", addr_code, channel);
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == addr_code)
		{
			ZX_COMMUNICATION_PACKET comm_data;
			memset(&comm_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
			NOTIFY_DEV_INFO *dev_base_info = &comm_data.param_body.dev_base_info;

			comm_data.msg_head.head_tag = PAG_HEARD_TAG;
			comm_data.msg_head.command_id = APP_CMD_DEVS_BIND_NOTIFY;
			comm_data.msg_head.param_len = sizeof(NOTIFY_DEV_INFO);
			comm_data.msg_head.random = random();
			comm_data.msg_head.sign_code = NO_SEC_KEY;
			comm_data.msg_head.channel_id = channel;
			comm_data.msg_head.dev_type = 0x01;

			sprintf(gdev_base_param->dev_param[i].dev_name, "%s%02d", SEC_CAMERA_NAME, channel);			
			gdev_base_param->dev_param[i].channle_id = channel;	
			gdev_base_param->dev_param[i].dev_type = dev_type;
		#if 1
			char dev_sn[DEVICE_SN_LEN+1] = {0};
			strncpy(dev_sn, gdev_base_param->hub_info.hub_sn, DEVICE_SN_LEN-3);
			sprintf(dev_sn, "%s%s%d", dev_sn, &gdev_base_param->hub_info.hub_sn[14], channel);
			memcpy(&gdev_base_param->dev_param[i].dev_sn, dev_sn, strlen(dev_sn));	
		#endif
			memcpy(&dev_base_info->dev_sn, gdev_base_param->dev_param[i].dev_sn, DEVICE_SN_LEN);		
		//#if RUN_P2P_SERVER
			sprintf(dev_base_info->dev_name, "%s%02d", SEC_CAMERA_NAME, channel);
							
			dev_base_info->channle_id = channel;
			dev_base_info->dev_type = dev_type;

			write_config_param(HUB_BIND_DEV);

			dzlog_info("dev_sn=%s %s", dev_base_info->dev_sn, dev_sn);
			if (gbopen_p2p)
		#if RUN_P2P_SERVER
				zx_write_notify(channel, (uint8_t *)&comm_data, COMM_HEARD_LEN + sizeof(NOTIFY_DEV_INFO), gsession_id);
		#endif
			return 0;
		}
	}
	#endif
	return -1;
}


//sub1g允许配对确认上报 zx_set_join_permit_cnf
void zx_set_join_permit_cnf(uint8_t Status)
{
    dzlog_info("Set JointPermit Confirmed, Status=%d ", Status);
	
}

//sub1g网关获取 zx_get_gw_info_cnf
void zx_get_gw_info_cnf(uint8_t Status)
{
    dzlog_info("Get Nwk Info Confirmed, Status=%d ", Status);

}
#if 1
//获取设备列表回调 zx_get_dev_list_cnf
void zx_get_dev_list_cnf(AppclientDeviceDescriptor* appClientDev, uint8_t devNum)
{
	int i = 0, j = 0;
    dzlog_info("there are %d devices bonded ", devNum);

	if( devNum > 0 )
	{
		for (i = 0; i < devNum; i ++)
		{		
			dzlog_info("Dev[%d]: shortadd=%d, extadd=0x%llX ", i, appClientDev[i].shortaddress, appClientDev[i].extaddress); 
			for (j = 0; j < MAX_SUB1G_CONNECT; j++)
			{
				//dzlog_info("shortaddress %d ", gdev_base_param->dev_param[j].sub1g_info.shortaddress);
				if (gdev_base_param->dev_param[j].sub1g_info.shortaddress == appClientDev[i].shortaddress)
				{	
					int oldaddr = gdev_base_param->dev_param[j].sub1g_info.shortaddress;
					memcpy(&gdev_base_param->dev_param[j].sub1g_info, &appClientDev[i], sizeof(AppclientDeviceDescriptor));
					dzlog_info("the dev have add to list,panid=%d old=%d new shortaddress=%d channel=%d",gdev_base_param->dev_param[j].sub1g_info.panid, 
									oldaddr, gdev_base_param->dev_param[j].sub1g_info.shortaddress, gdev_base_param->dev_param[j].channle_id);	
					break;
				}				
				else if (gdev_base_param->dev_param[j].sub1g_info.panid == 0)
				{
					memcpy(&gdev_base_param->dev_param[j].sub1g_info, &appClientDev[i], sizeof(AppclientDeviceDescriptor));
					dzlog_info("add new Dev[%d]: shortadd=%d, panid=%d ", j, gdev_base_param->dev_param[j].sub1g_info.shortaddress, gdev_base_param->dev_param[j].sub1g_info.panid); 
					break;
				}					
			}
		}

	}
}
#endif
//sub1g发送确认 zx_tx_cnf
void zx_dev_tx_cnf(uint8_t Status)
{
    dzlog_info("Tx Data Confirmed ");

}

//sub1g网关状态更新上报
void zx_dev_update_ind(uint8_t Status)
{
    dzlog_info("Device Update Ind ");
	//appclient_SendGetDeviceArrayReq();
}
#if 1
//sub1g设备配对成功后上报 
void zx_dev_joined_ind(AppclientDeviceDescriptor* appClientDev)
{
    dzlog_info("Device Joined!, device Panid=%d, shortAddr=%d, extAddr=0x%llX ", 
					appClientDev->panid, appClientDev->shortaddress,appClientDev->extaddress);
	appclient_SendGetDeviceArrayReq();
}
#endif
//sub1g设备解绑后上报 解绑接口上报
void zx_dev_left_ind(uint8_t Status)
{
    dzlog_info("Device remove Ind ");
	//int ret = 0;
	//write(gsub1g_pipe[1], &ret, sizeof(ret));
	//appclient_SendGetDeviceArrayReq();
}

//sub1g网关程序（Collector）状态上报
void zx_gw_state_chg_ind(uint8_t State)
{
    dzlog_info("Collector Stat Chg Ind, state=%d ", State);
}


int zx_sub1g_data_process(uint8_t *data, int data_len)
{
	//dzlog_info("enter msgsnd[%d]" , gsub1g_msgid);  
	int ret = -1;	
	if (gsub1g_msgid >= 0)
	{
		ZX_MAG_DATA send_data; 
		memset(&send_data, 0, sizeof(ZX_MAG_DATA));
		send_data.msg_type = SUB1G_RECV;
		
		memcpy(&send_data.comm_data, data, data_len);
		if(msgsnd(gsub1g_msgid, (void*)&send_data, data_len , 0) == -1)  
        {  
         	dzlog_info("msgsnd failed");  
       	} 
		else
			ret = 0;
	}
	//dzlog_info("exit");  
	return ret;	
}
#if 1
//sub1g接收数据上报
void zx_dev_rx_ind(AppclientDeviceDescriptor* apClientDev,uint8_t* pData, uint8_t len, int32_t rssi)
{
	int i = 0;
	int is_valid = 0;
	//dzlog_info("Device len=%d addr=%d extaddr=0x%llX rssi=%d" , len, apClientDev->shortaddress, apClientDev->extaddress, rssi);
	if( pData == NULL )
	{
		dzlog_error("Device Data Rx Ind: pData is NULL!!");
        return;
	}
	zx_update_dev_rssi_by_shortaddr(apClientDev->shortaddress, rssi);
#if 1	
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == apClientDev->shortaddress 
			&& gdev_base_param->dev_param[i].sub1g_info.extaddress ==  apClientDev->extaddress)
		{
			is_valid = 1;
			break;
		}
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == -1)
			break;
	}
	if (is_valid == 0)
	{
    	dzlog_info("invalid Device: panid=%d, shortaddr=%d, extaddr=%d ", apClientDev->panid,apClientDev->shortaddress,apClientDev->extaddress);
		appclient_SendDisassocDevReq(apClientDev);	
		return;	
	}
#endif
	if (gsub1g_msgid >= 0 && len >= sizeof(ZX_COMM_HEAD))
	{
		ZX_COMM_HEAD *msg_head = (ZX_COMM_HEAD *)pData;
		if (msg_head->head_tag ==  PAG_HEARD_TAG) 
		{
			//printf_hex((char *)pData, len);  
			zx_sub1g_data_process(pData, len);	
		}
	}
}
#endif
#if 1
//sub1g设备在线状态上报
void zx_dev_state_update_ind(AppclientDeviceDescriptor* appClientDev, int32_t state)
{
    dzlog_info("Dev[%d] device Panid=%d, shortAddr=%d, extAddr=0x%llX state=%d ", appClientDev->shortaddress, 
			appClientDev->panid, appClientDev->shortaddress, appClientDev->extaddress, state);
	char *dev_sn = zx_get_dev_sn_by_shortaddr(appClientDev->shortaddress);
	char sstatus[2] = {0};
	if (state <= 1)
		sprintf(sstatus, "%d", state);
	if (dev_sn && strlen(sstatus) == 1)
		zx_upload_devs_params(gdev_base_param->hub_info.account_id, gdev_base_param->hub_info.hub_sn, dev_sn, APP_CMD_GET_DEV_STATUS, sstatus);

}
#endif

#if 1
void zx_dev_get_mt_version_cnf(uint8_t status, AppclientMtVersion *pVersion)
{
	ZX_COMMUNICATION_PACKET comm_pack;// = (ZX_COMMUNICATION_PACKET *)malloc(sizeof(ZX_COMMUNICATION_PACKET));
	ZX_COMMUNICATION_PACKET *send_pkg = &comm_pack;	
	SUB1G_DEV_VERSION *pver = &comm_pack.param_body.dev_version;
	send_pkg->msg_head.command_id = SUB1G_CMD_GET_MT_VERSION;
	send_pkg->msg_head.param_len = sizeof(SUB1G_DEV_VERSION);
	send_pkg->msg_head.head_tag = PAG_HEARD_TAG;
	memset(pver, 0, sizeof(SUB1G_DEV_VERSION));
	sprintf(pver->version, "%d.%d.%d.%d", pVersion->product, pVersion->major, pVersion->minor, pVersion->maint);
	dzlog_info("status = %d, version=%s ", status, pver->version);	
	write(gsub1g_pipe[1], &send_pkg, sizeof(send_pkg));//COMM_HEARD_LEN + sizeof(SUB1G_DEV_VERSION)

	usleep(50*1000); // waiting read version
}
#endif

void zx_get_adc_result_cnf(uint8_t Status, uint32_t result)
{
	dzlog_info("Get ADC result status = %d, result=0x%X ", Status, result);
}

#if 1
Appclient_callbacks_t app_Client_callback_list =
{
	
    zx_set_join_permit_cnf,
    zx_get_gw_info_cnf,	
    zx_get_dev_list_cnf,
    zx_dev_tx_cnf,
    zx_dev_update_ind,
    zx_dev_joined_ind,
	zx_dev_left_ind,
	zx_gw_state_chg_ind,
	zx_dev_rx_ind,
	zx_dev_state_update_ind,
	zx_get_adc_result_cnf,
	zx_dev_get_mt_version_cnf
	
};
#endif

const char *get_sub1g_command_str_info(int command_type)
{
    switch (command_type)
    {
		case SUB1G_CMD_BIND:	        //设备发起配对请求
			return "SUB1G_CMD_BIND";
		case SUB1G_CMD_BIND_SUCESS:	            //设备确认配对成功
			return "SUB1G_CMD_BIND_SUCESS";
		case SUB1G_CMD_WAKEUP:					//基站唤醒设备  0:出视频流  1：用于设置不出视频 2：新版本通知
			return "SUB1G_CMD_WAKEUP";
		case SUB1G_CMD_SLEEP:					//基站请求设备休眠
			return "SUB1G_CMD_SLEEP";
		case SUB1G_CMD_CHECK_STATUS:			    //基站检查设备状态
			return "SUB1G_CMD_CHECK_STATUS";
		case SUB1G_CMD_GET_VOLTAGE:				//获取电池电量
			return "SUB1G_CMD_GET_VOLTAGE";
		case SUB1G_CMD_GET_RSSI:			        //获取SUB1G信号强度
			return "SUB1G_CMD_GET_RSSI";
		case SUB1G_CMD_OPEN_PIR:				    //打开PIR
			return "SUB1G_CMD_OPEN_PIR";
		case SUB1G_CMD_CLOSE_PIR:			    //关闭PIR
			return "SUB1G_CMD_CLOSE_PIR";
		case SUB1G_CMD_SET_PIR_SENSITIVITY:      //设置PIR灵密度
			return "SUB1G_CMD_SET_PIR_SENSITIVITY";
		case SUB1G_CMD_OPEN_GSENSOR:			    //打开GSENSOR
			return "SUB1G_CMD_OPEN_GSENSOR";
		case SUB1G_CMD_CLOSE_GSENSOR:			//关闭GSENSOR
			return "SUB1G_CMD_CLOSE_GSENSOR";
		case SUB1G_CMD_SET_GSENSOR_SENSITIVITY:  //设置GSENSOR灵密度
			return "SUB1G_CMD_SET_GSENSOR_SENSITIVITY";
		case SUB1G_CMD_UPDATE_WIFI_INFO:         //基站更新设备wifi信息
			return "SUB1G_CMD_UPDATE_WIFI_INFO";
		case SUB1G_CMD_GET_VERSION:              //获取设备版本号
			return "SUB1G_CMD_GET_VERSION";
		case SUB1G_CMD_OPEN_AUDIO_DEC:           //打开音频侦测
			return "SUB1G_CMD_OPEN_AUDIO_DEC";
		case SUB1G_CMD_CLOSE_AUDIO_DEC:          //关闭音频侦测
			return "SUB1G_CMD_CLOSE_AUDIO_DEC";
		case SUB1G_CMD_OPEN_LED:                 //打开指示灯
			return "SUB1G_CMD_OPEN_LED";
		case SUB1G_CMD_CLOSE_LED:                //关闭指示灯
			return "SUB1G_CMD_CLOSE_LED";
		case SUB1G_CMD_OPEN_LIGHT_DEC:           //打开光感
			return "SUB1G_CMD_OPEN_LIGHT_DEC";
		case SUB1G_CMD_CLOSE_LIGHT_DEC:          //关闭光感
			return "SUB1G_CMD_CLOSE_LIGHT_DEC";
    	case SUB1G_CMD_AUDIO_LOOPTEST:           //麦克、喇叭回环测试
			return "SUB1G_CMD_AUDIO_LOOPTEST";
    	case SUB1G_CMD_OPEN_WIFI:                //打开WIFI
			return "SUB1G_CMD_OPEN_WIFI";
		case SUB1G_CMD_CLOSE_WIFI:               //关闭WIFI
			return "SUB1G_CMD_CLOSE_WIFI";
		case SUB1G_CMD_WIFI_TXTEST:              //WIFI发射功率测试
			return "SUB1G_CMD_WIFI_TXTEST";
		case SUB1G_CMD_WIFI_RXTEST:              //WIFI接收灵敏度测试
			return "SUB1G_CMD_WIFI_RXTEST";
		case SUB1G_CMD_OPER_IRCUT:               //IRCUT操作
			return "SUB1G_CMD_OPER_IRCUT";
		case SUB1G_CMD_WRITE_SN:                 //写设备SN
			return "SUB1G_CMD_WRITE_SN";
		case SUB1G_CMD_READ_SN:                  //读设备SN
			return "SUB1G_CMD_READ_SN";
		case SUB1G_CMD_WRITE_MAC:                //写设备MAC
			return "SUB1G_CMD_WRITE_MAC";
		case SUB1G_CMD_READ_MAC:                 //读设备MAC
			return "SUB1G_CMD_READ_MAC";
		case SUB1G_CMD_DISASSOC_DEV:             //设备解除配对
			return "SUB1G_CMD_DISASSOC_DEV";
		case SUB1G_CMD_GET_DEV_COUNT:            //获取连接设备数
			return "SUB1G_CMD_GET_DEV_COUNT";
		case SUB1G_CMD_GET_MT_VERSION:           //获取网关版本号
			return "SUB1G_CMD_GET_MT_VERSION";
		case SUB1G_CMD_SWITCH_SERIAL:            //USB口切换3518串口
			return "SUB1G_CMD_SWITCH_SERIAL";
		case SUB1G_CMD_SET_LIGHT_SENSITIVITY:    //设置光感灵敏度
			return "SUB1G_CMD_SET_LIGHT_SENSITIVITY";
		case SUB1G_CMD_SET_IRLED_POWER:         //设置红外灯亮度
			return "SUB1G_CMD_SET_IRLED_POWER";
		case SUB1G_REP_LOWPOWER:                //SUB1G上报低电警告
			return "SUB1G_REP_LOWPOWER";
		case SUB1G_REP_GSENSOR:                  //SUB1G上GSENSOR警告
			return "SUB1G_REP_GSENSOR";
		case SUB1G_REP_PIR:                      // SUB1G上PIR警告
			return "SUB1G_REP_PIR";
		case SUB1G_REP_CAMERA_DIED:              //SUB1G上报Camera死机
			return "SUB1G_REP_CAMERA_DIED";
		case SUB1G_REP_AUDIO_DEC:                //SUB1G上报声音侦测事件
			return "SUB1G_REP_AUDIO_DEC";
		case SUB1G_REP_LIGHT_DEC:                //SUB1G上报光感事件
			return "SUB1G_REP_LIGHT_DEC";
		case SUB1G_REP_KEY:                      //SUB1G上报按键事件
			return "SUB1G_REP_KEY";
		
	}
	return "";
}

void *zx_sub1g_receive(void *argv)
{
	#if 1
	int write_size = 0;
	int ret = -1;
	unsigned int short_addr = -1;
    int *sub1g_pipe = NULL;
	ZX_MAG_DATA *rec_data = (ZX_MAG_DATA *)malloc(sizeof(ZX_MAG_DATA)); 
 	if (rec_data == NULL)
	{
		dzlog_error("MALLOC rec_data ERR! errno: %d", errno);	
		goto EXIT;
	}
	ZX_COMMUNICATION_PACKET *comm_pack = (ZX_COMMUNICATION_PACKET *)malloc(sizeof(ZX_COMMUNICATION_PACKET));
	if (comm_pack == NULL)
	{
		dzlog_error("MALLOC comm_pack ERR! errno: %d", errno);	
		goto EXIT;
	}
	ZX_COMMUNICATION_PACKET *send_pack = (ZX_COMMUNICATION_PACKET *)malloc(sizeof(ZX_COMMUNICATION_PACKET)); 
	if (send_pack == NULL)
	{
		dzlog_error("MALLOC send_pack ERR! errno: %d", errno);	
		goto EXIT;
	}
	int msg_id = zx_get_msgid_by_type(SUB1G_RECV); 

	dzlog_info("start zx_sub1g_receive, msgid=%d, PID=%d......", msg_id, getpid());
	//comm_pack = &rec_data.comm_data;
    while (grunning)  
    {  
		memset(rec_data, 0, sizeof(ZX_MAG_DATA));
        if(msgrcv(msg_id, (void*)rec_data, sizeof(ZX_MAG_DATA), 0, 0) == -1)  
        {  
            dzlog_error("msgrcv failed with errno: %d", errno);
            break;
        } 
		memcpy(comm_pack, &rec_data->comm_data, sizeof(ZX_COMMUNICATION_PACKET));
		//dzlog_info("msgrcv data......"); 
		//comm_pack = &rec_data.comm_data;
		//printf_hex((char *)comm_pack, sizeof(ZX_COMM_HEAD));  		
		switch (comm_pack->msg_head.command_id)
		{
			case SUB1G_CMD_BIND:
				{
					WIFI_INFO wifi_info;
					char addr[SMALL_STR_LEN] = {0};
					SUB1G_DEV_BIND *dev_bind = (SUB1G_DEV_BIND *)&comm_pack->param_body.sub1g_bind;
					dzlog_info("[%s] dev sn: %s addr_code=%d", get_sub1g_command_str_info(comm_pack->msg_head.command_id), dev_bind->dev_sn, dev_bind->dev_addr_code);

					memset(send_pack, 0, sizeof(ZX_COMMUNICATION_PACKET));
					memcpy(send_pack, &comm_pack->msg_head, sizeof(ZX_COMM_HEAD));
					
					SUB1G_HUB_WIFI_INFO *sub1g_send_wifi = &send_pack->param_body.wifi_info;
					memset(&wifi_info, 0, sizeof(WIFI_INFO));

					if (get_wifi_info(&wifi_info) == -1)
					{
						dzlog_error("SUB1G_CMD_BIND get_wifi_info fail");
						break;
					}
					else
					{
						memcpy(sub1g_send_wifi, &wifi_info, sizeof(WIFI_INFO));
					}
					if (zx_alloc_wifi_addr(addr, dev_bind->dev_mac) == 0)
					{
						memcpy(sub1g_send_wifi->dev_ip_addr, addr, sizeof(addr)); 
					}
					else
					{
						dzlog_error("SUB1G_CMD_BIND alloc_wifi_addr fail\n");
						break;
					}
#if 1				
					char *hub_ip = zx_get_hub_ipaddr("br0");	
					if (hub_ip)
					{
						if (strlen(hub_ip) < MAC_LEN_BYTE + 1)
							memcpy(sub1g_send_wifi->hub_ip_addr, ZX_HUB_IP, strlen(ZX_HUB_IP));	
						else 
							memcpy(sub1g_send_wifi->hub_ip_addr, hub_ip, strlen(hub_ip));				
					}
#endif							
					sub1g_send_wifi->auth_type = AUTH_WPAWPA2;
					send_pack->msg_head.param_len = sizeof(SUB1G_HUB_WIFI_INFO);
					send_pack->msg_head.dev_type = comm_pack->msg_head.dev_type;
					//rec_data.msg_head.is_response[0] = 1;	
					//dzlog_info("addr=%s ssid=%s dev_addr_code=%d", sub1g_send_wifi->dev_ip_addr, sub1g_send_wifi->hub_wifi_ssid, 
					//			dev_bind->dev_addr_code);
					zx_update_dev_wifi_info_by_addr(dev_bind->dev_addr_code, addr, dev_bind->dev_sn, dev_bind->dev_mac);
					//printf_hex((char *)&send_pack, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_HUB_WIFI_INFO));
					AppclientDeviceDescriptor *dev_desc = zx_get_dev_descriptor_by_addr(dev_bind->dev_addr_code);
					if (dev_desc && dev_desc->shortaddress > 0)
					{
						appclient_SendTxDataReq(dev_desc, (uint8_t *)send_pack, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_HUB_WIFI_INFO));
					}
					else
					{
						dzlog_error("SUB1G_CMD_BIND not DeviceDescriptor\n");
					}
				}
				break;
			case SUB1G_CMD_BIND_SUCESS:	            //设备确认配对成功
				{
					SUB1G_DEV_BIND_OK *sub1g_bink_ok = (SUB1G_DEV_BIND_OK *)&comm_pack->param_body.sub1g_bink_ok;
					DEV_BASE_PARAM *dev_info = zx_get_dev_info_by_addr(sub1g_bink_ok->dev_addr_code);
					if (dev_info)
					{
						unsigned char str_mac[MAC_STR_LEN] = {0};
						//printf_hex((char *)dev_info, sizeof(DEV_BASE_PARAM));
						printf_hex((char *)&dev_info->dev_mac, MAC_LEN_BYTE); 
						//dzlog_info("byte_mac_to_str %s......", dev_info->dev_mac); 
						sprintf(str_mac, "%02X:%02X:%02X:%02X:%02X:%02X", (unsigned char)dev_info->dev_mac[0], (unsigned char)dev_info->dev_mac[1],
												(unsigned char)dev_info->dev_mac[2], (unsigned char)dev_info->dev_mac[3],
												(unsigned char)dev_info->dev_mac[4], (unsigned char)dev_info->dev_mac[5]);
						//byte_mac_to_str(dev_info->dev_mac, str_mac, MAC_LEN_BYTE);
						dzlog_info("ip=%s", dev_info->dev_ipaddr);
						//printf_hex((char *)str_mac, MAC_STR_LEN);  

						memset(send_pack, 0, sizeof(ZX_COMMUNICATION_PACKET));
						memcpy(send_pack, &comm_pack->msg_head, sizeof(ZX_COMM_HEAD));
						send_pack->msg_head.is_response = 0x01;
						send_pack->msg_head.param_len = 0;
						send_pack->msg_head.dev_type = comm_pack->msg_head.dev_type;
						AppclientDeviceDescriptor *dev_desc = zx_get_dev_descriptor_by_addr(sub1g_bink_ok->dev_addr_code);
						if (dev_desc && dev_desc->shortaddress > 0)					
							appclient_SendTxDataReq(dev_desc, (uint8_t *)send_pack, sizeof(ZX_COMM_HEAD));	
					
						int camera_channel = zx_match_dev(inet_addr(dev_info->dev_ipaddr), str_mac, strlen(str_mac));
						dzlog_info("[%s] mac=%s addr_code=%d ip=%s channel=%d", get_sub1g_command_str_info(comm_pack->msg_head.command_id), str_mac, 
									sub1g_bink_ok->dev_addr_code, dev_info->dev_ipaddr, camera_channel);

						if (camera_channel >= 0)
						{
							zx_update_channel_by_addr(sub1g_bink_ok->dev_addr_code, camera_channel, comm_pack->msg_head.dev_type);	
							//open_camera(camera_channel);
						}	
					}					
				}
				break;
			
			case SUB1G_REP_LOWPOWER:
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("%s [%d] report......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code); 
				}
				break;

			case SUB1G_REP_GSENSOR:
				{
					SUB1G_GSENSOR_REPORT *sub1g_gsensor_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.gsensor_report;
					dzlog_info("%s [%d] report x=%d y=%d z=%d......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_gsensor_rep->dev_addr_code, sub1g_gsensor_rep->x_value, sub1g_gsensor_rep->y_value, sub1g_gsensor_rep->z_value); 
				}
				break;

			case SUB1G_REP_PIR:
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					//dzlog_info("%s [%d] report......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code);
					if (gdev_base_param->hub_info.update_status == 1)
					{
						dzlog_info("hub updating......");
						break;
					}

					DEV_BASE_PARAM *dev_info = zx_get_dev_info_by_addr(sub1g_ctl_rep->dev_addr_code);
					if (dev_info)
					{
						if (dev_info->update_status == 1)
						{
							dzlog_info("dev updating......");
							break;
						}
						#if RUN_LOCAL_STORGE
						// new trigger local recording
						int channel = zx_get_dev_channel_by_shortaddr(sub1g_ctl_rep->dev_addr_code);
						if (channel >= 0)
						{
							pri_triger_handle_by_channel(channel);
						}
						#endif
					}
				} 
				break;
			case SUB1G_REP_CAMERA_DIED:
				break;


			case SUB1G_REP_AUDIO_DEC:                //SUB1G上报声音侦测事件
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("%s [%d] report......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code); 
				}
				break;
			case SUB1G_REP_LIGHT_DEC:                //SUB1G上报光感事件
				{
					SUB1G_LIGHT_REPORT *sub1g_light_rep = (SUB1G_LIGHT_REPORT *)&comm_pack->param_body.light_report;
					dzlog_info("%s R[%d] G[%d] B[%d] IR[%d] report......",get_sub1g_command_str_info(comm_pack->msg_head.command_id),  sub1g_light_rep->r_value, sub1g_light_rep->g_value, sub1g_light_rep->b_value, sub1g_light_rep->ir_value); 
				}
				break;
			case SUB1G_REP_KEY:                      //SUB1G上报按键事件
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("%s [%d] report......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code); 
				}
				break;

			case SUB1G_CMD_SLEEP:					//基站请求设备休眠
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("%s [%d] OK......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code);
					//printf_hex((char *)comm_pack, sizeof(ZX_COMM_HEAD));

					//sub1g_pipe = zx_write_pipe_by_shortaddr(sub1g_ctl_rep->dev_addr_code);		
					
					int channel = zx_get_dev_channel_by_shortaddr(sub1g_ctl_rep->dev_addr_code);
					if (channel >= 0)
					{
						sub1g_pipe = zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);
						//comm_pack.msg_head.
						if (sub1g_pipe)
						{
							dzlog_info("pipe0[%d] pipe1[%d]...... ", sub1g_pipe[0], sub1g_pipe[1]);
							write(sub1g_pipe[1], &comm_pack, sizeof(int));
						}
						zx_close_camera(channel);
					}					
				}
				break;
				
			case SUB1G_CMD_WAKEUP: 					//基站唤醒设备
			case SUB1G_CMD_CHECK_STATUS:		    //检查设备状态
			case SUB1G_CMD_GET_VOLTAGE:				//获取电池电量
			case SUB1G_CMD_GET_RSSI:				//获取SUB1G信号强度
			case SUB1G_CMD_OPEN_PIR:				//打开PIR
			case SUB1G_CMD_CLOSE_PIR:			    //关闭PIR
			case SUB1G_CMD_SET_PIR_SENSITIVITY:     //设置PIR灵密度
			case SUB1G_CMD_UPDATE_WIFI_INFO:        //基站更新设备wifi信息
			case SUB1G_CMD_OPEN_GSENSOR:			//打开GSENSOR
			case SUB1G_CMD_CLOSE_GSENSOR:			//关闭GSENSOR
			case SUB1G_CMD_SET_GSENSOR_SENSITIVITY:  //设置GSENSOR灵密度
			case SUB1G_CMD_OPEN_AUDIO_DEC:          //打开音频侦测
			case SUB1G_CMD_CLOSE_AUDIO_DEC:         //关闭音频侦测
			case SUB1G_CMD_OPEN_LED:                 //打开指示灯
			case SUB1G_CMD_CLOSE_LED:                //关闭指示灯
			case SUB1G_CMD_OPEN_LIGHT_DEC:           //打开光感
			case SUB1G_CMD_CLOSE_LIGHT_DEC:          //关闭光感
			case SUB1G_CMD_AUDIO_LOOPTEST:           //麦克、喇叭回环测试
			case SUB1G_CMD_OPEN_WIFI:                //打开WIFI
			case SUB1G_CMD_CLOSE_WIFI:               //关闭WIFI
			case SUB1G_CMD_WIFI_TXTEST:              //WIFI发射功率测试
			case SUB1G_CMD_WIFI_RXTEST:              //WIFI接收灵敏度测试
			case SUB1G_CMD_OPER_IRCUT:              //操作IRCUT
			case SUB1G_CMD_WRITE_SN:                //写设备SN
			case SUB1G_CMD_WRITE_MAC:               //写设备MAC
			case SUB1G_CMD_SWITCH_SERIAL:           //USB口切换3518串口
			case SUB1G_CMD_SET_LIGHT_SENSITIVITY:   //设置光感灵敏度
			case SUB1G_CMD_SET_IRLED_POWER:         //设置红外灯亮度
				{
					SUB1G_DEV_CONTROL_REP *sub1g_ctl_rep = (SUB1G_DEV_CONTROL_REP *)&comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("%s [%d] OK......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_ctl_rep->dev_addr_code);
					//sub1g_pipe = zx_write_pipe_by_shortaddr(sub1g_ctl_rep->dev_addr_code);	
					int channel = zx_get_dev_channel_by_shortaddr(sub1g_ctl_rep->dev_addr_code);
					if (channel >= 0)	
					{		
						sub1g_pipe = zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);	
						if (sub1g_pipe)
						{
							dzlog_info("pipe0[%d] pipe1[%d]...... ", sub1g_pipe[0], sub1g_pipe[1]);
							write(sub1g_pipe[1],  &comm_pack, sizeof(int));
						}
					}
					//printf_hex((char *)comm_pack, sizeof(ZX_COMM_HEAD)); 
				}
				break;
			

			case SUB1G_CMD_READ_SN:                  //读设备SN	
			case SUB1G_CMD_READ_MAC:                 //读设备MAC
			case SUB1G_CMD_GET_VERSION:
				{
					SUB1G_DEV_VERSION *sub1g_version = (SUB1G_DEV_VERSION *)&comm_pack->param_body.dev_version;
					dzlog_info("%s [%d] value=%s OK......", get_sub1g_command_str_info(comm_pack->msg_head.command_id), sub1g_version->dev_addr_code, sub1g_version->version);
					int channel = zx_get_dev_channel_by_shortaddr(sub1g_version->dev_addr_code);
					if (channel >= 0)	
					{		
						sub1g_pipe = zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);	
						if (sub1g_pipe)				
						{
							dzlog_info("pipe0[%d] pipe1[%d]...... ", sub1g_pipe[0], sub1g_pipe[1]);
							write(sub1g_pipe[1], &comm_pack, sizeof(int));
						}
					}
					//printf_hex((char *)comm_pack, sizeof(ZX_COMM_HEAD)); 
				}
				break;


			default:
				break;
		}
		//memset(&rec_data, 0, sizeof(ZX_MAG_DATA));
    }  
 
    if(msgctl(msg_id, IPC_RMID, 0) == -1)  
    {  
        dzlog_error("msgctl(IPC_RMID) failed");  
    }  

EXIT:
	if (send_pack)
	{
		free(send_pack);
		send_pack = NULL;
	}

	if (comm_pack)
	{
		free(comm_pack);
		comm_pack = NULL;
	}

	if (rec_data)
	{
		free(rec_data);
		rec_data = NULL;
	}
	#endif
	dzlog_info("end......");
	return 0;		
}


int zx_init_sub1g(HUB_BASE_PARAM *dev_param, void *list)
{
	#if 1
	int argc = 2;
	char *argv[2] = {"test","/etc_ro/appclient.cfg"};
	int i = 0;
	if (dev_param && list)
	{
		gdev_base_param = dev_param;
		gsub1g_con_list = (P2P_CONNECT_INFO *)list;
		for (i = 0; i < MAX_SUB1G_CONNECT; i++)
		{
			if (gdev_base_param->dev_param[i].sub1g_info.shortaddress == 0)
			{
				//gdev_base_param->dev_param[i].sub1g_info.shortaddress = -1;
				gdev_base_param->dev_param[i].channle_id = -1;	
			}	
		}

    	dzlog_info("enter...");    
    	int ret = appclient_Init(argc, argv);

		zx_create_thread(HIGH_PRIORITY, zx_sub1g_receive, NULL, -1, SUB1G_RECV, -1);
		gsub1g_msgid = zx_get_msgid_by_type(SUB1G_RECV);
		if (pipe(gsub1g_pipe) != 0)
			dzlog_error("create gsub1g_pipe fail...");  
	
    	dzlog_info("msgid=%d ret=%d", gsub1g_msgid, ret);   
		appclient_GetDeviceNum();
		return appclient_RegisterCallBacks(&app_Client_callback_list);
	}
	return -1;
	#endif
}


int zx_deinit_sub1g()
{
	dzlog_info("enter......");	
	close(gsub1g_pipe[0]);
	close(gsub1g_pipe[1]);
	return 0;
}


int zx_set_bind_status(int session_id, int timeout)
{
	gsession_id = session_id;
	dzlog_info("JointPermitReq=[%d] session=%d ", timeout, session_id);
	return appclient_SendJointPermitReq(timeout);
}

int zx_get_dev_count(void)
{
	#if 1
	int dev_count = appclient_GetDeviceNum();
	dzlog_info("GetDeviceNum[%d]...... ", dev_count);
	//if (dev_count > 0) 
	appclient_SendGetDeviceArrayReq();
	return dev_count;
	#endif
}


int zx_sub1g_wait_res(int command_id, int channel, int short_addr)
{
	fd_set rfds;
	struct timeval tv; 
    int try_count = 0;
	tv.tv_sec = 3;	// 加上retry时间不能超5秒( P2P 断线)
	tv.tv_usec = 0;

	ZX_COMMUNICATION_PACKET *comm_pack = NULL;
	SUB1G_DEV_CONTROL_REP *sub1g_dev_ctl_rep = NULL;

	//获取p2p管道
	int *sub1g_pipe = zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);
	
	if (sub1g_pipe == NULL)
	{
		dzlog_warn("channel %d, SUB1G_PIPE is NULL", channel);
		return ERROR_WAIT_TIMEOUT;
	}
	//dzlog_info("command_id[%d] channel[%d] pipe0[%d] pipe1[%d]...... ", command_id, channel, sub1g_pipe[0], sub1g_pipe[1]);

try_again:	

	FD_ZERO(&rfds);
	if (sub1g_pipe[0] >= 0)
		FD_SET(sub1g_pipe[0], &rfds);
	else
		return ERROR_NULL_POINT;

	switch(select(sub1g_pipe[0] + 1, &rfds, NULL, NULL, &tv))
	{
		case -1: 
			break; 

		case 0:
		{
			try_count++;
			if (try_count > TRY_COUNT)
			{
				return ERROR_WAIT_TIMEOUT;
			}
			else
			{
				tv.tv_sec = 0;
				tv.tv_usec = 500*1000;
				dzlog_info("try_count[%d] pipe=%d...... ", try_count, sub1g_pipe[0]);
				goto try_again;
			}
		}

        default: 
            {
				if(FD_ISSET(sub1g_pipe[0], &rfds)) 
				{
					FD_CLR(sub1g_pipe[0], &rfds);
					if (read(sub1g_pipe[0], &comm_pack, sizeof(int)) <=0)
					{
						dzlog_error("pipe read fail");
						break;	
					}
					if (command_id != comm_pack->msg_head.command_id)
					{
						tv.tv_sec = 0;
						tv.tv_usec = 500*1000;
						printf_hex((char *)comm_pack, sizeof(ZX_COMM_HEAD)); 
						dzlog_error("wait command[%d], but get command[%d]...... ", command_id, comm_pack->msg_head.command_id);
						goto try_again;
					}
					sub1g_dev_ctl_rep = &comm_pack->param_body.sub1g_ctl_rep;
					dzlog_info("get result[%d]...... ", sub1g_dev_ctl_rep->value);
					if (sub1g_dev_ctl_rep->value == 255)
						return 0;
					return sub1g_dev_ctl_rep->value;
				}
				break;
			}
	}
	return ERROR_WAIT_TIMEOUT;
}


int zx_sub1g_wait_res_ex(int command_id, char *value, int channel, int short_addr)
{
	fd_set rfds;
	struct timeval tv; 
    int try_count = 0;
	tv.tv_sec = 3;	// 加上retry时间不能超5秒( P2P 断线)
	tv.tv_usec = 0;
 
	ZX_COMMUNICATION_PACKET *comm_pack = NULL;
	SUB1G_DEV_VERSION *sub1g_dev_version = NULL;
	int *sub1g_pipe = zx_get_p2p_pipe_by_channel(channel, SUB1G_PIPE);
	if (sub1g_pipe == NULL)
		return ERROR_WAIT_TIMEOUT;

try_again: 

	FD_ZERO(&rfds);
	if (sub1g_pipe[0] >= 0)
		FD_SET(sub1g_pipe[0], &rfds);
	else
		return ERROR_NULL_POINT;   
	
	switch(select(sub1g_pipe[0] + 1, &rfds, NULL, NULL, &tv))
	{
		case -1: 
			break; 

		case 0:
			try_count++;
			if (try_count > TRY_COUNT)
			{
				return ERROR_WAIT_TIMEOUT;
			}
			else
			{
				tv.tv_sec = 0;
				tv.tv_usec = 500*1000;
				dzlog_info("try_count[%d] pipe=%d...... ", try_count, sub1g_pipe[0]);
				goto try_again;
			}
 
		default: 
		{
			if(FD_ISSET(sub1g_pipe[0], &rfds)) 
			{
				FD_CLR(sub1g_pipe[0], &rfds);
				read(sub1g_pipe[0], &comm_pack, sizeof(int));//COMM_HEARD_LEN + sizeof(SUB1G_DEV_VERSION)
				if (command_id != comm_pack->msg_head.command_id)
				{
					tv.tv_sec = 0;
					tv.tv_usec = 500*1000;
					dzlog_info("wait command[%d], but get command[%d]...... ", command_id, comm_pack->msg_head.command_id);
					goto try_again;
				}

				sub1g_dev_version = &comm_pack->param_body.dev_version;
				memcpy(value, sub1g_dev_version->version, sizeof(sub1g_dev_version->version));
				dzlog_info("get result[%s]...... ", sub1g_dev_version->version);
				return 0;
			}
			break;
		}
	}
	return ERROR_WAIT_TIMEOUT;
}


int zx_sub1g_send_command(int command_type, int channel, int value, int value1)
{
	#if 1
	dzlog_info("enter channel=%d...... ", channel);
	ZX_COMMUNICATION_PACKET send_data;
	AppclientDeviceDescriptor * dest_dev_info = NULL;
	
	memset(&send_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
	send_data.msg_head.head_tag = PAG_HEARD_TAG;

	//获取设备描述
	dest_dev_info = zx_get_dev_descriptor_by_channel(channel);	
	
	if (dest_dev_info)
	{
		if (dest_dev_info->shortaddress > 0)
		{
			send_data.msg_head.command_id = command_type; 
			
			/*++ yuxw add for wifi connect. */
			if( SUB1G_CMD_WAKEUP == command_type )
			{
				system("iwpriv ra0 set DisConnectAllSta=1"); // yuxw add for debug. test only.2018-03-30
			}
			/*-- yuxw add for wifi connect. */
			 
			switch (command_type)  
			{
				case SUB1G_CMD_SLEEP:                   //基站请求设备休眠
				case SUB1G_CMD_CHECK_STATUS:            //检查设备是否在线
				case SUB1G_CMD_OPEN_PIR:                //打开PIR
				case SUB1G_CMD_CLOSE_PIR:               //关闭PIR
				case SUB1G_CMD_OPEN_GSENSOR:            //打开GSENSOR
				case SUB1G_CMD_CLOSE_GSENSOR:           //关闭GSENSOR
				case SUB1G_CMD_GET_VOLTAGE:             //获取电池电量
				case SUB1G_CMD_GET_RSSI:                //获取SUB1G信号强度
				case SUB1G_CMD_OPEN_AUDIO_DEC:          //打开音频侦测
				case SUB1G_CMD_CLOSE_AUDIO_DEC:         //关闭音频侦测
				case SUB1G_CMD_OPEN_LIGHT_DEC:          //打开光感
				case SUB1G_CMD_CLOSE_LIGHT_DEC:         //关闭光感
				case SUB1G_CMD_AUDIO_LOOPTEST:          //麦克、喇叭回环测试
				case SUB1G_CMD_OPEN_WIFI:               //打开WIFI
				case SUB1G_CMD_CLOSE_WIFI:              //关闭WIFI
				{
					send_data.msg_head.param_len = 0; 
					send_data.msg_head.dev_type = 0x01;
					//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD));	
					
					dzlog_info("%s [%d] shortaddress=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress);
					
					if (command_type == SUB1G_CMD_SLEEP)
					{
						//清摄像头的标志
						int ret = clear_camera_clientmark(channel, value);
						
						if (ret == 0) // 投票可以关闭
						{
							//appclient 发送数据
							appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD));
						}
                        else
                        {
                            dzlog_info("this camera %d is busy, can't close!", channel);
                            return ERROR_DEV_BUSY;
                        }
					}
					else
					{
						//appclient 发送数据
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD));
					}
					
					return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
				}
				break;

				case SUB1G_CMD_WAKEUP:                  //基站唤醒设备
				case SUB1G_CMD_SET_PIR_SENSITIVITY:     //设置PIR灵密度
				case SUB1G_CMD_SET_GSENSOR_SENSITIVITY: //设置GSENSOR灵密度
				case SUB1G_CMD_OPER_IRCUT:              //操作IRCUT
				case SUB1G_CMD_OPEN_LED:                 //打开指示灯
				case SUB1G_CMD_CLOSE_LED:                //关闭指示灯
				case SUB1G_CMD_SWITCH_SERIAL:           //USB口切换3518串口		
				case SUB1G_CMD_SET_IRLED_POWER:         //设置红外灯亮度		
					{
						SUB1G_DEV_CONTROL *sub1g_dev_ctl = &send_data.param_body.sub1g_dev_ctl;
						send_data.msg_head.param_len = sizeof(SUB1G_DEV_CONTROL); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_dev_ctl->value = value;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;

				case SUB1G_CMD_SET_LIGHT_SENSITIVITY:    //设置光感灵敏度
					{
						SUB1G_LIGHT_SENSITIVITY *sub1g_light_ctl = &send_data.param_body.light_sensitivity;
						send_data.msg_head.param_len = sizeof(SUB1G_LIGHT_SENSITIVITY); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_light_ctl->value = value;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;

				case SUB1G_CMD_UPDATE_WIFI_INFO:        //基站更新设备wifi信息
					break;

				case SUB1G_CMD_DISASSOC_DEV:
					appclient_SendDisassocDevReq(dest_dev_info);
					dzlog_info("%s [%d] shortaddress=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress);	
					return 0;//zx_sub1g_wait_res(gsub1g_pipe[0]);					

				case SUB1G_CMD_GET_DEV_COUNT:
					appclient_GetDeviceNum();					
					return 0;

				case SUB1G_CMD_WIFI_TXTEST:              //WIFI发射功率测试
				case SUB1G_CMD_WIFI_RXTEST:              //WIFI接收灵敏度测试
					{
						SUB1G_DEV_WIFI_CONTROL *sub1g_dev_ctl = &send_data.param_body.wifi_ctl;
						send_data.msg_head.param_len = sizeof(SUB1G_DEV_WIFI_CONTROL); 
						send_data.msg_head.dev_type = 0x01;
						sub1g_dev_ctl->channel = value;
						sub1g_dev_ctl->type = value1;
						//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
						dzlog_info("%s [%d] shortaddress=%d value=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value);									
						appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_WIFI_CONTROL));
						return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
					}
					break;
				

				default:
					break;
			}         
		}
	}
	return ERROR_DEV_OFFLINE;
	#endif
}



int zx_sub1g_send_command_ex(int command_type, int channel, int value, char *value1)
{
#if 1
	dzlog_info("enter channel=%d...... ", channel);
	ZX_COMMUNICATION_PACKET send_data;
	AppclientDeviceDescriptor * dest_dev_info = NULL;
	memset(&send_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
	send_data.msg_head.head_tag = PAG_HEARD_TAG;
	dest_dev_info = zx_get_dev_descriptor_by_channel(channel);	
	if (dest_dev_info)
	{
		if (dest_dev_info->shortaddress > 0)
		{
			send_data.msg_head.command_id = command_type;  
			switch (command_type)  
			{
				case SUB1G_CMD_WRITE_SN:                 //写设备SN
				case SUB1G_CMD_WRITE_MAC:               //写设备MAC				
    			{
					SUB1G_SET_STR_PARAM *sub1g_str_param = &send_data.param_body.sub1g_str_param;
					send_data.msg_head.param_len = sizeof(SUB1G_SET_STR_PARAM); 
					send_data.msg_head.dev_type = 0x01;
					memcpy(sub1g_str_param->value, value1, strlen(value1)>SUB1G_EXTADDR_LEN?SHORT_STR_LEN:strlen(value1));
					//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD)+sizeof(SUB1G_DEV_CONTROL));	
					dzlog_info("%s [%d] shortaddress=%d value=%s...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress, value1);									
					appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + send_data.msg_head.param_len);
					return zx_sub1g_wait_res(command_type, channel, dest_dev_info->shortaddress);
				}
				break;	
		
				case SUB1G_CMD_READ_SN:                  //读设备SN	
				case SUB1G_CMD_READ_MAC:                 //读设备MAC
				case SUB1G_CMD_GET_VERSION:             //获取版本号
				{
					send_data.msg_head.param_len = 0; 
					send_data.msg_head.dev_type = 0x01;
					//printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD));	
					dzlog_info("%s [%d] shortaddress=%d...... ", get_sub1g_command_str_info(command_type), command_type, dest_dev_info->shortaddress);									
					appclient_SendTxDataReq(dest_dev_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD));
					return zx_sub1g_wait_res_ex(command_type, value1, channel, dest_dev_info->shortaddress);
				}
				break;

				case SUB1G_CMD_GET_MT_VERSION:     //获取sub1G网关版本号
				{
					appclient_SendGetMtVersionReq();
					return zx_sub1g_wait_res_ex(command_type, value1, channel, dest_dev_info->shortaddress);
				}

				default:
					break;
			}         
		}
	}
	return ERROR_DEV_OFFLINE;
#endif
}


int zx_sub1g_disassoc_all_dev(void)
{
	#if 1
	int i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress > 0)
		{
			appclient_SendDisassocDevReq(&gdev_base_param->dev_param[i].sub1g_info);
			//dzlog_info(" shortaddress=%d...... ", gdev_base_param->dev_param[i].sub1g_info.shortaddress);
		}
	}
#endif
}


int zx_sub1g_send_data(uint32_t dest, void *msg, int len)
{
	#if 1
	int i = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress > 0)
		{
			ZX_COMMUNICATION_PACKET send_data;
			memset(&send_data, 0, sizeof(ZX_COMMUNICATION_PACKET));
			send_data.msg_head.head_tag = PAG_HEARD_TAG;
			send_data.msg_head.command_id = SUB1G_CMD_BIND;                 
			send_data.msg_head.param_len = sizeof(SUB1G_DEV_BIND);  
			SUB1G_DEV_BIND *dev_bind = (SUB1G_DEV_BIND *)&send_data.param_body.sub1g_bind;  
			dev_bind->dev_addr_code = gdev_base_param->dev_param[i].sub1g_info.shortaddress;
			strcpy(dev_bind->dev_sn, "1234567890abcdef");
			strcpy(dev_bind->dev_mac, "AABBCC");           
			printf_hex((char *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_BIND)); 
			appclient_SendTxDataReq(&gdev_base_param->dev_param[i].sub1g_info, (uint8_t *)&send_data, sizeof(ZX_COMM_HEAD) + sizeof(SUB1G_DEV_BIND));
			usleep(500*1000);
		}
		else
			break;
	}
#endif
}

int zx_get_colector_version(char *version)
{
	if (version)
	{
		//appclient_SendGetMtVersionReq();
		zx_sub1g_wait_res_ex(SUB1G_CMD_GET_MT_VERSION, version, 128, 0);	
#if 0
		int len = strlen(version);
		if (len > 0)
			version[len - 1] = 0x00;	
#endif
		return 0;
	}
	return ERROR_NULL_POINT;
}


int zx_upload_dev_info(void)
{
#if 1
	int i = 0;
	zx_Error err;
	char str_value[2] = {0};
	char dev_status = 0;
	char dev_power_level = 0;
	for (i = 0; i < MAX_SUB1G_CONNECT; i++)
	{
		if (gdev_base_param->dev_param[i].sub1g_info.shortaddress > 0 &&  gdev_base_param->dev_param[i].channle_id >= 0) //
		{
			
		
			dev_status = zx_sub1g_send_command(SUB1G_CMD_CHECK_STATUS, gdev_base_param->dev_param[i].channle_id, 0, 0); 
			dzlog_info("dev_status=%d dev_sn=%s channel=%d...... ", dev_status, gdev_base_param->dev_param[i].dev_sn, gdev_base_param->dev_param[i].channle_id);
			if (dev_status >= 0)
			{
				dev_power_level = zx_sub1g_send_command(SUB1G_CMD_GET_VOLTAGE, gdev_base_param->dev_param[i].channle_id, 0, 0); //获取电量
				dzlog_info("dev_power=%d..... ", dev_power_level);
				sprintf(str_value, "%d", dev_power_level);	
				err = zx_upload_devs_params(gdev_base_param->hub_info.account_id, gdev_base_param->hub_info.hub_sn, gdev_base_param->dev_param[i].dev_sn, APP_CMD_GET_BATTERY, str_value);
				sprintf(str_value, "%d", 1);
			
			}
			else
			{
				sprintf(str_value, "%d", 0);
			}
		
		
			err = zx_upload_devs_params(gdev_base_param->hub_info.account_id, gdev_base_param->hub_info.hub_sn, gdev_base_param->dev_param[i].dev_sn, APP_CMD_GET_DEV_STATUS, str_value);
			
		}
		else
			break;
	}
#endif
	return 0;
}


int zx_dev_ota_process(void *version, void *version_720, const char *new_ver, int type)
{
	#if 1
	if (new_ver && version)
	{
		int i = 0;
		int ret = -1;
		VERSION_UPGRADE *tmp_version = (VERSION_UPGRADE *)version;
		VERSION_UPGRADE *version_720p = (VERSION_UPGRADE *)version_720;
		unsigned char bhave_down = 0;
		unsigned char bhave_down_720p = 0;
		char cur_ver[20] = {0};
		char hw_ver[SHORT_STR_LEN] = {0};
		char save_path[NORMAL_STR_LEN] = {0};
		char file_path[NORMAL_STR_LEN] = {0};
		char file_name[SHORT_STR_LEN] = {0};
        unsigned char bis_1080p = 0;
		
		for (i = 0; i < MAX_SUB1G_CONNECT; i++)
		{
			memset(&cur_ver, 0, sizeof(cur_ver));
			memset(&file_name, 0, sizeof(file_name));
			if (gdev_base_param->dev_param[i].sub1g_info.shortaddress > 0 && gdev_base_param->dev_param[i].channle_id >= 0) 
			{
				if (type == UPDATE_TYPE_SYS)
				{
					ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, gdev_base_param->dev_param[i].channle_id, WAKEUP_WITH_WIFI, 0);
					memset(&hw_ver, 0, sizeof(hw_ver));	
										
					if (ret == 0)
					{
						zx_wait_channel_ready(gdev_base_param->dev_param[i].channle_id, 30, 1);	
						ret = zx_get_dev_version(gdev_base_param->dev_param[i].channle_id, cur_ver, hw_ver);
						dzlog_info("dev 3518 new new_ver=%s cur_ver=%s", new_ver, cur_ver);
						if (strcmp(hw_ver, XM_CAM_1080P_HWMODEL) == 0)
						{
							bis_1080p = 1;	
							strcpy(file_name, DEV_MAIN_VER_NAME);
						} 
						else if (strcmp(hw_ver, XM_CAM_720P_HWMODEL) == 0)
						{
							bis_1080p = 0;	
							strcpy(file_name, DEV_MAIN_VER_NAME_720P);
						} 
						zx_sub1g_send_command(SUB1G_CMD_SLEEP, gdev_base_param->dev_param[i].channle_id, CLIENT_OTA, 0);
					}										
				}
				else if (type == UPDATE_TYPE_SUB1G)
				{			
					strcpy(file_name, DEV_SEC_VER_NAME);		
					zx_sub1g_send_command_ex(SUB1G_CMD_GET_VERSION, gdev_base_param->dev_param[i].channle_id, 0, &cur_ver);  //获取版本号
					dzlog_info("dev 1310 new new_ver=%s cur_ver=%s", new_ver, cur_ver);					 
				}

				if(strlen(cur_ver) > 0 && strcmp(new_ver, cur_ver) != 0)
				{
					memset(&save_path, 0, sizeof(save_path));
					memset(&file_path, 0, sizeof(file_path));
					FILE *fd = fopen(VERSION_TF_PATH, "r");   //判断TF卡是否存在
					if (fd)
						memcpy(save_path, VERSION_TF_PATH, strlen(VERSION_TF_PATH));
					else
					{	
						dzlog_error("****** file [%s] open error******", VERSION_TF_PATH);
						fd = fopen(VERSION_PATH, "r"); 	//没有TF卡就存储到tmp
						if (fd)
							memcpy(save_path, VERSION_PATH, strlen(VERSION_PATH));	
					}
					if (fd)  
					{  
						dzlog_info("upgrade version down : %s",save_path); 	
						gdev_base_param->dev_param[i].update_status = 1;
						
						if (bhave_down == 0 && bis_1080p)	
						{	
							zx_do_system("rm %s/%s", save_path, file_name);
		    				ret = zx_dnload_upgrade_version(save_path, tmp_version, file_name);
							if(ret != 0)
							{
								dzlog_error("****** zx_dnload_upgrade_version is error******");
								gdev_base_param->dev_param[i].update_status = 0;
								return -1;
							}  
							bhave_down = 1;
						}
                        if (bhave_down_720p == 0 && bis_1080p == 0)	
						{	
							zx_do_system("rm %s/%s", save_path, file_name);
							if (version_720p)
							{
		    					ret = zx_dnload_upgrade_version(save_path, version_720p, file_name);
								if(ret != 0)
								{
									dzlog_error("****** zx_dnload_upgrade_version is error******");
									gdev_base_param->dev_param[i].update_status = 0;
									return -1;
								}  
								bhave_down_720p = 1;
							}
							else
								return -1;
						}
							
						fclose(fd);
						sync();
						
						sprintf(file_path, "%s/%s", save_path, file_name);
						ret = zx_sub1g_send_command(SUB1G_CMD_WAKEUP, gdev_base_param->dev_param[i].channle_id, WAKEUP_WITH_WIFI, 0); //升级sub1g
						if (ret == 0)
						{
							ret = zx_update_xmdsp(gdev_base_param->dev_param[i].channle_id, file_path, type);
							if (ret == 0)
							{
								if (type == UPDATE_TYPE_SUB1G)
								{
									zx_hub_edit_devs_strinfo_by_paramname(gdev_base_param->dev_param[i].dev_sn, 
																		  gdev_base_param->hub_info.hub_sn, 
                                                                          gdev_base_param->hub_info.account_id, 
                     													  "sec_sw_version", new_ver);	
								}
								else if (type == UPDATE_TYPE_SYS)
								{
									zx_hub_edit_devs_strinfo_by_paramname(gdev_base_param->dev_param[i].dev_sn, 
																		  gdev_base_param->hub_info.hub_sn, 
                                                                          gdev_base_param->hub_info.account_id, 
                     													  "main_sw_version", new_ver);									
								}								
							}
							zx_sub1g_send_command(SUB1G_CMD_SLEEP, gdev_base_param->dev_param[i].channle_id, CLIENT_OTA, 0);
						}	
						gdev_base_param->dev_param[i].update_status = 0;						
					}
					else
					{
						dzlog_error("****** file [%s] open error******", VERSION_PATH);
						return -1;
					}			
		   			return 0; 
				} 
			}
		}
	}

	return ERROR_NULL_POINT;
	#endif
}


int zx_hub_sub1g_ota_process(void *version, const char *new_ver, const char *cur_ver)
{
	zx_create_dir(HUB_SUB1G_OTA_PATH);
	if (new_ver && cur_ver && version)
	{
		VERSION_UPGRADE *tmp_version = (VERSION_UPGRADE *)version;
		int ret = -1;
		dzlog_error("new_ver[%d]=%s cur_ver[%d]=%s", strlen(new_ver), new_ver, strlen(cur_ver), cur_ver);
		if(strlen(cur_ver) > 0 && strcmp(new_ver, cur_ver) != 0)
		{
			FILE *fd = fopen(HUB_SUB1G_OTA_PATH, "r");   //存放在制定路径
			if (fd)  
			{  
				zx_do_system("rm %s/%s", HUB_SUB1G_OTA_PATH, HUB_SEC_VER_NAME);
				//dzlog_info("can't fopen the TF card,upgrade version down : %s",VERSION_PATH); 			
		    	ret = zx_dnload_upgrade_version(HUB_SUB1G_OTA_PATH, tmp_version, HUB_SEC_VER_NAME);

				if(ret != 0)
				{
					dzlog_error("****** zx_dnload_upgrade_version is error******");
					return -1;
				}  
				fclose(fd);
				sync();
				zx_hub_update_info_by_infoname(gdev_base_param->hub_info.hub_sn, gdev_base_param->hub_info.account_id, "sec_sw_version", new_ver);
				appclient_SendOtaCC1310Req();
			}
		   	return 0; 
		}  		
	}
	return ERROR_NULL_POINT;
}





