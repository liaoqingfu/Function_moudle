/*
 ============================================================================
 Name        : circular_buffer.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-11-15 
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "circular_buffer.h"


zx_Bool query_queue(QUEUE *pQueue, QUEUE **ppQueue,int type, int queue_num)
{
	int nQueryQueueNum = queue_num;
	if (pQueue == NULL)
	{
		return zx_False;
	}
	while (nQueryQueueNum--)
	{
		if (pQueue->nUseFlag == type)
		{
			*ppQueue = pQueue;
			return zx_True;
		}
		pQueue = pQueue->pNextQueue;
	}
	return zx_False;
}


zx_Bool query_use_queue(QUEUE *pQueue, QUEUE **ppQueue, int queue_num)
{
	int nQueryQueueNum = queue_num;
	if (pQueue == NULL)
	{
		return zx_False;
	}
	while (nQueryQueueNum--)
	{
		if (pQueue->nUseFlag > NOTUSE)
		{
			*ppQueue = pQueue;
			return zx_True;
		}
		pQueue = pQueue->pNextQueue;
	}
	return zx_False;
}

QUEUE * create_queue(unsigned int queue_num, unsigned int buf_size)
{
	//dzlog_info("enter......");
	int i = 0;
	unsigned int list_num = queue_num; 
	if (queue_num == 0)
		return NULL;
	QUEUE *pQueueHead = NULL;
	QUEUE *pQueue = NULL;
	char *pFrameBuf = NULL;
	pQueueHead = (QUEUE *)malloc(sizeof(QUEUE) * list_num);
	if (NULL == pQueueHead)
	{
		dzlog_warn("pQueueHead == NULL");
		return NULL;
	}
	pFrameBuf = (char *)malloc(buf_size * list_num);
	if (NULL == pFrameBuf)
	{
		dzlog_warn("pFrameBuf == NULL");
		free(pQueueHead);
		return NULL;
	}

	memset(pQueueHead,0,sizeof(QUEUE) * list_num);
	memset(pFrameBuf,0,buf_size * list_num);
	pQueueHead->pFrameBuf = pFrameBuf;
	pQueueHead->nUseFlag = NOTUSE;
	pQueueHead->pNextQueue = NULL;
	pQueue = pQueueHead;
	i++;
	while (--list_num)
	{
		pQueue->pNextQueue = pQueueHead + i;
		pQueue = pQueue->pNextQueue;
		pQueue->pFrameBuf = pFrameBuf + i * buf_size;
		pQueue->nUseFlag = NOTUSE;
		pQueue->pNextQueue = NULL;
		pQueue->frame_size = 0;
		i++;
	}
	pQueue->pNextQueue = pQueueHead;
	//dzlog_info("queue=0x%X exit......", pQueueHead);
	return pQueueHead;
}

void clear_queue(QUEUE *pQueue,unsigned int queue_num)
{
	//dzlog_info("enter......");
	if (pQueue)
	{
		while (queue_num--)
		{
			pQueue->nUseFlag = NOTUSE;
			pQueue = pQueue->pNextQueue;
		}
	}
	//dzlog_info("exit......");
}

void destroy_queue(QUEUE *pQueue)
{
	//dzlog_info("enter......");
	if (pQueue)
	{
		if (pQueue->pFrameBuf)
		{
			free(pQueue->pFrameBuf);
		}
		pQueue->pFrameBuf = NULL;
		free(pQueue);
		pQueue = NULL;
	}
	dzlog_info("exit......");
}

