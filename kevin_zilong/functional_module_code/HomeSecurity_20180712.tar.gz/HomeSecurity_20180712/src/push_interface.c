/*============================================================================
 Name        : push_interface.c
 Author      : Oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : lucien.liu
 date        : 2017-12-04 
 Description :
 ============================================================================*/

/*
Attention: 
*	WiPN Call Step: 
	1. Get NDT Lib Version: NDT_PPCS_GetAPIVersion(...)
	2. Initialize the NDT: NDT_PPCS_Initialize(...) --> Note, for WiPN push, the device is equivalent to a client
	3. Network detection: NDT_PPCS_NetworkDetect(...) --> Detecting the network state
	4. Do Job:
		4.1. Call WiPN_Query: Query PostServerString and UTCTString, obtain PostServerDID
		4.2. Call WiPN_Post: When the Query is successful, According to the set interval time,call WiPN_Post to push message on time
	5. Before the end of the program needs to call NDT_PPCS_DeInitialize() release resources

请知悉:
*	 WiPN 设备端推送程序流程:
	1. 获取 NDT 库版本信息: NDT_PPCS_GetAPIVersion(...)  
	2. 初始化 NDT: NDT_PPCS_Initialize(...) --> 注意对于 WiPN 推送，设备相当于客户端
	3. 网络侦测: NDT_PPCS_NetworkDetect(...) --> 侦测网络状态
	4. 开始工作:
		4.1. 调用 WiPN_Query: 查询 PostServerString 与 UTCTString, 获取 PostServerDID
		4.2. 调用 WiPN_Post: 当查询成功之后，根据设定的推送时间间隔准点调用 WiPN_Post 来推送消息。
	5. 程序结束时调用 NDT_PPCS_DeInitialize() 释放资源
*/

#include "push_interface.h"
#include "as_interface.h"
#include "local_storage_interface.h"

// Save QueryServer DID
const CHAR *g_QueryServerDIDBuf[(QUERY_SERVER_NUMBER/4+1)*4] = {QUERY_SERVER_DID_1, QUERY_SERVER_DID_2,
																QUERY_SERVER_DID_3,	QUERY_SERVER_DID_4,
																QUERY_SERVER_DID_5,	QUERY_SERVER_DID_6};
HUB_BASE_PARAM *gpush_base_param = NULL;
extern unsigned char grunning;

//// Title, you must Todo: Modify this for your own Title
//CHAR g_Title[] = "home security message";
//// Content, you must Todo: Modify this for your own Content, This content will be displayed in the notification bar
//CHAR g_Content[SIZE_Content] = {0};			
//// Payload, you must Todo: Modify this for your own Payload
//CHAR g_Payload[SIZE_Payload] = {0};
//// message_type:1->Notification bar message,2->Payload. Only one of use
//// message_type need for XinGe Push, default 1
//CHAR g_SoundName[] = "doorbell.wav";

int gpush_msgid = -1;

#define USED_FACEID 1
typedef struct push_msg_st
{
    long int msg_type;
    char channel;
    char title[SIZE_Title];
    char content[SIZE_Content];
    char sn[SIZE_Title];    
    char doorSensorEvt;  //  1 = door close,2= door open,3 = low power,4 = enough power
}PUSH_MSG_ST;

int set_push_command(char *pCmd, unsigned short SizeOfCmd, const CHAR *pDeviceDID, const CHAR *pIPNLicense, 
			ULONG EventCH, const char *pTitle, const char *pContent, const char *pSoundName, 
			unsigned short Badge, const char *pPayload,	unsigned short Message_type)
{
	if (!pCmd 
		|| 0 == SizeOfCmd 
		|| !pDeviceDID 
		|| !pIPNLicense)
	{
		return WiPN_ERROR_InvalidParameter;
	}	
	if (0 == strlen(pDeviceDID) 
		|| 0 == strlen(pIPNLicense) 
		|| 0xFFFFFFFF < EventCH)
	{
		return WiPN_ERROR_InvalidParameter;
	}
	if (!pTitle) 
		pTitle = "";
	if (!pContent) 
		pContent = "";
	if (!pSoundName) 
		pSoundName = "";
	if (!pPayload) 
		pPayload = "";
	if (SIZE_Content+SIZE_Payload < strlen(pContent)+strlen(pPayload))
	{
		dzlog_info( "setCmd - Length Of Content and Payload Exceed %d bytes!!", SIZE_Content+SIZE_Payload);
		return WiPN_ERROR_ExceedMaxSize;
	}
	
	unsigned short Length_Title = ((strlen(pTitle)*4/3)/4+2)*4;
	char *title_Base64 = (char *)malloc(Length_Title);
	if (!title_Base64)
	{
		dzlog_error( "setCmd - Malloc title_Base64 Buf failed!!");
		return WiPN_ERROR_MallocFailed;
	}
	memset(title_Base64, 0, sizeof(title_Base64));
	// base64 Transformation Title
	Base64_Encode(pTitle, title_Base64);

	unsigned short Length_Content = (((strlen(pContent)*4)/3)/4+2)*4;
	char *Content_Base64 = (char *)malloc(Length_Content);
	if (!Content_Base64)
	{
		dzlog_error( "setCmd - Malloc Content_Base64 Buf failed!!");
		free((void*)title_Base64);
		return WiPN_ERROR_MallocFailed;
	}
	memset(Content_Base64, 0, Length_Content);
	// base64 Transformation Content 
	Base64_Encode(pContent, Content_Base64);
	
	unsigned short LengthAfterBase64 = 	strlen(pDeviceDID)
										+strlen(pIPNLicense)
										+sizeof(EventCH)
										+strlen(title_Base64)
										+strlen(Content_Base64)
										+strlen(pSoundName)
										+sizeof(Badge)
										+sizeof(Message_type);
	memset(pCmd, '\0', SizeOfCmd);
	if (NULL != pPayload && 0 != strlen(pPayload))
	{
		unsigned short Length_Payload = ((strlen(pPayload)*4/3)/4+2)*4;
		char *Payload_Base64 = (char*)malloc(Length_Payload);
		if (!Payload_Base64)
		{
			dzlog_error( "setCmd - Malloc Payload_Base64 Buf failed!!");
			free((void*)title_Base64);
			free((void*)Content_Base64);
			return WiPN_ERROR_MallocFailed;
		}
		memset(Payload_Base64, 0, Length_Payload);
		// base64 Transformation Payload 
		Base64_Encode(pPayload, Payload_Base64);
		
		if (LengthAfterBase64 + strlen(Payload_Base64) > SizeOfCmd - 1)
		{
			free((void*)title_Base64);
			free((void*)Content_Base64);
			free((void*)Payload_Base64);
			return WiPN_ERROR_ExceedMaxSize;
		}
		// Format Cmd
		SNPRINTF(pCmd, SizeOfCmd, "DID=%s&LNS=%s&CH=%lu&PINFO=title=%s,content=%s,sound=%s,badge=%d,payload=%s,Message_type=%d&", pDeviceDID, 
pIPNLicense, EventCH, title_Base64, Content_Base64, pSoundName, Badge, Payload_Base64, Message_type);
		
		if (Payload_Base64) 
			free((void*)Payload_Base64);
	}
	else 
	{
		if (LengthAfterBase64 > SizeOfCmd - 1)
		{
			free((void*)title_Base64);
			free((void*)Content_Base64);
			return WiPN_ERROR_ExceedMaxSize;
		}
		SNPRINTF(pCmd, SizeOfCmd, "DID=%s&LNS=%s&CH=%lu&PINFO=title=%s,content=%s,sound=%s,badge=%d,Message_type=%d&", pDeviceDID, pIPNLicense, 
				EventCH, title_Base64, Content_Base64, pSoundName, Badge, Message_type);
	}
	if (title_Base64) 
		free((void*)title_Base64);
	if (Content_Base64) 
		free((void*)Content_Base64);
	
	return 0;
}

// thread for WiPN Post 

void * thread_wipn_post(void *arg)
{
	P2P_BASE_INFO *p2p_info = arg;
	char ContentBuf[SIZE_Content] = {0};
	memset(ContentBuf, 0, sizeof(ContentBuf));
	
	char RETString[SIZE_RETString];
    memset(RETString, 0, sizeof(RETString)); 

	ULONG event_ch = 0;						// Event Channel: 0~0xFFFFFFFF
	UINT16 Push_mode = 0;
	UINT16 badge = 1;
	UINT16 message_type = 1;
	
	int msgid = zx_get_msgid_by_type(PUSH_INFO);
	
	time_t CurrentTime;
	struct tm *ptm;
	dzlog_info("enter[%d]-----------" , msgid);
	
	char Cmd[SIZE_DID + SIZE_iPNLicense	+ sizeof(ULONG) + SIZE_Title*2 + (SIZE_Content*4)/3	+ (SIZE_Payload*4)/3 + SIZE_SoundName+64] = {0};
	
	// Post Count
	static unsigned long PostCount = 0;
	char TimeBuf[] = "[yyyy-mm-dd hh:mm:ss]1234:";// 格式长度
	int Len_Content = 0;
	unsigned long Count = 0;
	int ret = -1;
	PUSH_MSG_ST push_msg;
	char payload[SIZE_Payload] = {0};
	char sound_name[] = "doorbell.wav";

	while (grunning)
	{
		memset(&push_msg, 0, sizeof(PUSH_MSG_ST));
		if(msgrcv(msgid, (void*)&push_msg, sizeof(PUSH_MSG_ST), 0, 0) == -1)  
        {  
            dzlog_error("msgrcv failed with errno: %d", errno);
			goto exit;
        } 
 
		//dzlog_info("content:%s  title=%s-----------", push_msg.content, push_msg.title);
		if (1000 <= ++PostCount)
		{
			PostCount = 0;
		}
	
		CurrentTime = time(NULL);
		ptm = localtime((const time_t *)&CurrentTime);
	
		// 在内容前面拼接时间和推送次数
		Len_Content = strlen(push_msg.content);
	
		if (((SIZE_Content - Len_Content) > strlen(TimeBuf)) && NULL != ptm)
		{
			// Content: 通知栏显示的内容,客户可以自定义
			SNPRINTF(ContentBuf, sizeof(ContentBuf), "[%04d-%02d-%02d %02d:%02d:%02d]%03ld:%s", ptm->tm_year+1900, 
					ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec, PostCount, push_msg.content);
		}
		else
		{
			memcpy(ContentBuf, push_msg.content, Len_Content);
		}
	
		if (ptm)
		{
			//{"sn":"T8001G0217530580","ch":0,"Path":"/media/mmcblk0p1/wert/19700101001012.dat"}
			//{\"s\":\"T8001G0217530460\",\"c\":0,\"n\":\"Hansen\",\"p\":\"20180521175522\",\"u\":\"http://tinyurl.com/y9t5ggea\"}
			// Payload: 透传给 App 的内容,格式为JSON
			memset(payload, 0, SIZE_Payload);
            switch (push_msg.msg_type)
            {
                case PUSH_SECURITY_EVT:
                {
                    LOCAL_FP_INFO * fileinfo = get_local_filerecord_by_channel(push_msg.channel);
                    if (fileinfo == NULL)
                    {
                        dzlog_info("msgsnd failed, channel=%d", push_msg.channel);
                        return -1;
                    }
                    char filename[32] = {0};
                    char *p = strrchr(fileinfo->filename, '/');
                    if (p != NULL)
                    {
                        p += 1;
                        memcpy(filename, p, strlen(p)-4); //只传文件名,path由APP补全(xxxx.dat)
                    }
                    char nick_name[20] = {0};
                    char short_url[32] = {0};
					
				#if 0
                    char *pname = zx_get_ai_nickname(fileinfo->faceid[0]);
                    if (pname)
                    {
                        memcpy(nick_name, pname, strlen(pname));
                        #if USED_FACEID
                        
                        #else
                        zx_get_faceid_url(gpush_base_param->hub_info.account_id,
                                          gpush_base_param->hub_info.hub_sn,
                                          fileinfo->faceid[0], short_url);
                        #endif
                    }
                    else
                    {
                        memcpy(nick_name, "visitor", 7);
                        #if USED_FACEID
                        
                        #else
                        strcpy(short_url, fileinfo->short_url);
                        #endif
                    }
				#endif
				
                    #if USED_FACEID
                    SNPRINTF(payload, SIZE_Payload,
                    "{\\\"s\\\":\\\"%s\\\",\\\"c\\\":%d,\\\"n\\\":\\\"%s\\\",\\\"p\\\":\\\"%s\\\",\\\"i\\\":\\\"%x\\\"}",
                     push_msg.sn, push_msg.channel, nick_name, filename, fileinfo->faceid[0]);
                    #else
                    SNPRINTF(payload, SIZE_Payload,
                    "{\\\"s\\\":\\\"%s\\\",\\\"c\\\":%d,\\\"n\\\":\\\"%s\\\",\\\"p\\\":\\\"%s\\\",\\\"u\\\":\\\"%s\\\"}",
                     push_msg.sn, push_msg.channel, nick_name, filename, short_url);
                    #endif
                }
                break;

                case PUSH_TFCARD_EVT:
                {
                    SNPRINTF(payload, SIZE_Payload,
                    "{\\\"s\\\":\\\"%s\\\",\\\"tfcard\\\":%d,\\\"t\\\":\\\"%ld\\\"}", push_msg.sn, push_msg.channel, time(0));
                }
                break;

                case PUSH_DOOR_SENSOR_EVT:
                {
                    SNPRINTF(payload, SIZE_Payload,
                        "{\\\"s\\\":\\\"%s\\\",\\\"c\\\":%d,\\\"t\\\":\\\"%ld\\\",\\\"e\\\":\\\"%d\\\"}",
                         push_msg.sn, push_msg.channel, time(0), push_msg.doorSensorEvt);
                }
                break;

                default:
                    break;
            }
#if 0
			SNPRINTF(payload, SIZE_Payload,  "%s", push_msg.payload);
#endif
			dzlog_info("Payload:%s. Size:%u byte", payload, (unsigned int)strlen(payload));
		}

		Count = PostCount;
	
		//// ------------------ Set Cmd ------------------
		ret = set_push_command(Cmd, 			// Buffer for Save CMD 
					sizeof(Cmd), 	            // Cmd Buf Size
					p2p_info->p2p_uid, 	        // Device DID
					p2p_info->push_license, 	// iPNLicense
					event_ch, 		            // Event Channel: 0~0xFFFFFFFF
					push_msg.title,             // Title
					ContentBuf, 	            // Content
					sound_name, 	            // SoundName
					badge, 		                // iOS proprietary parameters
					payload,		            // Directly through the message to App
					message_type);              // XinGe need it
		if (0 > ret)
		{
			dzlog_info("%u: set Cmd failed!! ret= %d [%s]", Count, ret, getErrorCodeInfo(ret));
			continue;			
			//pthread_exit(0);
		}
	//// ---------------------------------------------
	
		/*if (ptm)
		{
			dzlog_info("[%d-%d-%d %d:%d:%d] WiPN_Post[%u]...", ptm->tm_year+1900, ptm->tm_mon+1, 
						ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec, Count);
		}
		else
		{
			dzlog_info( "WiPN_Post[%u]...", Count);
		}*/	
		//dzlog_info( "WiPN_Post[%u]...", Count);	
		
		ret = WiPN_Post(p2p_info->push_post_server_string, Cmd, RETString, sizeof(RETString), 
					p2p_info->push_utct_string, sizeof(p2p_info->push_utct_string));
		if (0 > ret)
		{
			dzlog_error( "[%u] - Post failed! ret= %d [%s]", Count, ret, getErrorCodeInfo(ret));
		}  
    	else
    	{
        	time_t ServerTime = strtol(p2p_info->push_utct_string, NULL, 16);
			struct tm *ptm = localtime((const time_t*)&ServerTime);
			if (!ptm)
			{
				dzlog_info("%u: - RET= %s", Count, RETString);
				dzlog_info("%u: - UTCT= %s", Count, p2p_info->push_utct_string);
			}	 
			else
			{
				//dzlog_info("%u: RET= %s", Count, RETString); 
				//dzlog_info("%u: ServerTime: %d-%d-%d %d:%d:%d", Count, ptm->tm_year+1900, ptm->tm_mon+1, 
				//	ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec); 
			}			
			if (0 == strcmp(RETString, "OK"))
			{
				dzlog_info( "%u: Post success!", Count);
			}        
        	else
			{
				//dzlog_info( "%u: RET= %s", Count, RETString);
				//dzlog_info( "%u: UTCT= %s", Count, p2p_info->push_utct_string);
				dzlog_error( "%u: Post failed!", Count);
			}
    	}
		sleep(1);
	}
exit:
	dzlog_info("exit");
	pthread_exit(0);
}


int zx_init_push_server(HUB_BASE_PARAM *base_param) //char *init_str, char *aes128key, char *push_uid, char *push_license
{
	int ret = -1;
	if (base_param)
	{
		// 1. Get NDT Version. 
		UINT32 APIVersion;
		gpush_base_param = base_param;
		P2P_BASE_INFO *p2p_info = &base_param->p2p_info;	

		CHAR *API_Description = NDT_PPCS_GetAPIVersion(&APIVersion);
	
		dzlog_info("NDT API Version: %d.%d.%d.%d ", 
				 (APIVersion & 0xFF000000) >> 24, (APIVersion & 0x00FF0000) >> 16, (APIVersion & 0x0000FF00) >> 8, 
				 (APIVersion & 0x000000FF) >> 0);
	
		// 2. NDT Initialize  
		
		unsigned short Port = 0;//The working UDP Port Number, 0 -> decided by system.
		short tryCount = 0;
		while (grunning)
    	{
        	//dzlog_info("NDT_PPCS_Initialize(%s, %d, NULL, %s)...", p2p_info->p2p_initstr, Port, p2p_info->push_aes128_key);			
		
			ret = NDT_PPCS_Initialize(p2p_info->p2p_initstr, Port, NULL, p2p_info->push_aes128_key); //
			if (NDT_ERROR_NoError == ret)
			{
				dzlog_info("NDT_PPCS_Initialize ret = %d. Initialize Success!!", ret);
				break;
			}
			else 
			{
				dzlog_error("NDT_PPCS_Initialize ret = %d. [%s]", ret, getErrorCodeInfo(ret));
				if (NDT_ERROR_AlreadyInitialized == ret) // Already Initialize   
				{
					break;
				}			   
				else if (NDT_ERROR_ThreadCreateFailed == ret && 3 > tryCount++)
				{                     
					usleep(1000*1000);
					continue;
				}
				else
				{
					dzlog_error("NDT_PPCS_Initialize failed: %s", getErrorCodeInfo(ret));
					return ret;
				}
			}
    	} // while
		tryCount = 0;
	
		// 3. Network Detect. 
		st_NDT_NetInfo NetInfo;
		while (grunning)
		{
			dzlog_info("NDT_PPCS_NetworkDetect... ");			
		
			NDT_PPCS_NetworkDetect(&NetInfo, 3000); //// wait for 3 sec  
		
			dzlog_info("My Lan IP:Port=%s:%d", NetInfo.LanIP, NetInfo.LanPort);
			dzlog_info("My Wan IP:Port=%s:%d", NetInfo.WanIP, NetInfo.WanPort);
			dzlog_info("Server Hello Ack: %s", 1 == NetInfo.bServerHelloAck ? "Yes":"No");
		
			if (0 == NetInfo.bServerHelloAck && 2 > tryCount++)
			{
				dzlog_info("*** Warning!! CS didn't response!! Client from Internet won't be able to send command to Device.");
				usleep(500*1000);
			}
			else 
			{
				break;
			}
		} // while
		tryCount = 0;
	
		// 4. WiPN Query 
		while (1 == NetInfo.bServerHelloAck && 3 > tryCount++)
		{
			dzlog_info("WiPN_Query uid=%s... ", p2p_info->p2p_uid);			
		
			// For device，Just need to Query PostServerString and UTCTString, If you don't need SubscribeServerString, This parameter set NULL
			ret = WiPN_Query(p2p_info->p2p_uid, 				// Device DID
					g_QueryServerDIDBuf, 		                // QueryServer DID
					p2p_info->push_post_server_string, 		    // Save PostServerString
					sizeof(p2p_info->push_post_server_string),  // PostServerString Buffer Size
					NULL,                                       // If you don't need SubscribeServerString, This parameter set NULL.
					0, 
					p2p_info->push_utct_string, 				// Save UTCT
					sizeof(p2p_info->push_utct_string));		// UTCT Buffer Size

    		if (0 > ret)
			{
				dzlog_error("WiPN_Query: Query PostServerString failed!");
				usleep(500*1000);
			}
    		else
    		{
				dzlog_info("WiPN_Query: PostServerString= %s", p2p_info->push_post_server_string);
				dzlog_info("WiPN_Query: UTCTString= %s", p2p_info->push_utct_string);
				break;
        	}
			
		}  
		if (0 > ret)
		{
			zx_deinit_push_server();
			goto exit;
		}
		zx_create_thread(MID_PRIORITY, thread_wipn_post, p2p_info, -1, PUSH_INFO, -1);	
		gpush_msgid = zx_get_msgid_by_type(PUSH_INFO);
exit:	
		dzlog_info("exit... ");
	}
	return ret;
}

int zx_deinit_push_server(void)
{
	dzlog_info("enter ...");
	NDT_PPCS_DeInitialize();
	dzlog_info( "exit");
}


int zx_push_message(const char *title, const char *content, short channel)
{
    dzlog_info("[%d] %s %s ..." , gpush_msgid, title, content);
    if (gpush_msgid >=0 && title && content)
    {
        PUSH_MSG_ST push_msg;

        memset(&push_msg, 0, sizeof(PUSH_MSG_ST));
        memcpy(push_msg.title, title, strlen(title));
        memcpy(push_msg.content, content, strlen(content));

        push_msg.channel = channel;
        zx_get_dev_sn_by_channel(channel, push_msg.sn);

        push_msg.msg_type = PUSH_SECURITY_EVT;
        if(msgsnd(gpush_msgid, (void*)&push_msg, sizeof(PUSH_MSG_ST), 0) == -1)
        {
            dzlog_info("msgsnd failed[%d], %s", errno, strerror(errno));
            return -1;
        }
        return 0;
    }
    return -1;
}

int zx_push_message_door_sensor(const char *title, const char *content, short channel,char evt)
{
    dzlog_info("zx_push_message_door_sensor,channel = %d,evt = %d",channel,evt);
    //dzlog_info("[%d] %s %s ..." , gpush_msgid, title, content);
    if (gpush_msgid >=0 && title && content)
    {
        PUSH_MSG_ST push_msg;

        memset(&push_msg, 0, sizeof(PUSH_MSG_ST));
        memcpy(push_msg.title, title, strlen(title));
        memcpy(push_msg.content, content, strlen(content));

        push_msg.channel = channel;
        zx_get_dev_sn_by_channel(channel, push_msg.sn);

        push_msg.doorSensorEvt = evt;

        push_msg.msg_type = PUSH_DOOR_SENSOR_EVT;
        if(msgsnd(gpush_msgid, (void*)&push_msg, sizeof(PUSH_MSG_ST), 0) == -1)
        {
            dzlog_info("msgsnd failed[%d], %s", errno, strerror(errno));
            return -1;
        }  
        return 0;
    }
    return -1;
}

int zx_push_tfcard_message(const char *title, const char *content, char status)
{
    if (gpush_msgid >=0 && title && content)
    {
        PUSH_MSG_ST push_msg;

        memset(&push_msg, 0, sizeof(PUSH_MSG_ST));
        memcpy(push_msg.title, title, strlen(title));
        memcpy(push_msg.content, content, strlen(content));
        memcpy(push_msg.sn, gpush_base_param->hub_info.hub_sn, strlen(gpush_base_param->hub_info.hub_sn));
        push_msg.channel = status;
        push_msg.msg_type = PUSH_TFCARD_EVT;
        if(msgsnd(gpush_msgid, (void*)&push_msg, sizeof(PUSH_MSG_ST), 0) == -1)
        {
            dzlog_info("msgsnd failed[%d], %s", errno, strerror(errno));
            return -1;
        }
        return 0;
    }
    return -1;
}
