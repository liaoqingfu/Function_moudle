/*============================================================================
 Name        : hisi_interface.c
 Author      : oceanwing.com
 Copyright   : 2017(c) Shenzhen Oceanwing Smart Innovations Co., Ltd.
 Create      : brady.xiao
 Date        : 2018-04-27 
 Description : 
 ============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  
#include <sys/socket.h>  
#include <string.h>  
#include <netinet/in.h>  
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <curl/curl.h>
#include <curl/easy.h>
#include <sys/stat.h>
#include <termio.h>
#include <net/if.h>  
#include <netdb.h>
#include <arpa/inet.h>  
#include <sys/ioctl.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>


#include "ppcs_interface.h"
#include "hal.h"
#include "hal_audio.h"
#include "hal_interface.h"
#include "hal_pir.h"
#include "hal_video.h"
#include "cjson.h"
#include "hal_wifi.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_ircut.h"

#include "hisi_interface.h"
#include "hal_interface.h"
#include "comm_protocol_define.h"
#include "mgw_interface.h"
#include "local_storage_interface.h"
#include "push_stream.h"
#include "broadcast_interface.h"
#include "floodlight_interface.h"
#include "cloud_storage_interface.h"
#include "g711_codec.h"


FILE *g_pvideoFile = NULL;

P2P_CONNECT_INFO *hisi_gxm_con_list = NULL;
int hisi_gready_pipe[2] = {-1};
int hisi_gcommand_pipe[2] = {-1};
int hisi_gupdate_pipe[2] = {-1};
//视频回调
//buff                 视频BUFF    
//size                 视频数据长度
//stream_type          视频流类型  
//frame_type           视频帧类型 1-I帧 0-P帧
//frame_rate           帧率
//width height         分辨率
//ntimestamp           时间戳
//channel              通道号

QUEUE hisi_snapshot_queue;             // 因为缩略图比较大，这个定义一个queue
QUEUE* hisi_psnapshot_queue = NULL;

QUEUE* hisi_video_queue = NULL;     // 所有打开的camera共用一个queue, 当前约占用6.5M内存
QUEUE* hisi_audio_queue = NULL;

int hisi_gcount = 0;
int hisi_gaudio_count = 0;
extern int grunning;
char hisi_gcheck_ready = 0;

#define HISI_SAVE_VIDEO_DATA  0
#define HISI_SAVE_AUDIO_DATA  0

#if HISI_SAVE_VIDEO_DATA		
FILE *hisi_fp_video = NULL;
#define HISI_VIDEO_FILE_NAME 			"/mnt/sdcard/rec_video.h264"
#endif

#if HISI_SAVE_AUDIO_DATA		
FILE *hisi_fp_audio = NULL;
#define HISI_AUDIO_FILE_NAME 			"/mnt/sdcard/rec_audio.pcm"
FILE *hisi_fp_dec_audio = NULL;
#define HISI_AUDIO_DEC_FILE_NAME 		"/mnt/sdcard/dec_audio.pcm"
#endif

FILE *hisi_audio = NULL;


extern long long zx_LocalTime_ms(void);

char hisi_gdec_buf[AUDIO_FRAME_SIZE] = {0};
char hisi_genc_buf[AUDIO_FRAME_SIZE] = {0};

HISI_CAMERA_INFO hisi_gCamera_info[MAX_CAMERA_NUM] = {0};

extern HISI_CAMERA_INFO_DATA * hisi_cam_data;

extern HISI_WIFI_LIST_DATA *hisi_wifi_list;

extern HISI_CAMERA_WIFI_DATA *hisi_cam_wifi;

extern int p2p_status;







int hisi_ota_callback(unsigned int state,      /* ota状态 */
                           unsigned int err_code,   /* 错误代码 */
                           long reserve)           /* 保留 */

{
	dzlog_info("state %d ,err_code : %u , reserve : %ld",state,err_code,reserve);
	
	zx_mgw_setTimer(1,0);

	if(err_code == 0)
	{
		zx_do_system("%s", "reboot");
	}else{
		dzlog_error("ota update error : %u",err_code);
		return -1;
	}
	return 0;
}


int hisi_ota_test()		
{
	int ret = -1;
	//const char * path_bin = "/mnt/sdcard/update-OTA.bin";
	const char * path_bin = "/etc/update-OTA.bin";

	unsigned long bin_len = 0;
	
	hal_ota_register_cb(hisi_ota_callback);

	bin_len = get_file_size(path_bin);

	if(bin_len <= 0)
	{
		dzlog_error("get file size is error");
		return -1;
	}
	dzlog_info("get file size %lu",bin_len);
	
	ret = hal_ota_update(path_bin,bin_len,0);

	if(ret != 0)
	{
		dzlog_error("ota update is error ret :%d",ret);
		return ret;
	}
	dzlog_info("ota update is ok");
	return ret;
}



void hisi_pir_detect_cb(int ch)
{
	int ret = -1;
#if HISI_CAMERA_SWITCH
	dzlog_info("pir cb is ok ch : %d",ch);
	ret = zx_hisi_alarm_flood_bright();
	if(ret != 0)
	{
		dzlog_error("hisi alarm flood bright error");
		return;
	}
#endif

#if 0
	switch (ch)
	{
		case 0:
			dzlog_info("pir trigger left ok ch : %d",ch);		//pir的位置 0
			break;
		case 1:
			dzlog_info("pir trigger middle ok ch : %d",ch);		//pir的位置 1
			break;
		case 2:
			dzlog_info("pir trigger right ok ch : %d",ch);		//pir的位置 2
			break;
		default:
			dzlog_error("pir trigger error ch : %d",ch);
			break;
	}
#endif
}



int zx_hisi_connect_wifi_network(const char *ssid, const char *password)
{
	int ret = -1;
	char wifi_ssid[HISI_WIFI_DATA_LEN + 2] = {0};

	memcpy(wifi_ssid,ssid,strlen(ssid));
	
	ret = hal_set_wifi_sta_mode_and_connect(ssid,password);

	if(ret != 0)
	{
		dzlog_error("set wifi sta mode and connect error ret : %d",ret);
		return ret;
	}
	dzlog_info("set wifi sta mode and connect is ok");
	
WIFI_CHECK_AGAIN:
	ret = hal_wifi_check_link(wifi_ssid);
	
	if(ret < 2)
	{
		if(ret == 0)
		{
			dzlog_error("hal wifi check link not connect");
			ret = -1;
		}
		else if(ret == 1)
		{
			dzlog_warn("hal wifi check link is connecting");
			zx_mgw_setTimer(1,0);
			goto WIFI_CHECK_AGAIN;
		}
		else
			dzlog_error("hal wifi check link is error ret : %d",ret);
		
	}
	dzlog_info("wifi check is ok");

	return ret;
}




#if 0
int connect_video_server(void)
{
	int sockfd;
	struct sockaddr_in dest_addr;
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
	{
		dzlog_error("create socket error");
		return -1;
	}

    //阻塞式发达
	int nSendBuf = sizeof(COMM_HEARD_LEN+sizeof(VIDEO_FRAME));
	if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const char*)&nSendBuf, sizeof(int)) < 0) 
	{
		dzlog_error("setsockopt error");
		close(sockfd);
		return -1;
	}
	
	bzero(&dest_addr,sizeof(dest_addr));
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(9000);
	inet_pton(AF_INET,IP_ADDR_REMOTE, &dest_addr.sin_addr);
	if (connect(sockfd, (struct sockaddr*)&dest_addr, sizeof(dest_addr)) != 0)
	{
		dzlog_error("connect error");
		close(sockfd);
		return -1;
	}
	
	dzlog_info("connect the server=%s success",IP_ADDR_REMOTE);
	return sockfd;
	
}
#endif

void hisi_video_stream_cb_push(int ch, char *data, int len, 
unsigned int stream_type, unsigned int frame_type, 
unsigned int  u32Width , unsigned int  u32Height, long long pts)
{
	int frame_rate = 0;
	int gop = 0;
	int i = 0;
	
	int ret = hal_video_get_fpsAndgop(ch,&frame_rate,&gop);
	if(ret != 0)
	{
		dzlog_error("video get fps and gop");
		return;
	}
	if(stream_type == 1)
	{
		STREAM_CONNECT_INFO *stream_info = NULL;
		stream_info            = zx_get_stream(ch);
	    if (stream_info)			/*reserve != TFCARD_RD_FLAG && */
	    {
	      memset(&stream_info->videoInfo,0,sizeof(VIDEO_INFO));
	      stream_info->videoInfo.frame_rate   = frame_rate;
	      stream_info->videoInfo.width      = u32Width;
	      stream_info->videoInfo.height      = u32Height;
	      stream_info->videoInfo.frame_type   = frame_type;
	      stream_info->videoInfo.ntimestamp   = zx_LocalTime_ms();

	      if( len > VIDEO_FRAME_SIZE )
	      {
	        int sendCnt        = len/VIDEO_FRAME_SIZE;
	        
	        for(i = 0; i < sendCnt; i ++)
	        {
	          stream_info->videoInfo.frame_size = VIDEO_FRAME_SIZE;
	          zx_stream_send_video_frame(ch,data + VIDEO_FRAME_SIZE*i);
	        }
	        
	        stream_info->videoInfo.frame_size    = len - VIDEO_FRAME_SIZE*sendCnt;
	        zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*sendCnt);
	      }
	      else
	      {
	        stream_info->videoInfo.frame_size    = len;
	        zx_stream_send_video_frame(ch,data);
	      }
	      
	    }
	}
}



int hisi_video_push_stream()
{

	hal_video_register_stream_cb(hisi_video_stream_cb_push);
}

void hisi_audio_stream_cb_push(char *data, int len, unsigned int pts, void *user_data)
{
	//int audio_ch = *(int *)user_data;
	
	int audio_ch = HISI_CH0;
	int result = 0;
	
	dzlog_info("audio stream cb push start");
	
	STREAM_CONNECT_INFO *info = zx_get_stream(audio_ch);
	 
      if(info)
      {
        if(info->iControlThreadRun)
        {
          info->iAudioCallBackRunState = 1;
          QUEUE *aqueue = (QUEUE *)info->audio_queue;  
          if (aqueue)
          {
            if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE)){
              ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf; 
              memset(comm_head, 0, COMM_HEARD_LEN);
              comm_head->head_tag   = PAG_HEARD_TAG;
              comm_head->command_id   = APP_CMD_AUDIO_FRAME;
              comm_head->param_len   = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
              comm_head->version = COMM_VERSION;
              comm_head->channel_id   = audio_ch;
              comm_head->sign_code   = NO_SEC_KEY;
			  comm_head->dev_type = FLOODLIGHT;
              
              AUDIO_FRAME *audio     = (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];
              audio->frame_size     = len;
              audio->channel       = audio_ch;
              audio->ntimestamp     = pts;  
              
              audio->ntimestamp     = zx_LocalTime_ms();
              
              memcpy(audio->buf, data, len);
              
              aqueue->frame_size     = COMM_HEARD_LEN + comm_head->param_len; 
              aqueue->nUseFlag     = ADDTOQUEUE;
              result           = write(info->audio_pipe[1], &aqueue, sizeof(aqueue));
              //dzlog_info("audio_size=%d write=%d audio_pipe=%d......", size, result, gxm_con_list[i].audio_pipe[1]);                      
            }
            else
              dzlog_error("QUEUE FULL......");
          }
        }  
        info->iAudioCallBackRunState = 0;
      }
}


int hisi_audio_push_stream()
{
	//int ch = CH0;
	dzlog_info("hisi_audio_push_stream ok");
	hal_audio_register_cb(hisi_audio_stream_cb_push,NULL);
}






int hisi_get_camera_clientmark(short channel)
{
	int i;

	for (i = 0; i <= MAX_CAMERA_NUM; i++)
	{
		if (hisi_gCamera_info[i].channel == channel)
		{
			return hisi_gCamera_info[i].clientmark;
		}
	}
	return 0;
}


int hisi_set_camera_clientmark(short channel, short clientmark)
{
	int i;
	int ret = -1;

	for (i = 0; i < MAX_CAMERA_NUM; i++)
	{
		if (hisi_gCamera_info[i].channel == channel) // reopen
		{
			hisi_gCamera_info[i].clientmark |= clientmark;
			ret = 1;
			break;
		}
	}
	if (ret == -1)
	{
		for (i = 0; i < MAX_CAMERA_NUM; i++)
		{
			if (hisi_gCamera_info[i].channel == -1)
			{
				hisi_gCamera_info[i].channel = channel;
				hisi_gCamera_info[i].clientmark = clientmark;
				ret = 0;
				break;
			}
		}
	}
	dzlog_info("open camera channel = %d ,clientmark =%d", channel, hisi_gCamera_info[i].clientmark);
	return ret;
}




int zx_hisi_open_camera(int channel, short clientmark)
{
	int i;
	int ret = -1;
#if HISI_SAVE_VIDEO_DATA
	if(hisi_fp_video == NULL) 
	{
		hisi_fp_video = fopen(HISI_VIDEO_FILE_NAME, "wb");
		if(hisi_fp_video == NULL)
		{
			dzlog_error("open file %s failed", HISI_VIDEO_FILE_NAME);
		}
	}
#endif

#if HISI_SAVE_AUDIO_DATA
	if(hisi_fp_audio == NULL) 
	{
		hisi_fp_audio = fopen(HISI_AUDIO_FILE_NAME, "wb");
		if(hisi_fp_audio == NULL)
		{
			dzlog_error("open file %s failed", HISI_AUDIO_FILE_NAME);
		}
	}
	if(hisi_fp_dec_audio == NULL) 
	{
		hisi_fp_dec_audio = fopen(HISI_AUDIO_DEC_FILE_NAME, "wb");
		if(hisi_fp_dec_audio == NULL)
		{
			dzlog_error("open file %s failed", HISI_AUDIO_DEC_FILE_NAME);
		}
	}

#endif

#if 0
	if(hisi_audio == NULL)
	{
		hisi_audio = fopen(HISI_AUDIO_FILE,"wb");

		if(hisi_audio == NULL)
		{
			dzlog_error("open file %s failed error", HISI_AUDIO_FILE);
		}
	}

#endif

#if 0
	if (hisi_get_camera_clientmark(channel) != 0)
	{
		dzlog_warn("reopen camera %d", channel);
	}
#endif

	ret = hal_open_camera();

	if(ret != 0)
	{
		dzlog_error("open camera error ret = %d",ret);
	}else{
		
		//hisi_set_camera_clientmark(channel, clientmark);
		
		dzlog_info("open_camera ok, waiting data stream...");
	}
		
#if 0
	ret = zx_hisi_send_command(SUB1G_CMD_WAKEUP, channel, WAKEUP_WITH_VIDEO, 0);
	if (ret)
	{
		dzlog_error("open_camera error=%d", ret);
	}
	else
	{
		hisi_set_camera_clientmark(channel, clientmark);
		dzlog_info("open_camera ok, waiting data stream...");
	}
#endif
	return ret;
}

void hisi_clear_camera_status(short channel)
{
	int i;
	for (i = 0; i < MAX_CAMERA_NUM; i++)
	{
		if (hisi_gCamera_info[i].channel == channel)
		{
			hisi_gCamera_info[i].channel = -1;
			hisi_gCamera_info[i].clientmark = 0;
			break;
		}
	}
}


int zx_hisi_close_camera(int channel)
{
	int ret = -1;
	
	dzlog_info("enter channel=%d...", channel);
	hisi_gcount = 0;
	hisi_gaudio_count = 0;

	//ret = XMHAL_ReleaseChannle(channel);//XMHAL_UserOnline(0, channel);
	
	ret = hal_close_camera();

	if(ret != 0)
	{
		dzlog_error("close camera error ret = %d",ret);
		return ret;
	}
	
	hisi_clear_camera_status(channel);

#if HISI_SAVE_AUDIO_DATA		
	if(hisi_fp_audio) 
	{
		fclose(hisi_fp_audio);
		hisi_fp_audio = NULL;	
	}	
	if(hisi_fp_dec_audio) 
	{
		fclose(hisi_fp_dec_audio);
		hisi_fp_dec_audio = NULL;	
	}			
#endif

#if HISI_SAVE_VIDEO_DATA		
	if(hisi_fp_video) 
	{
		fclose(hisi_fp_video);
		hisi_fp_video = NULL;	
	}				
#endif

	dzlog_info("ret = %d exit...", ret);

	return ret;
}




#if 0
/*
int zx_video_callback(char *buff, int size, int stream_type, int frame_type, int frame_rate,
	                  int width, int height, long long ntimestamp, int channel, long reserve)
*/
void zx_hisi_video_callback_function (int ch, char *data, int len, 
unsigned int stream_type, unsigned int frame_type, 
unsigned int  u32Width , unsigned int  u32Height, long long pts)
{
	
#if 0
	if (hisi_gcount == 0)
		dzlog_info("******** enter Video: channel = %d, video size = %d, %d x %d, stream_type = %d , isIframe = %d ", ch, len, u32Width, u32Height, stream_type,frame_type);
#endif

	QUEUE * queue = NULL;
	QUEUE * vqueue = NULL;
	int i = 0;
	int session_handle = -1;
	int msg_id = -1;
	int result = -1;
	int temp_size = 0;
	int multiple = 0;
	LOCAL_FP_INFO* file_info = NULL;
	STREAM_CONNECT_INFO *stream_info = NULL;
	
	int frame_rate = 0;		//码率
	int gop = 0;			//I帧间隔
	
#if 0
    if (len > VIDEO_FRAME_SIZE)
		dzlog_info("******** enter Video: channel = %d, size = %d, %d x %d, isIframe = %d ********", ch, len, u32Width, u32Height, frame_type);
#endif


	
	int ret = hal_video_get_fpsAndgop(ch,&frame_rate,&gop);
	if(ret != 0)
	{
		dzlog_error("video get fps and gop");
		return;
	}


	if (data)
	{
#if HISI_SAVE_VIDEO_DATA		
		if(hisi_fp_video ) 
		{
			fwrite(data, 1, len, hisi_fp_video);	
		}				
#endif
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			temp_size = len;
			multiple = 0;
			session_handle = hisi_gxm_con_list[i].session_handle;
			if (session_handle >= 0 ) // P2P or playback
			{
				if (hisi_gxm_con_list[i].channel == ch /*|| reserve == TFCARD_RD_FLAG*/)
				{ // 回放时，channel = -1，PIR打开的数据不会从当前 session 发出去
trans_next:
					queue = (QUEUE *)hisi_gxm_con_list[i].video_queue;
					if (queue)
					{
						//dzlog_info("queue in %d......", size);
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXVIDEOQUEUE)) 
			            {
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;	
							VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_VIDEO_FRAME;

							comm_head->version = COMM_VERSION;		//根据时间产生一个无规律的随机数
							
							comm_head->channel_id = ch;
							comm_head->sign_code = NO_SEC_KEY;
							
							video->frame_rate = frame_rate;
							video->width = u32Width;
							video->height = u32Height;
							video->frame_type = frame_type;
							video->ntimestamp = pts;

							if (temp_size > VIDEO_FRAME_SIZE)
							{
								comm_head->param_len = sizeof(VIDEO_FRAME);	
								temp_size = temp_size - VIDEO_FRAME_SIZE;
								video->frame_size = VIDEO_FRAME_SIZE;
								memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
								multiple++;
								queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
								queue->nUseFlag = ADDTOQUEUE;	
								result = write(hisi_gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
								goto trans_next;
							}
							else
							{
								video->frame_size = temp_size;
								comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
								memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], temp_size);
								temp_size = 0;
							}
							
							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
							queue->nUseFlag = ADDTOQUEUE;	
							result = write(hisi_gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
							//if (gcount == 0)
							//	dzlog_info("queue=0x%X video_size=%d ......", queue, size);
												
						}
						else
						{
							dzlog_error("QUEUE FULL......");
							//dzlog_info("queue out......");
						}
					}
				}
			} 
		}

#if RUN_LOCAL_STORGE
		if (TFCARD_RD_FLAG ) /*if(reserve != TFCARD_RD_FLAG)*/
		{
			file_info = get_local_filerecord_by_channel(ch);
			if (file_info != NULL && file_info->record_flag) // 这个channel有PIR触发
			{
				if (file_info->frame_num > 0 || frame_type == FRAME_TYPE_I)
				{// 第一帧录像要为I帧
					temp_size = len;
					multiple = 0;
					
                    pts = zx_LocalTime_ms(); // 相同的frame，时间不变
local_trans_next:
					if (query_queue(hisi_video_queue, &queue, NOTUSE, HISI_VIDEO_MAX_QUEUE))
					{
						ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
						VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
						memset(comm_head, 0, COMM_HEARD_LEN);

						comm_head->head_tag = PAG_HEARD_TAG;
						comm_head->command_id = APP_CMD_VIDEO_FRAME;
						
						comm_head->version = COMM_VERSION;
						comm_head->channel_id = ch;
						comm_head->sign_code = NO_SEC_KEY;

						video->frame_rate = frame_rate;
						video->width = u32Width;
						video->height = u32Height;
						video->frame_type = frame_type;
						video->ntimestamp = pts;

						if (temp_size >= VIDEO_FRAME_SIZE)
						{
							comm_head->param_len = sizeof(VIDEO_FRAME);
							video->frame_size = VIDEO_FRAME_SIZE;
							memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
							temp_size = temp_size - VIDEO_FRAME_SIZE;
							multiple++;

							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
							queue->nUseFlag = ADDTOQUEUE;
							result = write(file_info->Local_video_pipe[1], &queue, sizeof(queue));
							goto local_trans_next;
						}
						else
						{
							comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
							video->frame_size = temp_size;
							memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], temp_size);
							temp_size = 0;
						}

						queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
						queue->nUseFlag = ADDTOQUEUE;
						write(file_info->Local_video_pipe[1], &queue, sizeof(queue));
					}
					else
					{
						dzlog_error("video QUEUE FULL......");
                        file_info->end_time = pts; //提前结束
					}
					
				}
			}
		}
#endif

#if RUN_PUSH_STREAM
		stream_info = zx_get_stream(ch);
		/*if (reserve != TFCARD_RD_FLAG && stream_info)*/
		if ( stream_info)
		{
			VIDEO_INFO     		videoInfo;
			memset(&videoInfo,0,sizeof(VIDEO_INFO));
			videoInfo.frame_rate   = frame_rate;
			videoInfo.width	   	   = u32Width;
			videoInfo.height	   = u32Height;
			videoInfo.frame_type   = frame_type;
			videoInfo.ntimestamp   = zx_LocalTime_ms();

			if( len > VIDEO_FRAME_SIZE )
			{
				int sendCnt 			 = len/VIDEO_FRAME_SIZE;
				
				for(i = 0; i < sendCnt; i ++)
				{
					videoInfo.frame_size = VIDEO_FRAME_SIZE;
					zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*i);
				}
				
				videoInfo.frame_size 	 = len - VIDEO_FRAME_SIZE*sendCnt;
				
				zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*sendCnt);
			}
			else
			{
				videoInfo.frame_size 	 = len;
				zx_stream_send_video_frame(ch, data);
			}
			
		}
		
#endif
		
	}
	
	hisi_gcount++;
	if (hisi_gcount == 100)
		hisi_gcount = 0;	
#if 0	
	if (hisi_gcount == 0)
	{
		//dzlog_info("exit......");		
	}	
#endif
	return;
}

//音频回调            
//编码格式			   G711A
//buff                 音频BUFF    
//size                 音频数据长度
//ntimestamp           时间戳
//channel              通道号


/*int zx_audio_callback(char *buff, int size, long long ntimestamp, int channel, long reserve)*/
void zx_hisi_audio_callback_function(char *data, int len, unsigned int pts, void *user_data)
{
	QUEUE * queue = NULL;
	int i = 0;
	int session_handle = -1;
	int msg_id = -1;
	int result = -1;	
	LOCAL_FP_INFO* file_info = NULL;
	int channel = HISI_CH0;
	int lengnth = 0;

#if HISI_SAVE_AUDIO_DATA	

	g711a_decode((unsigned char*)data, &hisi_gdec_buf, len);

	g711a_encode(hisi_gdec_buf, (unsigned char*)&hisi_genc_buf, len*2);	
	
	if(hisi_fp_audio) 
	{
		fwrite(hisi_genc_buf, 1, len, hisi_fp_audio);	
	}
	
	if(hisi_fp_dec_audio) 
	{
		fwrite(hisi_gdec_buf, 1, len*2, hisi_fp_dec_audio);	
	}
#endif


#if 0
	if (hisi_gaudio_count == 0)
		dzlog_info("Audio: channel = %d, auto size = %d", channel, len);
#endif

	hisi_gaudio_count++;
	if (hisi_gaudio_count == 100)
		hisi_gaudio_count = 0;

	if(data)
	{
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			session_handle = hisi_gxm_con_list[i].session_handle;
			
			if (session_handle >= 0 )
			{
				if (hisi_gxm_con_list[i].channel == channel /*|| reserve == TFCARD_RD_FLAG*/)
				{
					queue = (QUEUE *)hisi_gxm_con_list[i].audio_queue;
					
					if (queue)	
					{
						//dzlog_info("queue in %d......", len);
						
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXAUDIOQUEUE)) 
			            {
							
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;	
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_AUDIO_FRAME;
							comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
							comm_head->version = COMM_VERSION;
							comm_head->channel_id = channel;
							comm_head->sign_code = NO_SEC_KEY;

							AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size = len;
							audio->channel = channel;
							audio->ntimestamp = pts;
							memcpy(audio->buf, data, len);
							
							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
							queue->nUseFlag = ADDTOQUEUE;
							
							result = write(hisi_gxm_con_list[i].audio_pipe[1], &queue, sizeof(queue));
#if 0
							XMHAL_AudioPlay(data, len, channel);

							hal_audio_out(data,len);
#endif
							//dzlog_info("audio_size=%d write=%d audio_pipe=%d......", len, result, hisi_gxm_con_list[i].audio_pipe[1]);											
						}
						else
						{
							dzlog_error("QUEUE FULL......");
						///dzlog_info("queue out......");
						}
					}
				}				
			} 
		}

#if RUN_LOCAL_STORGE
		/*if (reserve != TFCARD_RD_FLAG)*/
		if (TFCARD_RD_FLAG)
		{
			file_info = get_local_filerecord_by_channel(channel);
			if (file_info != NULL && file_info->record_flag && file_info->frame_num) // 这个channel有PIR触发
			{
				pts = zx_LocalTime_ms();
				if (query_queue(hisi_audio_queue, &queue, NOTUSE, HISI_AUDIO_MAX_QUEUE))
				{
					ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
					memset(comm_head, 0, COMM_HEARD_LEN);
					if ( len > AUDIO_FRAME_SIZE)
					{
						len = AUDIO_FRAME_SIZE;
					}
					comm_head->head_tag = PAG_HEARD_TAG;
					comm_head->command_id = APP_CMD_AUDIO_FRAME;
					comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
					comm_head->version = COMM_VERSION;
					comm_head->channel_id = channel;
					comm_head->sign_code = NO_SEC_KEY;

					AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
					audio->frame_size = len;
					audio->channel = channel;
					audio->ntimestamp = pts;
					memcpy(audio->buf, data, len);
					queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
					queue->nUseFlag = ADDTOQUEUE;

					write(file_info->Local_audio_pipe[1], &queue, sizeof(queue));
				}
				else
				{
					dzlog_error("audio QUEUE FULL......");
					file_info->end_time = pts;
				}
			}
		}
#endif	


#if RUN_PUSH_STREAM
		/*if (reserve != TFCARD_RD_FLAG)*/
		if (TFCARD_RD_FLAG)
		{
			//static int audioFrameCnt  = 0;
			STREAM_CONNECT_INFO *info = zx_get_stream(channel);
			
			if(info)
			{
				if(info->iControlThreadRun)
				{
					info->iAudioCallBackRunState = 1;
					QUEUE *aqueue = (QUEUE *)info->audio_queue;	
					
					if (aqueue)
					{
						if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE)){
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf; 
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag 	= PAG_HEARD_TAG;
							comm_head->command_id   = APP_CMD_AUDIO_FRAME;
							comm_head->param_len 	= sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
							comm_head->version = COMM_VERSION;
							comm_head->channel_id 	= channel;
							comm_head->sign_code 	= NO_SEC_KEY;
							
							AUDIO_FRAME *audio 		= (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size 		= len;
							audio->channel 			= channel;
							audio->ntimestamp 		= pts;	
							//audio->ntimestamp 		= audioFrameCnt*1000*1024/8000;
							audio->ntimestamp 		= zx_LocalTime_ms();
							
							//audioFrameCnt ++;
							memcpy(audio->buf, data, len);
							
							aqueue->frame_size 		= COMM_HEARD_LEN + comm_head->param_len; 
							aqueue->nUseFlag 		= ADDTOQUEUE;
							result 					= write(info->audio_pipe[1], &aqueue, sizeof(aqueue));
							//dzlog_info("audio_size=%d write=%d audio_pipe=%d......", len, result, hisi_gxm_con_list[i].audio_pipe[1]);											
						}
						else
							dzlog_error("QUEUE FULL......");
					}
				}	
				info->iAudioCallBackRunState = 0;
			}

		}
#endif
	}

	return;
}
#endif


void zx_hisi_video_callback_function (int ch, char *data, int len, 
unsigned int stream_type, unsigned int frame_type, 
unsigned int  u32Width , unsigned int  u32Height, long long pts)
{
	

	QUEUE * queue = NULL;
	QUEUE * vqueue = NULL;
	int i = 0;
	int session_handle = -1;
	int msg_id = -1;
	int result = -1;
	int temp_size = 0;
	int multiple = 0;
	LOCAL_FP_INFO* file_info = NULL;
	STREAM_CONNECT_INFO *stream_info = NULL;
	
	int frame_rate = 0;		//帧率
	int gop = 0;			//I帧间隔

	int bitrate = 0;
	BITRATE_MODE_E mode;
	
#if 0
    if (len > VIDEO_FRAME_SIZE)
		dzlog_info("******** enter Video: channel = %d, size = %d, %d x %d, isIframe = %d ********", ch, len, u32Width, u32Height, frame_type);

#if 0
    if (len > VIDEO_FRAME_SIZE || frame_type == FRAME_TYPE_I)
    {
        dzlog_info("Video: channel = %d, size = %d, %d x %d, isIframe = %d, IR_mode: %d",
                    channel, size, width, height, frame_type, IR_mode);
    }
#endif
#endif


	
	int ret = hal_video_get_fpsAndgop(ch,&frame_rate,&gop);
	if(ret != 0)
	{
		dzlog_error("video get fps and gop");
		return;
	}

	hal_video_get_bitrate(HISI_CH0,&bitrate,&mode);

#if 0
	if (hisi_gcount == 0)
		dzlog_info("******** enter Video: channel = %d, video size = %d, %d x %d, \
		stream_type = %d , frame_type = %d frame_rate = %d gop = %d bitrate = %d mode = %d", \
		ch, len, u32Width, u32Height, stream_type,frame_type,frame_rate,gop,bitrate,mode);
#endif


	if (data)
	{
#if HISI_SAVE_VIDEO_DATA		
		if(hisi_fp_video ) 
		{
			fwrite(data, 1, len, hisi_fp_video);	
		}				
#endif
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			temp_size = len;
			multiple = 0;
			session_handle = hisi_gxm_con_list[i].session_handle;
			if (session_handle >= 0 ) // P2P or playback
			{
				if (hisi_gxm_con_list[i].channel == ch /*|| reserve == TFCARD_RD_FLAG*/)
				{ // 回放时，channel = -1，PIR打开的数据不会从当前 session 发出去
trans_next:
					queue = (QUEUE *)hisi_gxm_con_list[i].video_queue;
					if (queue)
					{
						//dzlog_info("queue in %d......", len);
						
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXVIDEOQUEUE)) 
			            {
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;	
							VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_VIDEO_FRAME;

							comm_head->version = COMM_VERSION;		//根据时间产生一个无规律的随机数
							
							comm_head->channel_id = ch;
							comm_head->sign_code = NO_SEC_KEY;
							comm_head->dev_type = FLOODLIGHT;
							
							video->frame_rate = frame_rate;
							video->width = u32Width;
							video->height = u32Height;
							video->frame_type = frame_type;
							video->ntimestamp = pts;

							if (temp_size > VIDEO_FRAME_SIZE)
							{
								comm_head->param_len = sizeof(VIDEO_FRAME);	
								temp_size = temp_size - VIDEO_FRAME_SIZE;
								video->frame_size = VIDEO_FRAME_SIZE;
								memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
								multiple++;
								queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
								queue->nUseFlag = ADDTOQUEUE;	
								result = write(hisi_gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
								dzlog_info("【Video_size=%d write=%d Video_pipe=%d queue_size = %d......】", len, result, hisi_gxm_con_list[i].video_pipe[1],queue->frame_size);	
								goto trans_next;
							}
							else
							{
								video->frame_size = temp_size;
								comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
								memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], temp_size);
								temp_size = 0;
							}
							
							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
							queue->nUseFlag = ADDTOQUEUE;	
							result = write(hisi_gxm_con_list[i].video_pipe[1], &queue, sizeof(queue));
							dzlog_info("【Video_size=%d write=%d Video_pipe=%d queue_size = %d......】", len, result, hisi_gxm_con_list[i].video_pipe[1],queue->frame_size);	
							//if (gcount == 0)
							//	dzlog_info("queue=0x%X video_size=%d ......", queue, temp_size);
												
						}
						else
						{
							dzlog_error("QUEUE FULL......");
							//dzlog_info("queue out......");
						}
					}
				}
			} 
		}

#if RUN_LOCAL_STORGE
		if (TFCARD_RD_FLAG ) /*if(reserve != TFCARD_RD_FLAG)*/
		{
			//dzlog_info("local storage video...");
			
			file_info = get_local_filerecord_by_channel(ch);
			
			if (file_info != NULL && file_info->record_flag) // 这个channel有PIR触发,或者设置为全天录像
			{
				dzlog_info("local storage video file_info...");
				
				if (file_info->frame_num > 0 || frame_type == FRAME_TYPE_I)
				{// 第一帧录像要为I帧
					temp_size = len;
					multiple = 0;

				#if 0
                    pts = zx_LocalTime_ms(); // 相同的frame，时间不变		,本地时间有问题
                #endif
local_trans_next:
					if (query_queue(hisi_video_queue, &queue, NOTUSE, HISI_VIDEO_MAX_QUEUE))
					{
						dzlog_info("local storage video query...");
						ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
						VIDEO_FRAME *video = (VIDEO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
						memset(comm_head, 0, COMM_HEARD_LEN);

						comm_head->head_tag = PAG_HEARD_TAG;
						comm_head->command_id = APP_CMD_VIDEO_FRAME;
						
						comm_head->version = COMM_VERSION;
						comm_head->channel_id = ch;
						comm_head->sign_code = NO_SEC_KEY;
                        comm_head->dev_type = FLOODLIGHT;
						
                        if (frame_rate) // 生成mp4文件时需要frame_rate计算时间
                        {
                            video->frame_rate = frame_rate;
                        }
                        else
                        {
                            video->frame_rate = FRAME_RATE;
                        }
						
						video->width = u32Width;
						video->height = u32Height;
						video->frame_type = frame_type;
						video->ntimestamp = pts;

						if (temp_size >= VIDEO_FRAME_SIZE)
						{
							comm_head->param_len = sizeof(VIDEO_FRAME);
							video->frame_size = VIDEO_FRAME_SIZE;
							memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], VIDEO_FRAME_SIZE);
							temp_size = temp_size - VIDEO_FRAME_SIZE;
							multiple++;

							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
							queue->nUseFlag = ADDTOQUEUE;
							result = write(file_info->storage_pipe[1], &queue, sizeof(queue));
							goto local_trans_next;
						}
						else
						{
							comm_head->param_len = sizeof(VIDEO_FRAME) - VIDEO_FRAME_SIZE + temp_size;
							video->frame_size = temp_size;
							memcpy(video->buf, &data[VIDEO_FRAME_SIZE*multiple], temp_size);
							temp_size = 0;
						}

						queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;
						queue->nUseFlag = ADDTOQUEUE;
						write(file_info->storage_pipe[1], &queue, sizeof(queue));
					}
					else
					{
						dzlog_error("video QUEUE FULL......");
                        file_info->end_time = pts; //提前结束
					}
					
				}
			}
		}
#endif

#if 0
		stream_info = zx_get_stream(ch);
		/*if (reserve != TFCARD_RD_FLAG && stream_info)*/
		if ( stream_info)
		{
		
			memset(&stream_info->videoInfo,0,sizeof(VIDEO_INFO));
			stream_info->videoInfo.frame_rate   = frame_rate;
			stream_info->videoInfo.width	   	= u32Width;
			stream_info->videoInfo.height	    = u32Height;
			stream_info->videoInfo.frame_type   = frame_type;
			stream_info->videoInfo.ntimestamp   = zx_LocalTime_ms();

			if( len > VIDEO_FRAME_SIZE )
			{
				int sendCnt 			 = len/VIDEO_FRAME_SIZE;
				
				for(i = 0; i < sendCnt; i ++)
				{
					stream_info->videoInfo.frame_size = VIDEO_FRAME_SIZE;
					zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*i);
				}
				
				stream_info->videoInfo.frame_size 	 = len - VIDEO_FRAME_SIZE*sendCnt;
				
				zx_stream_send_video_frame(ch, data + VIDEO_FRAME_SIZE*sendCnt);
			}
			else
			{
				stream_info->videoInfo.frame_size 	 = len;
				zx_stream_send_video_frame(ch, data);
			}
			
		}
		
#endif
		
	}
	
	hisi_gcount++;
	if (hisi_gcount == 100)
		hisi_gcount = 0;	
#if 0	
	if (hisi_gcount == 0)
	{
		//dzlog_info("exit......");		
	}	
#endif
	return;
}

//音频回调            
//编码格式			   G711A
//buff                 音频BUFF    
//size                 音频数据长度
//ntimestamp           时间戳
//channel              通道号


/*int zx_audio_callback(char *buff, int size, long long ntimestamp, int channel, long reserve)*/
void zx_hisi_audio_callback_function(char *data, int len, unsigned int pts, void *user_data)
{
	QUEUE * queue = NULL;
	int i = 0;
	int session_handle = -1;
	int msg_id = -1;
	int result = -1;	
	LOCAL_FP_INFO* file_info = NULL;
	int channel = HISI_CH0;
	int lengnth = 0;

#if HISI_SAVE_AUDIO_DATA	

	g711a_decode((unsigned char*)data, &hisi_gdec_buf, len);

	g711a_encode(hisi_gdec_buf, (unsigned char*)&hisi_genc_buf, len*2);	
	
	if(hisi_fp_audio) 
	{
		fwrite(hisi_genc_buf, 1, len, hisi_fp_audio);	
	}
	
	if(hisi_fp_dec_audio) 
	{
		fwrite(hisi_gdec_buf, 1, len*2, hisi_fp_dec_audio);	
	}
#endif
#if 0
	if (hisi_gaudio_count == 0)
		dzlog_info("Audio: channel = %d, auto size = %d", channel, len);
#endif

	if(hisi_audio)
	{
		fwrite(data, 1, len, hisi_audio);
	}

	hisi_gaudio_count++;
	if (hisi_gaudio_count == 100)
		hisi_gaudio_count = 0;

	if(data)
	{
		//printf_hex((char *)buff, 3*COMM_HEARD_LEN);
		for (i = 0; i < MAX_CONNECT_NUM; i++)
		{
			session_handle = hisi_gxm_con_list[i].session_handle;
			
			if (session_handle >= 0 )
			{
				if (hisi_gxm_con_list[i].channel == channel /*|| reserve == TFCARD_RD_FLAG*/)
				{
					queue = (QUEUE *)hisi_gxm_con_list[i].audio_queue;
					
					if (queue)	
					{
						//dzlog_info("queue in %d......", len);
						
						if (query_queue(queue->pNextQueue, &queue, NOTUSE, MAXAUDIOQUEUE)) 
			            {
							
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;	
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag = PAG_HEARD_TAG;
							comm_head->command_id = APP_CMD_AUDIO_FRAME;
							comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
							comm_head->version = COMM_VERSION;
							comm_head->channel_id = channel;
							comm_head->sign_code = NO_SEC_KEY;
                            comm_head->dev_type = FLOODLIGHT;

							AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size = len;
							audio->channel = channel;
							audio->ntimestamp = pts;
							memcpy(audio->buf, data, len);
							
							queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
							queue->nUseFlag = ADDTOQUEUE;
							
							result = write(hisi_gxm_con_list[i].audio_pipe[1], &queue, sizeof(queue));
#if 0
							XMHAL_AudioPlay(data, len, channel);

							hal_audio_out(data,len);
#endif
							//dzlog_info("【audio_size=%d write=%d audio_pipe=%d......】", len, result, hisi_gxm_con_list[i].audio_pipe[1]);											
						}
						else
						{
							dzlog_error("QUEUE FULL......");
						///dzlog_info("queue out......");
						}
					}
				}				
			} 
		}

#if RUN_LOCAL_STORGE
		/*if (reserve != TFCARD_RD_FLAG)*/
		if (TFCARD_RD_FLAG)
		{
			//dzlog_info("local storge audio ...");
			file_info = get_local_filerecord_by_channel(channel);
			
			if (file_info != NULL && file_info->record_flag && file_info->frame_num) // 这个channel有PIR触发
			{
				dzlog_info("local storge audio ...");
				
			#if 0
				pts = zx_LocalTime_ms();
			#endif
			
				if (query_queue(hisi_audio_queue, &queue, NOTUSE, HISI_AUDIO_MAX_QUEUE))
				{
					ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)queue->pFrameBuf;
					memset(comm_head, 0, COMM_HEARD_LEN);
					if ( len > AUDIO_FRAME_SIZE)
					{
						len = AUDIO_FRAME_SIZE;
					}
					comm_head->head_tag = PAG_HEARD_TAG;
					comm_head->command_id = APP_CMD_AUDIO_FRAME;
					comm_head->param_len = sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
					comm_head->version = COMM_VERSION;
					comm_head->channel_id = channel;
					comm_head->sign_code = NO_SEC_KEY;
                    comm_head->dev_type = FLOODLIGHT;

					AUDIO_FRAME *audio = (AUDIO_FRAME *)&queue->pFrameBuf[COMM_HEARD_LEN];
					audio->frame_size = len;
					audio->channel = channel;
					audio->ntimestamp = pts;
					memcpy(audio->buf, data, len);
					queue->frame_size = COMM_HEARD_LEN + comm_head->param_len;	
					queue->nUseFlag = ADDTOQUEUE;

					write(file_info->storage_pipe[1], &queue, sizeof(queue));
				}
				else
				{
					dzlog_error("audio QUEUE FULL......");
					file_info->end_time = pts;
				}
			}
		}
#endif	


#if 0
		/*if (reserve != TFCARD_RD_FLAG)*/
		if (TFCARD_RD_FLAG)
		{
			//static int audioFrameCnt  = 0;
			STREAM_CONNECT_INFO *info = zx_get_stream(channel);
			
			if(info)
			{
				if(info->iControlThreadRun)
				{
					info->iAudioCallBackRunState = 1;
					QUEUE *aqueue = (QUEUE *)info->audio_queue;	
					
					if (aqueue)
					{
						if (query_queue(aqueue->pNextQueue, &aqueue, NOTUSE, MAXAUDIOQUEUE)){
							ZX_COMM_HEAD *comm_head = (ZX_COMM_HEAD *)aqueue->pFrameBuf; 
							memset(comm_head, 0, COMM_HEARD_LEN);
							comm_head->head_tag 	= PAG_HEARD_TAG;
							comm_head->command_id   = APP_CMD_AUDIO_FRAME;
							comm_head->param_len 	= sizeof(AUDIO_FRAME) - AUDIO_FRAME_SIZE + len;
							comm_head->version = COMM_VERSION;
							comm_head->channel_id 	= channel;
							comm_head->sign_code 	= NO_SEC_KEY;
                            comm_head->dev_type = FLOODLIGHT;

							AUDIO_FRAME *audio 		= (AUDIO_FRAME *)&aqueue->pFrameBuf[COMM_HEARD_LEN];
							audio->frame_size 		= len;
							audio->channel 			= channel;
							audio->ntimestamp 		= pts;	
							//audio->ntimestamp 		= audioFrameCnt*1000*1024/8000;
							audio->ntimestamp 		= zx_LocalTime_ms();
							
							//audioFrameCnt ++;
							memcpy(audio->buf, data, len);
							
							aqueue->frame_size 		= COMM_HEARD_LEN + comm_head->param_len; 
							aqueue->nUseFlag 		= ADDTOQUEUE;
							result 					= write(info->audio_pipe[1], &aqueue, sizeof(aqueue));
							//dzlog_info("audio_size=%d write=%d audio_pipe=%d......", len, result, hisi_gxm_con_list[i].audio_pipe[1]);											
						}
						else
							dzlog_error("QUEUE FULL......");
					}
				}	
				info->iAudioCallBackRunState = 0;
			}

		}
#endif
	}

	return;
}



int zx_hisi_init_camera_sdk(int print_type, void *list)
{
	int ret = -1;
	int i = 0;
	dzlog_info("enter......"); 

	if(!list)
	{
		dzlog_error("The function parameter is NULL");
		return -1;
	}
	 
	dzlog_info("ZYLIB VERSION: %s", hisi_cam_data->version); //获取SD库版本号

	hisi_gxm_con_list = (P2P_CONNECT_INFO *)list;
	
	memset(hisi_gCamera_info, 0, sizeof(HISI_CAMERA_INFO)*MAX_CAMERA_NUM);
	
#if 0
    hisi_snapshot_queue.nUseFlag = NOTUSE;
#endif

	for (i = 0; i < MAX_CAMERA_NUM; i++)
	{
		hisi_gCamera_info[i].channel = -1;
		hisi_gCamera_info[i].clientmark = 0;
	}

#if 1
    //所有camera的queue分配一次，不动动态释放,提供给本地存储使用的队列
    
    hisi_video_queue = create_queue(HISI_VIDEO_MAX_QUEUE, COMM_HEARD_LEN + sizeof(VIDEO_FRAME));
    hisi_audio_queue = create_queue(HISI_AUDIO_MAX_QUEUE, COMM_HEARD_LEN + sizeof(AUDIO_FRAME));
#endif

	if (pipe(hisi_gready_pipe) != 0)
		dzlog_error("create hisi_gready_pipe fail...");  

	if (pipe(hisi_gcommand_pipe) != 0)
		dzlog_error("create hisi_gcommand_pipe fail...");  
	
	if (pipe(hisi_gupdate_pipe) != 0)
		dzlog_error("create hisi_gupdate_pipe fail..."); 


	hal_video_register_stream_cb(zx_hisi_video_callback_function);			//注册音频回调
	hal_audio_register_cb(zx_hisi_audio_callback_function,NULL);			//注册视频回调

	dzlog_info("*【 end ......】*");
	return 0;

}

int zx_hisi_deinit_camera_sdk(void)
{
	dzlog_info("enter...");
	if (hisi_gready_pipe[0] >= 0)
	{
		close(hisi_gready_pipe[0]);
		close(hisi_gready_pipe[1]);
	}

	if (hisi_gcommand_pipe[0] >= 0)
	{
		close(hisi_gcommand_pipe[0]);
		close(hisi_gcommand_pipe[1]);
	}

	if (hisi_gupdate_pipe[0] >= 0)
	{
		close(hisi_gupdate_pipe[0]);
		close(hisi_gupdate_pipe[1]);
	}

    if (hisi_video_queue != NULL)
    {
        destroy_queue(hisi_video_queue);
        hisi_video_queue = NULL;
    }
    if (hisi_audio_queue != NULL)
    {
        destroy_queue(hisi_audio_queue);
        hisi_audio_queue = NULL;
    }
	
	dzlog_info("【deinit camera sdk end...】");

    return 0;
}


int get_hisi_camera_clientmark(short channel)
{
	int i = 0;

	for (i = 0; i <= MAX_CAMERA_NUM; i++)
	{
		if (hisi_gCamera_info[i].channel == channel)
		{
			return hisi_gCamera_info[i].clientmark;
		}
	}
	return 0;
}

int hisi_clear_camera_clientmark(short channel, short clientmark)
{
	int i;
	int ret = 0;
	for (i = 0;i < MAX_CAMERA_NUM; i++)
	{
		if (hisi_gCamera_info[i].channel == channel)
		{
			hisi_gCamera_info[i].clientmark &= ~clientmark;
			dzlog_info("clear_camera_clientmark channel = %d ,client =%d, clientmark =%d\n", channel, clientmark, hisi_gCamera_info[i].clientmark);
			if (hisi_gCamera_info[i].clientmark != 0)
			{
				ret = -1; // 不可以待机
			}
			break;
		}
	}

    for (i = 0; i < MAX_CAMERA_NUM; i++)
    {
        if (hisi_gCamera_info[i].clientmark & CLIENT_PIR == CLIENT_PIR)
        {
            break;
        }
    }
    if (i >= MAX_CAMERA_NUM)    // 如果 CLIENT_PIR都关闭了，重置
    {
        if (hisi_video_queue)
        {
            clear_queue(hisi_video_queue, HISI_VIDEO_MAX_QUEUE);
        }
        if (hisi_audio_queue)
        {
            clear_queue(hisi_audio_queue, HISI_AUDIO_MAX_QUEUE);
        }
    }

    return ret;
}


int zx_hisi_get_dev_version(int channel, char* sw_ver, char *hw_ver)
{
	if (sw_ver && hw_ver && channel >= 0)
	{
		fd_set rfds;
		struct timeval tv; 
		char ver[HISI_VERSION_NAME_LEN] = {0};
		usleep(1000*1000);
		int ret = hal_get_version(ver);
		dzlog_info("ZY Version ret[%d] ", ret);
		if (ret == 0)
		{
			FD_ZERO(&rfds);
			if (hisi_gcommand_pipe[0] >= 0)
				FD_SET(hisi_gcommand_pipe[0], &rfds);
			else
				return ERROR_NULL_POINT;   
			tv.tv_sec = 5;	
			tv.tv_usec = 0;
			switch(select(hisi_gcommand_pipe[0] + 1, &rfds, NULL, NULL, &tv))
			{
				case -1: 
				case 0:
					break; 
 
				default: 
				{
					HISI_CAMERA_VERSION ver_info;
					if(FD_ISSET(hisi_gcommand_pipe[0], &rfds)) 
					{
						FD_CLR(hisi_gcommand_pipe[0], &rfds);
						read(hisi_gcommand_pipe[0], &ver_info, sizeof(HISI_CAMERA_VERSION));
						dzlog_info("get sw_ver[%s] hw_ver[%s]", ver_info.dspsoftversion, ver_info.dsphardversion);
						memcpy(sw_ver, ver_info.dspsoftversion, strlen(ver_info.dspsoftversion));
						memcpy(hw_ver, ver_info.dsphardversion, strlen(ver_info.dsphardversion));
						return 0;
					}
					break;
				}
			}			
		}
	}
	return ERROR_NULL_POINT;
}






